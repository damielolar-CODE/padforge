// Unit tests for the DEESTECH announcement selection logic.
//
// Everything here is pure Dart: no widgets, no plugins, no network. That is
// the whole reason `announcement_feed.dart` was split out from the networky
// `announcement_center.dart` -- the rules that decide WHICH message a user
// sees (slug targeting, date window, dismissed-forever, Pro-upsell
// suppression) are provable without a device or a live feed.
//
// What these protect:
//  * slug targeting -- an entry for other apps is skipped; null / ["all"] /
//    [this slug] are shown;
//  * the inclusive yyyy-MM-dd date window on both ends;
//  * the dismissed-id filter;
//  * first-match-wins ordering;
//  * Pro-upsell suppression for Pro users;
//  * defensive parsing (one bad entry does not silence the feed).
import 'package:flutter_test/flutter_test.dart';
import 'package:padforge/services/announcement_feed.dart';

const slug = 'padforge';

Announcement ann(
  String id, {
  List<String>? apps,
  String? start,
  String? end,
  String? style,
  String? audience,
  String title = 'Title',
}) {
  return Announcement(
    id: id,
    title: title,
    body: 'Body',
    apps: apps,
    startDate: start,
    endDate: end,
    style: style,
    audience: audience,
  );
}

Announcement? pick(
  List<Announcement> all, {
  String today = '2026-10-30',
  Set<String> dismissed = const <String>{},
  bool isPro = false,
}) =>
    selectAnnouncement(all,
        today: today, dismissed: dismissed, appSlug: slug, isPro: isPro);

void main() {
  group('slug targeting', () {
    test('null apps targets everyone', () {
      expect(pick([ann('a', apps: null]))?.id, 'a');
    });

    test('["all"] targets everyone', () {
      expect(pick([ann('a', apps: ['all'])])?.id, 'a');
    });

    test('a list containing this slug is shown', () {
      expect(pick([ann('a', apps: ['roomstudio', 'padforge'])])?.id, 'a');
    });

    test('a list without this slug is skipped', () {
      expect(pick([ann('a', apps: ['deestape'])]), isNull);
    });

    test('an empty apps list targets nobody', () {
      expect(pick([ann('a', apps: [])]), isNull);
    });
  });

  group('date window (inclusive, yyyy-MM-dd)', () {
    test('before startDate is hidden', () {
      expect(pick([ann('a', start: '2026-11-01')], today: '2026-10-30'), isNull);
    });

    test('on startDate is shown', () {
      expect(pick([ann('a', start: '2026-10-30')], today: '2026-10-30')?.id, 'a');
    });

    test('after endDate is hidden', () {
      expect(pick([ann('a', end: '2026-10-29')], today: '2026-10-30'), isNull);
    });

    test('on endDate is shown', () {
      expect(pick([ann('a', end: '2026-10-30')], today: '2026-10-30')?.id, 'a');
    });

    test('inside a two-sided window is shown', () {
      expect(
        pick([ann('a', start: '2026-10-01', end: '2026-12-31')],
            today: '2026-10-30')?.id,
        'a',
      );
    });

    test('missing bounds are always in-window', () {
      expect(pick([ann('a')], today: '1999-01-01')?.id, 'a');
    });
  });

  group('dismissed filter', () {
    test('a dismissed id is skipped', () {
      expect(pick([ann('a')], dismissed: {'a'}), isNull);
    });

    test('dismissing one reveals the next eligible entry', () {
      final feed = [ann('a'), ann('b')];
      expect(pick(feed)?.id, 'a');
      expect(pick(feed, dismissed: {'a'})?.id, 'b');
    });
  });

  group('ordering', () {
    test('first eligible entry wins', () {
      final feed = [
        ann('skip', apps: ['deestape']),
        ann('want'),
        ann('also'),
      ];
      expect(pick(feed)?.id, 'want');
    });

    test('empty feed yields null', () {
      expect(pick(const []), isNull);
    });
  });

  group('Pro-upsell suppression', () {
    test('audience "free" is hidden from Pro users', () {
      final a = ann('a', audience: 'free');
      expect(isProUpsell(a), isTrue);
      expect(pick([a], isPro: true), isNull);
      expect(pick([a], isPro: false)?.id, 'a');
    });

    test('a promo mentioning Pro is treated as an upsell', () {
      final a = ann('unlock-pro', style: 'promo', title: 'Get PadForge Pro');
      expect(isProUpsell(a), isTrue);
      expect(pick([a], isPro: true), isNull);
    });

    test('a plain info entry is never an upsell', () {
      final a = ann('a', style: 'info', title: 'Got an idea?');
      expect(isProUpsell(a), isFalse);
      expect(pick([a], isPro: true)?.id, 'a');
    });
  });

  group('defensive parsing', () {
    test('a well-formed feed parses in order', () {
      const raw = '''
      {"version":1,"announcements":[
        {"id":"a","title":"One","body":"b","apps":["padforge"]},
        {"id":"b","title":"Two","body":"b"}
      ]}''';
      final items = parseAnnouncementFeed(raw);
      expect(items.map((e) => e.id).toList(), ['a', 'b']);
      expect(items.first.apps, ['padforge']);
    });

    test('one malformed entry is dropped, the rest survive', () {
      const raw = '''
      {"announcements":[
        {"title":"no id","body":"b"},
        {"id":"ok","title":"Good","body":"b"}
      ]}''';
      final items = parseAnnouncementFeed(raw);
      expect(items.map((e) => e.id).toList(), ['ok']);
    });

    test('a feed with no announcements array throws', () {
      expect(() => parseAnnouncementFeed('{"version":1}'),
          throwsA(isA<FormatException>()));
    });

    test('non-JSON throws', () {
      expect(() => parseAnnouncementFeed('not json'), throwsA(anything));
    });
  });

  group('todayString', () {
    test('zero-pads month and day', () {
      expect(todayString(DateTime(2026, 1, 5)), '2026-01-05');
    });

    test('full width month and day', () {
      expect(todayString(DateTime(2026, 12, 30)), '2026-12-30');
    });
  });
}

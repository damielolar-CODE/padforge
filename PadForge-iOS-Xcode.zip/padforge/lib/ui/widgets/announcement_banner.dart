/// The DEESTECH announcement banner -- a slim, dismissible strip that sits at
/// the very top of the instrument, below the status bar and above the tape
/// deck. It never overlaps the pads or the LED display: it lives in the home
/// screen's vertical Column, so when it is present every piece below it simply
/// gets sized from the height that remains (see HomeScreen's layout budget).
///
/// Because it is a flow child of the Column and NOT a Stack overlay, it can
/// never intercept a pad's pointer-down -- the pads are entirely below it.
///
/// It draws nothing at all when there is no current announcement (a
/// `SizedBox.shrink`), so it costs effectively nothing when idle, and it kicks
/// off the one feed fetch for the session from its [initState].
library;

import 'dart:async';

import 'package:flutter/material.dart';

import '../../services/announcement_center.dart';
import '../../services/announcement_feed.dart';
import '../theme/app_theme.dart';

class AnnouncementBanner extends StatefulWidget {
  const AnnouncementBanner({super.key});

  @override
  State<AnnouncementBanner> createState() => _AnnouncementBannerState();
}

class _AnnouncementBannerState extends State<AnnouncementBanner> {
  @override
  void initState() {
    super.initState();
    // Fire-and-forget: the center never throws and never blocks launch.
    unawaited(AnnouncementCenter.instance.refresh());
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AnnouncementCenter.instance,
      builder: (context, _) {
        final a = AnnouncementCenter.instance.current;
        if (a == null) return const SizedBox.shrink();
        return _Banner(announcement: a);
      },
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner({required this.announcement});

  final Announcement announcement;

  @override
  Widget build(BuildContext context) {
    final a = announcement;
    final showCta = AnnouncementCenter.canOpen(a);

    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 4),
      child: DecoratedBox(
        decoration: BoxDecoration(
          // Panel-on-chassis is the app's own card convention, so the banner
          // reads as part of the instrument rather than a web pop-up.
          color: AppColors.panel,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.amber.withValues(alpha: 0.35)),
          boxShadow: const [
            BoxShadow(color: Color(0x59000000), blurRadius: 10, offset: Offset(0, 4)),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(13, 11, 6, 11),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Amber status dot, aligned with the title's cap height.
              Container(
                margin: const EdgeInsets.only(top: 4, right: 11),
                width: 9,
                height: 9,
                decoration: const BoxDecoration(
                  color: AppColors.amber,
                  shape: BoxShape.circle,
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      a.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppColors.lcdText,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        height: 1.2,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      a.body,
                      maxLines: 4,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: AppColors.lcdText.withValues(alpha: 0.82),
                        fontSize: 12.5,
                        height: 1.3,
                      ),
                    ),
                    if (showCta) ...[
                      const SizedBox(height: 9),
                      _CtaButton(announcement: a),
                    ],
                  ],
                ),
              ),
              // Dismiss. 44x44 min tap target around a small glyph.
              Semantics(
                button: true,
                label: 'Dismiss announcement',
                child: InkResponse(
                  onTap: () => AnnouncementCenter.instance.dismiss(a),
                  radius: 22,
                  child: const Padding(
                    padding: EdgeInsets.all(8),
                    child: Icon(Icons.close, size: 16, color: AppColors.lcdTextDim),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CtaButton extends StatelessWidget {
  const _CtaButton({required this.announcement});

  final Announcement announcement;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.amber,
      borderRadius: BorderRadius.circular(40),
      child: InkWell(
        borderRadius: BorderRadius.circular(40),
        onTap: () => AnnouncementCenter.instance.openCta(announcement),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          child: Text(
            (announcement.cta ?? '').toUpperCase(),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AppColors.chassis,
              fontSize: 11,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.6,
            ),
          ),
        ),
      ),
    );
  }
}

#include "soloud_common.h"
#include "player.h"
#include "audiobuffer/circular_float_buffer.h"
#include "audiobuffer/pull_buffer_stream.h"
#include "filters/filters.h"
#include "soloud.h"
#include "soloud/include/soloud.h"
#include "soloud_wav.h"
// #include "soloud_thread.h"
#include "soloud_wavstream.h"
#include "synth/basic_wave.h"

#include <algorithm>
#include <chrono>
#include <cstdarg>
#include <cstring>
#include <fstream>
#include <random>
#include <thread>

#ifdef _IS_WIN_
#include <stddef.h> // for size_t
#else
#include <unistd.h>
#endif

#ifdef __EMSCRIPTEN__
#define __WEB__ 1
#else
#define __WEB__ 0
#endif

namespace
{
    constexpr unsigned int kOggXiphBufferStreamMaxBytes = 512u * 1024u * 1024u;

    bool readFileBytes(const std::string &filePath,
                       std::vector<unsigned char> &bytes)
    {
        std::ifstream file(filePath, std::ios::binary | std::ios::ate);
        if (!file.good())
        {
            return false;
        }

        const std::streamoff fileSize = file.tellg();
        if (fileSize <= 0)
        {
            return false;
        }

        bytes.resize(static_cast<size_t>(fileSize));
        file.seekg(0, std::ios::beg);
        file.read(reinterpret_cast<char *>(bytes.data()), fileSize);
        return file.gcount() == fileSize;
    }

    bool isOggXiphBytes(const std::vector<unsigned char> &bytes)
    {
        if (bytes.size() < 35 || std::memcmp(bytes.data(), "OggS", 4) != 0)
        {
            return false;
        }

        size_t scanOffset = 0;
        const size_t scanLimit = std::min(bytes.size(), static_cast<size_t>(64 * 1024));
        while (scanOffset + 27 < scanLimit)
        {
            if (std::memcmp(bytes.data() + scanOffset, "OggS", 4) != 0)
            {
                ++scanOffset;
                continue;
            }

            const uint8_t segmentCount = bytes[scanOffset + 26];
            const size_t segmentTableOffset = scanOffset + 27;
            if (segmentTableOffset + segmentCount > scanLimit)
            {
                return false;
            }

            size_t payloadSize = 0;
            for (uint8_t i = 0; i < segmentCount; ++i)
            {
                payloadSize += bytes[segmentTableOffset + i];
            }

            const size_t payloadOffset = segmentTableOffset + segmentCount;
            if (payloadOffset + payloadSize > bytes.size())
            {
                return false;
            }

            if (payloadSize >= 8 &&
                std::memcmp(bytes.data() + payloadOffset, "OpusHead", 8) == 0)
            {
                return true;
            }

            if (payloadSize >= 13 &&
                std::memcmp(bytes.data() + payloadOffset + 1, "FLAC", 4) == 0 &&
                std::memcmp(bytes.data() + payloadOffset + 9, "fLaC", 4) == 0)
            {
                return true;
            }

            scanOffset = payloadOffset + payloadSize;
        }

        return false;
    }

    PlayerErrors loadOggXiphBufferStream(Player *player,
                                         ActiveSound *activeSound,
                                         const std::vector<unsigned char> &bytes)
    {
        if (player == nullptr || activeSound == nullptr || bytes.empty())
        {
            return invalidParameter;
        }

        activeSound->sound = std::make_unique<SoLoud::BufferStream>();
        activeSound->soundType = TYPE_BUFFER_STREAM;
        PCMformat pcmFormat = {player->mSampleRate, player->mChannels, 4, AUTO};
        auto *bufferStream =
            static_cast<SoLoud::BufferStream *>(activeSound->sound.get());
        PlayerErrors error = bufferStream->setBufferStream(
            player,
            activeSound,
            kOggXiphBufferStreamMaxBytes,
            BufferingType::PRESERVED,
            0.0f,
            pcmFormat);
        if (error != noError)
        {
            return error;
        }

        error = bufferStream->addData(bytes.data(),
                                      static_cast<unsigned int>(bytes.size()));
        if (error != noError)
        {
            return error;
        }

        bufferStream->setDataIsEnded();
        return noError;
    }
}

/// Translate a `SoLoud::SOLOUD_ERRORS` value into a `PlayerErrors` one.
///
/// The two enums are NOT interchangeable: they agree up to
/// `FILE_LOAD_FAILED` (3) and then diverge, because `PlayerErrors` inserts
/// `fileAlreadyLoaded` at 4. Casting one to the other silently turns, for
/// example, SoLoud's `NOT_IMPLEMENTED` (6) into `outOfMemory` (6).
static PlayerErrors fromSoLoudError(SoLoud::result result)
{
    switch (result)
    {
    case SoLoud::SO_NO_ERROR:
        return noError;
    case SoLoud::INVALID_PARAMETER:
        return invalidParameter;
    case SoLoud::FILE_NOT_FOUND:
        return fileNotFound;
    case SoLoud::FILE_LOAD_FAILED:
        return fileLoadFailed;
    case SoLoud::DLL_NOT_FOUND:
        return dllNotFound;
    case SoLoud::OUT_OF_MEMORY:
        return outOfMemory;
    case SoLoud::NOT_IMPLEMENTED:
        return notImplemented;
    default:
        return unknownError;
    }
}

Player::Player() : mInited(false), mFilters(&soloud, nullptr, nullptr),
                   mPauseRequested(false), mStopPauseThread(false),
                   mPauseThreadRunning(false)
{
}

Player::~Player()
{
    // If the scheduler was started, stop it before touching Soloud.
    stopPauseEngineScheduler();

    if (!mInited)
    {
        // dispose() was called properly — Soloud is already deinited and safe.
        // Let ~Soloud() run normally to free its remaining allocations.
        return;
    }

    // Neutralize the Soloud member so ~Soloud() and its deinit() call become
    // harmless no-ops. The OS will reclaim all resources on process exit.
    //
    // We intentionally leak here — this only runs during abnormal exit
    // (app closed without calling dispose()), and the process is terminating.
    soloud.mBackendCleanupFunc = nullptr;
    soloud.mAudioThreadMutex = nullptr;
    soloud.mHighestVoice = 0;
    soloud.mVoiceGroup = nullptr;
    soloud.mVoiceGroupCount = 0;
    soloud.mResampleData = nullptr;
    soloud.mResampleDataOwner = nullptr;
    for (int i = 0; i < FILTERS_PER_STREAM; i++)
    {
        soloud.mFilterInstance[i] = nullptr;
    }
}

void Player::dispose()
{
    if (!mInited)
        return;

    // Stop accepting new pause requests and wake the scheduler so it exits.
    stopPauseEngineScheduler();

    mInited = false;

    // Clean up SoLoud
    setVoiceEndedCallback(nullptr);
    setStateChangedCallback(nullptr);
    {
        std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
        sounds.clear();
    }
    soloud.deinit();
}

void Player::setVoiceEndedCallback(void (*voiceEndedCallback)(unsigned int *))
{
    soloud.setVoiceEndedCallback(voiceEndedCallback);
}

void Player::setStateChangedCallback(void (*stateChangedCallback)(unsigned int))
{
    soloud.setStateChangedCallback(stateChangedCallback);
}

// Defined in the miniaudio backend (soloud_miniaudio.cpp). Forward-declared
// here so we don't need to pull in the backend-internal header.
namespace SoLoud { void miniaudio_setLowLatency(bool aLowLatency); }

PlayerErrors Player::init(unsigned int sampleRate, unsigned int bufferSize, unsigned int channels, int deviceID, bool lowLatency)
{
    if (mInited)
        return playerAlreadyInited;

    // Choose the device performance profile before SoLoud opens the backend.
    SoLoud::miniaudio_setLowLatency(lowLatency);

    // Anything below -1 is never a valid device selector.
    if (deviceID < -1)
        return invalidParameter;

    // -1 leaves this null, which asks miniaudio for the OS default device.
    void *playbackInfos_id = nullptr;
    // Must outlive `soloud.init()`: `playbackInfos_id` points into it.
    std::vector<PlaybackDevice> devices;
    if (deviceID >= 0)
    {
        // Get the device list and find the requested device
        devices = listPlaybackDevices();
        size_t const index = (size_t)deviceID;
        if (index >= devices.size())
            return noPlaybackDevicesFound;
        // Use the stored device ID from the PlaybackDevice struct
        playbackInfos_id = (void *)&devices[index].deviceId;
    }

    // initialize SoLoud.
    SoLoud::result result;
    result = soloud.init(0, SoLoud::Soloud::MINIAUDIO, sampleRate, bufferSize, channels, playbackInfos_id);
    if (result != SoLoud::SO_NO_ERROR)
    {
        return backendNotInited;
    }
    else
    {
        soloud.setPostClipScaler(1.0f);
        mInited = true;
        mSampleRate = sampleRate;
        mBufferSize = bufferSize;
        mChannels = channels;
        // Start the deferred-pause scheduler now that the engine is in use.
        startPauseEngineScheduler();
    }
    // `result` is `SO_NO_ERROR` here (anything else returned above), but map it
    // rather than cast: the two error enums are not interchangeable.
    return fromSoLoudError(result);
}

PlayerErrors Player::changeDevice(int deviceID)
{
    if (!mInited)
        return backendNotInited;

    // Anything below -1 is never a valid device selector.
    if (deviceID < -1)
        return invalidParameter;

    // `nullptr` asks miniaudio for the current OS default output device. The
    // default device doesn't depend on a successful enumeration, so only
    // explicit IDs need the device list (same as `init()` does).
    void *playbackInfos_id = nullptr;
    // Must outlive `miniaudio_changeDevice()`: `playbackInfos_id` points into it.
    std::vector<PlaybackDevice> devices;
    if (deviceID >= 0)
    {
        // Get the device list and find the requested device
        devices = listPlaybackDevices();
        size_t const index = (size_t)deviceID;
        if (index >= devices.size())
            return noPlaybackDevicesFound;
        // Use the stored device ID from the PlaybackDevice struct
        playbackInfos_id = (void *)&devices[index].deviceId;
    }

    SoLoud::result const result = soloud.miniaudio_changeDevice(playbackInfos_id);

    // `NOT_IMPLEMENTED` means the engine was built without the miniaudio
    // backend, so there is no device to swap at all.
    if (result == SoLoud::NOT_IMPLEMENTED)
        return notImplemented;

    // Anything else non-zero is `UNKNOWN_ERROR`: the replacement device could
    // not be initialized or started. The engine itself may well still be
    // initialized, hence not `backendNotInited`.
    if (result != SoLoud::SO_NO_ERROR)
        return audioDeviceFailedToStart;

    return noError;
}

// List available playback devices.
std::vector<PlaybackDevice> Player::listPlaybackDevices()
{
    // printf("***************** LIST DEVICES START\n");
    ma_context context;
    ma_uint32 playbackCount;
    // Both info arrays belong to `context` and are freed by `ma_context_uninit`
    // below, so they must stay local: keeping them alive past this function
    // (as a member) would only leave a dangling pointer behind.
    ma_device_info *pPlaybackInfos;
    ma_device_info *pCaptureInfos;
    ma_uint32 captureCount;
    std::vector<PlaybackDevice> ret;
    ma_result result;
    if ((result = ma_context_init(NULL, 0, NULL, &context)) != MA_SUCCESS)
    {
        // Failed to initialize audio context.
        return ret;
    }

    if ((result = ma_context_get_devices(
             &context,
             &pPlaybackInfos,
             &playbackCount,
             &pCaptureInfos,
             &captureCount)) != MA_SUCCESS)
    {
        printf("Failed to get devices %d\n", result);
        ma_context_uninit(&context);
        return ret;
    }

    // Loop over each device info and do something with it. Here we just print
    // the name with their index. You may want
    // to give the user the opportunity to choose which device they'd prefer.
    for (ma_uint32 i = 0; i < playbackCount; i++)
    {
        // printf("######%s %d - %s\n",
        //        pPlaybackInfos[i].isDefault ? " X" : "-",
        //        i,
        //        pPlaybackInfos[i].name);
        PlaybackDevice cd;
        // `std::string` takes a copy: the source dies with the context, and a
        // `strdup()` here would leak since nothing ever freed these names.
        cd.name = pPlaybackInfos[i].name;
        cd.isDefault = pPlaybackInfos[i].isDefault;
        cd.id = i;
        cd.deviceId = pPlaybackInfos[i].id; // Copy the device ID
        ret.push_back(cd);
    }
    // printf("***************** LIST DEVICES END\n");
    ma_context_uninit(&context);
    return ret;
}

bool Player::isInited()
{
    return mInited;
}

int Player::getSoundsCount()
{
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    return (int)sounds.size();
}

const std::string Player::getErrorString(PlayerErrors errorCode) const
{
    switch (errorCode)
    {
    case noError:
        return "No error";
    case invalidParameter:
        return "error: some parameter is invalid!";
    case fileNotFound:
        return "error: file not found!";
    case fileLoadFailed:
        return "error: file found, but could not be loaded!";
    case fileAlreadyLoaded:
        return "error: file already loaded!";
    case dllNotFound:
        return "error: DLL not found, or wrong DLL!";
    case outOfMemory:
        return "error: out of memory!";
    case notImplemented:
        return "error: feature not implemented!";
    case backendNotInited:
        return "error: player not yet initialized!";
    case filterNotFound:
        return "error: filter not found!";
    case unknownError:
        return "error: unknown error!";
    case nullPointer:
        return "error: nullPointer!";
    case soundHashNotFound:
        return "error: sound hash not found!";
    case visualizationNotEnabled:
        return "error: visualization not enabled!";
    case maxNumberOfFiltersReached:
        return "error: max number of filter reached!";
    case filterAlreadyAdded:
        return "error: filter already added!";
    case playerAlreadyInited:
        return "error: the player is already initialized!";
    case soundHandleNotFound:
        return "error: audio handle is not found!";
    case filterParameterGetError:
        return "error: getting filter parameter error!";
    case noPlaybackDevicesFound:
        return "error: no playback devices found!";
    case pcmBufferFull:
        return "error: pcm buffer full!";
    case hashIsNotABufferStream:
        return "error: hash is not a buffer stream!";
    case streamEndedAlready:
        return "error: trying to add PCM data but the stream is marked to be ended!";
    case failedToCreateOpusDecoder:
        return "error: failed to create Opus decoder!";
    case failedToDecodeOpusPacket:
        return "error: failed to decode Opus packet!";
    case bufferStreamCanBePlayedOnlyOnce:
        return "error: buffer stream can be played only once!";
    case maxActiveVoiceCountReached:
        return "error: the maximum number of active voices has been reached!";
    case wrongBufferTypeToAskForTimeConsumed:
        return "error: trying to get time consumed from wrong buffer type!";
    case bufferStreamWithReleasedBufferTypeCannotBeSeeked:
        return "error: buffer stream with released buffer type cannot be seeked!";
    case audioFormatNotSupported:
        return "error: audio format not supported!";
    case xiphLibsNotFound:
        return "error: Xiph libraries not found!";
    case busIdNotFound:
        return "error: bus id not found!";
    case hashIsNotAPullBufferStream:
        return "error: hash is not a pull buffer stream!";
    case invalidPullBufferState:
        return "error: pull buffer stream is in an invalid state!";
    case audioDeviceFailedToStart:
        return "error: the output audio device could not be started!";
    case failedToStartPlayback:
        return "error: failed to start the playback, no valid voice handle!";
    }
    return "Other error";
}

PlayerErrors Player::loadFile(
    const std::string &completeFileName,
    bool loadIntoMem,
    unsigned int *hash)
{
    if (!mInited)
        return backendNotInited;

    *hash = 0;

    unsigned int newHash = (int32_t)std::hash<std::string>{}(completeFileName) & 0x7fffffff;
    /// check if the sound has already been loaded
    auto const s = findByHash(newHash);

    // If the hash already exists, create a new unique random hash.
    // This allows loading the same file multiple times with unique identifiers.
    if (s != nullptr)
    {
        std::random_device rd;
        std::mt19937 g(rd());
        std::uniform_int_distribution<unsigned int> dist(0, 0x7fffffff);
        do
        {
            newHash = dist(g);
        } while (findByHash(newHash) != nullptr);
    }

    std::unique_ptr<ActiveSound> newSound = std::make_unique<ActiveSound>();
    newSound.get()->completeFileName = std::string(completeFileName);
    *hash = newHash;
    newSound.get()->soundHash = newHash;

    SoLoud::result result;
    // This function is never called when running on the Web, but [__WEB__] is checked for consistency with [loadMem].
    if (loadIntoMem || __WEB__)
    {
        newSound.get()->sound = std::make_unique<SoLoud::Wav>();
        newSound.get()->soundType = TYPE_WAV;
        result = static_cast<SoLoud::Wav *>(newSound.get()->sound.get())->load(completeFileName.c_str());
    }
    else
    {
        newSound.get()->sound = std::make_unique<SoLoud::WavStream>();
        newSound.get()->soundType = TYPE_WAVSTREAM;
        result = static_cast<SoLoud::WavStream *>(newSound.get()->sound.get())->load(completeFileName.c_str());
    }

    PlayerErrors loadError = fromSoLoudError(result);
    if (result != SoLoud::SO_NO_ERROR)
    {
        std::vector<unsigned char> bytes;
        if (readFileBytes(completeFileName, bytes) && isOggXiphBytes(bytes))
        {
            loadError = loadOggXiphBufferStream(this, newSound.get(), bytes);
        }
    }

    if (loadError != noError)
    {
        *hash = 0;
    }
    else
    {
        *hash = newHash;
        newSound.get()->filters = std::make_unique<Filters>(&soloud, newSound.get(), nullptr);
        {
            std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
            sounds.push_back(std::move(newSound));
        }
    }

    // Return fileAlreadyLoaded if the filename hash was already in use,
    // even though we've now loaded a new instance with a unique hash.
    if (s != nullptr && loadError == noError)
    {
        return fileAlreadyLoaded;
    }

    return loadError;
}

PlayerErrors Player::loadMem(
    const std::string &uniqueName,
    unsigned char *mem,
    int length,
    bool loadIntoMem,
    unsigned int &hash)
{
    if (!mInited)
        return backendNotInited;

    hash = 0;

    unsigned int newHash = (int32_t)std::hash<std::string>{}(uniqueName) & 0x7fffffff;
    /// check if the sound has already been loaded
    auto const s = findByHash(newHash);

    // If already loaded, generate a unique hash
    if (s != nullptr)
    {
        std::random_device rd;
        std::mt19937 g(rd());
        std::uniform_int_distribution<unsigned int> dist(0, 0x7fffffff);
        do
        {
            newHash = dist(g);
        } while (findByHash(newHash) != nullptr);
    }

    auto newSound = std::make_unique<ActiveSound>();
    newSound.get()->completeFileName = std::string(uniqueName);
    hash = newHash;
    newSound.get()->soundHash = newHash;
    SoLoud::result result;
    if (loadIntoMem || __WEB__)
    {
        newSound.get()->sound = std::make_unique<SoLoud::Wav>();
        newSound.get()->soundType = TYPE_WAV;
        result = static_cast<SoLoud::Wav *>(newSound.get()->sound.get())->loadMem(mem, length, true, true);
    }
    else
    {
        newSound.get()->sound = std::make_unique<SoLoud::WavStream>();
        newSound.get()->soundType = TYPE_WAVSTREAM;
        result = static_cast<SoLoud::WavStream *>(newSound.get()->sound.get())->loadMem(mem, length, false, true);
    }

    PlayerErrors loadError = fromSoLoudError(result);
    if (result != SoLoud::SO_NO_ERROR && mem != nullptr && length > 0)
    {
        std::vector<unsigned char> bytes(mem, mem + length);
        if (isOggXiphBytes(bytes))
        {
            loadError = loadOggXiphBufferStream(this, newSound.get(), bytes);
        }
    }

    if (loadError == noError)
    {
        newSound.get()->filters = std::make_unique<Filters>(&soloud, newSound.get(), nullptr);
        {
            std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
            sounds.push_back(std::move(newSound));
        }
    }

    // Return fileAlreadyLoaded if the unique name hash was already in use,
    // even though we've now loaded a new instance with a unique hash.
    if (s != nullptr && loadError == noError)
    {
        return fileAlreadyLoaded;
    }

    return loadError;
}

PlayerErrors Player::setBufferStream(
    unsigned int &hash,
    unsigned long maxBufferSize,
    BufferingType bufferingType,
    SoLoud::time bufferingTimeNeeds,
    PCMformat pcmFormat,
    dartOnBufferingCallback_t onBufferingCallback,
    dartOnMetadataCallback_t onMetadataCallback)
{
    if (!mInited)
        return backendNotInited;

    std::random_device rd;
    std::mt19937 g(rd());
    std::uniform_int_distribution<unsigned int> dist(0, INT32_MAX);

    hash = dist(g);

    auto newSound = std::make_unique<ActiveSound>();
    newSound.get()->completeFileName = "";
    newSound.get()->soundHash = hash;

    newSound.get()->sound = std::make_unique<SoLoud::BufferStream>();

    newSound.get()->soundType = SoundType::TYPE_BUFFER_STREAM;
    PlayerErrors e = static_cast<SoLoud::BufferStream *>(newSound.get()->sound.get())->setBufferStream(this, newSound.get(), static_cast<unsigned int>(maxBufferSize), bufferingType, bufferingTimeNeeds, pcmFormat, onBufferingCallback, onMetadataCallback);

    newSound.get()->filters = std::make_unique<Filters>(&soloud, newSound.get(), nullptr);
    {
        std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
        sounds.push_back(std::move(newSound));
    }

    return e;
}

PlayerErrors Player::setPullBufferStream(
    unsigned int &hash,
    unsigned int bufferSizeBytes,
    double bufferTriggerPosition,
    unsigned int sampleRate,
    unsigned int channels,
    BufferType format,
    uint64_t audioSizeBytes,
    dartOnBufferingCallback_t onBufferingCallback,
    dartOnMetadataCallback_t onMetadataCallback,
    dartOnMoreDataIsNeededCallback_t onMoreDataIsNeededCallback,
    dartOnAudioDurationCallback_t onAudioDurationCallback)
{
    if (!mInited)
        return backendNotInited;

    std::random_device rd;
    std::mt19937 g(rd());
    std::uniform_int_distribution<unsigned int> dist(0, INT32_MAX);

    hash = dist(g);

    auto newSound = std::make_unique<ActiveSound>();
    newSound.get()->completeFileName = "";
    newSound.get()->soundHash = hash;

    newSound.get()->sound = std::make_unique<SoLoud::PullBufferStream>();
    newSound.get()->soundType = SoundType::TYPE_PULL_BUFFER_STREAM;

    auto *pullStream = static_cast<SoLoud::PullBufferStream *>(newSound.get()->sound.get());
    PlayerErrors e = pullStream->setPullBufferStream(
        this, newSound.get(), bufferSizeBytes, bufferTriggerPosition,
        sampleRate, channels, format, audioSizeBytes,
        onBufferingCallback, onMetadataCallback, onMoreDataIsNeededCallback,
        onAudioDurationCallback);

    newSound.get()->filters = std::make_unique<Filters>(&soloud, newSound.get(), nullptr);
    {
        std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
        sounds.push_back(std::move(newSound));
    }

    return e;
}

PlayerErrors Player::resetPullBufferStream(unsigned int hash)
{
    auto const s = findByHash(hash);

    if (s == nullptr || s->soundType != SoundType::TYPE_PULL_BUFFER_STREAM)
        return PlayerErrors::soundHashNotFound;

    static_cast<SoLoud::PullBufferStream *>(s->sound.get())->resetPullBufferStream();
    return PlayerErrors::noError;
}

PlayerErrors Player::addPullBufferDataStream(
    unsigned int hash,
    const unsigned char *data,
    unsigned int aDataLen,
    uint64_t offset)
{
    auto const s = findByHash(hash);

    if (s == nullptr)
        return PlayerErrors::soundHashNotFound;

    if (s->soundType != SoundType::TYPE_PULL_BUFFER_STREAM)
        return PlayerErrors::hashIsNotAPullBufferStream;

    return static_cast<SoLoud::PullBufferStream *>(s->sound.get())
        ->addAudioData(data, aDataLen, offset);
}

PlayerErrors Player::getPullBufferTimeRange(
    unsigned int hash,
    double *startTime,
    double *endTime)
{
    auto const s = findByHash(hash);

    if (s == nullptr)
        return PlayerErrors::soundHashNotFound;

    if (s->soundType != SoundType::TYPE_PULL_BUFFER_STREAM)
        return PlayerErrors::hashIsNotAPullBufferStream;

    auto *pullStream = static_cast<SoLoud::PullBufferStream *>(s->sound.get());
    double start = 0.0;
    double end = 0.0;
    pullStream->getBufferTimeRange(start, end);
    if (startTime != nullptr) *startTime = start;
    if (endTime != nullptr) *endTime = end;
    return PlayerErrors::noError;
}

PlayerErrors Player::addAudioDataStream(
    unsigned int hash,
    const unsigned char *data,
    unsigned int aDataLen)
{
    // Hold sounds_mutex for the whole call: disposeSound()/disposeAllSound()
    // destroy the ActiveSound (and its Buffer's mutex) only after acquiring
    // it, so this guarantees the BufferStream outlives the addData() call.
    // Otherwise a feeder thread can lock a destroyed std::mutex, which
    // aborts on Android (HandleUsingDestroyedMutex).
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    auto const s = findByHash(hash);

    if (s == nullptr)
        return PlayerErrors::soundHashNotFound;

    if (s->soundType != SoundType::TYPE_BUFFER_STREAM)
        return hashIsNotABufferStream;

    return static_cast<SoLoud::BufferStream *>(s->sound.get())->addData(data, aDataLen, false);
}

PlayerErrors Player::resetBufferStream(unsigned int hash)
{
    // See addAudioDataStream() for why the lock must span the whole call.
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    auto const s = findByHash(hash);

    if (s == nullptr || s->soundType != SoundType::TYPE_BUFFER_STREAM)
    {
        return PlayerErrors::soundHashNotFound;
    }

    static_cast<SoLoud::BufferStream *>(s->sound.get())->resetBuffer();
    return PlayerErrors::noError;
}

PlayerErrors Player::setBufferIcyMetaInt(unsigned int hash, int icyMetaInt)
{
    // See addAudioDataStream() for why the lock must span the whole call.
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    auto const s = findByHash(hash);

    if (s == nullptr || s->soundType != SoundType::TYPE_BUFFER_STREAM)
    {
        return PlayerErrors::soundHashNotFound;
    }

    static_cast<SoLoud::BufferStream *>(s->sound.get())->setBufferIcyMetaInt(icyMetaInt);
    return PlayerErrors::noError;
}

PlayerErrors Player::getStreamTimeConsumed(unsigned int hash, float *timeConsumed)
{
    // See addAudioDataStream() for why the lock must span the whole call.
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    auto const s = findByHash(hash);

    if (s == nullptr || s->soundType != SoundType::TYPE_BUFFER_STREAM)
        return PlayerErrors::soundHashNotFound;

    if (static_cast<SoLoud::BufferStream *>(s->sound.get())->getBufferingType() != BufferingType::RELEASED)
        return PlayerErrors::wrongBufferTypeToAskForTimeConsumed;

    *timeConsumed = static_cast<SoLoud::BufferStream *>(s->sound.get())->getStreamTimeConsumed();
    return PlayerErrors::noError;
}

PlayerErrors Player::setDataIsEnded(unsigned int hash)
{
    // See addAudioDataStream() for why the lock must span the whole call.
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    auto const s = findByHash(hash);

    if (s == nullptr || s->soundType != SoundType::TYPE_BUFFER_STREAM)
        return PlayerErrors::soundHashNotFound;

    static_cast<SoLoud::BufferStream *>(s->sound.get())->setDataIsEnded();
    return PlayerErrors::noError;
}

PlayerErrors Player::getBufferSize(unsigned int hash, unsigned int *sizeInBytes)
{
    // See addAudioDataStream() for why the lock must span the whole call.
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    auto const s = findByHash(hash);

    if (s == nullptr || s->soundType != SoundType::TYPE_BUFFER_STREAM)
        return PlayerErrors::soundHashNotFound;

    auto *bufferStream = static_cast<SoLoud::BufferStream *>(s->sound.get());
    std::lock_guard<std::recursive_mutex> bufferLock(bufferStream->mBuffer.bufferMutex);
    *sizeInBytes = static_cast<unsigned int>(
        bufferStream->mBuffer.getActiveSizeInBytes() +
        bufferStream->buffer.size());
    return PlayerErrors::noError;
}

PlayerErrors Player::loadWaveform(
    int waveform,
    bool superWave,
    float scale,
    float detune,
    unsigned int &hash)
{
    if (!mInited)
        return backendNotInited;

    hash = 0;

    std::random_device rd;
    std::mt19937 g(rd());
    std::uniform_int_distribution<unsigned int> dist(0, INT32_MAX);

    hash = dist(g);

    {
        std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
        sounds.push_back(std::make_unique<ActiveSound>());
        sounds.back().get()->completeFileName = "";
        sounds.back().get()->soundHash = hash;
        auto basicWave = std::make_unique<Basicwave>((SoLoud::Soloud::WAVEFORM)waveform, superWave, detune, scale);
        basicWave->setSamplerate(mSampleRate);
        sounds.back().get()->sound = std::move(basicWave);
        sounds.back().get()->soundType = TYPE_SYNTH;
        sounds.back().get()->filters = std::make_unique<Filters>(&soloud, sounds.back().get(), nullptr);
    }

    return noError;
}

void Player::setWaveformScale(unsigned int soundHash, float newScale)
{
    auto const s = findByHash(soundHash);

    if (s == nullptr || s->soundType != TYPE_SYNTH)
        return;

    static_cast<Basicwave *>(s->sound.get())->setScale(newScale);
}

void Player::setWaveformDetune(unsigned int soundHash, float newDetune)
{
    auto const s = findByHash(soundHash);

    if (s == nullptr || s->soundType != TYPE_SYNTH)
        return;

    static_cast<Basicwave *>(s->sound.get())->setDetune(newDetune);
}

void Player::setWaveform(unsigned int soundHash, int newWaveform)
{
    auto const s = findByHash(soundHash);

    if (s == nullptr || s->soundType != TYPE_SYNTH)
        return;

    static_cast<Basicwave *>(s->sound.get())->setWaveform((SoLoud::Soloud::WAVEFORM)newWaveform);
}

void Player::setWaveformFreq(unsigned int soundHash, float newFreq)
{
    auto const s = findByHash(soundHash);

    if (s == nullptr || s->soundType != TYPE_SYNTH)
        return;

    static_cast<Basicwave *>(s->sound.get())->setFreq(newFreq);
}

void Player::setWaveformSuperwave(unsigned int soundHash, bool superwave)
{
    auto const s = findByHash(soundHash);

    if (s == nullptr || s->soundType != TYPE_SYNTH)
        return;

    static_cast<Basicwave *>(s->sound.get())->setSuperWave(superwave);
}

PlayerErrors Player::ensureAudioDeviceStarted()
{
    if (!mInited)
        return backendNotInited;

    const SoLoud::result result = soloud.resume();
    // `NOT_IMPLEMENTED` means the backend has no pause/resume concept, so its
    // device is always running and there is nothing to start. Every other
    // non-zero result is a genuine failure to (re)start the output device.
    if (result != SoLoud::SO_NO_ERROR && result != SoLoud::NOT_IMPLEMENTED)
        return audioDeviceFailedToStart;

    return noError;
}

PlayerErrors Player::pauseSwitch(unsigned int handle)
{
    if (!mInited)
        return backendNotInited;
    if (!isValidHandle(handle))
        return soundHandleNotFound;

    return setPause(handle, !soloud.getPause(handle));
}

PlayerErrors Player::setPause(unsigned int handle, bool pause, bool isUserAction)
{
    if (!mInited)
        return backendNotInited;
    if (!isValidHandle(handle))
        return soundHandleNotFound;

    if (!pause)
    {
        // When unpausing, ensure the audio device is started.
        // This handles cases where the OS stopped the device without notifying us
        // (e.g., Control Center pause on iOS).
        // If the device cannot be started, leave the voice paused (and its
        // `isUserPaused` flag untouched) so the caller can retry later instead
        // of ending up with a running voice and no audio output.
        const PlayerErrors deviceError = ensureAudioDeviceStarted();
        if (deviceError != noError)
            return deviceError;
    }

    soloud.setPause(handle, pause);

    // Track whether this handle was paused by the user, so the BufferStream
    // buffering logic does not automatically unpause it when data becomes
    // available. The user must explicitly unpause it again.
    auto s = findByHandle(handle);
    if (s != nullptr)
    {
        for (size_t i = 0; i < s->handle.size(); i++)
        {
            if (s->handle[i].handle == handle)
            {
                s->handle[i].isUserPaused = pause && isUserAction;
                break;
            }
        }
    }

    if (pause)
    {
        // When pausing, check if there are any remaining active voices.
        // If no voices are active, pause the audio device to allow the OS
        // to properly manage the audio session (important for Control Center
        // and remote command handling on iOS).
        pauseEngine();
    }

    return noError;
}

// On some platforms (notably iOS) the OS can take a short time to fully
// tear down or hand back the audio session after the last active voice is
// stopped/paused. If we pause the SoLoud engine immediately, a subsequent
// play/resume request can arrive while the audio device is still settling,
// which can cause the OS to keep the Control Center / lock-screen media
// controls in an inconsistent state or to fail to restart playback cleanly.
//
// To avoid this, we defer the engine pause by ~500 ms. This gives the audio
// backend and the OS enough time to stabilize, while still pausing the
// engine promptly once no voices remain active. It also coalesces rapid
// stop/pause events so we don't pause/unpause the device repeatedly. The
// latter happens when stopping many sounds in a short time and new sounds
// are then started causing a lag when starting to play again.
//
// Instead of spawning a detached thread for every request, a single
// persistent scheduler thread handles all pause requests.
void Player::pauseEngine()
{
#ifdef __EMSCRIPTEN__
    // Web: the wasm build is single-threaded (no pthreads), so the deferred
    // scheduler thread cannot run. Pause the device immediately instead. The
    // browser's AudioContext does not have the OS audio-session settling issue
    // that motivates the delay on native platforms.
    if (mInited && soloud.getActiveVoiceCount() == 0)
        soloud.pause();
#else
    {
        std::lock_guard<std::mutex> lock(mPauseMutex);
        if (!mPauseThreadRunning)
            return;
        mPauseRequested = true;
    }
    mPauseCv.notify_one();
#endif
}

void Player::startPauseEngineScheduler()
{
#ifndef __EMSCRIPTEN__
    std::lock_guard<std::mutex> lock(mPauseMutex);
    if (mPauseThreadRunning)
        return;
    mStopPauseThread = false;
    mPauseRequested = false;
    mPauseThread = std::thread(&Player::pauseEngineScheduler, this);
    mPauseThreadRunning = true;
#endif
}

void Player::stopPauseEngineScheduler()
{
#ifndef __EMSCRIPTEN__
    {
        std::lock_guard<std::mutex> lock(mPauseMutex);
        if (!mPauseThreadRunning)
            return;
        mStopPauseThread = true;
    }
    mPauseCv.notify_all();
    if (mPauseThread.joinable())
    {
        mPauseThread.join();
    }
    {
        std::lock_guard<std::mutex> lock(mPauseMutex);
        mPauseThreadRunning = false;
    }
#endif
}

void Player::pauseEngineScheduler()
{
    while (!mStopPauseThread)
    {
        std::unique_lock<std::mutex> lock(mPauseMutex);
        mPauseCv.wait(lock, [this]
                      { return mPauseRequested || mStopPauseThread; });
        if (mStopPauseThread)
            break;

        // A request arrived. Reset it and wait for the delay, but wake early
        // if another request arrives (coalescing rapid calls).
        mPauseRequested = false;
        mPauseCv.wait_for(lock, std::chrono::milliseconds(kPauseEngineDelayMs),
                          [this]
                          { return mPauseRequested || mStopPauseThread; });

        if (mStopPauseThread)
            break;

        // If another request arrived during the wait, loop back and restart
        // the delay so the pause happens only after the burst of requests ends.
        if (mPauseRequested)
            continue;

        lock.unlock();
        if (mInited && soloud.getActiveVoiceCount() == 0)
        {
            soloud.pause();
        }
    }
}

bool Player::getPause(unsigned int handle)
{
    return soloud.getPause(handle);
}

void Player::setRelativePlaySpeed(unsigned int handle, float speed)
{
    if (speed < 0.05)
        speed = 0.05;
    soloud.setRelativePlaySpeed(handle, speed);
}

float Player::getRelativePlaySpeed(unsigned int handle)
{
    return soloud.getRelativePlaySpeed(handle);
}

float Player::getApproximateVolume(unsigned int channel)
{
    return soloud.getApproximateVolume(channel);
}

unsigned int Player::getActiveVoiceCount_internal()
{
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    unsigned int count = 0;
    for (auto &s : sounds)
    {
        count += s->handle.size();
    }
    return count;
}

PlayerErrors Player::play(
    unsigned int soundHash,
    unsigned int &handle,
    unsigned int busId,
    float volume,
    float pan,
    bool paused,
    bool looping,
    double loopingStartAt,
    double loopingEndAt)
{
    handle = 0;

    ActiveSound *sound = findByHash(soundHash);

    if (sound == nullptr)
        return soundHashNotFound;

    // A BufferStream using `release` buffer type can only have one instance.
    if (sound->soundType == SoundType::TYPE_BUFFER_STREAM &&
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->getBufferingType() == BufferingType::RELEASED &&
        sound->handle.size() > 0)
    {
        return bufferStreamCanBePlayedOnlyOnce;
    }

    // Check if playing this sound will exceed the maximum number of voice counts. If true, then
    // check if [soudHash] has other instances playing. If true remove the first and play the new one.
    // If no other instances are playing, this sound cannot be played and return an error.
    // Issue https://github.com/alnitak/flutter_soloud/issues/204
    if (getActiveVoiceCount_internal() >= getMaxActiveVoiceCount())
    {
        if (sound->handle.size() > 0)
        {
            stop(sound->handle[0].handle);
        }
        else
        {
            return PlayerErrors::maxActiveVoiceCountReached;
        }
    }

    // Ensure miniaudio device is started if it's stopped, ie by an interruption.
    // Only when the voice will actually end up playing: a voice requested
    // paused produces no audio, so requiring the device here would stop
    // callers from creating and configuring a voice while an interruption is
    // active. When [looping] is set the voice is created paused only to set
    // the loop region up, and the `setPause()` below starts the device if it
    // has to unpause it.
    if (!paused)
    {
        const PlayerErrors deviceError = ensureAudioDeviceStarted();
        if (deviceError != noError)
            return deviceError;
    }

    SoLoud::handle newHandle = 0;
    const bool startPaused = paused || looping;
    if (busId == 0)
    {
        newHandle = soloud.play(*sound->sound.get(), volume, pan, startPaused, 0);
    }
    else
    {
        auto it = busMap.find(busId);
        if (it != busMap.end())
            newHandle = it->second.bus.play(*sound->sound.get(), volume, pan, startPaused);
        else
            return PlayerErrors::busIdNotFound;
    }

    // `Soloud::play()` returns the invalid-handle sentinel 0 when it could not
    // allocate a voice. Testing the value with `isValidVoiceHandle()` would not
    // be safe: handles are `(voice + 1) | (playIndex << 12)`, so a failure code
    // can collide with the real handle of an existing voice.
    if (newHandle == 0)
        return failedToStartPlayback;

    if (looping)
    {
        setLoopPoint(newHandle, loopingStartAt);
        setLoopEndPoint(newHandle, loopingEndAt);
        setLooping(newHandle, true);
    }

    sound->handle.push_back({newHandle, MAX_DOUBLE, false});
    if (looping)
    {
        // The voice was created paused to set up the loop region. Unpausing it
        // can fail if the output device cannot be (re)started; in that case
        // don't hand back a partially initialized handle.
        const PlayerErrors pauseError = setPause(newHandle, paused);
        if (pauseError != noError)
        {
            stop(newHandle);
            removeHandle(newHandle);
            return pauseError;
        }
    }
    // Check if this buffer has enough data to be played
    if (sound->soundType == SoundType::TYPE_BUFFER_STREAM)
    {
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->checkBuffering(0);
    }
    handle = newHandle;
    return PlayerErrors::noError;
}

PlayerErrors Player::playClocked(
    unsigned int soundHash,
    unsigned int &handle,
    double soundTime,
    unsigned int busId,
    float volume,
    float pan)
{
    handle = 0;

    ActiveSound *sound = findByHash(soundHash);

    if (sound == nullptr)
        return soundHashNotFound;

    // A BufferStream using `release` buffer type can only have one instance.
    if (sound->soundType == SoundType::TYPE_BUFFER_STREAM &&
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->getBufferingType() == BufferingType::RELEASED &&
        sound->handle.size() > 0)
    {
        return bufferStreamCanBePlayedOnlyOnce;
    }

    // Check if playing this sound will exceed the maximum number of voice counts. If true, then
    // check if [soudHash] has other instances playing. If true remove the first and play the new one.
    // If no other instances are playing, this sound cannot be played and return an error.
    // Issue https://github.com/alnitak/flutter_soloud/issues/204
    if (getActiveVoiceCount_internal() >= getMaxActiveVoiceCount())
    {
        if (sound->handle.size() > 0)
        {
            stop(sound->handle[0].handle);
        }
        else
        {
            return PlayerErrors::maxActiveVoiceCountReached;
        }
    }

    // Ensure miniaudio device is started if it's stopped, ie by an interruption.
    const PlayerErrors deviceError = ensureAudioDeviceStarted();
    if (deviceError != noError)
        return deviceError;

    SoLoud::handle newHandle = 0;
    if (busId == 0)
    {
        newHandle = soloud.playClocked(
            soundTime, *sound->sound.get(), volume, pan, 0);
    }
    else
    {
        auto it = busMap.find(busId);
        if (it != busMap.end())
            newHandle = it->second.bus.playClocked(
                soundTime, *sound->sound.get(), volume, pan);
        else
            return PlayerErrors::busIdNotFound;
    }

    // 0 is the invalid-handle sentinel: no voice could be allocated.
    if (newHandle == 0)
        return failedToStartPlayback;

    sound->handle.push_back({newHandle, MAX_DOUBLE, false});
    // Check if this buffer has enough data to be played
    if (sound->soundType == SoundType::TYPE_BUFFER_STREAM)
    {
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->checkBuffering(0);
    }
    handle = newHandle;
    return PlayerErrors::noError;
}

void Player::setDelaySamples(unsigned int handle, unsigned int samples)
{
    soloud.setDelaySamples(handle, samples);
}

double Player::getStreamTime(unsigned int handle)
{
    return soloud.getStreamTime(handle);
}

void Player::resetStreamTime()
{
    soloud.resetClockedAnchor();
}

double Player::getEngineTime()
{
    return soloud.getEngineTime();
}

PlayerErrors Player::playScheduled(
    unsigned int soundHash,
    unsigned int &handle,
    double atTime,
    double duration,
    unsigned int busId,
    float volume,
    float pan)
{
    handle = 0;

    ActiveSound *sound = findByHash(soundHash);

    if (sound == nullptr)
        return soundHashNotFound;

    // A BufferStream using `release` buffer type can only have one instance.
    if (sound->soundType == SoundType::TYPE_BUFFER_STREAM &&
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->getBufferingType() == BufferingType::RELEASED &&
        sound->handle.size() > 0)
    {
        return bufferStreamCanBePlayedOnlyOnce;
    }

    // Check if playing this sound will exceed the maximum number of voice counts. If true, then
    // check if [soudHash] has other instances playing. If true remove the first and play the new one.
    // If no other instances are playing, this sound cannot be played and return an error.
    // Issue https://github.com/alnitak/flutter_soloud/issues/204
    if (getActiveVoiceCount_internal() >= getMaxActiveVoiceCount())
    {
        if (sound->handle.size() > 0)
        {
            stop(sound->handle[0].handle);
        }
        else
        {
            return PlayerErrors::maxActiveVoiceCountReached;
        }
    }

    // Ensure miniaudio device is started if it's stopped, ie by an interruption.
    const PlayerErrors deviceError = ensureAudioDeviceStarted();
    if (deviceError != noError)
        return deviceError;

    SoLoud::handle newHandle = 0;
    if (busId == 0)
    {
        newHandle = soloud.playScheduled(
            atTime, *sound->sound.get(), volume, pan, 0);
    }
    else
    {
        auto it = busMap.find(busId);
        if (it != busMap.end())
            newHandle = it->second.bus.playScheduled(
                atTime, *sound->sound.get(), volume, pan);
        else
            return PlayerErrors::busIdNotFound;
    }

    // 0 is the invalid-handle sentinel: no voice could be allocated.
    if (newHandle == 0)
        return failedToStartPlayback;

    sound->handle.push_back({newHandle, MAX_DOUBLE, false});
    if (duration > 0.0)
    {
        soloud.scheduleStopAt(newHandle, atTime + duration);
    }
    // Check if this buffer has enough data to be played
    if (sound->soundType == SoundType::TYPE_BUFFER_STREAM)
    {
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->checkBuffering(0);
    }
    handle = newHandle;
    return PlayerErrors::noError;
}

void Player::stopScheduled(unsigned int handle, double atTime)
{
    soloud.scheduleStopAt(handle, atTime);
}

void Player::fadeScheduled(unsigned int handle, double atTime, float to,
                           double fadeTime, bool thenStop)
{
    soloud.scheduleFadeAt(handle, atTime, to, fadeTime, thenStop);
}

PlayerErrors Player::stop(unsigned int handle)
{
    if (!mInited)
        return backendNotInited;
    if (!isValidHandle(handle))
    {
        // The voice is already gone. Report it, but still re-evaluate whether
        // the device should idle: the previous `void` version ran this on
        // every call, and skipping it here would quietly change the
        // idle-device behaviour when a voice ends between Dart's validity
        // check and this call.
        pauseEngine();
        return soundHandleNotFound;
    }

    soloud.stop(handle);
    // After stopping, check if there are any remaining active voices.
    // If no voices are active, pause the audio device to allow the OS
    // to properly manage the audio session.
    pauseEngine();

    return noError;
}

void Player::removeHandle(unsigned int handle)
{
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    if (sounds.empty())
    {
        return;
    }

    bool found = false;
    size_t i = 0;
    while (i < sounds.size() && !found)
    {
        auto const &sound = sounds[i];
        if (sound)
        { // Check if unique_ptr is valid
            size_t n = 0;
            while (n < sound->handle.size() && !found)
            {
                if (sound->handle[n].handle == handle)
                {
                    sound->handle.erase(sound->handle.begin() + n);
                    found = true;
                }
                ++n;
            }
        }
        ++i;
    }
}

void Player::disposeSound(unsigned int soundHash)
{
    std::unique_ptr<ActiveSound> soundToDestroy;

    {
        std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
        if (sounds.empty())
        {
            return;
        }

        auto it = std::find_if(sounds.begin(), sounds.end(),
                               [soundHash](const std::unique_ptr<ActiveSound> &sound)
                               {
                                   return sound->soundHash == soundHash;
                               });

        if (it != sounds.end())
        {
            // Stop all handles for this sound before destroying to prevent
            // the audio thread from accessing filters during destruction.
            for (auto &handleInfo : it->get()->handle)
            {
                soloud.stop(handleInfo.handle);
            }

            // Mark BufferStream for destruction before removing it
            if (it->get()->soundType == SoundType::TYPE_BUFFER_STREAM)
            {
                auto *bufferStream = static_cast<SoLoud::BufferStream *>(it->get()->sound.get());
                if (bufferStream != nullptr)
                {
                    bufferStream->markForDestruction();
                }
            }
            else if (it->get()->soundType == SoundType::TYPE_PULL_BUFFER_STREAM)
            {
                auto *pullStream = static_cast<SoLoud::PullBufferStream *>(it->get()->sound.get());
                if (pullStream != nullptr)
                {
                    pullStream->markForDestruction();
                }
            }

            // Clear all filters from this sound BEFORE moving it out.
            // This prevents the audio thread from accessing filter instances
            // when the sound is destroyed.
            if (it->get()->sound)
            {
                for (int i = 0; i < FILTERS_PER_STREAM; i++)
                {
                    it->get()->sound->setFilter(i, nullptr);
                }
            }

            // Move the sound out of the vector before erasing
            soundToDestroy = std::move(*it);
            sounds.erase(it);
        }
    }
    // Sound (and its filters) is destroyed here when soundToDestroy goes out of scope

    // After disposing a sound, check if there are any remaining active voices.
    // If no voices are active, pause the audio device.
    pauseEngine();
}

void Player::disposeAllSound()
{
    // Stop all voices first. This stops all active audio processing.
    soloud.stopAll();

    // Pause the audio device BEFORE destroying sounds to ensure the audio thread
    // is not accessing filter memory. This prevents race conditions where the
    // audio thread crashes trying to access freed filter instances.
    soloud.pause();

    std::vector<std::unique_ptr<ActiveSound>> soundsToDestroy;

    {
        std::lock_guard<std::recursive_mutex> lock(sounds_mutex);

        // First, remove all filters from sounds while the audio thread is paused.
        // This prevents the audio thread from accessing filter instances during destruction.
        for (auto &sound : sounds)
        {
            if (sound->soundType == SoundType::TYPE_BUFFER_STREAM)
            {
                auto *bufferStream = static_cast<SoLoud::BufferStream *>(sound->sound.get());
                if (bufferStream != nullptr)
                {
                    bufferStream->markForDestruction();
                }
            }
            else if (sound->soundType == SoundType::TYPE_PULL_BUFFER_STREAM)
            {
                auto *pullStream = static_cast<SoLoud::PullBufferStream *>(sound->sound.get());
                if (pullStream != nullptr)
                {
                    pullStream->markForDestruction();
                }
            }
            // Clear all filters from this sound
            if (sound->sound)
            {
                for (int i = 0; i < FILTERS_PER_STREAM; i++)
                {
                    sound->sound->setFilter(i, nullptr);
                }
            }
        }

        // Clear global filters
        for (int i = 0; i < FILTERS_PER_STREAM; i++)
        {
            soloud.setGlobalFilter(i, nullptr);
        }

        // Move all sounds out to destroy them after releasing the lock
        soundsToDestroy = std::move(sounds);
        sounds.clear();
    }
    // Sounds (and their filters) are destroyed here when soundsToDestroy goes out of scope
}

void Player::clearDartCallbackRegistrations()
{
    setVoiceEndedCallback(nullptr);
    setStateChangedCallback(nullptr);

    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    for (auto &sound : sounds)
    {
        if (sound != nullptr && sound->sound != nullptr)
        {
            if (sound->soundType == SoundType::TYPE_BUFFER_STREAM)
            {
                static_cast<SoLoud::BufferStream *>(sound->sound.get())
                    ->clearDartCallbacks();
            }
            else if (sound->soundType == SoundType::TYPE_PULL_BUFFER_STREAM)
            {
                static_cast<SoLoud::PullBufferStream *>(sound->sound.get())
                    ->clearDartCallbacks();
            }
        }
    }
}

bool Player::getLooping(unsigned int handle)
{
    return soloud.getLooping(handle);
}

void Player::setLooping(unsigned int handle, bool enable)
{
    soloud.setLooping(handle, enable);
}

double Player::getLoopPoint(unsigned int handle)
{
    return soloud.getLoopPoint(handle);
}

void Player::setLoopPoint(unsigned int handle, double time)
{
    soloud.setLoopPoint(handle, time);
}

double Player::getLoopEndPoint(unsigned int handle)
{
    return soloud.getLoopEndPoint(handle);
}

void Player::setLoopEndPoint(unsigned int handle, double time)
{
    soloud.setLoopEndPoint(handle, time);
}

PlayerErrors Player::textToSpeech(const std::string &textToSpeech, unsigned int &handle)
{
    handle = 0;

    if (!mInited)
        return backendNotInited;

    const SoLoud::result result = speech.setText(textToSpeech.c_str());
    if (result != SoLoud::SO_NO_ERROR)
        return fromSoLoudError(result);

    // Ensure miniaudio device is started if it's stopped, ie by an interruption.
    const PlayerErrors deviceError = ensureAudioDeviceStarted();
    if (deviceError != noError)
        return deviceError;

    const SoLoud::handle newHandle = soloud.play(speech);
    // 0 is the invalid-handle sentinel: no voice could be allocated. Don't
    // create any bookkeeping for a sound that is not playing.
    if (newHandle == 0)
        return failedToStartPlayback;

    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    sounds.push_back(std::make_unique<ActiveSound>());
    ActiveSound *sound = sounds.back().get();
    sound->completeFileName = std::string("");
    sound->soundHash = newHandle;
    sound->soundType = TYPE_TEXT_TO_SPEECH;
    sound->filters = std::make_unique<Filters>(&soloud, sound, nullptr);
    sound->handle.push_back({newHandle, MAX_DOUBLE, false});

    handle = newHandle;
    return noError;
}

void Player::setVisualizationEnabled(bool enabled)
{
    soloud.setVisualizationEnable(enabled);
}

bool Player::isVisualizationEnabled()
{
    return soloud.mFlags & SoLoud::Soloud::ENABLE_VISUALIZATION;
}

float fftData[256];
float *Player::calcFFT(bool *isTheSameAsBefore)
{
    float *currentWave = soloud.calcFFT();
    if (memcmp(fftData, currentWave, sizeof(fftData)) != 0)
    {
        *isTheSameAsBefore = false;
    }
    else
    {
        *isTheSameAsBefore = true;
    }
    memcpy(fftData, currentWave, sizeof(fftData));

    return fftData;
}

float waveData[256];
float *Player::getWave(bool *isTheSameAsBefore)
{
    float *currentWave = soloud.getWave();
    if (memcmp(waveData, currentWave, sizeof(waveData)) != 0)
    {
        *isTheSameAsBefore = false;
    }
    else
    {
        *isTheSameAsBefore = true;
    }
    memcpy(waveData, currentWave, sizeof(waveData));

    return waveData;
}

// The length in seconds
double Player::getLength(unsigned int soundHash)
{
    auto const &s = findByHash(soundHash);

    if (s == nullptr || s->soundType == TYPE_SYNTH || s->soundType == TYPE_TEXT_TO_SPEECH)
        return 0.0;
    if (s->soundType == TYPE_WAV)
        return static_cast<SoLoud::Wav *>(s->sound.get())->getLength();
    if (s->soundType == TYPE_BUFFER_STREAM)
        return static_cast<SoLoud::BufferStream *>(s->sound.get())->getLength();
    if (s->soundType == TYPE_WAVSTREAM)
        return static_cast<SoLoud::WavStream *>(s->sound.get())->getLength();
    return 0.0;
}

// time in seconds
PlayerErrors Player::seek(SoLoud::handle handle, float time)
{
    if (!mInited)
        return backendNotInited;

    ActiveSound *sound = findByHandle(handle);
    bool isGroupHandle = soloud.isVoiceGroup(handle);

    if ((sound == nullptr || sound->soundType == TYPE_SYNTH) && !isGroupHandle)
        return invalidParameter;

    // A BufferStream using `release` buffer type cannot use seek.
    if (sound != nullptr && sound->soundType == SoundType::TYPE_BUFFER_STREAM &&
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->getBufferingType() == BufferingType::RELEASED)
    {
        return bufferStreamWithReleasedBufferTypeCannotBeSeeked;
    }

    SoLoud::result result = soloud.seek(handle, time);
    return fromSoLoudError(result);
}

// returns time in seconds
double Player::getPosition(SoLoud::handle handle)
{
    return soloud.getStreamPosition(handle);
}

float Player::getGlobalVolume()
{
    return soloud.getGlobalVolume();
}

void Player::setGlobalVolume(float volume)
{
    return soloud.setGlobalVolume(volume);
}

float Player::getVolume(SoLoud::handle handle)
{
    return soloud.getVolume(handle);
}

void Player::setVolume(SoLoud::handle handle, float volume)
{
    return soloud.setVolume(handle, volume);
}

float Player::getPan(SoLoud::handle handle)
{
    return soloud.getPan(handle);
}

void Player::setPan(SoLoud::handle handle, float pan)
{
    pan = std::clamp(pan, -1.0f, 1.0f);
    soloud.setPan(handle, pan);
}

void Player::setPanAbsolute(SoLoud::handle handle, float panLeft, float panRight)
{
    panLeft = std::clamp(panLeft, -1.0f, 1.0f);
    panRight = std::clamp(panRight, -1.0f, 1.0f);
    soloud.setPanAbsolute(handle, panLeft, panRight);
}

bool Player::isValidHandle(SoLoud::handle handle)
{
    return soloud.isValidVoiceHandle(handle) || soloud.isVoiceGroup(handle);
}

int Player::countAudioSource(unsigned int soundHash)
{
    auto const &s = findByHash(soundHash);

    if (s == nullptr)
        return 0;

    SoLoud::AudioSource *as;
    switch (s->soundType)
    {
    case TYPE_SYNTH:
        return 0;
    case TYPE_WAV:
        as = static_cast<SoLoud::Wav *>(s->sound.get());
    case TYPE_WAVSTREAM:
        as = static_cast<SoLoud::WavStream *>(s->sound.get());
    case TYPE_BUFFER_STREAM:
        as = static_cast<SoLoud::BufferStream *>(s->sound.get());
    default:
        return 0;
    }
    return soloud.countAudioSource(*as);
}

unsigned int Player::getVoiceCount()
{
    return soloud.getVoiceCount();
}

bool Player::getProtectVoice(SoLoud::handle handle)
{
    return soloud.getProtectVoice(handle);
}

void Player::setProtectVoice(SoLoud::handle handle, bool protect)
{
    soloud.setProtectVoice(handle, protect);
}

void Player::setInaudibleBehavior(SoLoud::handle handle, bool mustTick, bool kill)
{
    soloud.setInaudibleBehavior(handle, mustTick, kill);
}

unsigned int Player::getMaxActiveVoiceCount()
{
    return soloud.getMaxActiveVoiceCount();
}

void Player::setMaxActiveVoiceCount(unsigned int maxVoiceCount)
{
    soloud.setMaxActiveVoiceCount(maxVoiceCount);
}

ActiveSound *Player::findByHandle(SoLoud::handle handle)
{
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    int i = 0;
    while (i < (int)sounds.size())
    {
        int index = 0;
        while (sounds[i].get() && index < (int)sounds[i].get()->handle.size())
        {
            if (sounds[i].get()->handle[index].handle == handle)
            {
                return sounds[i].get();
            }
            ++index;
        }
        ++i;
    }

    return nullptr;
}

ActiveSound *Player::findByHash(unsigned int soundHash)
{
    std::lock_guard<std::recursive_mutex> lock(sounds_mutex);
    auto const &s = std::find_if(sounds.begin(), sounds.end(),
                                 [&](std::unique_ptr<ActiveSound> const &f)
                                 { return f->soundHash == soundHash; });
    if (s == sounds.end())
        return nullptr;

    return s->get();
}

/////////////////////////////////////////
/// voice groups
/////////////////////////////////////////

unsigned int Player::createVoiceGroup()
{
    unsigned int ret = soloud.createVoiceGroup();
    return ret;
}

void Player::destroyVoiceGroup(SoLoud::handle handle)
{
    soloud.destroyVoiceGroup(handle);
}

void Player::addVoiceToGroup(SoLoud::handle voiceGroupHandle, SoLoud::handle voiceHandle)
{
    soloud.addVoiceToGroup(voiceGroupHandle, voiceHandle);
}

bool Player::isVoiceGroup(SoLoud::handle handle)
{
    return soloud.isVoiceGroup(handle);
}

bool Player::isVoiceGroupEmpty(SoLoud::handle handle)
{
    return soloud.isVoiceGroupEmpty(handle);
}

/////////////////////////////////////////
/// faders
/////////////////////////////////////////

void Player::fadeGlobalVolume(float to, float time)
{
    soloud.fadeGlobalVolume(to, time);
}

void Player::fadeVolume(SoLoud::handle handle, float to, float time)
{
    soloud.fadeVolume(handle, to, time);
}

void Player::fadePan(SoLoud::handle handle, float to, float time)
{
    soloud.fadePan(handle, to, time);
}

void Player::fadeRelativePlaySpeed(SoLoud::handle handle, float to, float time)
{
    soloud.fadeRelativePlaySpeed(handle, to, time);
}

void Player::schedulePause(SoLoud::handle handle, float time)
{
    soloud.schedulePause(handle, time);
}

void Player::scheduleStop(SoLoud::handle handle, float time)
{
    soloud.scheduleStop(handle, time);
}

void Player::oscillateVolume(SoLoud::handle handle, float from, float to, float time)
{
    soloud.oscillateVolume(handle, from, to, time);
}

void Player::oscillatePan(SoLoud::handle handle, float from, float to, float time)
{
    soloud.oscillatePan(handle, from, to, time);
}

void Player::oscillateRelativePlaySpeed(SoLoud::handle handle, float from, float to, float time)
{
    soloud.oscillateRelativePlaySpeed(handle, from, to, time);
}

void Player::oscillateGlobalVolume(float from, float to, float time)
{
    soloud.oscillateGlobalVolume(from, to, time);
}

/////////////////////////////////////////
/// 3D audio methods
/////////////////////////////////////////

void Player::update3dAudio()
{
    soloud.update3dAudio();
}

PlayerErrors Player::play3d(
    unsigned int soundHash,
    unsigned int &handle,
    float posX,
    float posY,
    float posZ,
    float velX,
    float velY,
    float velZ,
    float volume,
    bool paused,
    unsigned int busId,
    bool looping,
    double loopingStartAt,
    double loopingEndAt)
{
    handle = 0;

    ActiveSound *sound = findByHash(soundHash);
    if (sound == 0)
        return soundHashNotFound;

    // A BufferStream using `release` buffer type can only have one instance.
    if (sound->soundType == SoundType::TYPE_BUFFER_STREAM &&
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->getBufferingType() == BufferingType::RELEASED &&
        sound->handle.size() > 0)
    {
        return bufferStreamCanBePlayedOnlyOnce;
    }

    // Check if by playing this sound will exceed the maximum number of voice count. If true, then
    // check if [soudHash] has other instances playing. If true remove the first and play the new one.
    // If there are no other instances playing, this sound cannot be played and return an error.
    // Issue https://github.com/alnitak/flutter_soloud/issues/204
    if (getActiveVoiceCount_internal() >= getMaxActiveVoiceCount())
    {
        if (sound->handle.size() > 0)
        {
            stop(sound->handle[0].handle);
        }
        else
        {
            return PlayerErrors::maxActiveVoiceCountReached;
        }
    }

    // Ensure miniaudio device is started if it's stopped, ie by an interruption.
    // Only when the voice will actually end up playing: a voice requested
    // paused produces no audio, so requiring the device here would stop
    // callers from creating and configuring a voice while an interruption is
    // active. When [looping] is set the voice is created paused only to set
    // the loop region up, and the `setPause()` below starts the device if it
    // has to unpause it.
    if (!paused)
    {
        const PlayerErrors deviceError = ensureAudioDeviceStarted();
        if (deviceError != noError)
            return deviceError;
    }

    SoLoud::handle newHandle = 0;
    const bool startPaused = paused || looping;
    if (busId == 0)
    {
        newHandle = soloud.play3d(
            *sound->sound.get(),
            posX, posY, posZ,
            velX, velY, velZ,
            volume,
            startPaused,
            0);
    }
    else
    {
        auto it = busMap.find(busId);
        if (it != busMap.end())
            newHandle = it->second.bus.play3d(
                *sound->sound.get(),
                posX, posY, posZ,
                velX, velY, velZ,
                volume,
                startPaused);
        else
            return PlayerErrors::busIdNotFound;
    }

    // 0 is the invalid-handle sentinel: no voice could be allocated.
    if (newHandle == 0)
        return failedToStartPlayback;

    sound->handle.push_back({newHandle, MAX_DOUBLE, false});
    if (looping)
    {
        setLoopPoint(newHandle, loopingStartAt);
        setLoopEndPoint(newHandle, loopingEndAt);
        setLooping(newHandle, true);
        seek(newHandle, loopingStartAt);
        // The voice was created paused to set up the loop region. Unpausing it
        // can fail if the output device cannot be (re)started; in that case
        // don't hand back a partially initialized handle.
        const PlayerErrors pauseError = setPause(newHandle, paused);
        if (pauseError != noError)
        {
            stop(newHandle);
            removeHandle(newHandle);
            return pauseError;
        }
    }
    // Check if this buffer has enough data to be played
    if (sound->soundType == SoundType::TYPE_BUFFER_STREAM)
    {
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->checkBuffering(0);
    }
    handle = newHandle;
    return PlayerErrors::noError;
}

PlayerErrors Player::play3dClocked(
    unsigned int soundHash,
    unsigned int &handle,
    double soundTime,
    float posX,
    float posY,
    float posZ,
    float velX,
    float velY,
    float velZ,
    float volume,
    unsigned int busId)
{
    handle = 0;

    ActiveSound *sound = findByHash(soundHash);
    if (sound == 0)
        return soundHashNotFound;

    // A BufferStream using `release` buffer type can only have one instance.
    if (sound->soundType == SoundType::TYPE_BUFFER_STREAM &&
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->getBufferingType() == BufferingType::RELEASED &&
        sound->handle.size() > 0)
    {
        return bufferStreamCanBePlayedOnlyOnce;
    }

    // Check if by playing this sound will exceed the maximum number of voice count. If true, then
    // check if [soudHash] has other instances playing. If true remove the first and play the new one.
    // If there are no other instances playing, this sound cannot be played and return an error.
    // Issue https://github.com/alnitak/flutter_soloud/issues/204
    if (getActiveVoiceCount_internal() >= getMaxActiveVoiceCount())
    {
        if (sound->handle.size() > 0)
        {
            stop(sound->handle[0].handle);
        }
        else
        {
            return PlayerErrors::maxActiveVoiceCountReached;
        }
    }

    // Ensure miniaudio device is started if it's stopped, ie by an interruption.
    const PlayerErrors deviceError = ensureAudioDeviceStarted();
    if (deviceError != noError)
        return deviceError;

    SoLoud::handle newHandle = 0;
    if (busId == 0)
    {
        newHandle = soloud.play3dClocked(
            soundTime,
            *sound->sound.get(),
            posX, posY, posZ,
            velX, velY, velZ,
            volume,
            0);
    }
    else
    {
        auto it = busMap.find(busId);
        if (it != busMap.end())
            newHandle = it->second.bus.play3dClocked(
                soundTime,
                *sound->sound.get(),
                posX, posY, posZ,
                velX, velY, velZ,
                volume);
        else
            return PlayerErrors::busIdNotFound;
    }

    // 0 is the invalid-handle sentinel: no voice could be allocated.
    if (newHandle == 0)
        return failedToStartPlayback;

    sound->handle.push_back({newHandle, MAX_DOUBLE, false});
    // Check if this buffer has enough data to be played
    if (sound->soundType == SoundType::TYPE_BUFFER_STREAM)
    {
        static_cast<SoLoud::BufferStream *>(sound->sound.get())->checkBuffering(0);
    }
    handle = newHandle;
    return PlayerErrors::noError;
}

void Player::set3dSoundSpeed(float speed)
{
    soloud.set3dSoundSpeed(speed);
}

float Player::get3dSoundSpeed()
{
    return soloud.get3dSoundSpeed();
}

void Player::set3dListenerParameters(
    float aPosX, float aPosY, float aPosZ,
    float aAtX, float aAtY, float aAtZ,
    float aUpX, float aUpY, float aUpZ,
    float aVelocityX, float aVelocityY, float aVelocityZ)
{
    soloud.set3dListenerParameters(
        aPosX, aPosY, aPosZ,
        aAtX, aAtY, aAtZ,
        aUpX, aUpY, aUpZ,
        aVelocityX, aVelocityY, aVelocityZ);
}

void Player::set3dListenerPosition(float aPosX,
                                   float aPosY,
                                   float aPosZ)
{
    soloud.set3dListenerPosition(aPosX, aPosY, aPosZ);
}

void Player::set3dListenerAt(float aAtX,
                             float aAtY,
                             float aAtZ)
{
    soloud.set3dListenerAt(aAtX, aAtY, aAtZ);
}

void Player::set3dListenerUp(float aUpX,
                             float aUpY,
                             float aUpZ)
{
    soloud.set3dListenerAt(aUpX, aUpY, aUpZ);
}

void Player::set3dListenerVelocity(float aVelocityX,
                                   float aVelocityY,
                                   float aVelocityZ)
{
    soloud.set3dListenerVelocity(aVelocityX, aVelocityY, aVelocityZ);
}

void Player::set3dSourceParameters(
    unsigned int aVoiceHandle,
    float aPosX, float aPosY, float aPosZ,
    float aVelocityX, float aVelocityY, float aVelocityZ)
{
    soloud.set3dSourceParameters(aVoiceHandle,
                                 aPosX, aPosY, aPosZ,
                                 aVelocityX, aVelocityY, aVelocityZ);
}

void Player::set3dSourcePosition(
    unsigned int aVoiceHandle,
    float aPosX,
    float aPosY,
    float aPosZ)
{
    soloud.set3dSourcePosition(aVoiceHandle, aPosX, aPosY, aPosZ);
}

void Player::set3dSourceVelocity(
    unsigned int aVoiceHandle,
    float aVelocityX,
    float aVelocityY,
    float aVelocityZ)
{
    soloud.set3dSourceVelocity(aVoiceHandle, aVelocityX, aVelocityY, aVelocityZ);
}

void Player::set3dSourceMinMaxDistance(
    unsigned int aVoiceHandle,
    float aMinDistance,
    float aMaxDistance)
{
    soloud.set3dSourceMinMaxDistance(aVoiceHandle, aMinDistance, aMaxDistance);
}

void Player::set3dSourceAttenuation(
    unsigned int aVoiceHandle,
    unsigned int aAttenuationModel,
    float aAttenuationRolloffFactor)
{
    soloud.set3dSourceAttenuation(aVoiceHandle, aAttenuationModel, aAttenuationRolloffFactor);
}

void Player::set3dSourceDopplerFactor(
    unsigned int aVoiceHandle,
    float aDopplerFactor)
{
    soloud.set3dSourceDopplerFactor(aVoiceHandle, aDopplerFactor);
}

/////////////////////////////////////////
/// Mixing Bus
/////////////////////////////////////////

unsigned int Player::createBus()
{
    unsigned int id = ++busIdCounter;
    busMap.try_emplace(id, id, &soloud);
    return id;
}

void Player::destroyBus(unsigned int busId)
{
    busMap.erase(busId);
}

PlayerErrors Player::busPlayOnEngine(unsigned int busId, float volume,
                                     bool paused, unsigned int &handle)
{
    handle = 0;

    if (!mInited)
        return backendNotInited;
    auto it = busMap.find(busId);
    if (it == busMap.end())
        return busIdNotFound;

    if (!paused)
    {
        // The bus voice is about to start producing audio, so the output
        // device must be running. Without this a valid, unpaused bus voice
        // could be handed back while the device is still stopped.
        const PlayerErrors deviceError = ensureAudioDeviceStarted();
        if (deviceError != noError)
            return deviceError;
    }

    SoLoud::handle newHandle = soloud.play(it->second.bus, volume, 0.0f, paused);
    // 0 is the invalid-handle sentinel: no voice could be allocated. Never
    // store or configure that value.
    if (newHandle == 0)
        return failedToStartPlayback;

    it->second.handle = newHandle;
    // Playing a sound inside a bus decreases the volume compared to playing it directly.
    // https://github.com/jarikomppa/soloud/issues/395#issuecomment-4148675275
    soloud.setPanAbsolute(newHandle, 1.0f, 1.0f);

    handle = newHandle;
    return noError;
}

int Player::busSetChannels(unsigned int busId, unsigned int channels)
{
    auto it = busMap.find(busId);
    if (it == busMap.end())
        return -1; // bus not found
    return static_cast<int>(it->second.bus.setChannels(channels));
}

void Player::busSetVisualizationEnable(unsigned int busId, bool enable)
{
    auto it = busMap.find(busId);
    if (it == busMap.end())
        return;
    it->second.bus.setVisualizationEnable(enable);
}

float *Player::busCalcFFT(unsigned int busId)
{
    auto it = busMap.find(busId);
    if (it == busMap.end())
        return nullptr;
    return it->second.bus.calcFFT();
}

float *Player::busGetWave(unsigned int busId)
{
    auto it = busMap.find(busId);
    if (it == busMap.end())
        return nullptr;
    return it->second.bus.getWave();
}

float Player::busGetApproximateVolume(unsigned int busId,
                                      unsigned int channel)
{
    auto it = busMap.find(busId);
    if (it == busMap.end())
        return 0.0f;
    return it->second.bus.getApproximateVolume(channel);
}

void Player::busAnnexSound(unsigned int busId, unsigned int voiceHandle)
{
    auto it = busMap.find(busId);
    if (it == busMap.end())
        return;
    it->second.bus.annexSound(voiceHandle);
}

unsigned int Player::busGetActiveVoiceCount(unsigned int busId)
{
    auto it = busMap.find(busId);
    if (it == busMap.end())
        return 0;
    unsigned int ret = it->second.bus.getActiveVoiceCount();
    return ret;
}

BusData *Player::findBusData(unsigned int busId)
{
    auto it = busMap.find(busId);
    if (it == busMap.end())
        return nullptr;
    return &it->second;
}

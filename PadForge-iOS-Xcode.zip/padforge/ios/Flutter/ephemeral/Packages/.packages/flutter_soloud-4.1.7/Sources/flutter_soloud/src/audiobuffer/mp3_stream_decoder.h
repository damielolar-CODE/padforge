#ifndef MP3_STREAM_DECODER_H
#define MP3_STREAM_DECODER_H

#include <cstring>
#include <deque>
#include <iostream>
#include <vector>

// #define DR_MP3_IMPLEMENTATION
#include "../soloud/src/audiosource/wav/dr_mp3.h"

#include "stream_decoder.h"

/// Wrapper class for MP3 stream decoder using dr_mp3
class MP3DecoderWrapper : public IDecoderWrapper {
public:
  MP3DecoderWrapper();

  ~MP3DecoderWrapper();

  bool initializeDecoder(int engineSamplerate, int engineChannels) override;

  // call this only once before decoding
  void setIcyMetaInt(int icyMetaInt);

  // Call this when the stream ends to clean up internal state
  void cleanup();

  // Call this when no more data will be added to signal end-of-stream
  void setDataEnded() override;

  std::pair<std::vector<float>, DecoderError>
  decode(std::vector<unsigned char> &buffer, int *samplerate,
         int *channels, size_t maxOutputSamples = 0) override;

  bool canSeekToTime(double seconds) const override;
  uint64_t timeToByteOffset(double seconds) override;
  double getDuration() const override;
  void setTotalAudioSizeBytes(uint64_t size) override;

  static bool checkForValidFrames(const std::vector<unsigned char> &buffer);

  drmp3 decoder;

private:
  static size_t on_read(void *pUserData, void *pBufferOut, size_t bytesToRead);
  static drmp3_bool32 on_seek(void *pUserData, int offset,
                              drmp3_seek_origin origin);
  static void on_meta(void *pUserData, const drmp3_metadata *pMetadata);

  // bool extractID3Tags(const std::vector<unsigned char>& buffer,
  // AudioMetadata& metadata);
  void processIcyStream(std::vector<unsigned char> &buffer);
  // size_t getLastFrameStartingPos(std::vector<unsigned char> &buffer, size_t
  // *bytes_discarded_at_end);
  bool isInitialized;
  std::vector<unsigned char> audioData;
  size_t m_read_pos;
  /// Absolute stream offset of audioData[0]. The buffer is a sliding window
  /// over the stream: consumed bytes are discarded and this base is advanced
  /// accordingly, so dr_mp3 always works in window-relative positions.
  uint64_t m_audioDataBaseOffset;
  /// Value of m_audioDataBaseOffset in effect when mSeekPoints was built;
  /// added to seek point byte positions to get absolute stream offsets.
  uint64_t m_seekTableBaseOffset;
  /// Size of the ID3v2 tag detected at initialization (0 when absent).
  size_t m_id3Size;
  size_t bytes_until_meta;
  std::string metadata_buffer;
  std::string lastMetadata;
  int mIcyMetaInt;
  bool ID3TagsFound;
  bool mDataEnded; // Signals that no more data will be added
  uint64_t mTotalAudioSizeBytes;

  void buildSeekTable();
  double estimateBitrateFromFirstFrame() const;
  double parseDurationFromXingVbri() const;
  mutable std::vector<drmp3_seek_point> mSeekPoints;
};

#endif // MP3_STREAM_DECODER_H
// Tests for the pad grid's drawing order and the labels printed on the pads.
//
// The drawing order is the v5 bug fix: the MPD218's pad 1 is its BOTTOM-left
// pad, so the app has to draw the grid bottom-left-first or the screen is a
// mirror image of the hardware in the player's hands.
import 'package:flutter_test/flutter_test.dart';
import 'package:padforge/models/kit.dart';
import 'package:padforge/models/pad.dart';
import 'package:padforge/ui/widgets/pad_grid.dart';

void main() {
  group('pad grid drawing order', () {
    test('MPD218 order puts pad 1 bottom-left and pad 16 top-right', () {
      // Drawn slots read left-to-right, top-to-bottom.
      final drawn = [
        for (var slot = 0; slot < 16; slot++)
          padIndexForGridSlot(slot, bottomLeft: true),
      ];

      // Top row of the screen is pads 13-16 (indexes 12-15).
      expect(drawn.sublist(0, 4), [12, 13, 14, 15]);
      expect(drawn.sublist(4, 8), [8, 9, 10, 11]);
      expect(drawn.sublist(8, 12), [4, 5, 6, 7]);
      // Bottom row is pads 1-4, with pad 1 bottom-left.
      expect(drawn.sublist(12, 16), [0, 1, 2, 3]);
    });

    test('every pad appears exactly once', () {
      for (final bottomLeft in [true, false]) {
        final drawn = <int>{};
        for (var slot = 0; slot < 16; slot++) {
          drawn.add(padIndexForGridSlot(slot, bottomLeft: bottomLeft));
        }
        expect(drawn.length, 16);
        expect(drawn.reduce((a, b) => a > b ? a : b), 15);
        expect(drawn.reduce((a, b) => a < b ? a : b), 0);
      }
    });

    test('top-left mode is plain reading order', () {
      for (var slot = 0; slot < 16; slot++) {
        expect(padIndexForGridSlot(slot, bottomLeft: false), slot);
      }
    });

    test('the bottom-left pad plays the kick, as on the hardware', () {
      final kit = Kit.blank(name: 'T', folderName: 't');
      final pads = kit.padsForBank('A');
      // Slot 12 is the bottom-left square of the drawn grid.
      final bottomLeft = pads[padIndexForGridSlot(12, bottomLeft: true)];
      expect(bottomLeft.padId, 'A1');
      // 36 is the General MIDI kick, and MPD218 pad 1 sends it.
      expect(bottomLeft.note, 36);

      final topLeft = pads[padIndexForGridSlot(0, bottomLeft: true)];
      expect(topLeft.padId, 'A13');
      expect(topLeft.note, 48);
    });
  });

  group('pad labels', () {
    Pad padWith(String sample) =>
        Pad(padId: 'A1', note: 36, samplePath: 'samples/$sample');

    test('shows the sample name, not the file name', () {
      expect(padWith('kick.wav').sampleShortLabel, 'KICK');
      expect(padWith('snare.wav').sampleShortLabel, 'SNARE');
    });

    test('drum modifiers read the way they do on hardware', () {
      expect(padWith('hat_closed.wav').sampleShortLabel, 'CL HAT');
      expect(padWith('hat_open.wav').sampleShortLabel, 'OP HAT');
      expect(padWith('tom_floor.wav').sampleShortLabel, 'FLR TOM');
    });

    test('multi-word names are shortened rather than dropped', () {
      expect(padWith('crash_short.wav').sampleShortLabel, 'SHRT CRASH');
      expect(padWith('noise_sweep.wav').sampleShortLabel, 'NZ SWP');
    });

    test('an empty pad says so', () {
      expect(Pad(padId: 'A2', note: 37).sampleShortLabel, '--');
    });
  });
}

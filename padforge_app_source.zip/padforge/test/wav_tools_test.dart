// Unit tests for the pure-Dart WAV reading/trimming helpers used by the tape
// deck's looper. No plugins, no widgets -- these run anywhere.
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:padforge/tape/wav_tools.dart';

/// Builds a mono 16-bit WAV of [frames] frames where every sample equals its
/// own frame index, so a trimmed file's contents are easy to assert on.
Uint8List makeWav({
  int frames = 100,
  int sampleRate = 1000,
  int numChannels = 1,
  int bitsPerSample = 16,
}) {
  final bytesPerFrame = numChannels * (bitsPerSample ~/ 8);
  final dataLength = frames * bytesPerFrame;
  final header = buildWavHeader(
    sampleRate: sampleRate,
    numChannels: numChannels,
    bitsPerSample: bitsPerSample,
    dataLength: dataLength,
  );
  final out = Uint8List(header.length + dataLength);
  out.setRange(0, header.length, header);
  final view = ByteData.sublistView(out);
  for (var i = 0; i < frames; i++) {
    view.setInt16(header.length + i * 2, i, Endian.little);
  }
  return out;
}

/// Builds an 8-bit (unsigned) mono WAV, whose silence sits at 128 rather than
/// 0 -- the one format where padding can't just be zeroes.
Uint8List makeWav8({int frames = 100, int sampleRate = 1000}) {
  final header = buildWavHeader(
    sampleRate: sampleRate,
    numChannels: 1,
    bitsPerSample: 8,
    dataLength: frames,
  );
  final out = Uint8List(header.length + frames);
  out.setRange(0, header.length, header);
  out.fillRange(header.length, header.length + frames, 200);
  return out;
}

/// Builds a WAV whose every sample equals [value], for mixing tests.
Uint8List makeFlatWav({
  required int frames,
  required int value,
  int sampleRate = 1000,
  int numChannels = 1,
}) {
  final dataLength = frames * numChannels * 2;
  final header = buildWavHeader(
    sampleRate: sampleRate,
    numChannels: numChannels,
    bitsPerSample: 16,
    dataLength: dataLength,
  );
  final out = Uint8List(header.length + dataLength);
  out.setRange(0, header.length, header);
  final view = ByteData.sublistView(out);
  for (var i = 0; i < frames * numChannels; i++) {
    view.setInt16(header.length + i * 2, value, Endian.little);
  }
  return out;
}

/// Every 16-bit sample in [wav], interleaved as it is stored, so a mix can be
/// asserted on as a plain list of numbers.
List<int> samplesOf(Uint8List wav) {
  final info = readWavInfo(wav)!;
  final view = ByteData.sublistView(wav);
  return [
    for (var i = 0; i < info.dataLength ~/ 2; i++)
      view.getInt16(info.dataOffset + i * 2, Endian.little),
  ];
}

void main() {
  test('readWavInfo reads back what buildWavHeader wrote', () {
    final wav = makeWav(frames: 500, sampleRate: 44100);
    final info = readWavInfo(wav);

    expect(info, isNotNull);
    expect(info!.sampleRate, 44100);
    expect(info.numChannels, 1);
    expect(info.bitsPerSample, 16);
    expect(info.dataOffset, 44);
    expect(info.dataLength, 1000);
    expect(info.bytesPerFrame, 2);
  });

  test('readWavInfo rejects things that are not WAV files', () {
    expect(readWavInfo(Uint8List(0)), isNull);
    expect(readWavInfo(Uint8List.fromList(List<int>.filled(64, 0))), isNull);
  });

  test('duration is derived from the data length', () {
    // 1000 frames at 1000 Hz is exactly one second.
    final wav = makeWav(frames: 1000, sampleRate: 1000);
    expect(readWavInfo(wav)!.duration.inMilliseconds, 1000);
  });

  test('trimWav removes exactly the requested amount from the front', () {
    // 1000 Hz mono means 1 frame per millisecond, which makes the arithmetic
    // easy to check by hand.
    final wav = makeWav(frames: 1000, sampleRate: 1000);
    final trimmed = trimWav(wav, start: const Duration(milliseconds: 200));

    expect(trimmed, isNotNull);
    final info = readWavInfo(trimmed!)!;
    expect(info.sampleRate, 1000);
    expect(info.dataLength, 800 * 2);
    expect(info.duration.inMilliseconds, 800);

    // The first surviving sample should be the one that was at 200ms.
    final view = ByteData.sublistView(trimmed);
    expect(view.getInt16(info.dataOffset, Endian.little), 200);
  });

  test('trimWav also caps the length from the end', () {
    final wav = makeWav(frames: 1000, sampleRate: 1000);
    final trimmed = trimWav(
      wav,
      start: const Duration(milliseconds: 100),
      length: const Duration(milliseconds: 250),
    );

    final info = readWavInfo(trimmed!)!;
    expect(info.dataLength, 250 * 2);
    expect(info.duration.inMilliseconds, 250);

    final view = ByteData.sublistView(trimmed);
    expect(view.getInt16(info.dataOffset, Endian.little), 100);
    expect(view.getInt16(info.dataOffset + 249 * 2, Endian.little), 349);
  });

  test('trimming past the end of the audio yields a valid, empty WAV', () {
    final wav = makeWav(frames: 100, sampleRate: 1000);
    final trimmed = trimWav(wav, start: const Duration(seconds: 5));

    expect(trimmed, isNotNull);
    expect(trimmed!.length, 44);
    final info = readWavInfo(trimmed)!;
    expect(info.dataLength, 0);
    expect(info.duration, Duration.zero);
  });

  test('stereo trimming stays on frame boundaries', () {
    final wav = makeWav(frames: 400, sampleRate: 1000, numChannels: 2);
    final info = readWavInfo(wav)!;
    expect(info.bytesPerFrame, 4);

    final trimmed = trimWav(wav, start: const Duration(milliseconds: 50));
    final trimmedInfo = readWavInfo(trimmed!)!;
    expect(trimmedInfo.numChannels, 2);
    expect(trimmedInfo.dataLength % trimmedInfo.bytesPerFrame, 0);
    expect(trimmedInfo.dataLength, (400 - 50) * 4);
  });

  test('a data chunk claiming more bytes than exist is clamped to the file', () {
    final wav = makeWav(frames: 100, sampleRate: 1000);
    // Lie in the Subchunk2Size field: claim far more audio than is present.
    ByteData.sublistView(wav).setUint32(40, 999999, Endian.little);

    final info = readWavInfo(wav);
    expect(info, isNotNull);
    expect(info!.dataLength, 200);
  });

  // --- padWavWithSilence (the other half of quantising) -------------------

  test('padWavWithSilence extends a short take with silence', () {
    final wav = makeWav(frames: 900, sampleRate: 1000);
    final padded = padWavWithSilence(wav, targetLength: const Duration(seconds: 1));

    expect(padded, isNotNull);
    final info = readWavInfo(padded!)!;
    expect(info.dataLength, 1000 * 2);
    expect(info.duration.inMilliseconds, 1000);

    final view = ByteData.sublistView(padded);
    // The original audio survives untouched...
    expect(view.getInt16(info.dataOffset + 899 * 2, Endian.little), 899);
    // ...and everything after it is silence.
    expect(view.getInt16(info.dataOffset + 900 * 2, Endian.little), 0);
    expect(view.getInt16(info.dataOffset + 999 * 2, Endian.little), 0);
  });

  test('padWavWithSilence never shortens audio that is already long enough', () {
    final wav = makeWav(frames: 1000, sampleRate: 1000);
    final padded =
        padWavWithSilence(wav, targetLength: const Duration(milliseconds: 400));

    final info = readWavInfo(padded!)!;
    expect(info.dataLength, 1000 * 2);
    expect(info.duration.inMilliseconds, 1000);
  });

  test('padWavWithSilence pads 8-bit audio with 128, not 0', () {
    // 8-bit WAV is unsigned, so its silence is the midpoint of the range.
    final wav = makeWav8(frames: 100, sampleRate: 1000);
    final padded =
        padWavWithSilence(wav, targetLength: const Duration(milliseconds: 200));

    final info = readWavInfo(padded!)!;
    expect(info.bitsPerSample, 8);
    expect(info.dataLength, 200);
    expect(padded[info.dataOffset + 99], 200);
    expect(padded[info.dataOffset + 100], 128);
    expect(padded[info.dataOffset + 199], 128);
  });

  test('padWavWithSilence rejects things that are not WAV files', () {
    expect(padWavWithSilence(Uint8List(10), targetLength: Duration.zero), isNull);
  });

  test('trim-then-pad lands on exactly the quantised length either way', () {
    // This is what the looper actually does: cut off the "waiting to start"
    // portion, cap the end, then top up with silence. A take that ran long and
    // one that came up short must both end up the same length, to the byte.
    const target = Duration(seconds: 2); // one bar at 120bpm

    Uint8List quantise(Uint8List wav, Duration start) {
      final trimmed = trimWav(wav, start: start, length: target)!;
      return padWavWithSilence(trimmed, targetLength: target)!;
    }

    final long = quantise(makeWav(frames: 3000, sampleRate: 1000), const Duration(milliseconds: 500));
    final short = quantise(makeWav(frames: 1800, sampleRate: 1000), const Duration(milliseconds: 300));

    expect(readWavInfo(long)!.dataLength, 2000 * 2);
    expect(readWavInfo(short)!.dataLength, 2000 * 2);
    expect(readWavInfo(long)!.duration, target);
    expect(readWavInfo(short)!.duration, target);
  });

  // --- mixWavPair (the recorder's BOTH mode) -----------------------------

  test('mixWavPair sums two takes sample by sample', () {
    final a = makeFlatWav(frames: 10, value: 1000);
    final b = makeFlatWav(frames: 10, value: 2500);
    final mixed = mixWavPair(a, b);

    expect(mixed, isNotNull);
    final info = readWavInfo(mixed!)!;
    expect(info.numChannels, 1);
    expect(info.dataLength, 10 * 2);
    final view = ByteData.sublistView(mixed);
    expect(view.getInt16(info.dataOffset, Endian.little), 3500);
  });

  test('mixWavPair clips instead of wrapping around', () {
    final a = makeFlatWav(frames: 4, value: 30000);
    final b = makeFlatWav(frames: 4, value: 30000);
    final mixed = mixWavPair(a, b)!;
    final info = readWavInfo(mixed)!;
    final view = ByteData.sublistView(mixed);
    expect(view.getInt16(info.dataOffset, Endian.little), 32767);

    final c = makeFlatWav(frames: 4, value: -30000);
    final quiet = mixWavPair(c, c)!;
    expect(
      ByteData.sublistView(quiet).getInt16(readWavInfo(quiet)!.dataOffset, Endian.little),
      -32768,
    );
  });

  test('mixWavPair spreads a mono take across a stereo one and keeps the '
      'longer length', () {
    final stereo = makeFlatWav(frames: 8, value: 100, numChannels: 2);
    final mono = makeFlatWav(frames: 20, value: 50);
    final mixed = mixWavPair(stereo, mono)!;

    final info = readWavInfo(mixed)!;
    expect(info.numChannels, 2);
    expect(info.dataLength, 20 * 2 * 2);

    final view = ByteData.sublistView(mixed);
    // Inside the overlap both layers contribute, on both channels.
    expect(view.getInt16(info.dataOffset, Endian.little), 150);
    expect(view.getInt16(info.dataOffset + 2, Endian.little), 150);
    // Past the end of the stereo take only the mono one is left.
    expect(view.getInt16(info.dataOffset + 8 * 2 * 2, Endian.little), 50);
    expect(view.getInt16(info.dataOffset + 8 * 2 * 2 + 2, Endian.little), 50);
  });

  test('mixWavPair refuses takes that disagree about the sample rate', () {
    final a = makeFlatWav(frames: 4, value: 10, sampleRate: 44100);
    final b = makeFlatWav(frames: 4, value: 10, sampleRate: 22050);
    expect(mixWavPair(a, b), isNull);
    expect(mixWavPair(a, Uint8List(4)), isNull);
  });

  // --- mixWavIntoLoop (the looper's overdub) ------------------------------
  //
  // Every test here uses 1000 Hz mono, so one frame is exactly one millisecond
  // and an offset in milliseconds is an offset in samples. The loop is always
  // silent to start with, so whatever ends up in it came from the overlay.

  test('mixWavIntoLoop never changes the loop length, however long the overlay',
      () {
    final loop = makeFlatWav(frames: 10, value: 0);
    final short = mixWavIntoLoop(loop, makeFlatWav(frames: 3, value: 5),
        offset: Duration.zero)!;
    final long = mixWavIntoLoop(loop, makeFlatWav(frames: 250, value: 5),
        offset: Duration.zero)!;

    expect(readWavInfo(short)!.dataLength, 10 * 2);
    expect(readWavInfo(long)!.dataLength, 10 * 2);
    expect(readWavInfo(long)!.numChannels, 1);
    expect(readWavInfo(long)!.sampleRate, 1000);
  });

  test('mixWavIntoLoop drops the overlay in at the offset it is given', () {
    final loop = makeFlatWav(frames: 10, value: 0);
    final overlay = makeFlatWav(frames: 3, value: 100);
    final mixed = mixWavIntoLoop(loop, overlay,
        offset: const Duration(milliseconds: 4))!;

    expect(samplesOf(mixed), [0, 0, 0, 0, 100, 100, 100, 0, 0, 0]);
  });

  test('mixWavIntoLoop wraps an overlay that runs off the end of the loop', () {
    // Engaged three quarters of the way round: part of the layer lands at the
    // end of the loop and the rest carries on at the beginning.
    final loop = makeFlatWav(frames: 8, value: 0);
    final overlay = makeFlatWav(frames: 4, value: 7);
    final mixed = mixWavIntoLoop(loop, overlay,
        offset: const Duration(milliseconds: 6))!;

    expect(samplesOf(mixed), [7, 7, 0, 0, 0, 0, 7, 7]);
  });

  test('mixWavIntoLoop keeps going round when the overlay is longer than the '
      'loop, summing onto what it already laid down', () {
    final loop = makeFlatWav(frames: 4, value: 0);
    // Two and a half laps of the loop.
    final overlay = makeFlatWav(frames: 10, value: 10);
    final mixed = mixWavIntoLoop(loop, overlay, offset: Duration.zero)!;

    // Frames 0 and 1 were passed three times, 2 and 3 twice.
    expect(samplesOf(mixed), [30, 30, 20, 20]);
  });

  test('an offset past the end of the loop wraps round rather than being lost',
      () {
    final loop = makeFlatWav(frames: 5, value: 0);
    final overlay = makeFlatWav(frames: 2, value: 3);
    final mixed = mixWavIntoLoop(loop, overlay,
        offset: const Duration(milliseconds: 11))!;

    // 11ms into a 5ms loop is 1ms into the loop.
    expect(samplesOf(mixed), [0, 3, 3, 0, 0]);
  });

  test('mixWavIntoLoop clips instead of wrapping around the 16-bit range', () {
    final loud = makeFlatWav(frames: 4, value: 30000);
    final mixed = mixWavIntoLoop(loud, loud, offset: Duration.zero)!;
    expect(samplesOf(mixed), [32767, 32767, 32767, 32767]);

    final quiet = makeFlatWav(frames: 4, value: -30000);
    final quieter = mixWavIntoLoop(quiet, quiet, offset: Duration.zero)!;
    expect(samplesOf(quieter), [-32768, -32768, -32768, -32768]);
  });

  test('mixWavIntoLoop leaves the loop it was given untouched', () {
    // UNDO depends on the previous master surviving the mix intact.
    final loop = makeFlatWav(frames: 6, value: 40);
    final before = Uint8List.fromList(loop);
    mixWavIntoLoop(loop, makeFlatWav(frames: 6, value: 5), offset: Duration.zero);
    expect(loop, before);
  });

  test('a mono overlay lands on every channel of a stereo loop', () {
    final loop = makeFlatWav(frames: 4, value: 0, numChannels: 2);
    final overlay = makeFlatWav(frames: 2, value: 60);
    final mixed = mixWavIntoLoop(loop, overlay,
        offset: const Duration(milliseconds: 1))!;

    final info = readWavInfo(mixed)!;
    expect(info.numChannels, 2);
    expect(info.dataLength, 4 * 2 * 2);
    // Frames 1 and 2, both channels.
    expect(samplesOf(mixed), [0, 0, 60, 60, 60, 60, 0, 0]);
  });

  test('mixWavIntoLoop refuses input it cannot line up', () {
    final loop = makeFlatWav(frames: 4, value: 0, sampleRate: 44100);
    final other = makeFlatWav(frames: 4, value: 1, sampleRate: 22050);
    expect(mixWavIntoLoop(loop, other, offset: Duration.zero), isNull);
    expect(mixWavIntoLoop(loop, Uint8List(8), offset: Duration.zero), isNull);
    expect(mixWavIntoLoop(Uint8List(8), loop, offset: Duration.zero), isNull);
    // A loop with no audio at all has nothing to wrap around.
    expect(
      mixWavIntoLoop(makeFlatWav(frames: 0, value: 0), loop, offset: Duration.zero),
      isNull,
    );
  });

  test('an empty overlay leaves the loop exactly as it was', () {
    final loop = makeFlatWav(frames: 4, value: 11);
    final mixed = mixWavIntoLoop(loop, makeFlatWav(frames: 0, value: 0),
        offset: const Duration(milliseconds: 2))!;
    expect(samplesOf(mixed), [11, 11, 11, 11]);
  });

  // --- buildSilentWav -----------------------------------------------------

  test('buildSilentWav is a readable, silent file of exactly the right length',
      () {
    final silence = buildSilentWav(
      sampleRate: 1000,
      numChannels: 1,
      length: const Duration(milliseconds: 250),
    );
    final info = readWavInfo(silence)!;
    expect(info.sampleRate, 1000);
    expect(info.bitsPerSample, 16);
    expect(info.dataLength, 250 * 2);
    expect(info.duration.inMilliseconds, 250);
    expect(samplesOf(silence).every((s) => s == 0), isTrue);
  });

  test('an overdub onto a silent bed lands exactly where it was played', () {
    // This is what happens when a mic layer is the first audio the loop has
    // had: a silent bed of the loop's length, then the layer mixed onto it.
    final bed = buildSilentWav(
      sampleRate: 1000,
      numChannels: 1,
      length: const Duration(milliseconds: 8),
    );
    final mixed = mixWavIntoLoop(bed, makeFlatWav(frames: 3, value: 9),
        offset: const Duration(milliseconds: 7))!;
    expect(samplesOf(mixed), [9, 9, 0, 0, 0, 0, 0, 9]);
  });

  test('wavFramesForDuration rounds to whole frames and floors at zero', () {
    expect(wavFramesForDuration(const Duration(seconds: 1), 44100), 44100);
    expect(wavFramesForDuration(const Duration(milliseconds: 500), 1000), 500);
    expect(wavFramesForDuration(Duration.zero, 44100), 0);
    expect(wavFramesForDuration(const Duration(seconds: -1), 44100), 0);
    expect(wavFramesForDuration(const Duration(seconds: 1), 0), 0);
  });

  test('wavBytesForDuration rounds to whole frames', () {
    expect(wavBytesForDuration(const Duration(seconds: 1), 44100, 4), 44100 * 4);
    expect(wavBytesForDuration(Duration.zero, 44100, 4), 0);
    expect(wavBytesForDuration(const Duration(seconds: -1), 44100, 4), 0);
    expect(wavBytesForDuration(const Duration(seconds: 1), 0, 4), 0);
  });
}

// Guards the two strings in this app that cannot be allowed to drift.
//
// 1. The version printed on the About screen is a Dart constant, because a
//    Flutter app cannot read `pubspec.yaml` at runtime and this project is
//    not adding `package_info_plus` to do it. A constant copy of a number
//    that lives somewhere else is exactly the kind of thing that silently
//    goes stale, so this test reads `pubspec.yaml` off disk and fails the
//    build the moment the two disagree.
//
// 2. The copyright line is contractual. It is asserted here character by
//    character, including the copyright sign, so a well-meaning edit cannot
//    quietly reword it.
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:padforge/app_info.dart';

void main() {
  test('kAppVersion matches the version: field in pubspec.yaml', () {
    // `flutter test` runs with the package root as the working directory.
    final pubspec = File('pubspec.yaml');
    expect(pubspec.existsSync(), isTrue,
        reason: 'expected to run from the package root');

    final match = RegExp(r'^version:\s*(\S+)\s*$', multiLine: true)
        .firstMatch(pubspec.readAsStringSync());
    expect(match, isNotNull, reason: 'pubspec.yaml has no version: line');

    // pubspec carries "1.0.0+1"; the About screen shows the part before the
    // build number.
    final marketingVersion = match!.group(1)!.split('+').first;
    expect(
      kAppVersion,
      marketingVersion,
      reason: 'lib/app_info.dart and pubspec.yaml must be bumped together',
    );
  });

  test('the copyright line is exact', () {
    expect(kAppCopyright, 'Deestech © 2026');
    expect(kAppCopyright.codeUnitAt(9), 0xA9);
    expect(kAppCopyright.endsWith('2026'), isTrue);
  });

  test('the product name and tagline are the ones the store listing uses', () {
    expect(kAppName, 'PadForge');
    expect(kAppTagline, 'MPC-style sampler for the Akai MPD218');
    expect(kAppVendor, 'Deestech');
  });
}

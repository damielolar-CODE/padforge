// Unit tests for the looper's pure-Dart core: the playback scheduler and the
// quantise maths. No plugins, no widgets, no audio hardware -- these run
// anywhere `flutter test` runs, which is the only way any of this can be
// verified without a phone in hand.
//
// What they are actually protecting:
//
//  * every recorded hit fires **exactly once per pass**, in order, however
//    badly the timer that drives playback stutters (the v4 bug: a late tick
//    could skip a whole pass, or fire a hit sitting near the loop seam twice);
//  * committing an overdub layer mid-pass does not replay the hits the player
//    just performed live;
//  * quantise snaps to the right grid, wraps a hit that lands on the end of
//    the loop round to its start, and never loses the raw timing.
import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:padforge/tape/loop_events.dart';

LoopPadEvent hit(String padId, int offsetMs, {int layer = 0}) =>
    LoopPadEvent(padId: padId, offsetMs: offsetMs, velocity: 100, layer: layer);

/// Runs [scheduler] across [passes] loop passes with ticks that jitter between
/// [minStep] and [maxStep] milliseconds, and returns everything that fired, in
/// order, tagged with the pass it fired during.
List<String> runJittery(
  LoopScheduler scheduler, {
  required int passes,
  required int minStep,
  required int maxStep,
  int seed = 7,
}) {
  final random = Random(seed);
  final fired = <String>[];
  final loopMs = scheduler.loopMs;
  final end = loopMs * passes;
  var now = 0;
  while (now <= end) {
    scheduler.advanceTo(now, (event) {
      fired.add('${event.padId}@${event.offsetMs}');
    });
    now += minStep + random.nextInt(maxStep - minStep + 1);
  }
  // One final catch-up tick right on the end, so the last pass is complete.
  scheduler.advanceTo(end, (event) => fired.add('${event.padId}@${event.offsetMs}'));
  return fired;
}

void main() {
  group('LoopScheduler', () {
    test('fires every hit exactly once per pass, in order, with steady ticks', () {
      final events = [hit('A1', 0), hit('A3', 250), hit('A7', 500), hit('A3', 750)];
      final scheduler = LoopScheduler()..reset(loopMs: 1000, events: events);

      final fired = <String>[];
      for (var now = 0; now <= 4000; now += 10) {
        scheduler.advanceTo(now, (e) => fired.add('${e.padId}@${e.offsetMs}'));
      }

      // 4 passes fully elapsed plus the downbeat of the fifth.
      expect(fired.length, 4 * 4 + 1);
      expect(fired.take(4).toList(), ['A1@0', 'A3@250', 'A7@500', 'A3@750']);
      expect(fired.skip(4).take(4).toList(), ['A1@0', 'A3@250', 'A7@500', 'A3@750']);
      expect(fired.last, 'A1@0');
    });

    test('jittery ticks still fire every hit exactly once per pass', () {
      final events = [
        hit('A1', 0),
        hit('A2', 1),
        hit('A5', 333),
        hit('A9', 500),
        hit('A13', 995), // deliberately a hair before the seam
      ];
      const passes = 12;
      final scheduler = LoopScheduler()..reset(loopMs: 1000, events: events);

      // 5-45ms between ticks: worse than a phone dropping frames.
      final fired = runJittery(scheduler, passes: passes, minStep: 5, maxStep: 45);

      final counts = <String, int>{};
      for (final entry in fired) {
        counts[entry] = (counts[entry] ?? 0) + 1;
      }
      for (final event in events) {
        final key = '${event.padId}@${event.offsetMs}';
        // 12 passes plus the hits of the final boundary pass for offset 0/1.
        expect(counts[key], greaterThanOrEqualTo(passes),
            reason: '$key fired ${counts[key]} times, expected >= $passes');
        expect(counts[key], lessThanOrEqualTo(passes + 1),
            reason: '$key fired ${counts[key]} times, expected <= ${passes + 1}');
      }

      // Order within each pass is preserved.
      final order = fired.map((e) => e.split('@').first).toList();
      for (var i = 0; i + 5 <= order.length - 5; i += 5) {
        final window = order.sublist(i, i + 5);
        if (window.first != 'A1') continue;
        expect(window, ['A1', 'A2', 'A5', 'A9', 'A13']);
      }
    });

    test('a tick later than a whole pass does not fire a burst', () {
      final events = [for (var i = 0; i < 16; i++) hit('A$i', i * 60)];
      final scheduler = LoopScheduler()..reset(loopMs: 1000, events: events);

      var fired = 0;
      scheduler.advanceTo(0, (_) => fired++); // downbeat
      expect(fired, 1);

      fired = 0;
      // The app was suspended for five whole loops.
      scheduler.advanceTo(5000, (_) => fired++);
      expect(fired, lessThanOrEqualTo(events.length),
          reason: 'at most one loop pass worth of hits may be caught up');
    });

    test('a short loop skipped entirely by one tick still plays', () {
      final events = [hit('A1', 0), hit('A2', 100)];
      final scheduler = LoopScheduler()..reset(loopMs: 200, events: events);

      final fired = <String>[];
      // 250ms between ticks on a 200ms loop: every tick spans a seam.
      for (var now = 0; now <= 2000; now += 250) {
        scheduler.advanceTo(now, (e) => fired.add(e.padId));
      }
      // 2000ms is 10 passes; every hit must still be heard about once a pass
      // rather than the whole pass being dropped.
      expect(fired.length, greaterThanOrEqualTo(16));
      expect(fired.where((p) => p == 'A1').length, greaterThanOrEqualTo(8));
      expect(fired.where((p) => p == 'A2').length, greaterThanOrEqualTo(8));
    });

    test('committing a layer mid-pass does not replay hits already played', () {
      final base = [hit('A1', 0), hit('A1', 500)];
      final scheduler = LoopScheduler()..reset(loopMs: 1000, events: base);

      final fired = <String>[];
      for (var now = 0; now <= 700; now += 10) {
        scheduler.advanceTo(now, (e) => fired.add('${e.padId}@${e.offsetMs}'));
      }
      expect(fired, ['A1@0', 'A1@500']);

      // The player has just laid an overdub down live at 200ms and 600ms; both
      // are behind the playhead (at 700ms) and must not be heard again until
      // the loop comes round.
      fired.clear();
      scheduler.setEvents([
        hit('A1', 0),
        hit('A5', 200, layer: 1),
        hit('A1', 500),
        hit('A5', 600, layer: 1),
      ]);
      for (var now = 710; now <= 990; now += 10) {
        scheduler.advanceTo(now, (e) => fired.add('${e.padId}@${e.offsetMs}'));
      }
      expect(fired, isEmpty);

      // ...and on the next pass everything plays, in order.
      for (var now = 1000; now <= 1990; now += 10) {
        scheduler.advanceTo(now, (e) => fired.add('${e.padId}@${e.offsetMs}'));
      }
      expect(fired, ['A1@0', 'A5@200', 'A1@500', 'A5@600']);
    });

    test('a hit exactly on the downbeat fires on the very first tick', () {
      final scheduler = LoopScheduler()..reset(loopMs: 500, events: [hit('A1', 0)]);
      final fired = <String>[];
      scheduler.advanceTo(0, (e) => fired.add(e.padId));
      expect(fired, ['A1']);
    });

    test('an empty loop and a zero-length loop are harmless', () {
      final scheduler = LoopScheduler()..reset(loopMs: 0);
      var fired = 0;
      scheduler.advanceTo(1000, (_) => fired++);
      expect(fired, 0);

      scheduler.reset(loopMs: 1000);
      scheduler.advanceTo(5000, (_) => fired++);
      expect(fired, 0);
    });
  });

  group('quantise', () {
    // 120 BPM: one bar = 2,000,000us, one 1/16 = 125ms, one 1/8 = 250ms.
    const barUs = 2000000;

    test('snaps to the nearest sixteenth', () {
      expect(
        snapOffsetMs(offsetMs: 130, barUs: barUs, grid: QuantizeGrid.sixteenth, loopMs: 2000),
        125,
      );
      // Half a step (62.5ms) is the tipping point: 62 rounds back to the
      // downbeat, 63 rounds forward to the first sixteenth.
      expect(
        snapOffsetMs(offsetMs: 62, barUs: barUs, grid: QuantizeGrid.sixteenth, loopMs: 2000),
        0,
      );
      expect(
        snapOffsetMs(offsetMs: 63, barUs: barUs, grid: QuantizeGrid.sixteenth, loopMs: 2000),
        125,
      );
      expect(
        snapOffsetMs(offsetMs: 0, barUs: barUs, grid: QuantizeGrid.sixteenth, loopMs: 2000),
        0,
      );
    });

    test('coarser grids snap further', () {
      expect(
        snapOffsetMs(offsetMs: 130, barUs: barUs, grid: QuantizeGrid.eighth, loopMs: 2000),
        250,
      );
      expect(
        snapOffsetMs(offsetMs: 130, barUs: barUs, grid: QuantizeGrid.quarter, loopMs: 2000),
        0,
      );
    });

    test('a hit just before the end wraps round to the downbeat', () {
      // 1990ms on a 2000ms loop snaps to 2000 -- which is the top of the next
      // pass, i.e. position 0. It must not be dropped (the v4 behaviour) and it
      // must not sit outside the loop.
      final snapped = snapOffsetMs(
        offsetMs: 1990,
        barUs: barUs,
        grid: QuantizeGrid.sixteenth,
        loopMs: 2000,
      );
      expect(snapped, 0);
    });

    test('effectiveOffsetMs wraps overshoot and honours the quantise switch', () {
      // Played 40ms past the end of the loop: wraps to 40ms in.
      expect(
        effectiveOffsetMs(
          rawOffsetMs: 2040,
          loopMs: 2000,
          barUs: barUs,
          quantize: false,
          grid: QuantizeGrid.sixteenth,
        ),
        40,
      );
      // Same hit, quantised: 40ms snaps back to the downbeat.
      expect(
        effectiveOffsetMs(
          rawOffsetMs: 2040,
          loopMs: 2000,
          barUs: barUs,
          quantize: true,
          grid: QuantizeGrid.sixteenth,
        ),
        0,
      );
    });

    test('the raw timing survives being quantised', () {
      final played = hit('A1', 137);
      final snapped = played.withOffset(snapOffsetMs(
        offsetMs: played.rawOffsetMs,
        barUs: barUs,
        grid: QuantizeGrid.sixteenth,
        loopMs: 2000,
      ));
      expect(snapped.offsetMs, 125);
      expect(snapped.rawOffsetMs, 137, reason: 'quantise must be non-destructive');

      // Turning quantise off restores the human feel exactly.
      final unquantised = snapped.withOffset(snapped.rawOffsetMs);
      expect(unquantised.offsetMs, 137);
    });

    test('every hit of a quantised bar lands on a grid line', () {
      const grid = QuantizeGrid.sixteenth;
      const stepMs = 125; // one sixteenth at 120 BPM
      final random = Random(3);
      for (var i = 0; i < 200; i++) {
        final raw = random.nextInt(2000);
        final snapped = snapOffsetMs(
          offsetMs: raw,
          barUs: barUs,
          grid: grid,
          loopMs: 2000,
        );
        expect(snapped % stepMs, 0, reason: '$raw snapped to $snapped');
        expect(snapped, lessThan(2000));
        // Nothing moves by more than half a step -- measured the short way
        // round the loop, since a hit near the end snaps forward to 0.
        final direct = (snapped - raw).abs();
        final shortest = min(direct, 2000 - direct);
        expect(shortest, lessThanOrEqualTo(stepMs));
      }
    });
  });
}

// Unit tests for the global controller map -- the v6 architectural fix.
//
// Everything here is pure Dart: no widgets, no plugins, no MIDI hardware.
// That matters, because the whole reason this class exists is that PadForge
// shipped two *guesses* at what note numbers an MPD218 sends and both were
// wrong on the user's actual unit. The behaviour that replaces the guessing
// therefore has to be provable without a device in hand.
//
// What these protect:
//
//  * resolution order -- the controller map beats the kit, and the kit is the
//    fallback for any note the map says nothing about;
//  * the no-ghost-trigger rule -- a pad the map has claimed must not *also*
//    still answer to its kit default;
//  * both duplicate invariants (one note -> one pad, one pad -> one note);
//  * a lossless save/load round trip, and a load that cannot throw whatever
//    rubbish it is handed;
//  * clearing, per-pad and wholesale.
import 'package:flutter_test/flutter_test.dart';
import 'package:padforge/midi/controller_map.dart';
import 'package:padforge/models/kit.dart';

void main() {
  group('resolution order', () {
    test('an empty map always falls back to the kit', () {
      final map = ControllerMap();
      expect(map.isEmpty, isTrue);
      expect(map.resolve(36, kitPadId: 'A1'), 'A1');
      expect(map.resolve(51, kitPadId: 'A16'), 'A16');
      // Nothing in the map, nothing in the kit: nothing happens.
      expect(map.resolve(99, kitPadId: null), isNull);
    });

    test('the controller map wins over the kit', () {
      final map = ControllerMap();
      map.assign(42, 'A1');
      // The hardware sends 42 for the pad the kit thinks is A7.
      expect(map.resolve(42, kitPadId: 'A7'), 'A1');
    });

    test('notes the map says nothing about still reach the kit', () {
      final map = ControllerMap();
      map.assign(42, 'A1');
      // A5 is untouched by the map, so its kit note still works.
      expect(map.resolve(40, kitPadId: 'A5'), 'A5');
    });

    test('a claimed pad does not also answer to its kit default', () {
      final map = ControllerMap();
      map.assign(42, 'A1');
      // 36 is A1's kit default. Letting it through would mean two different
      // notes firing A1 -- exactly the ghost trigger this rule exists to stop.
      expect(map.resolve(36, kitPadId: 'A1'), isNull);
    });

    test('a real scrambled controller maps cleanly onto a stock kit', () {
      // The failure that started all this: pads 1 and 2 line up and the rest
      // do not, which is only possible if the notes are not a contiguous run.
      const hardware = <int, int>{
        1: 36, 2: 37, 3: 40, 4: 41,
        5: 38, 6: 39, 7: 42, 8: 43,
        9: 44, 10: 45, 11: 48, 12: 49,
        13: 46, 14: 47, 15: 50, 16: 51,
      };
      final kit = Kit.blank(name: 'T', folderName: 't');
      final map = ControllerMap();
      hardware.forEach((padNumber, note) => map.assign(note, 'A$padNumber'));

      // Every hardware pad now reaches the pad with the same number, whatever
      // the kit's own note happens to be.
      hardware.forEach((padNumber, note) {
        final kitPad = kit.padByNote(note);
        expect(map.resolve(note, kitPadId: kitPad?.padId), 'A$padNumber');
      });
    });
  });

  group('duplicate handling', () {
    test('assigning a note that was elsewhere moves it', () {
      final map = ControllerMap();
      map.assign(42, 'A1');
      map.assign(42, 'A2');
      expect(map.padIdForNote(42), 'A2');
      expect(map.noteForPad('A1'), isNull);
      expect(map.noteForPad('A2'), 42);
      expect(map.length, 1);
    });

    test('assigning a pad that already had a note releases the old note', () {
      final map = ControllerMap();
      map.assign(42, 'A1');
      map.assign(50, 'A1');
      expect(map.padIdForNote(42), isNull);
      expect(map.padIdForNote(50), 'A1');
      expect(map.noteForPad('A1'), 50);
      expect(map.length, 1);
    });

    test('re-assigning the identical pairing is a no-op', () {
      final map = ControllerMap();
      map.assign(42, 'A1');
      map.assign(42, 'A1');
      expect(map.length, 1);
      expect(map.padIdForNote(42), 'A1');
      expect(map.noteForPad('A1'), 42);
    });

    test('a swap between two pads leaves no orphan', () {
      final map = ControllerMap();
      map.assign(40, 'A1');
      map.assign(41, 'A2');
      // The user re-runs the wizard and hits them the other way round.
      map.assign(41, 'A1');
      map.assign(40, 'A2');
      expect(map.entries, <int, String>{41: 'A1', 40: 'A2'});
      expect(map.length, 2);
    });
  });

  group('serialization', () {
    test('round trips losslessly', () {
      final original = ControllerMap();
      for (var i = 0; i < 16; i++) {
        original.assign(40 + i, 'A${i + 1}');
      }
      original.assign(7, 'C16');

      final restored = ControllerMap.fromJsonString(original.toJsonString());
      expect(restored.length, original.length);
      expect(restored.entries, original.entries);
      expect(restored.noteForPad('C16'), 7);
      expect(restored.padIdForNote(55), 'A16');
    });

    test('the stored shape is the compact one we document', () {
      final map = ControllerMap();
      map.assign(36, 'A1');
      expect(map.toJsonString(), '{"v":1,"map":{"36":"A1"}}');
    });

    test('loading replaces whatever was there before', () {
      final map = ControllerMap();
      map.assign(99, 'B4');
      map.loadJsonString('{"v":1,"map":{"36":"A1"}}');
      expect(map.length, 1);
      expect(map.noteForPad('B4'), isNull);
      expect(map.padIdForNote(36), 'A1');
    });

    test('rubbish input leaves an empty map rather than throwing', () {
      for (final source in <String?>[
        null,
        '',
        'not json at all',
        '[]',
        '{}',
        '{"v":1}',
        '{"v":1,"map":[]}',
        '{"v":1,"map":{"notanumber":"A1"}}',
        '{"v":1,"map":{"36":42}}',
        '{"v":1,"map":{"36":""}}',
        '{"v":1,"map":{"-1":"A1"}}',
        '{"v":1,"map":{"128":"A1"}}',
      ]) {
        final map = ControllerMap.fromJsonString(source);
        expect(map.isEmpty, isTrue, reason: 'source was: $source');
      }
    });

    test('a good entry alongside a bad one still loads', () {
      final map = ControllerMap.fromJsonString(
        '{"v":1,"map":{"36":"A1","999":"A2","37":"A3"}}',
      );
      expect(map.length, 2);
      expect(map.padIdForNote(36), 'A1');
      expect(map.padIdForNote(37), 'A3');
    });

    test('an empty map serializes and reloads as empty', () {
      final map = ControllerMap();
      expect(map.toJsonString(), '{"v":1,"map":{}}');
      expect(ControllerMap.fromJsonString(map.toJsonString()).isEmpty, isTrue);
    });
  });

  group('clearing', () {
    test('clearing one pad puts that pad back on its kit note', () {
      final map = ControllerMap();
      map.assign(42, 'A1');
      map.assign(43, 'A2');

      map.clearPad('A1');
      expect(map.hasPad('A1'), isFalse);
      expect(map.padIdForNote(42), isNull);
      // ...and the kit fallback is live again for A1.
      expect(map.resolve(36, kitPadId: 'A1'), 'A1');
      // A2 is untouched.
      expect(map.resolve(43, kitPadId: null), 'A2');
    });

    test('clearing a pad that was never mapped is harmless', () {
      final map = ControllerMap();
      map.assign(42, 'A1');
      map.clearPad('C9');
      expect(map.length, 1);
    });

    test('clearing a note works from the note side too', () {
      final map = ControllerMap();
      map.assign(42, 'A1');
      map.clearNote(42);
      expect(map.isEmpty, isTrue);
      expect(map.noteForPad('A1'), isNull);
    });

    test('clearing everything returns the whole app to kit defaults', () {
      final map = ControllerMap();
      for (var i = 0; i < 16; i++) {
        map.assign(60 + i, 'A${i + 1}');
      }
      map.clear();
      expect(map.isEmpty, isTrue);
      expect(map.length, 0);
      final kit = Kit.blank(name: 'T', folderName: 't');
      for (final pad in kit.padsForBank('A')) {
        expect(map.resolve(pad.note, kitPadId: pad.padId), pad.padId);
      }
    });

    test('replaceAll swaps the whole map in one go', () {
      final map = ControllerMap();
      map.assign(1, 'A1');
      map.replaceAll(<int, String>{60: 'B1', 61: 'B2'});
      expect(map.length, 2);
      expect(map.padIdForNote(1), isNull);
      expect(map.padIdForNote(60), 'B1');
    });
  });

  group('reporting', () {
    test('describeLines is sorted by note and reads plainly', () {
      final map = ControllerMap();
      map.assign(50, 'A3');
      map.assign(36, 'A1');
      expect(map.describeLines(), ['note 36 -> A1', 'note 50 -> A3']);
    });

    test('entries is a read-only view', () {
      final map = ControllerMap();
      map.assign(36, 'A1');
      expect(() => map.entries[37] = 'A2', throwsUnsupportedError);
    });
  });
}

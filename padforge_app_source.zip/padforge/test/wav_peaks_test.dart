// Unit tests for the waveform display's maths: reducing a WAV to a peak
// envelope, re-bucketing that envelope onto however many pixel columns the
// phone gave the panel, and the drawing gain that keeps a quiet take visible.
//
// All pure Dart -- no widgets, no plugins, no audio device. These are the
// pieces of the v7 waveform rework that can be wrong in a way you cannot see by
// looking at the screen (a peak silently dropped when the strip is narrower
// than the bucket count looks exactly like audio that was never recorded).
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:padforge/tape/wav_tools.dart';

/// A mono 16-bit WAV whose sample values come from [valueAt].
Uint8List makeSignal(int frames, int Function(int frame) valueAt,
    {int sampleRate = 1000, int numChannels = 1}) {
  final dataLength = frames * numChannels * 2;
  final header = buildWavHeader(
    sampleRate: sampleRate,
    numChannels: numChannels,
    bitsPerSample: 16,
    dataLength: dataLength,
  );
  final out = Uint8List(header.length + dataLength);
  out.setRange(0, header.length, header);
  final view = ByteData.sublistView(out);
  for (var frame = 0; frame < frames; frame++) {
    for (var channel = 0; channel < numChannels; channel++) {
      view.setInt16(
        header.length + (frame * numChannels + channel) * 2,
        valueAt(frame),
        Endian.little,
      );
    }
  }
  return out;
}

WavPeaks peaksOf(List<double> mins, List<double> maxs) =>
    WavPeaks(mins: mins, maxs: maxs);

void main() {
  group('computeWavPeaks', () {
    test('reduces audio to the requested number of buckets', () {
      final wav = makeSignal(1000, (f) => f.isEven ? 16384 : -16384);
      final peaks = computeWavPeaks(wav, buckets: 50);
      expect(peaks, isNotNull);
      expect(peaks!.length, 50);
      expect(peaks.mins.length, 50);
      expect(peaks.maxs.length, 50);
    });

    test('finds the real minimum and maximum in every bucket', () {
      // Full-scale square wave: every bucket must show +/- half scale.
      final wav = makeSignal(400, (f) => f.isEven ? 16384 : -16384);
      final peaks = computeWavPeaks(wav, buckets: 8)!;
      for (var i = 0; i < peaks.length; i++) {
        expect(peaks.maxs[i], closeTo(0.5, 0.001));
        expect(peaks.mins[i], closeTo(-0.5, 0.001));
      }
    });

    test('silence gives a flat envelope rather than null', () {
      final peaks = computeWavPeaks(makeSignal(200, (_) => 0), buckets: 10)!;
      expect(peaks.isEmpty, isFalse);
      expect(peaks.mins.every((v) => v == 0), isTrue);
      expect(peaks.maxs.every((v) => v == 0), isTrue);
      expect(peaks.peakAmplitude, 0);
    });

    test('rejects what it cannot read', () {
      expect(computeWavPeaks(Uint8List(4)), isNull);
      expect(computeWavPeaks(makeSignal(10, (_) => 0), buckets: 0), isNull);
      // No audio at all in the file.
      expect(computeWavPeaks(makeSignal(0, (_) => 0), buckets: 8), isNull);
    });

    test('peakAmplitude is the loudest excursion either way', () {
      final quiet = computeWavPeaks(makeSignal(200, (_) => 3276), buckets: 4)!;
      expect(quiet.peakAmplitude, closeTo(0.1, 0.001));
      final negative = computeWavPeaks(makeSignal(200, (_) => -16384), buckets: 4)!;
      expect(negative.peakAmplitude, closeTo(0.5, 0.001));
    });
  });

  group('resampleWavPeaks', () {
    test('narrowing keeps every peak instead of skipping past it', () {
      // One loud bucket in the middle of 100 quiet ones. Sampling the nearest
      // bucket per column would lose it about four times out of five; taking
      // the min/max of the range it falls in cannot.
      final mins = List<double>.filled(100, -0.05);
      final maxs = List<double>.filled(100, 0.05);
      mins[37] = -0.9;
      maxs[37] = 0.9;

      final columns = resampleWavPeaks(peaksOf(mins, maxs), 20);
      expect(columns.length, 20);
      expect(columns.maxs.reduce((a, b) => a > b ? a : b), closeTo(0.9, 0.0001));
      expect(columns.mins.reduce((a, b) => a < b ? a : b), closeTo(-0.9, 0.0001));
      // ...and it lands in the column that actually covers bucket 37.
      expect(columns.maxs[37 * 20 ~/ 100], closeTo(0.9, 0.0001));
    });

    test('every column is covered exactly once, in order', () {
      final mins = List<double>.generate(12, (i) => -i.toDouble());
      final maxs = List<double>.generate(12, (i) => i.toDouble());
      final columns = resampleWavPeaks(peaksOf(mins, maxs), 4);
      expect(columns.length, 4);
      // Buckets 0-2, 3-5, 6-8, 9-11.
      expect(columns.maxs, [2.0, 5.0, 8.0, 11.0]);
      expect(columns.mins, [-2.0, -5.0, -8.0, -11.0]);
    });

    test('widening repeats buckets and never invents a value', () {
      final source = peaksOf([-0.2, -0.4], [0.2, 0.4]);
      final columns = resampleWavPeaks(source, 6);
      expect(columns.length, 6);
      expect(columns.maxs, [0.2, 0.2, 0.2, 0.4, 0.4, 0.4]);
      expect(columns.mins, [-0.2, -0.2, -0.2, -0.4, -0.4, -0.4]);
    });

    test('one column collapses the whole envelope', () {
      final columns = resampleWavPeaks(peaksOf([-0.1, -0.7, -0.3], [0.1, 0.6, 0.3]), 1);
      expect(columns.length, 1);
      expect(columns.mins.first, closeTo(-0.7, 0.0001));
      expect(columns.maxs.first, closeTo(0.6, 0.0001));
    });

    test('same width is the identity', () {
      final source = peaksOf([-0.1, -0.2, -0.3], [0.4, 0.5, 0.6]);
      final columns = resampleWavPeaks(source, 3);
      expect(columns.mins, source.mins);
      expect(columns.maxs, source.maxs);
    });

    test('degenerate inputs give an empty envelope, never a crash', () {
      expect(resampleWavPeaks(peaksOf([-0.1], [0.1]), 0).isEmpty, isTrue);
      expect(resampleWavPeaks(peaksOf([-0.1], [0.1]), -5).isEmpty, isTrue);
      expect(resampleWavPeaks(const WavPeaks(mins: [], maxs: []), 10).isEmpty, isTrue);
    });

    test('a real envelope survives a phone-sized strip', () {
      // 240 buckets (what the deck computes) onto a 296dp panel and back down
      // to a 180dp one: the loudest peak is still the loudest peak.
      final wav = makeSignal(48000, (f) => f == 24000 ? 32000 : (f.isEven ? 800 : -800));
      final peaks = computeWavPeaks(wav)!;
      for (final width in [296, 180, 64, 1000]) {
        final columns = resampleWavPeaks(peaks, width);
        expect(columns.length, width);
        final loudest = columns.maxs.reduce((a, b) => a > b ? a : b);
        expect(loudest, greaterThan(0.9),
            reason: 'the transient must survive a $width-column strip');
      }
    });
  });

  group('envelopeDisplayGain', () {
    test('leaves a loud take alone', () {
      expect(envelopeDisplayGain(1.0), 1.0);
      expect(envelopeDisplayGain(0.95), 1.0);
    });

    test('lifts a quiet take towards full scale', () {
      expect(envelopeDisplayGain(0.5), closeTo(1.9, 0.001));
      expect(envelopeDisplayGain(0.25), closeTo(3.8, 0.001));
    });

    test('never amplifies near-silence into a wall', () {
      expect(envelopeDisplayGain(0.001), 4.0);
      expect(envelopeDisplayGain(0.0), 1.0);
      expect(envelopeDisplayGain(double.nan), 1.0);
      expect(envelopeDisplayGain(0.1, maxGain: 2.0), 2.0);
    });

    test('gain x peak never draws outside the panel', () {
      for (final peak in [0.02, 0.1, 0.33, 0.5, 0.8, 1.0]) {
        expect(envelopeDisplayGain(peak) * peak, lessThanOrEqualTo(1.0));
      }
    });
  });
}

// Basic unit tests for the pure-Dart Kit/Pad model logic (no plugins, no
// widgets involved, so these run anywhere without platform mocking).
import 'package:flutter_test/flutter_test.dart';
import 'package:padforge/models/kit.dart';

void main() {
  test('Kit.blank creates 48 pads across banks A, B, C with factory MPD218 note numbers', () {
    final kit = Kit.blank(name: 'Test Kit', folderName: 'test_kit');

    expect(kit.pads.length, 48);
    expect(kit.padsForBank('A').length, 16);
    expect(kit.padsForBank('B').length, 16);
    expect(kit.padsForBank('C').length, 16);

    expect(kit.padById('A1')?.note, 36);
    expect(kit.padById('A16')?.note, 51);
    expect(kit.padById('B1')?.note, 52);
    expect(kit.padById('B16')?.note, 67);
    expect(kit.padById('C1')?.note, 68);
    expect(kit.padById('C16')?.note, 83);
  });

  test('Kit.blank pads start with no sample assigned', () {
    final kit = Kit.blank(name: 'Test Kit', folderName: 'test_kit');
    for (final pad in kit.pads) {
      expect(pad.hasSample, isFalse);
    }
  });

  test('Kit round-trips through JSON', () {
    final kit = Kit.blank(name: 'Round Trip', folderName: 'round_trip');
    kit.padById('A1')!.samplePath = 'samples/kick.wav';
    kit.padById('A3')!.chokeGroup = 1;

    final json = kit.toJson();
    final restored = Kit.fromJson(json, folderName: kit.folderName);

    expect(restored.name, 'Round Trip');
    expect(restored.padById('A1')!.samplePath, 'samples/kick.wav');
    expect(restored.padById('A3')!.chokeGroup, 1);
    expect(restored.knobs.length, 6);
  });

  test('knob CC and function lookups work', () {
    final kit = Kit.blank(name: 'Knob Test', folderName: 'knob_test');
    final masterKnob = kit.knobByIndex(1)!;
    expect(masterKnob.cc, 70);
    expect(kit.knobByCc(70), same(masterKnob));
    expect(kit.masterVolume, 1.0);
    expect(kit.playbackRate, 1.0); // pitch/speed knob defaults to center (0.5) -> rate 1.0
  });
}

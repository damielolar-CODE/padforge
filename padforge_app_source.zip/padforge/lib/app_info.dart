// The handful of facts about the product itself: what it is called, what
// version it is, and who owns it. They live here, in one file, because they
// are printed on the About screen and quoted in the store listing, and a
// second copy of any of them is a copy that will eventually be wrong.
//
// ## The version, and why it is a constant
//
// A Flutter app cannot read `pubspec.yaml` at runtime -- the file is not
// bundled -- and the usual answer (`package_info_plus`) is a new pub package,
// which this project is not adding. So the version is written out here and
// `test/app_info_test.dart` **fails the build** if it ever stops matching the
// `version:` line in `pubspec.yaml`. Bump the two together; the test is what
// makes sure you did.

/// The product name, spelled the one correct way. Also the Android
/// `android:label` and the iOS `CFBundleDisplayName`.
const String kAppName = 'PadForge';

/// The marketing version, i.e. the part of `pubspec.yaml`'s `version:` field
/// before the `+`. Kept in step with pubspec by `test/app_info_test.dart`.
const String kAppVersion = '1.0.0';

/// One line, said once, about what this is.
const String kAppTagline = 'MPC-style sampler for the Akai MPD218';

/// The owner of the product.
const String kAppVendor = 'Deestech';

/// The copyright line, exactly as it must appear. The copyright sign is
/// written as a `©` escape rather than as a literal character so that no
/// editor, patch tool or CI checkout can mangle the encoding of the one
/// string in this app that has to be byte-exact.
const String kAppCopyright = 'Deestech \u00A9 2026';

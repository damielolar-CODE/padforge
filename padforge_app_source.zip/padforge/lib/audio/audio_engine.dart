import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';

import '../models/pad.dart';

/// Polyphonic WAV sample playback engine.
///
/// Keeps a small pool of pre-created [AudioPlayer] instances (16, matching a
/// classic drum machine's voice count) and cycles through them round-robin
/// each time a pad is triggered. That lets several pads sound at once
/// without one hit cutting another one off -- unless they're in the same
/// "choke group" (see [Pad.chokeGroup]), in which case hitting one
/// deliberately stops the other (classic open-hat/closed-hat behavior).
class AudioEngine {
  AudioEngine._internal();

  static final AudioEngine instance = AudioEngine._internal();

  static const int poolSize = 16;

  final List<AudioPlayer> _pool = List.generate(poolSize, (_) => AudioPlayer());
  int _nextVoice = 0;
  bool _initialized = false;

  /// Maps choke group number -> index into [_pool] of the voice currently
  /// playing a sample from that group (if any).
  final Map<int, int> _chokeGroupVoice = {};

  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;
    for (final player in _pool) {
      try {
        await player.setReleaseMode(ReleaseMode.stop);
      } catch (e) {
        debugPrint('AudioEngine: setReleaseMode failed: $e');
      }
      // Low-latency mode trades some flexibility for much snappier one-shot
      // playback, which is exactly what drum pads need. If a platform
      // doesn't support it, just fall back to the default player mode.
      try {
        await player.setPlayerMode(PlayerMode.lowLatency);
      } catch (e) {
        debugPrint('AudioEngine: lowLatency mode unavailable, using default: $e');
      }
    }
  }

  /// Plays [pad]'s sample (located at [absoluteSamplePath] on disk).
  ///
  /// [velocityScale] (0.0-1.0) reflects how hard the pad was hit,
  /// [masterVolume] and [playbackRate] come from the kit's knobs.
  Future<void> playPad(
    Pad pad,
    String absoluteSamplePath, {
    double velocityScale = 1.0,
    double masterVolume = 1.0,
    double playbackRate = 1.0,
  }) async {
    if (!pad.hasSample) return;

    // Choke: if this pad belongs to a choke group, stop whatever else is
    // currently sounding in that same group before playing.
    final chokeGroup = pad.chokeGroup;
    if (chokeGroup != null) {
      final existingVoice = _chokeGroupVoice[chokeGroup];
      if (existingVoice != null) {
        try {
          await _pool[existingVoice].stop();
        } catch (e) {
          debugPrint('AudioEngine: choke stop failed: $e');
        }
      }
    }

    final voiceIndex = _nextVoice;
    _nextVoice = (_nextVoice + 1) % poolSize;
    final player = _pool[voiceIndex];

    final volume = (pad.volume * velocityScale * masterVolume).clamp(0.0, 1.0).toDouble();

    try {
      await player.stop();
      await player.setVolume(volume);
      try {
        await player.setPlaybackRate(playbackRate.clamp(0.5, 2.0).toDouble());
      } catch (e) {
        // Not every platform/mode supports variable playback rate for
        // low-latency sources; silently skip pitch/speed if so.
        debugPrint('AudioEngine: setPlaybackRate unavailable: $e');
      }
      await player.play(DeviceFileSource(absoluteSamplePath));
    } catch (e) {
      // A missing/corrupt sample file shouldn't crash pad playback -- just
      // log it and move on.
      debugPrint('AudioEngine: failed to play $absoluteSamplePath: $e');
    }

    if (chokeGroup != null) {
      _chokeGroupVoice[chokeGroup] = voiceIndex;
    }
  }

  Future<void> stopAll() async {
    for (final player in _pool) {
      try {
        await player.stop();
      } catch (e) {
        debugPrint('AudioEngine: stopAll failed for a voice: $e');
      }
    }
    _chokeGroupVoice.clear();
  }

  Future<void> dispose() async {
    for (final player in _pool) {
      await player.dispose();
    }
  }
}

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_soloud/flutter_soloud.dart';

import '../models/pad.dart';

/// PadForge's sample playback engine.
///
/// ## Why this file looks the way it does (plain English)
///
/// Version 1 of PadForge played each pad by handing a file path to a general
/// purpose media player. Every single hit therefore had to open the file,
/// decode it, hand it to the operating system's audio stack and only *then*
/// make a sound. That round trip is what made the pads feel late.
///
/// This version does the opposite. When a kit is loaded, **every** sample in
/// that kit is decoded once, up front, straight into memory ([loadKitSamples]).
/// After that, hitting a pad is just "start playing this chunk of memory",
/// which is a single, instant, non-waiting call ([playPad]). There is
/// deliberately no `await` anywhere between a pad being hit and the sound
/// starting -- that is the whole point of the rewrite.
///
/// The engine underneath is SoLoud (the `flutter_soloud` package), configured
/// with a small output buffer, which is the other half of the latency story:
/// a smaller buffer means the sound card asks for audio more often, so a note
/// that starts "now" is heard sooner.
///
/// ## What else lives here
///
///  - **Choke groups.** Pads can be told to cut each other off (the classic
///    open hi-hat / closed hi-hat trick). We remember which voice is currently
///    sounding for each choke group and stop it when a new pad in that group
///    fires.
///  - **Tape deck clips.** The looper and the recorder need to load and play
///    arbitrary WAV files too. Rather than let those files talk to SoLoud
///    directly, they go through the small "clip" API at the bottom of this
///    class ([loadClip] / [playClip] / [stopClip] / [unloadClip]) which hands
///    back plain integer ids. That keeps `flutter_soloud` confined to this one
///    file, the same way `flutter_midi_command` is confined to
///    `lib/midi/midi_service.dart`.
///  - **Failure handling.** If the audio device refuses to start we do not
///    crash and we do not silently play nothing: [failureMessage] is set and
///    the UI status bar shows "AUDIO ENGINE FAILED".
class AudioEngine {
  AudioEngine._internal();

  static final AudioEngine instance = AudioEngine._internal();

  /// Output buffer sizes, smallest (lowest latency) first.
  ///
  /// The engine starts at whatever rung the user chose in Settings
  /// ([preferredBufferSize]) and, if the audio device refuses it, **steps up**
  /// through the rest rather than giving up. [activeBufferSize] records the one
  /// that actually worked, and Settings prints it: it is the single most useful
  /// number when someone reports "the pads feel late on my phone".
  ///
  /// At 44.1kHz: 128 frames is ~2.9ms, 256 ~5.8ms, 512 ~11.6ms, 1024 ~23.2ms.
  /// One buffer is the *floor* of the output latency, not the whole of it --
  /// the device adds its own on top, and 128 will crackle on plenty of phones,
  /// which is exactly why this is a user choice with a warning next to it
  /// rather than a number the app picks on their behalf.
  static const List<int> bufferLadder = [128, 256, 512, 1024, 2048];

  /// What a fresh install asks for: low enough to feel immediate on a modern
  /// phone, high enough not to crackle on a cheap one.
  static const int defaultBufferFrames = 256;

  /// Sample rate we ask the device for.
  static const int _requestedSampleRate = 44100;

  /// How many voices can sound at once. SoLoud's own default is 16, which a
  /// two-handed roll on a long sample can genuinely exhaust -- and when it is
  /// exhausted the *oldest voice of the same sample* is stopped to make room,
  /// which is heard as a note being cut short. 32 costs nothing measurable.
  static const int _maxActiveVoices = 32;

  bool _initStarted = false;
  bool _ready = false;
  String? _failureMessage;
  int? _activeBufferSize;
  int _preferredBufferSize = defaultBufferFrames;

  /// The rung of [bufferLadder] the engine will *ask* for next time it starts.
  ///
  /// Changing it has no effect on a running engine -- the buffer size is fixed
  /// when the audio device is opened -- so the UI says "next time PadForge
  /// starts" rather than pretending otherwise.
  int get preferredBufferSize => _preferredBufferSize;

  set preferredBufferSize(int frames) {
    // Anything off the ladder is snapped to the nearest rung that is not
    // smaller, so a stale or corrupt setting can never ask for something
    // absurd.
    for (final rung in bufferLadder) {
      if (frames <= rung) {
        _preferredBufferSize = rung;
        return;
      }
    }
    _preferredBufferSize = bufferLadder.last;
  }

  /// True when the engine is running on a different buffer size than the one
  /// asked for -- either because the device refused it, or because the user has
  /// changed the setting since the app started. Settings uses this to explain
  /// itself instead of showing two numbers that disagree.
  bool get bufferSizePending =>
      _ready && _activeBufferSize != null && _activeBufferSize != _preferredBufferSize;

  /// The output buffer size the audio device actually accepted, or null if the
  /// engine never started. Surfaced in Settings: it is the single most useful
  /// number when a user reports "the pads feel late on my phone".
  int? get activeBufferSize => _activeBufferSize;

  /// The sample rate the engine is running at.
  int get sampleRate => _requestedSampleRate;

  /// Roughly how much latency the current buffer size represents, in
  /// milliseconds. One buffer's worth is the floor; the device adds its own on
  /// top, so this is a lower bound, not a promise.
  double? get approxBufferLatencyMs {
    final size = _activeBufferSize;
    if (size == null) return null;
    return size * 1000.0 / _requestedSampleRate;
  }

  /// One line for the Settings screen, e.g.
  /// `44100 Hz - 256 frames (~5.8 ms)`.
  String get latencyDebugLine {
    if (!_ready) return _failureMessage ?? 'AUDIO ENGINE NOT STARTED';
    final size = _activeBufferSize;
    if (size == null) return '$_requestedSampleRate Hz';
    final ms = approxBufferLatencyMs!.toStringAsFixed(1);
    return '$_requestedSampleRate Hz - $size frames (~$ms ms buffer)';
  }

  /// How long the **app's own** part of the last pad trigger took, in
  /// microseconds, or -1 if nothing has been played yet.
  ///
  /// This is measured around the `SoLoud.instance.play(...)` call in
  /// [playPad]: the time from PadForge deciding to make a sound to the audio
  /// engine having accepted it. It is **not** the latency you hear.
  /// `flutter_soloud` 4.1.6 exposes no way to ask the device what its true
  /// output latency is (there is no such getter anywhere in its Dart or FFI
  /// bindings -- only the buffer size we asked for), and the OS mixer, any
  /// Bluetooth hop and the speaker itself all add time this app cannot see. So
  /// the UI shows this number for what it is -- the part PadForge is
  /// responsible for -- and says plainly that the rest cannot be measured
  /// from inside the app. A fabricated round-trip figure would be worse than
  /// no figure at all.
  int get lastTriggerDispatchMicros => _lastTriggerDispatchMicros;

  int _lastTriggerDispatchMicros = -1;

  /// Reused rather than allocated per hit: `Stopwatch` allocation on the
  /// trigger path would be exactly the sort of thing this class exists to
  /// avoid. Reset/start/stop is three integer operations.
  final Stopwatch _dispatchWatch = Stopwatch();

  /// True once the audio device is up and samples can actually be played.
  bool get isReady => _ready;

  /// Human-readable reason the audio engine is unusable, or null when it is
  /// fine. The status bar surfaces this so a silent app is never a mystery.
  String? get failureMessage => _failureMessage;

  /// Decoded, in-memory samples for the currently loaded kit, keyed by pad id
  /// ("A1", "B7", ...). Rebuilt from scratch every time a kit is loaded.
  final Map<String, AudioSource> _padSources = {};

  /// Which voice is currently sounding for each choke group, so a new hit in
  /// the same group can stop it.
  final Map<int, SoundHandle> _chokeHandles = {};

  /// Tape deck clips (loop takes, recorded takes) by integer id.
  final Map<int, AudioSource> _clipSources = {};
  final Map<int, SoundHandle> _clipHandles = {};
  int _nextClipId = 1;

  /// Number of samples currently held in memory (handy for debugging /
  /// showing "kit loaded" state).
  int get loadedSampleCount => _padSources.length;

  // --- Startup ----------------------------------------------------------

  /// Starts the audio device. Safe to call more than once; only the first
  /// call does any work.
  Future<void> init() async {
    if (_initStarted) return;
    _initStarted = true;

    Object? lastError;
    for (final bufferSize in _attempts()) {
      try {
        await SoLoud.instance.init(
          sampleRate: _requestedSampleRate,
          bufferSize: bufferSize,
          channels: Channels.stereo,
          // `lowLatency: true` is the whole ball game on Android: it selects
          // AAudio's MMAP low-latency output path (the one games use) rather
          // than the conservative legacy mixer. Read the plugin's own source
          // before changing this -- `androidAAudioAttributes` below is
          // *ignored* while this is true, and its only two values
          // (mediaMusic / unmanaged) are about how the stream is tagged for
          // ducking and screen recording, not about latency. There is no
          // "game" attribute to pick; the low-latency profile is this flag.
          lowLatency: true,
          androidAAudioAttributes: AndroidAAudioAttributes.mediaMusic,
        );
        _ready = true;
        _activeBufferSize = bufferSize;
        _failureMessage = null;
        try {
          SoLoud.instance.setMaxActiveVoiceCount(_maxActiveVoices);
        } catch (e) {
          // Not fatal: the engine simply keeps its own default of 16.
          debugPrint('AudioEngine: could not raise the voice count: $e');
        }
        debugPrint('AudioEngine: SoLoud started -- $latencyDebugLine.');
        return;
      } catch (e) {
        lastError = e;
        debugPrint('AudioEngine: init failed at bufferSize=$bufferSize: $e');
      }
    }

    _ready = false;
    _activeBufferSize = null;
    _failureMessage = 'AUDIO ENGINE FAILED';
    debugPrint('AudioEngine: could not start any audio device. Last error: $lastError');
  }

  /// The rungs to try, in order: the one the user asked for, then every larger
  /// one. A device that refuses 128 gets 256 next, not a second attempt at
  /// something it has already said no to.
  List<int> _attempts() {
    final start = bufferLadder.indexOf(_preferredBufferSize);
    if (start < 0) return List<int>.from(bufferLadder);
    return bufferLadder.sublist(start);
  }

  /// Plays one **silent** voice, once, so the first audible hit does not pay
  /// any of the one-time costs of the first play call.
  ///
  /// Called after a kit finishes loading. What it warms up:
  ///
  ///  * the Dart -> FFI -> SoLoud `play` path (first-call code paths, any lazy
  ///    allocation inside the mixer), and
  ///  * on Android, the output stream itself: miniaudio's AAudio backend can
  ///    let an idle device wind down, and the first sound after that pays for
  ///    starting it again.
  ///
  /// It is deliberately **not** stopped: a one-shot sample retires its own
  /// voice when it reaches the end, which keeps the device running for those
  /// few hundred milliseconds instead of letting it idle straight back down.
  /// `volume: 0` is a real, supported argument to `SoLoud.play` (checked
  /// against flutter_soloud 4.1.6's `soloud.dart`), and a zero-volume voice is
  /// mixed like any other -- it simply contributes nothing.
  void prewarm() {
    if (!_ready || _padSources.isEmpty) return;
    try {
      SoLoud.instance.play(_padSources.values.first, volume: 0.0);
      debugPrint('AudioEngine: pre-warmed the output path with a silent voice.');
    } catch (e) {
      debugPrint('AudioEngine: pre-warm failed (harmless): $e');
    }
  }

  /// Plays one sample of the current kit at full volume, for the latency test
  /// in Settings. Returns false when there is nothing loaded to click with.
  ///
  /// It deliberately uses a real kit sample rather than a synthesised beep:
  /// the point of the test is to judge the delay on **the sound the pads
  /// actually make**, through the same [playPad]-shaped path.
  bool playTestClick() {
    if (!_ready || _padSources.isEmpty) return false;
    try {
      _dispatchWatch
        ..reset()
        ..start();
      SoLoud.instance.play(_padSources.values.first, volume: 1.0);
      _dispatchWatch.stop();
      _lastTriggerDispatchMicros = _dispatchWatch.elapsedMicroseconds;
      return true;
    } catch (e) {
      debugPrint('AudioEngine: test click failed: $e');
      return false;
    }
  }

  // --- Kit (pre)loading -------------------------------------------------

  /// Decodes every sample of a kit into memory, replacing whatever was loaded
  /// before. [padIdToAbsolutePath] maps a pad id to the full path of its WAV
  /// file on disk; pads with no sample simply aren't in the map.
  ///
  /// This is the slow part of playing a kit, and it deliberately all happens
  /// here -- ahead of time, while the UI shows "LOADING KIT" -- so that
  /// [playPad] never has to wait for anything.
  Future<void> loadKitSamples(Map<String, String> padIdToAbsolutePath) async {
    await unloadKitSamples();
    if (!_ready) return;

    for (final entry in padIdToAbsolutePath.entries) {
      try {
        final source = await SoLoud.instance.loadFile(
          entry.value,
          mode: LoadMode.memory,
        );
        _padSources[entry.key] = source;
      } catch (e) {
        // A missing or unreadable sample should cost us that one pad, not the
        // whole kit.
        debugPrint('AudioEngine: could not load ${entry.value} for pad ${entry.key}: $e');
      }
    }
    debugPrint('AudioEngine: preloaded ${_padSources.length} sample(s) into memory.');
  }

  /// Frees the memory used by the current kit's samples. Called automatically
  /// by [loadKitSamples] before loading a new kit, so switching kits does not
  /// leak.
  Future<void> unloadKitSamples() async {
    _chokeHandles.clear();
    if (_padSources.isEmpty) return;
    final sources = _padSources.values.toList();
    _padSources.clear();
    if (!_ready) return;
    for (final source in sources) {
      try {
        await SoLoud.instance.disposeSource(source);
      } catch (e) {
        debugPrint('AudioEngine: disposeSource failed: $e');
      }
    }
  }

  /// True when [padId]'s sample is decoded and ready to fire instantly.
  bool isPadLoaded(String padId) => _padSources.containsKey(padId);

  // --- Triggering -------------------------------------------------------

  /// Plays [pad]'s preloaded sample. **Synchronous on purpose** -- there is no
  /// `await` between a pad being hit and the sound starting.
  ///
  /// [velocityScale] (0.0-1.0) is how hard the pad was hit, [masterVolume] and
  /// [playbackRate] come from the kit's knobs.
  void playPad(
    Pad pad, {
    double velocityScale = 1.0,
    double masterVolume = 1.0,
    double playbackRate = 1.0,
  }) {
    if (!_ready) return;
    final source = _padSources[pad.padId];
    if (source == null) return;

    final volume = (pad.volume * velocityScale * masterVolume).clamp(0.0, 1.0).toDouble();
    final speed = playbackRate.clamp(0.25, 4.0).toDouble();
    final chokeGroup = pad.chokeGroup;

    // Choke: silence whatever else is sounding in this group. `stop()` is
    // asynchronous inside SoLoud, but we deliberately do not wait for it --
    // waiting here would reintroduce exactly the latency this rewrite removes.
    if (chokeGroup != null) {
      final previous = _chokeHandles.remove(chokeGroup);
      if (previous != null) {
        unawaited(_stopQuietly(previous));
      }
    }

    try {
      // Timed so Settings can show what the app's own share of the latency is.
      // Three integer operations either side of a call that has to happen
      // anyway; see [lastTriggerDispatchMicros] for what the number does and
      // does not mean.
      _dispatchWatch
        ..reset()
        ..start();
      final handle = SoLoud.instance.play(source, volume: volume);
      _dispatchWatch.stop();
      _lastTriggerDispatchMicros = _dispatchWatch.elapsedMicroseconds;
      if (speed != 1.0) {
        SoLoud.instance.setRelativePlaySpeed(handle, speed);
      }
      if (chokeGroup != null) {
        _chokeHandles[chokeGroup] = handle;
      }
    } catch (e) {
      // SoLoud can throw if the audio device disappeared (headphones yanked,
      // a phone call). Never let that take the app down mid-performance.
      debugPrint('AudioEngine: play failed for pad ${pad.padId}: $e');
    }
  }

  /// Stops a voice in the background, swallowing any error. Used by the choke
  /// logic, which must never block the trigger path or throw into it.
  Future<void> _stopQuietly(SoundHandle handle) async {
    try {
      await SoLoud.instance.stop(handle);
    } catch (e) {
      debugPrint('AudioEngine: choke stop failed: $e');
    }
  }

  /// Stops everything currently sounding (pads and tape deck clips alike).
  Future<void> stopAll() async {
    if (!_ready) return;
    final handles = <SoundHandle>[
      ..._chokeHandles.values,
      ..._clipHandles.values,
    ];
    _chokeHandles.clear();
    _clipHandles.clear();
    for (final handle in handles) {
      try {
        await SoLoud.instance.stop(handle);
      } catch (e) {
        debugPrint('AudioEngine: stopAll failed for a voice: $e');
      }
    }
  }

  // --- Tape deck clips --------------------------------------------------

  /// Loads an arbitrary WAV file (a loop take, a recorded take) into memory
  /// and returns an id for it, or null if it could not be loaded.
  Future<int?> loadClip(String absolutePath) async {
    if (!_ready) return null;
    try {
      final source = await SoLoud.instance.loadFile(absolutePath, mode: LoadMode.memory);
      final id = _nextClipId++;
      _clipSources[id] = source;
      return id;
    } catch (e) {
      debugPrint('AudioEngine: could not load clip $absolutePath: $e');
      return null;
    }
  }

  /// Starts a clip. With [looping] true SoLoud repeats it seamlessly (no gap,
  /// no re-triggering from Dart), which is what the looper needs.
  void playClip(int clipId, {double volume = 1.0, bool looping = false}) {
    if (!_ready) return;
    final source = _clipSources[clipId];
    if (source == null) return;
    try {
      final handle = SoLoud.instance.play(source, volume: volume, looping: looping);
      _clipHandles[clipId] = handle;
    } catch (e) {
      debugPrint('AudioEngine: could not play clip $clipId: $e');
    }
  }

  /// True while [clipId] has a voice we started and have not stopped.
  bool isClipPlaying(int clipId) => _clipHandles.containsKey(clipId);

  /// True while [clipId] is *actually still sounding*. A one-shot clip
  /// reaching its end silently retires its voice inside SoLoud, and this is
  /// how the UI notices so it can flip a "playing" button back to "play".
  bool isClipVoiceActive(int clipId) {
    if (!_ready) return false;
    final handle = _clipHandles[clipId];
    if (handle == null) return false;
    try {
      return SoLoud.instance.getIsValidVoiceHandle(handle);
    } catch (e) {
      return false;
    }
  }

  /// Stops a clip **now**, without waiting for the engine to confirm it.
  ///
  /// `SoLoud.stop()` returns a Future, but the native call that silences the
  /// voice happens before it ever yields -- the Future is only there so a
  /// caller can wait for the "voice ended" callback. The looper needs the old
  /// master gone *in the same turn of the event loop* that the new one starts,
  /// otherwise both are audible for a frame at the loop seam and the loop
  /// doubles on itself. That is what this is for.
  void stopClipNow(int clipId) {
    final handle = _clipHandles.remove(clipId);
    if (handle == null || !_ready) return;
    // _stopQuietly swallows any error, so this can never throw an unhandled
    // async exception into the transport.
    unawaited(_stopQuietly(handle));
  }

  Future<void> stopClip(int clipId) async {
    final handle = _clipHandles.remove(clipId);
    if (handle == null || !_ready) return;
    try {
      await SoLoud.instance.stop(handle);
    } catch (e) {
      debugPrint('AudioEngine: could not stop clip $clipId: $e');
    }
  }

  /// Stops a clip (if playing) and frees the memory it occupied.
  Future<void> unloadClip(int clipId) async {
    await stopClip(clipId);
    final source = _clipSources.remove(clipId);
    if (source == null || !_ready) return;
    try {
      await SoLoud.instance.disposeSource(source);
    } catch (e) {
      debugPrint('AudioEngine: could not dispose clip $clipId: $e');
    }
  }

  // --- Master output capture --------------------------------------------

  bool _masterCaptureRunning = false;

  /// True while [startMasterCapture] is feeding a stream.
  bool get isMasterCaptureRunning => _masterCaptureRunning;

  /// Taps the engine's own master output -- everything the app is playing,
  /// and **nothing** the microphone hears.
  ///
  /// This is what lets the recorder render a pad performance to a file without
  /// involving the mic at all. The stream yields raw little-endian signed
  /// 16-bit PCM, interleaved, at [sampleRate] / [channels]; the caller is
  /// expected to wrap it in a WAV header of its own (see `wav_tools.dart`).
  /// Plain PCM is deliberate: SoLoud's own WAV mode emits a header with
  /// placeholder sizes that has to be patched afterwards, whereas here we
  /// already know the exact format.
  ///
  /// Returns null (rather than throwing) if the engine isn't running, a
  /// capture is already in progress, or the platform refuses -- this API is
  /// newer than the rest of the engine, so callers must have a fallback.
  Stream<List<int>>? startMasterCapture({
    int sampleRate = 44100,
    int channels = 2,
  }) {
    if (!_ready || _masterCaptureRunning) return null;
    try {
      final stream = SoLoud.instance.startMixerOutputStream(
        format: MixerOutputFormat.pcmS16le,
        sampleRate: sampleRate,
        channels: channels,
      );
      _masterCaptureRunning = true;
      return stream;
    } catch (e) {
      debugPrint('AudioEngine: master output capture could not start: $e');
      try {
        SoLoud.instance.stopMixerOutputStream();
      } catch (_) {
        // Nothing to unwind; the capture never started.
      }
      return null;
    }
  }

  /// Stops a capture started by [startMasterCapture]. Safe to call when no
  /// capture is running.
  void stopMasterCapture() {
    if (!_masterCaptureRunning) return;
    _masterCaptureRunning = false;
    try {
      SoLoud.instance.stopMixerOutputStream();
    } catch (e) {
      debugPrint('AudioEngine: stopping the master capture failed: $e');
    }
  }

  // --- Shutdown ---------------------------------------------------------

  Future<void> dispose() async {
    stopMasterCapture();
    await stopAll();
    await unloadKitSamples();
    for (final id in _clipSources.keys.toList()) {
      await unloadClip(id);
    }
    if (_ready) {
      try {
        SoLoud.instance.deinit();
      } catch (e) {
        debugPrint('AudioEngine: deinit failed: $e');
      }
    }
    _ready = false;
  }
}

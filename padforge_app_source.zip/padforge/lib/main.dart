/// PadForge entry point.
///
/// PadForge is a companion sampler app for the Akai MPD218 USB MIDI pad
/// controller, styled after classic MPC-style hardware samplers. This file
/// just wires up the Flutter app shell: it kicks off [AppState.init] (which
/// loads settings, installs the starter kit on first launch, and connects to
/// MIDI) and shows a small splash screen until that's done, then hands off
/// to [HomeScreen].
library;

import 'package:flutter/material.dart';

import 'state/app_state.dart';
import 'ui/screens/home_screen.dart';
import 'ui/theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PadForgeApp());
}

class PadForgeApp extends StatefulWidget {
  const PadForgeApp({super.key});

  @override
  State<PadForgeApp> createState() => _PadForgeAppState();
}

class _PadForgeAppState extends State<PadForgeApp> {
  late final Future<void> _initFuture;

  @override
  void initState() {
    super.initState();
    _initFuture = AppState.instance.init();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PadForge',
      debugShowCheckedModeBanner: false,
      theme: buildPadForgeTheme(),
      home: FutureBuilder<void>(
        future: _initFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const _SplashScreen();
          }
          return const HomeScreen();
        },
      ),
    );
  }
}

/// A minimal LCD-style splash shown while PadForge loads its first kit and
/// scans for MIDI devices.
class _SplashScreen extends StatelessWidget {
  const _SplashScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.chassis,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.grid_view_rounded, color: AppColors.amber, size: 48),
            const SizedBox(height: 16),
            Text('PADFORGE', style: lcdTextStyle(fontSize: 32, color: AppColors.amber)),
            const SizedBox(height: 16),
            const SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(color: AppColors.amber, strokeWidth: 3),
            ),
          ],
        ),
      ),
    );
  }
}

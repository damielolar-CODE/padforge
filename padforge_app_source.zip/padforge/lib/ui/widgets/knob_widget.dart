import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../state/app_state.dart';
import '../theme/app_theme.dart';

/// A custom-painted rotary knob widget, styled like a chunky hardware
/// sampler knob rather than a Material slider.
///
/// Drag up/down to change the value (a common "vertical drag" rotary-knob
/// interaction on touchscreens, since a literal rotating gesture is fiddly
/// on a small dial). Tap while MIDI Learn is armed to select this knob as
/// the learn target.
class KnobWidget extends StatefulWidget {
  final int knobIndex; // 1-6

  const KnobWidget({super.key, required this.knobIndex});

  @override
  State<KnobWidget> createState() => _KnobWidgetState();
}

class _KnobWidgetState extends State<KnobWidget> {
  double? _dragStartValue;
  double _dragAccumDy = 0;

  void _handleTap() {
    final app = AppState.instance;
    if (app.learnModeArmed) {
      app.startKnobLearn(widget.knobIndex);
    }
  }

  void _handleDragStart(DragStartDetails details) {
    final knob = AppState.instance.currentKit?.knobByIndex(widget.knobIndex);
    _dragStartValue = knob?.value ?? 0.5;
    _dragAccumDy = 0;
  }

  void _handleDragUpdate(DragUpdateDetails details) {
    if (_dragStartValue == null) return;
    _dragAccumDy += details.delta.dy;
    // 150 vertical pixels = full sweep, feels natural for a small knob.
    final delta = -_dragAccumDy / 150.0;
    final newValue = (_dragStartValue! + delta).clamp(0.0, 1.0).toDouble();
    AppState.instance.setKnobValue(widget.knobIndex, newValue, persist: false);
  }

  void _handleDragEnd(DragEndDetails details) {
    final knob = AppState.instance.currentKit?.knobByIndex(widget.knobIndex);
    if (knob != null) {
      AppState.instance.setKnobValue(widget.knobIndex, knob.value, persist: true);
    }
    _dragStartValue = null;
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        final knob = app.currentKit?.knobByIndex(widget.knobIndex);
        final isLearning = app.isLearningKnob(widget.knobIndex);
        final value = knob?.value ?? 0.5;
        final label = knob?.label ?? 'Knob ${widget.knobIndex}';

        return GestureDetector(
          onTap: _handleTap,
          onVerticalDragStart: _handleDragStart,
          onVerticalDragUpdate: _handleDragUpdate,
          onVerticalDragEnd: _handleDragEnd,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 52,
                height: 52,
                child: CustomPaint(
                  painter: _KnobPainter(value: value, highlighted: isLearning),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: lcdTextStyle(fontSize: 12, color: AppColors.lcdTextDim),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _KnobPainter extends CustomPainter {
  final double value; // 0.0 - 1.0
  final bool highlighted;

  _KnobPainter({required this.value, required this.highlighted});

  // A 270 degree sweep, matching typical hardware knob travel: from
  // -135 degrees to +135 degrees, with 0 straight down (6 o'clock) as the
  // "gap" in the sweep.
  static const double _startAngle = math.pi * 0.75; // 135deg
  static const double _sweepAngle = math.pi * 1.5; // 270deg

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final radius = size.shortestSide / 2;

    // Knob body with a bevel-ish radial shading.
    final bodyPaint = Paint()
      ..shader = RadialGradient(
        colors: [const Color(0xFF3A352C), const Color(0xFF232019)],
      ).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius, bodyPaint);

    final rimPaint = Paint()
      ..color = highlighted ? AppColors.amber : Colors.black.withValues(alpha: 0.5)
      ..style = PaintingStyle.stroke
      ..strokeWidth = highlighted ? 2.5 : 1.5;
    canvas.drawCircle(center, radius - 1, rimPaint);

    // Track arc (dim) behind the value arc.
    final trackPaint = Paint()
      ..color = AppColors.lcdTextDim.withValues(alpha: 0.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius - 5),
      _startAngle,
      _sweepAngle,
      false,
      trackPaint,
    );

    // Value arc (amber).
    final valuePaint = Paint()
      ..color = AppColors.amber
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius - 5),
      _startAngle,
      _sweepAngle * value.clamp(0.0, 1.0),
      false,
      valuePaint,
    );

    // Pointer indicator line.
    final pointerAngle = _startAngle + _sweepAngle * value.clamp(0.0, 1.0);
    final pointerPaint = Paint()
      ..color = AppColors.lcdText
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;
    final inner = center + Offset(math.cos(pointerAngle), math.sin(pointerAngle)) * (radius * 0.25);
    final outer = center + Offset(math.cos(pointerAngle), math.sin(pointerAngle)) * (radius * 0.85);
    canvas.drawLine(inner, outer, pointerPaint);
  }

  @override
  bool shouldRepaint(covariant _KnobPainter oldDelegate) {
    return oldDelegate.value != value || oldDelegate.highlighted != highlighted;
  }
}

import 'dart:async';

import 'package:flutter/material.dart';

import '../../models/pad.dart';
import '../../state/app_state.dart';
import '../screens/pad_edit_screen.dart';
import '../theme/app_theme.dart';

/// One MPC-style pad button.
///
/// Touching it plays the sample (or arms it for MIDI Learn, if learn mode is
/// active). Long-pressing opens the full pad editor. It also listens for
/// hits coming from the physical MPD218 (via [AppState.padHitEvents]) and
/// flashes amber either way, so on-screen taps and hardware hits both give
/// the same tactile feedback.
///
/// ## The pad sounds on finger-DOWN (v7 -- read this before touching it)
///
/// Up to v6 this widget played the sample from `GestureDetector.onTap`.
/// **`onTap` fires when the finger is lifted**, so every on-screen hit was
/// delayed by however long the player held the pad down -- 80ms for a quick
/// stab, far more for anything expressive. No amount of audio-buffer tuning can
/// fix that, and it is why the user reported the on-screen pads as being just
/// as late as the hardware ones. A drum pad has to sound the instant it is
/// touched.
///
/// So the trigger now hangs off a raw [Listener]'s `onPointerDown`:
///
///  * `Listener` is not a gesture recogniser and **does not enter the gesture
///    arena**. Its callback runs during the pointer-down dispatch itself, in
///    the same synchronous turn as the touch event. Even `onTapDown` would not
///    do: a `TapGestureRecognizer` can be held in the arena while a competing
///    recogniser (an ancestor scrollable, a page-back swipe) disambiguates, and
///    `onTapDown` is only called once the tap has won or timed out.
///  * `onPointerUp` / `onPointerCancel` only clear the pressed *look*. Nothing
///    audible depends on them.
///  * The long press still works because the [GestureDetector] underneath the
///    Listener still gets the same pointer -- a Listener does not consume
///    events, it observes them, and both render objects sit in the same
///    hit-test path. That detector now handles **only** `onLongPress`, so it
///    has nothing to disambiguate against and cannot swallow the trigger.
///    Holding a pad therefore sounds it and *then*, half a second later, opens
///    the editor, which is exactly how a hardware pad with a shift function
///    behaves.
///  * `HitTestBehavior.opaque` makes the **whole pad rectangle** live. This is
///    a real second bug fixed here: `GestureDetector` defaults to
///    `deferToChild`, and the only thing in a pad that hit-tests itself is its
///    caption text, so taps that landed on the empty part of a pad used to miss
///    entirely.
///
/// The pressed highlight is driven by a [ValueNotifier] rather than by
/// `setState` for the same reason the flash is: `setState` here would rebuild
/// the pad's whole subtree (including relaying out its caption) on the very
/// frame the sound has to start, on the same thread.
///
/// ## What it says
///
/// The big caption is the **sample's short name** ("KICK", "CL HAT") because
/// that is what a player needs to read mid-take; the pad id sits small in the
/// corner for MIDI Learn and for talking about pads out loud. Both are laid
/// out so they shrink rather than overflow, whatever the phone's text scale.
///
/// ## Why the flash is built the way it is
///
/// The whole pad is wrapped in a [RepaintBoundary] and the flash is driven by
/// an [AnimationController] through [AnimatedBuilder], whose `child` holds the
/// (unchanging) caption. So a hit repaints one pad's glow and nothing else --
/// no text layout, no sibling pads, and certainly no screen rebuild. Pad
/// triggering and pad drawing share one thread, so anything the flash does not
/// do is time the next hit does not wait for.
class PadButton extends StatefulWidget {
  final String padId;

  const PadButton({super.key, required this.padId});

  @override
  State<PadButton> createState() => _PadButtonState();
}

class _PadButtonState extends State<PadButton> with SingleTickerProviderStateMixin {
  /// A firm, musical default for a finger. Real MPC players set their pads to a
  /// fixed velocity all the time; 110 of 127 is loud without being pinned to
  /// the top of the sample's range, which leaves room for a hard hit to be
  /// louder still.
  static const int _defaultTouchVelocity = 110;

  late final AnimationController _flashController;

  /// How many fingers are currently down on this pad. A count, not a bool, so
  /// a second finger landing while the first is still down (a roll, a flam)
  /// does not un-light the pad when the first one lifts.
  final ValueNotifier<int> _pressedPointers = ValueNotifier<int>(0);

  /// What the pad's face repaints from: the flash animation and the pressed
  /// count. Merging them means neither one needs a `setState`.
  late final Listenable _faceDriver;

  StreamSubscription<String>? _hitSub;

  @override
  void initState() {
    super.initState();
    _flashController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 220),
    );
    _faceDriver = Listenable.merge([_flashController, _pressedPointers]);
    _hitSub = AppState.instance.padHitEvents.listen((hitPadId) {
      if (hitPadId == widget.padId && mounted) {
        _flashController.forward(from: 0).then((_) {
          if (mounted) _flashController.reverse();
        });
      }
    });
  }

  @override
  void dispose() {
    _hitSub?.cancel();
    _flashController.dispose();
    _pressedPointers.dispose();
    super.dispose();
  }

  /// **The hot path.** Called during the pointer-down dispatch itself.
  ///
  /// The sound is started first and the lamp is lit second, for the same reason
  /// `AppState._triggerPad` orders its three steps the way it does: a light one
  /// millisecond late is invisible, a sound one millisecond late is not. There
  /// is nothing asynchronous here at all -- `hitPad` reaches
  /// `SoLoud.instance.play` synchronously.
  void _handlePointerDown(PointerDownEvent event) {
    // A pointer route captured at down survives the widget being removed from
    // the tree (a kit with fewer pads, a bank with an empty slot), and this
    // must never touch a disposed ValueNotifier.
    if (!mounted) return;
    final app = AppState.instance;
    if (app.learnModeArmed) {
      app.startPadLearn(widget.padId);
    } else {
      app.hitPad(widget.padId, velocity: _velocityFor(event));
    }
    _pressedPointers.value = _pressedPointers.value + 1;
  }

  void _handlePointerRelease() {
    if (!mounted) return;
    final next = _pressedPointers.value - 1;
    _pressedPointers.value = next < 0 ? 0 : next;
  }

  /// How hard the pad was hit, 1-127.
  ///
  /// Phones do not have real velocity sensors. What they do report -- when they
  /// report anything at all -- is `pressure`, which on Android is derived from
  /// the contact patch, and on most devices is either a constant or a small
  /// number that says more about finger size than about intent. So this is
  /// deliberately conservative: the default is a firm
  /// [_defaultTouchVelocity], and a usable pressure reading only ever
  /// **modulates the top of the range** (96..127). A player can lean on a pad
  /// for a little more, but no device quirk can make the app feel weak.
  int _velocityFor(PointerDownEvent event) {
    final min = event.pressureMin;
    final max = event.pressureMax;
    final pressure = event.pressure;
    if (!min.isFinite || !max.isFinite || !pressure.isFinite) {
      return _defaultTouchVelocity;
    }
    // A device that reports no range (min == max, the common case) or an
    // out-of-range reading gets the fixed default.
    if (max - min < 0.01 || pressure <= min) return _defaultTouchVelocity;
    final t = ((pressure - min) / (max - min)).clamp(0.0, 1.0).toDouble();
    return (96 + 31 * t).round().clamp(1, 127).toInt();
  }

  void _handleLongPress() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PadEditScreen(padId: widget.padId)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        final kit = app.currentKit;
        final Pad? pad = kit?.padById(widget.padId);
        final isLearning = app.isLearningPad(widget.padId);
        final hasSample = pad?.hasSample ?? false;
        final caption = isLearning
            ? 'LISTENING'
            : (hasSample ? pad!.sampleShortLabel : '--');

        return RepaintBoundary(
          // Listener OUTSIDE, GestureDetector inside: both render objects end
          // up in the same hit-test path, the detector's long-press recogniser
          // is entered into the arena first, and the Listener's onPointerDown
          // then runs in the same synchronous dispatch. Neither blocks the
          // other. See the class doc for why this is not a GestureDetector.
          child: Listener(
            behavior: HitTestBehavior.opaque,
            onPointerDown: _handlePointerDown,
            onPointerUp: (_) => _handlePointerRelease(),
            onPointerCancel: (_) => _handlePointerRelease(),
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              // Long press ONLY. Nothing here decides whether the pad sounds,
              // so there is no recogniser that can delay or swallow a hit.
              onLongPress: _handleLongPress,
              child: AnimatedBuilder(
                animation: _faceDriver,
                // Built once per (kit, learn-state) change rather than per
                // frame: AnimatedBuilder hands the same child straight back to
                // the builder, so the flash never re-lays-out this text.
                child: _PadFace(
                  padId: widget.padId,
                  caption: caption,
                  dimmed: !hasSample && !isLearning,
                ),
                builder: (context, child) {
                  final flash = _flashController.value;
                  final pressed = _pressedPointers.value > 0 || flash > 0.05;
                  return Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: pressed
                            ? [
                                Color.lerp(AppColors.amberDeep, AppColors.amber, flash)!,
                                AppColors.amberDeep,
                              ]
                            : [AppColors.padFace, const Color(0xFF221F1A)],
                      ),
                      border: Border.all(
                        color: isLearning
                            ? AppColors.amber
                            : Colors.black.withValues(alpha: 0.4),
                        width: isLearning ? 2 : 1,
                      ),
                      boxShadow: [
                        if (!pressed)
                          const BoxShadow(
                            color: AppColors.bevelShadow,
                            offset: Offset(0, 3),
                            blurRadius: 4,
                          ),
                        if (!pressed)
                          const BoxShadow(
                            color: AppColors.bevelHighlight,
                            offset: Offset(-1, -1),
                            blurRadius: 2,
                          ),
                        if (pressed || flash > 0)
                          BoxShadow(
                            color: AppColors.amber
                                .withValues(alpha: 0.55 * (pressed ? 1.0 : flash)),
                            blurRadius: 16,
                            spreadRadius: 1,
                          ),
                      ],
                    ),
                    // DefaultTextStyle carries the pressed/idle colour down to
                    // the (cached) caption without rebuilding it.
                    child: DefaultTextStyle.merge(
                      style: TextStyle(
                        color: pressed ? AppColors.chassis : AppColors.lcdText,
                      ),
                      child: child!,
                    ),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }
}

/// The printing on a pad: sample name across the middle, pad id small in the
/// top-left corner.
///
/// Everything is `FittedBox(scaleDown)` inside a `Flexible`, so a long sample
/// name or a large system text scale shrinks the caption instead of
/// overflowing the pad -- which matters a great deal now that the pads size
/// themselves from the screen height and can be as small as ~40dp.
class _PadFace extends StatelessWidget {
  final String padId;
  final String caption;
  final bool dimmed;

  const _PadFace({
    required this.padId,
    required this.caption,
    required this.dimmed,
  });

  @override
  Widget build(BuildContext context) {
    final colour = DefaultTextStyle.of(context).style.color ?? AppColors.lcdText;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 2),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Both lines are Flexible + scaleDown, so there is no combination of
          // pad size and system text scale that can overflow this column.
          Flexible(
            child: Align(
              alignment: Alignment.centerLeft,
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  padId,
                  maxLines: 1,
                  style: lcdTextStyle(
                    fontSize: 10,
                    color: colour.withValues(alpha: 0.55),
                  ),
                ),
              ),
            ),
          ),
          Flexible(
            flex: 2,
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                caption,
                maxLines: 1,
                textAlign: TextAlign.center,
                style: lcdTextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: dimmed ? colour.withValues(alpha: 0.5) : colour,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

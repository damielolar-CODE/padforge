import 'dart:async';

import 'package:flutter/material.dart';

import '../../models/pad.dart';
import '../../state/app_state.dart';
import '../screens/pad_edit_screen.dart';
import '../theme/app_theme.dart';

/// One MPC-style pad button.
///
/// Tapping it plays the sample (or arms it for MIDI Learn, if learn mode is
/// active). Long-pressing opens the full pad editor. It also listens for
/// hits coming from the physical MPD218 (via [AppState.padHitEvents]) and
/// flashes amber either way, so on-screen taps and hardware hits both give
/// the same tactile feedback.
class PadButton extends StatefulWidget {
  final String padId;

  const PadButton({super.key, required this.padId});

  @override
  State<PadButton> createState() => _PadButtonState();
}

class _PadButtonState extends State<PadButton> with SingleTickerProviderStateMixin {
  late final AnimationController _flashController;
  StreamSubscription<String>? _hitSub;
  bool _pressedByTouch = false;

  @override
  void initState() {
    super.initState();
    _flashController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 220),
    );
    _hitSub = AppState.instance.padHitEvents.listen((hitPadId) {
      if (hitPadId == widget.padId && mounted) {
        _flashController.forward(from: 0).then((_) {
          if (mounted) _flashController.reverse();
        });
      }
    });
  }

  @override
  void dispose() {
    _hitSub?.cancel();
    _flashController.dispose();
    super.dispose();
  }

  void _handleTap() {
    final app = AppState.instance;
    if (app.learnModeArmed) {
      app.startPadLearn(widget.padId);
    } else {
      app.hitPad(widget.padId);
    }
  }

  void _handleLongPress() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PadEditScreen(padId: widget.padId)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        final kit = app.currentKit;
        final Pad? pad = kit?.padById(widget.padId);
        final isLearning = app.isLearningPad(widget.padId);
        final hasSample = pad?.hasSample ?? false;

        return GestureDetector(
          onTap: _handleTap,
          onLongPress: _handleLongPress,
          onTapDown: (_) => setState(() => _pressedByTouch = true),
          onTapCancel: () => setState(() => _pressedByTouch = false),
          onTapUp: (_) => setState(() => _pressedByTouch = false),
          child: AnimatedBuilder(
            animation: _flashController,
            builder: (context, child) {
              final flash = _flashController.value;
              final pressed = _pressedByTouch || flash > 0.05;
              return Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: pressed
                        ? [
                            Color.lerp(AppColors.amberDeep, AppColors.amber, flash)!,
                            AppColors.amberDeep,
                          ]
                        : [AppColors.padFace, const Color(0xFF221F1A)],
                  ),
                  border: Border.all(
                    color: isLearning ? AppColors.amber : Colors.black.withValues(alpha: 0.4),
                    width: isLearning ? 2 : 1,
                  ),
                  boxShadow: [
                    if (!pressed)
                      const BoxShadow(
                        color: AppColors.bevelShadow,
                        offset: Offset(0, 3),
                        blurRadius: 4,
                      ),
                    if (!pressed)
                      const BoxShadow(
                        color: AppColors.bevelHighlight,
                        offset: Offset(-1, -1),
                        blurRadius: 2,
                      ),
                    if (pressed || flash > 0)
                      BoxShadow(
                        color: AppColors.amber.withValues(alpha: 0.55 * (pressed ? 1.0 : flash)),
                        blurRadius: 16,
                        spreadRadius: 1,
                      ),
                  ],
                ),
                padding: const EdgeInsets.all(6),
                child: Stack(
                  children: [
                    Positioned(
                      left: 4,
                      top: 2,
                      child: Text(
                        widget.padId,
                        style: lcdTextStyle(
                          fontSize: 14,
                          color: pressed ? AppColors.chassis : AppColors.lcdTextDim,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: Text(
                          hasSample ? pad!.sampleFileName.replaceAll('.wav', '') : (isLearning ? 'LISTENING' : '--'),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: lcdTextStyle(
                            fontSize: 11,
                            color: pressed ? AppColors.chassis : AppColors.lcdTextDim,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }
}

import 'package:flutter/material.dart';

import '../../services/pro_store.dart';
import '../theme/app_theme.dart';
import 'padforge_logo.dart';

/// Presents the PadForge Pro paywall as a modal bottom sheet.
///
/// This is the single entry point every locked touchpoint uses -- a locked bank
/// tab, an advanced-looper control, the recorder cap note, and the Settings
/// upgrade row all call `showPaywall(context, highlight: '...')`. The optional
/// [highlight] names the feature the user just reached for, so the sheet can say
/// "Unlock BANK B and everything else".
Future<void> showPaywall(BuildContext context, {String highlight = ''}) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppColors.chassis,
    isScrollControlled: true,
    builder: (_) => PaywallSheet(highlight: highlight),
  );
}

/// The paywall itself: the mark, the feature list, the one-time buy button,
/// Restore, and "Maybe later". It wears the same charcoal/amber chassis as the
/// rest of the app and dismisses itself the moment Pro becomes active (a
/// purchase, a restore, or the tester unlock), mirroring the iOS build.
class PaywallSheet extends StatefulWidget {
  /// What the user just tried to do, if anything. May be empty (the generic
  /// "Upgrade" entry point in Settings).
  final String highlight;

  const PaywallSheet({super.key, this.highlight = ''});

  @override
  State<PaywallSheet> createState() => _PaywallSheetState();
}

class _PaywallSheetState extends State<PaywallSheet> {
  static const List<String> _features = [
    'All 3 banks - 48 pads, not 16',
    'Advanced looper: overdub, undo, quantize',
    'Unlimited recording length',
    'Theme switching (charcoal/amber is free)',
    'Every future kit pack',
  ];

  @override
  void initState() {
    super.initState();
    ProStore.instance.addListener(_onProChanged);
  }

  @override
  void dispose() {
    ProStore.instance.removeListener(_onProChanged);
    super.dispose();
  }

  void _onProChanged() {
    // The instant Pro turns on, get out of the user's way.
    if (ProStore.instance.isPro && mounted && Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListenableBuilder(
        listenable: ProStore.instance,
        builder: (context, _) {
          final store = ProStore.instance;
          return SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Center(child: PadForgeLogo(size: 72)),
                const SizedBox(height: 12),
                Text(
                  'PADFORGE PRO',
                  textAlign: TextAlign.center,
                  style: lcdTextStyle(
                    fontSize: 26,
                    color: AppColors.lcdText,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 3,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  widget.highlight.isEmpty
                      ? 'One tap unlocks the whole instrument'
                      : 'Unlock ${widget.highlight.toUpperCase()} and everything else',
                  textAlign: TextAlign.center,
                  style: lcdTextStyle(
                    fontSize: 14,
                    color: widget.highlight.isEmpty
                        ? AppColors.lcdTextDim
                        : AppColors.amber,
                  ),
                ),
                const SizedBox(height: 18),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.panel,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black.withValues(alpha: 0.4)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (final line in _features)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Icon(Icons.check_circle,
                                  size: 18, color: AppColors.amber),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  line,
                                  style: lcdTextStyle(
                                      fontSize: 15, color: AppColors.lcdText),
                                ),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                ElevatedButton(
                  onPressed: store.purchaseInFlight
                      ? null
                      : () => ProStore.instance.buyPro(),
                  child: store.purchaseInFlight
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: AppColors.chassis),
                        )
                      : Text('Unlock PadForge Pro - ${store.displayPrice}, one-time'),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed:
                      store.purchaseInFlight ? null : () => ProStore.instance.restore(),
                  child: Text(
                    'Restore purchase',
                    style: lcdTextStyle(fontSize: 15, color: AppColors.lcdText),
                  ),
                ),
                if (store.lastMessage.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(
                    store.lastMessage,
                    textAlign: TextAlign.center,
                    style: lcdTextStyle(fontSize: 12, color: AppColors.lcdTextDim),
                  ),
                ],
                const SizedBox(height: 10),
                Text(
                  'A one-time purchase, not a subscription. Restores free on your '
                  'other devices signed in to the same store account.',
                  textAlign: TextAlign.center,
                  style: lcdTextStyle(fontSize: 12, color: AppColors.lcdTextDim),
                ),
                const SizedBox(height: 10),
                TextButton(
                  onPressed: () => Navigator.of(context).maybePop(),
                  child: Text(
                    'Maybe later',
                    style: lcdTextStyle(fontSize: 15, color: AppColors.lcdTextDim),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

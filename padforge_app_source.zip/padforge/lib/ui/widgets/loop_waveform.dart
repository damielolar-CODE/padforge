import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../tape/tape_deck.dart';
import '../../tape/wav_tools.dart';
import '../theme/app_theme.dart';

/// The tape deck's main display: an inset dark LCD panel showing what is
/// actually in the loop, with a bright playhead sweeping across it.
///
/// ## Why this was rewritten in v7
///
/// The v5 version was correct but invisible. It was handed **12 parts in 98**
/// of the deck's inner height, which on a 320x568 phone works out at
/// `146.8 x 12/98 =` **18 logical pixels**, 4 of which go on its own inset --
/// leaving a **14dp** drawing area. In that box an audio envelope is a 14px
/// squiggle, a hit-pattern row is a 1-2px dash, and the 11pt `NO LOOP` caption
/// lands right on the edge of the painter's own
/// `painter.height < size.height` guard (and past it, so not drawn at all,
/// whenever the pixel font falls back to the platform monospace, which lays out
/// taller). "Not showing up" and "too small" were one bug, and it was a
/// **height budget** bug, not a painting bug: everything v5 computed was
/// correct. v7 gives the panel 30/97 of the deck (see `TapeDeckPanel`) and
/// draws something worth the room.
///
/// ## What it draws
///
///  * **A mic (or BOTH) loop has audio**, so it draws that audio's peak
///    envelope: one filled column per horizontal pixel, from the quietest to
///    the loudest sample in that slice, sitting either side of a centre zero
///    line -- the shape any DAW would draw. The envelope is computed once by
///    the deck when the audio changes (`TapeDeck._refreshVisual`), cached
///    there, and re-bucketed to this panel's exact pixel width once per width
///    change by [resampleWavPeaks]. Nothing here reads a WAV file, ever.
///  * **A PADS loop has no audio at all.** Drawing a fake waveform would be a
///    lie, so it draws the loop's *hit pattern* as a step / piano-roll grid:
///    one horizontal row band per pad that has hits, a mark at every hit,
///    brightness by velocity. For a drum loop that is genuinely more useful
///    than a waveform -- you can see your kick pattern.
///  * **Bar and beat gridlines** derived from the loop's bar count and tempo,
///    so both views read as music rather than as a signal.
///  * **An empty state** (`NO LOOP`, flat centre line), so the panel never
///    looks broken, and a live progress fill while a take is being recorded.
///
/// ## Rebuild rules
///
/// Nothing here rebuilds per frame. The painter is handed a `repaint:`
/// listenable (the deck's loop-visual notifier, its transport tick, and the
/// deck itself) and the whole thing sits inside a [RepaintBoundary], so a
/// moving playhead repaints this one panel and touches no element in the tree.
class LoopWaveformView extends StatefulWidget {
  const LoopWaveformView({super.key});

  @override
  State<LoopWaveformView> createState() => _LoopWaveformViewState();
}

class _LoopWaveformViewState extends State<LoopWaveformView> {
  /// Lives as long as the panel does, so the painter can cache its re-bucketed
  /// envelope and its row captions across repaints. Held by the State rather
  /// than by the painter because a painter is, in principle, disposable at any
  /// time -- and because this is what guarantees the cache survives the ~15
  /// repaints a second a playing loop causes.
  final _WaveformCache _cache = _WaveformCache();

  late final _LoopWaveformPainter _painter;

  @override
  void initState() {
    super.initState();
    final deck = TapeDeck.instance;
    _painter = _LoopWaveformPainter(
      deck: deck,
      cache: _cache,
      repaint: Listenable.merge([deck.loopVisual, deck.transportTicks, deck]),
    );
  }

  @override
  void dispose() {
    _cache.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF0E0D0B),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: AppColors.amberDeep.withValues(alpha: 0.45)),
          boxShadow: const [
            // Inset: a dark rim inside the top edge reads as a recessed panel.
            BoxShadow(color: Color(0xCC000000), offset: Offset(0, 1), blurRadius: 3),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(5),
          child: CustomPaint(
            painter: _painter,
            size: Size.infinite,
          ),
        ),
      ),
    );
  }
}

/// Everything the painter would otherwise recompute on every repaint.
///
/// Two things are cached, both keyed by what they were derived from, so a
/// change invalidates them and nothing else does:
///
///  * the peak envelope re-bucketed to the panel's exact pixel width, and
///  * one laid-out [TextPainter] per pad-row caption.
class _WaveformCache {
  WavPeaks? _sourcePeaks;
  int _columns = 0;
  WavPeaks? _resampled;
  double _gain = 1.0;

  final Map<String, TextPainter> _labels = {};
  bool _disposed = false;

  /// The envelope, re-bucketed to [columns] columns. Recomputed only when the
  /// audio (identity of [peaks]) or the panel's width changes.
  WavPeaks envelopeFor(WavPeaks peaks, int columns) {
    if (identical(_sourcePeaks, peaks) && _columns == columns && _resampled != null) {
      return _resampled!;
    }
    _sourcePeaks = peaks;
    _columns = columns;
    _resampled = resampleWavPeaks(peaks, columns);
    _gain = envelopeDisplayGain(peaks.peakAmplitude);
    return _resampled!;
  }

  /// Drawing gain for the envelope last handed to [envelopeFor].
  double get gain => _gain;

  /// A laid-out caption for a pad row, e.g. `A1`. There are at most 48 pad ids
  /// in the whole app, so this map is bounded and never needs eviction.
  TextPainter label(String text, double fontSize, Color colour) {
    // The colour is part of the key by its `toString()` rather than by
    // `.value` (deprecated) or `.toARGB32()` (newer than the Flutter floor this
    // app builds against): a Color's description is stable and unique enough
    // for a cache of at most a few dozen captions.
    final key = '$text|${fontSize.toStringAsFixed(1)}|$colour';
    final existing = _labels[key];
    if (existing != null) return existing;
    final painter = TextPainter(
      text: TextSpan(text: text, style: lcdTextStyle(fontSize: fontSize, color: colour)),
      textDirection: TextDirection.ltr,
      maxLines: 1,
    )..layout();
    _labels[key] = painter;
    return painter;
  }

  /// Throws the caption cache away if it has grown past [_maxLabels].
  ///
  /// Most keys are pad ids and are a fixed, tiny set -- but the corner caption
  /// contains the tempo, and someone leaning on TAP TEMPO can mint a new string
  /// every second. Called **only at the start of a paint**, never in the middle
  /// of one: disposing a [TextPainter] that this frame has already fetched and
  /// is about to draw would be a use-after-dispose.
  void trim() {
    if (_labels.length <= _maxLabels) return;
    for (final painter in _labels.values) {
      painter.dispose();
    }
    _labels.clear();
  }

  static const int _maxLabels = 64;

  void dispose() {
    if (_disposed) return;
    _disposed = true;
    for (final painter in _labels.values) {
      painter.dispose();
    }
    _labels.clear();
    _sourcePeaks = null;
    _resampled = null;
  }
}

/// Paints the loop display. See [LoopWaveformView] for the why.
class _LoopWaveformPainter extends CustomPainter {
  final TapeDeck deck;
  final _WaveformCache cache;

  _LoopWaveformPainter({
    required this.deck,
    required this.cache,
    required super.repaint,
  });

  /// Cream, the colour of an old backlit LCD trace.
  static const Color _trace = Color(0xFFF4E4C1);
  static const Color _traceFill = Color(0xFFD8B778);
  static const Color _zeroLine = Color(0xFF6B5A3C);
  static const Color _beatLine = Color(0xFF2E2A22);
  static const Color _barLine = Color(0xFF4A3E28);
  static const Color _stepLine = Color(0xFF1E1B17);

  /// Breathing room inside the panel's border.
  static const double _inset = 3.0;

  @override
  void paint(Canvas canvas, Size size) {
    final width = size.width;
    final height = size.height;
    if (width <= 4 || height <= 4) return;

    final left = _inset;
    final right = width - _inset;
    final top = _inset;
    final bottom = height - _inset;
    if (right - left < 2 || bottom - top < 2) return;

    // Safe here and nowhere else: no caption has been handed out yet this
    // frame, so nothing that is about to be drawn can be disposed.
    cache.trim();

    final visual = deck.loopVisual.value;
    final centre = (top + bottom) / 2;

    _paintGrid(canvas, visual, left, right, top, bottom);

    if (visual.hasAudio) {
      _paintEnvelope(canvas, visual, left, right, top, bottom, centre);
    } else if (visual.hits.isNotEmpty) {
      _paintHitGrid(canvas, visual, left, right, top, bottom);
    } else {
      _paintEmpty(canvas, left, right, top, bottom, centre);
    }

    _paintPlayhead(canvas, left, right, top, bottom);
    _paintCorners(canvas, visual, left, right, top, bottom);
  }

  // --- Grid ---------------------------------------------------------------

  /// Bar lines, beat lines and (when quantise is on and there is room) step
  /// lines, all derived from the loop's bar count -- so the grid the hits snap
  /// to is the grid you can see.
  void _paintGrid(
    Canvas canvas,
    LoopVisual visual,
    double left,
    double right,
    double top,
    double bottom,
  ) {
    final bars = visual.bars;
    if (bars <= 0 || bars > 64) return;
    final span = right - left;
    if (span <= 4) return;

    final beatsPerBar = visual.beatsPerBar > 0 ? visual.beatsPerBar : 4;
    final beats = bars * beatsPerBar;
    final stepsPerBar = visual.stepsPerBar;

    final stepPaint = Paint()
      ..color = _stepLine
      ..strokeWidth = 1;
    final beatPaint = Paint()
      ..color = _beatLine
      ..strokeWidth = 1;
    final barPaint = Paint()
      ..color = _barLine
      ..strokeWidth = 1;

    // Steps first (faintest, most numerous), and only when they would not
    // smear into a solid block: below 4px apart they are noise, not a grid.
    if (stepsPerBar > 0 && stepsPerBar <= 32) {
      final steps = bars * stepsPerBar;
      if (steps > 0 && span / steps >= 4.0) {
        for (var i = 1; i < steps; i++) {
          final x = left + span * i / steps;
          canvas.drawLine(Offset(x, top), Offset(x, bottom), stepPaint);
        }
      }
    }

    if (beats > 0 && span / beats >= 3.0) {
      for (var i = 1; i < beats; i++) {
        if (i % beatsPerBar == 0) continue; // that one is a bar line
        final x = left + span * i / beats;
        canvas.drawLine(Offset(x, top), Offset(x, bottom), beatPaint);
      }
    }

    for (var bar = 1; bar < bars; bar++) {
      final x = left + span * bar / bars;
      canvas.drawLine(Offset(x, top), Offset(x, bottom), barPaint);
    }
  }

  // --- Audio ---------------------------------------------------------------

  /// The peak envelope: one filled column per pixel, from the quietest to the
  /// loudest sample in that slice, either side of the centre zero line.
  ///
  /// A drum or vocal loop's minima and maxima are near mirror images, so this
  /// reads as the symmetric shape a DAW draws -- but it is the *real* min/max,
  /// not one half reflected, so an asymmetric waveform still tells the truth.
  void _paintEnvelope(
    Canvas canvas,
    LoopVisual visual,
    double left,
    double right,
    double top,
    double bottom,
    double centre,
  ) {
    final peaks = visual.peaks;
    if (peaks == null || peaks.isEmpty) return;

    final span = right - left;
    final columns = span.floor().clamp(1, 4096).toInt();
    final envelope = cache.envelopeFor(peaks, columns);
    if (envelope.isEmpty) return;
    final gain = cache.gain;
    final half = (bottom - top) / 2;

    // Zero line first, so the trace sits on top of it.
    canvas.drawLine(
      Offset(left, centre),
      Offset(right, centre),
      Paint()
        ..color = _zeroLine
        ..strokeWidth = 1,
    );

    // One closed path -- out along the top edge, back along the bottom -- so
    // the whole envelope is a single fill and a single stroke, rather than
    // three draw calls per column. At ~290 columns and ~15 repaints a second
    // that difference is worth having on a cheap phone, and a continuous
    // outline is what makes it read as a waveform rather than as a bar chart.
    final columnWidth = span / columns;
    final tops = List<double>.filled(columns, 0);
    final bottoms = List<double>.filled(columns, 0);
    for (var column = 0; column < columns; column++) {
      final lo = (envelope.mins[column] * gain).clamp(-1.0, 1.0).toDouble();
      final hi = (envelope.maxs[column] * gain).clamp(-1.0, 1.0).toDouble();
      var yTop = centre - hi * half;
      var yBottom = centre - lo * half;
      if (yTop > yBottom) {
        final swap = yTop;
        yTop = yBottom;
        yBottom = swap;
      }
      // Silence still gets a hairline, so a gap in the audio reads as a flat
      // line rather than as a hole in the display.
      if (yBottom - yTop < 1.2) {
        yTop = centre - 0.6;
        yBottom = centre + 0.6;
      }
      tops[column] = yTop;
      bottoms[column] = yBottom;
    }

    final path = Path()..moveTo(left, tops[0]);
    for (var column = 0; column < columns; column++) {
      final x = left + column * columnWidth;
      path
        ..lineTo(x, tops[column])
        ..lineTo(x + columnWidth, tops[column]);
    }
    for (var column = columns - 1; column >= 0; column--) {
      final x = left + column * columnWidth;
      path
        ..lineTo(x + columnWidth, bottoms[column])
        ..lineTo(x, bottoms[column]);
    }
    path.close();

    canvas.drawPath(
      path,
      Paint()
        ..color = _traceFill
        ..style = PaintingStyle.fill,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = _trace
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1,
    );
  }

  // --- Pad hits ------------------------------------------------------------

  /// The step / piano-roll view a PADS loop gets instead of a waveform: one row
  /// band per pad that has hits, a mark at every hit.
  void _paintHitGrid(
    Canvas canvas,
    LoopVisual visual,
    double left,
    double right,
    double top,
    double bottom,
  ) {
    final loopMs = visual.loopMs;
    if (loopMs <= 0) return;

    final padIds = _rowsFor(visual.hits);
    if (padIds.isEmpty) return;
    final rows = padIds.length;
    final rowHeight = (bottom - top) / rows;
    if (rowHeight <= 0) return;

    final span = right - left;
    final rowIndex = <String, int>{};
    for (var i = 0; i < rows; i++) {
      rowIndex[padIds[i]] = i;
    }

    // A caption fits from about 9dp of row height upwards; below that the rows
    // are stripes and the marks have to speak for themselves.
    final showLabels = rowHeight >= 9.0 && span > 70;
    final labelFontSize = math.min(11.0, rowHeight - 1).clamp(7.0, 11.0).toDouble();
    var labelWidth = 0.0;
    if (showLabels) {
      for (final padId in padIds) {
        final painter = cache.label(padId, labelFontSize, AppColors.lcdTextDim);
        if (painter.width > labelWidth) labelWidth = painter.width;
      }
      labelWidth += 4;
      // Never let captions eat the pattern.
      if (labelWidth > span * 0.18) labelWidth = span * 0.18;
    }
    final laneLeft = left + labelWidth;
    final laneSpan = right - laneLeft;
    if (laneSpan <= 2) return;

    // Alternating row shading, so eight rows of dots still read as eight rows.
    final shade = Paint()..color = const Color(0x14FFFFFF);
    for (var row = 0; row < rows; row++) {
      if (row.isOdd) continue;
      canvas.drawRect(
        Rect.fromLTRB(left, top + rowHeight * row, right, top + rowHeight * (row + 1)),
        shade,
      );
    }

    if (showLabels) {
      for (var row = 0; row < rows; row++) {
        final painter = cache.label(padIds[row], labelFontSize, AppColors.lcdTextDim);
        if (painter.height > rowHeight) continue;
        painter.paint(
          canvas,
          Offset(left + 1, top + rowHeight * row + (rowHeight - painter.height) / 2),
        );
      }
    }

    final markWidth = math.max(2.0, math.min(5.0, laneSpan / 96));
    // One Paint, recoloured per hit: a busy loop is a few hundred marks and
    // this runs on every repaint.
    final paint = Paint()..style = PaintingStyle.fill;
    for (final hit in visual.hits) {
      final row = rowIndex[hit.padId];
      if (row == null) continue;
      final fraction = (hit.offsetMs / loopMs).clamp(0.0, 1.0).toDouble();
      final velocity = (hit.velocity / 127.0).clamp(0.12, 1.0).toDouble();

      final markHeight = math.max(2.0, (rowHeight - 3) * (0.45 + 0.55 * velocity));
      final rowTop = top + rowHeight * row + (rowHeight - markHeight) / 2;
      var x = laneLeft + laneSpan * fraction - markWidth / 2;
      if (x < laneLeft) x = laneLeft;
      if (x + markWidth > right) x = right - markWidth;

      paint.color = Color.lerp(AppColors.amberDeep, AppColors.amber, velocity)!;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, rowTop, markWidth, markHeight),
          const Radius.circular(1.5),
        ),
        paint,
      );
    }
  }

  /// Which pads get a row, top to bottom.
  ///
  /// Sorted by pad id the way a human reads them (`A2` before `A10`, `A16`
  /// before `B1`), so the rows keep the same order every repaint and a new
  /// overdub on a pad that already has hits lands in the row it belongs to
  /// rather than adding a second one.
  List<String> _rowsFor(List<LoopPadEvent> hits) {
    final ids = <String>{};
    for (final hit in hits) {
      ids.add(hit.padId);
    }
    return ids.toList()..sort(_comparePadIds);
  }

  static int _comparePadIds(String a, String b) {
    final bankA = a.isEmpty ? '' : a.substring(0, 1);
    final bankB = b.isEmpty ? '' : b.substring(0, 1);
    final byBank = bankA.compareTo(bankB);
    if (byBank != 0) return byBank;
    final numberA = int.tryParse(a.length > 1 ? a.substring(1) : '') ?? 0;
    final numberB = int.tryParse(b.length > 1 ? b.substring(1) : '') ?? 0;
    if (numberA != numberB) return numberA - numberB;
    return a.compareTo(b);
  }

  // --- Empty / recording ---------------------------------------------------

  void _paintEmpty(
    Canvas canvas,
    double left,
    double right,
    double top,
    double bottom,
    double centre,
  ) {
    final recording = deck.state == LoopState.recording;

    // While a take is being captured there is no loop to draw yet, so the panel
    // fills up behind the playhead instead of saying NO LOOP at someone who is
    // in the middle of recording.
    if (recording) {
      final progress = deck.progress.clamp(0.0, 1.0).toDouble();
      if (progress > 0) {
        canvas.drawRect(
          Rect.fromLTRB(left, top, left + (right - left) * progress, bottom),
          Paint()..color = AppColors.danger.withValues(alpha: 0.16),
        );
      }
    }

    canvas.drawLine(
      Offset(left, centre),
      Offset(right, centre),
      Paint()
        ..color = _trace.withValues(alpha: 0.22)
        ..strokeWidth = 1,
    );

    final text = recording ? 'RECORDING' : 'NO LOOP';
    final colour = recording ? AppColors.danger : AppColors.lcdTextDim;
    final fontSize = math.min(15.0, (bottom - top) * 0.34).clamp(8.0, 15.0).toDouble();
    final painter = cache.label(text, fontSize, colour);
    if (painter.width < right - left && painter.height < bottom - top) {
      painter.paint(
        canvas,
        Offset(
          left + ((right - left) - painter.width) / 2,
          centre - painter.height / 2,
        ),
      );
    }
  }

  // --- Playhead / captions --------------------------------------------------

  void _paintPlayhead(
    Canvas canvas,
    double left,
    double right,
    double top,
    double bottom,
  ) {
    final fraction = _playheadFraction();
    if (fraction == null) return;
    final span = right - left;
    final x = (left + span * fraction).clamp(left, right - 1).toDouble();

    // A soft halo either side, then the line itself: bright enough to find at
    // a glance on a lit stage, thin enough not to hide the hit under it.
    canvas.drawRect(
      Rect.fromLTRB(x - 2.5, top, x + 2.5, bottom),
      Paint()..color = AppColors.amber.withValues(alpha: 0.18),
    );
    canvas.drawLine(
      Offset(x, top),
      Offset(x, bottom),
      Paint()
        ..color = AppColors.amber
        ..strokeWidth = 1.6,
    );
  }

  /// A small caption in each top corner: what the panel is showing on the left,
  /// how long the loop is on the right. Skipped entirely when the panel is too
  /// short to carry text without covering the trace.
  void _paintCorners(
    Canvas canvas,
    LoopVisual visual,
    double left,
    double right,
    double top,
    double bottom,
  ) {
    final height = bottom - top;
    if (height < 34 || right - left < 110) return;

    final String leftText;
    if (visual.isEmpty) {
      return;
    } else if (visual.hasAudio) {
      leftText = 'AUDIO';
    } else {
      leftText = 'PADS';
    }
    final bars = visual.bars;
    final rightText = bars > 0
        ? '$bars BAR${bars == 1 ? '' : 'S'}  ${visual.bpm.toStringAsFixed(0)} BPM'
        : '${(visual.loopMs / 1000).toStringAsFixed(1)}s';

    final leftPainter = cache.label(leftText, 9, AppColors.amberDeep);
    final rightPainter = cache.label(rightText, 9, AppColors.amberDeep);
    if (leftPainter.width + rightPainter.width + 12 > right - left) return;
    leftPainter.paint(canvas, Offset(left + 2, top + 1));
    rightPainter.paint(canvas, Offset(right - rightPainter.width - 2, top + 1));
  }

  /// Where the playhead sits, 0.0-1.0, or null when nothing is moving.
  double? _playheadFraction() {
    switch (deck.state) {
      case LoopState.playing:
      case LoopState.overdubbing:
        final loopMs = deck.recordedLoopDuration.inMilliseconds;
        if (loopMs <= 0) return null;
        return (deck.position.inMilliseconds / loopMs).clamp(0.0, 1.0).toDouble();
      case LoopState.recording:
        return deck.progress;
      case LoopState.empty:
      case LoopState.armed:
      case LoopState.stopped:
        return null;
    }
  }

  @override
  bool shouldRepaint(covariant _LoopWaveformPainter oldDelegate) =>
      !identical(oldDelegate.deck, deck) || !identical(oldDelegate.cache, cache);
}

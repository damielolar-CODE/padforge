import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// The PadForge brand mark, drawn as vectors so it is crisp at any size.
///
/// ## The mark: "the struck pad and the rising step"
///
/// A 4x4 pad grid -- the MPD218's grid, and the app's own -- in which the lit
/// pads form an ascending staircase from the **bottom-left** pad upwards and
/// to the right (column heights 1, 2, 3, 4). Bottom-left is where an MPD218
/// starts counting, which is the same origin the pad grid on the home screen
/// uses, so the logo and the instrument tell the same story. The staircase
/// reads at once as a play/forward wedge, a rising velocity ramp and a step
/// pattern; the six unlit pads at the top left are what keep it reading as a
/// *grid* rather than as a generic triangle. The bottom-left pad is cream: it
/// is the one that has just been hit.
///
/// Nothing here is thinner than a pad, and there is no lettering, because both
/// vanish once the icon is scaled down to 48px on a home screen.
///
/// The geometry is the 1024-unit design from `assets/branding/logo.svg`, and
/// `tools/gen_branding.py` renders the launcher icons from the same numbers.
/// **Change one, change all three.**
///
/// This is never loaded from a raster: a `CustomPainter` costs one draw call
/// per pad and stays sharp on any display, where a PNG would be soft at half
/// the sizes it is used at.
class PadForgeLogo extends StatelessWidget {
  /// Side length of the mark in logical pixels.
  final double size;

  /// When true, the mark is drawn on its own rounded chassis plate, the way
  /// the app icon looks. When false (the default) only the pads are drawn, on
  /// whatever background it is placed over -- which is what the status bar and
  /// the About screen want.
  final bool plate;

  const PadForgeLogo({super.key, required this.size, this.plate = false});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'PadForge',
      image: true,
      child: RepaintBoundary(
        child: CustomPaint(
          size: Size.square(size),
          isComplex: false,
          willChange: false,
          painter: PadForgeLogoPainter(plate: plate),
        ),
      ),
    );
  }
}

/// Paints [PadForgeLogo]. Public so a screen can paint the mark into a
/// different box shape if it ever needs to.
class PadForgeLogoPainter extends CustomPainter {
  final bool plate;

  const PadForgeLogoPainter({this.plate = false});

  // The 1024-unit design grid, shared with logo.svg / gen_branding.py.
  static const double _design = 1024;
  static const double _gridOrigin = 152;
  static const double _cell = 150;
  static const double _gap = 40;
  static const double _cellRadius = 33;
  static const double _gridSpan = 4 * _cell + 3 * _gap; // 720
  static const double _plateRadius = 0.22;

  static const int _struckRow = 3;
  static const int _struckCol = 0;

  /// A pad is lit when `row >= 3 - col`, counting rows from the top. That is
  /// the ascending staircase, and it is the single line of logic the whole
  /// mark is built from.
  static bool isLit(int row, int col) => row >= 3 - col;

  static const LinearGradient _lit = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [AppColors.logoLitTop, AppColors.logoLitMid, AppColors.logoLitBottom],
    stops: [0.0, 0.55, 1.0],
  );

  static const LinearGradient _strike = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [AppColors.logoStrikeTop, AppColors.logoStrikeMid, AppColors.logoLitMid],
    stops: [0.0, 0.6, 1.0],
  );

  static const LinearGradient _recess = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [AppColors.logoRecessTop, AppColors.logoRecessBottom],
  );

  @override
  void paint(Canvas canvas, Size size) {
    final side = math.min(size.width, size.height);
    if (side <= 0) return;

    // Centre the (square) mark in whatever box we were handed.
    final dx = (size.width - side) / 2;
    final dy = (size.height - side) / 2;

    final double scale;
    final double origin;
    if (plate) {
      // Icon proportions: the grid sits inside a rounded chassis plate.
      scale = side / _design;
      origin = _gridOrigin * scale;
      final plateRect = Rect.fromLTWH(dx, dy, side, side);
      canvas.drawRRect(
        RRect.fromRectAndRadius(plateRect, Radius.circular(side * _plateRadius)),
        Paint()..color = AppColors.chassis,
      );
    } else {
      // In-app: the pads fill the box edge to edge, with no plate and no
      // padding of their own, so a caller sizing this to 20dp gets 20dp of
      // actual mark.
      scale = side / _gridSpan;
      origin = 0;
    }

    final cell = _cell * scale;
    final step = (_cell + _gap) * scale;
    final radius = Radius.circular(_cellRadius * scale);
    final paint = Paint()..isAntiAlias = true;

    for (var row = 0; row < 4; row++) {
      for (var col = 0; col < 4; col++) {
        final rect = Rect.fromLTWH(
          dx + origin + col * step,
          dy + origin + row * step,
          cell,
          cell,
        );
        final LinearGradient gradient;
        if (!isLit(row, col)) {
          gradient = _recess;
        } else if (row == _struckRow && col == _struckCol) {
          gradient = _strike;
        } else {
          gradient = _lit;
        }
        paint.shader = gradient.createShader(rect);
        canvas.drawRRect(RRect.fromRectAndRadius(rect, radius), paint);
      }
    }
  }

  @override
  bool shouldRepaint(PadForgeLogoPainter oldDelegate) => oldDelegate.plate != plate;
}

/// The mark beside the `PADFORGE` wordmark -- the lockup used in the status
/// bar and on the About screen.
///
/// Kept deliberately plain: a [Row] whose height is the taller of the mark and
/// one line of text, so dropping it into a fixed-height bar cannot change that
/// bar's height. The caller decides what happens on a tap.
class PadForgeLockup extends StatelessWidget {
  final double markSize;
  final double fontSize;
  final Color color;

  /// Space between the mark and the wordmark.
  final double spacing;

  const PadForgeLockup({
    super.key,
    this.markSize = 20,
    this.fontSize = 16,
    this.color = AppColors.lcdText,
    this.spacing = 7,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        PadForgeLogo(size: markSize),
        SizedBox(width: spacing),
        Text(
          'PADFORGE',
          maxLines: 1,
          overflow: TextOverflow.clip,
          style: lcdTextStyle(
            fontSize: fontSize,
            color: color,
            letterSpacing: fontSize * 0.06,
          ),
        ),
      ],
    );
  }
}

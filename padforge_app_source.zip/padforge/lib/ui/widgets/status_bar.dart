import 'package:flutter/material.dart';

import '../../midi/midi_service.dart';
import '../screens/settings_screen.dart';
import '../theme/app_theme.dart';

/// Top status bar: MIDI connection indicator + device name, and a settings
/// gear that opens the full MIDI device / connection screen.
class StatusBar extends StatelessWidget {
  const StatusBar({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: MidiService.instance,
      builder: (context, _) {
        final midi = MidiService.instance;
        final connected = midi.isConnected;
        final Color dotColor = connected
            ? AppColors.success
            : (midi.isScanning ? AppColors.amber : AppColors.danger);

        return Container(
          color: AppColors.panel,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'PADFORGE  //  ${midi.statusLabel}',
                  style: lcdTextStyle(fontSize: 18, color: AppColors.lcdText),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.settings, color: AppColors.lcdTextDim),
                tooltip: 'Settings',
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                  );
                },
              ),
            ],
          ),
        );
      },
    );
  }
}

import 'package:flutter/material.dart';

import '../../midi/midi_service.dart';
import '../../state/app_state.dart';
import '../screens/about_screen.dart';
import '../screens/settings_screen.dart';
import '../theme/app_theme.dart';
import 'padforge_logo.dart';

/// Top status bar: the PadForge logo and wordmark, a MIDI connection
/// indicator with the device name, and a settings gear.
///
/// It doubles as the app's "something you should know" line. If the audio
/// engine failed to start it says so in red, and while a kit's samples are
/// being decoded into memory it shows "LOADING KIT" -- otherwise that pause
/// would look like the app had frozen.
///
/// **Tapping the logo or the wordmark opens the About screen.**
///
/// ## The height budget (do not grow this bar)
///
/// `home_screen.dart` sizes the whole instrument from the height left over
/// after this bar and the bottom toolbar, so every dp here is a dp the pads
/// do not get. The bar is `4 + content + 4`, and its content height is set by
/// the tallest child: the settings gear, whose `BoxConstraints.tightFor`
/// pins it to **30**. The branding added in v8 is therefore deliberately
/// smaller than that -- an 18dp mark and a 16pt wordmark, inside a 30dp tap
/// target -- so the bar is exactly the ~38dp it has always been. Anything
/// taller than 30 here shifts every worked example in PROJECT_NOTES down.
class StatusBar extends StatelessWidget {
  const StatusBar({super.key});

  /// The tallest a child of the bar's [Row] may be. See the class doc.
  static const double contentHeight = 30;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([MidiService.instance, AppState.instance]),
      builder: (context, _) {
        final midi = MidiService.instance;
        final app = AppState.instance;
        final audioError = app.audioEngineError;
        final connected = midi.isConnected;

        final Color dotColor;
        final String label;
        final Color labelColor;
        if (audioError != null) {
          dotColor = AppColors.danger;
          label = audioError;
          labelColor = AppColors.danger;
        } else if (app.isLoadingKit) {
          dotColor = AppColors.amber;
          label = 'LOADING KIT...';
          labelColor = AppColors.amber;
        } else {
          dotColor = connected
              ? AppColors.success
              : (midi.isScanning ? AppColors.amber : AppColors.danger);
          label = midi.statusLabel;
          labelColor = AppColors.lcdText;
        }

        // Compact on purpose: every dp this bar gives back is a dp the pads
        // get. A stock IconButton reserves 48dp of height all by itself, which
        // is why the gear is constrained down to 30.
        return Container(
          color: AppColors.panel,
          padding: const EdgeInsets.fromLTRB(10, 4, 6, 4),
          // The bar is a fixed-height instrument fascia, not prose: at a 3.0
          // system text scale an unclamped 16pt wordmark plus an unclamped
          // status line is wider than a 320dp phone (a RenderFlex overflow)
          // *and* taller than the 30dp content row (which would push the pad
          // grid down). Clamping to 1.2 keeps both inside their budget while
          // still honouring most of the user's preference. Every other screen
          // in the app scales freely.
          child: MediaQuery.withClampedTextScaling(
            maxScaleFactor: 1.2,
            child: Row(
              children: [
                // The brand lockup, and the way into the About screen. Its
                // visual footprint is 18dp of mark plus one line of text; its
                // tap target is the full height of the bar's content row.
                Tooltip(
                  message: 'About PadForge',
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(builder: (_) => const AboutScreen()),
                      );
                    },
                    child: const SizedBox(
                      height: contentHeight,
                      child: Center(
                        child: PadForgeLockup(markSize: 18, fontSize: 16),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Container(
                  width: 9,
                  height: 9,
                  decoration: BoxDecoration(color: dotColor, shape: BoxShape.circle),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    label,
                    maxLines: 1,
                    style: lcdTextStyle(fontSize: 16, color: labelColor),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.settings, color: AppColors.lcdTextDim),
                  iconSize: 20,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints.tightFor(
                    width: 34,
                    height: contentHeight,
                  ),
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Settings',
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
                    );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

import 'package:flutter/material.dart';

import '../../state/app_state.dart';
import 'pad_button.dart';

/// The 4x4 pad grid for the currently-selected bank.
///
/// Pad order on screen is simple reading order (top-left = pad 1, reading
/// left-to-right, top-to-bottom) rather than mirroring the MPD218's
/// physical layout -- since hardware hits are matched purely by MIDI note
/// number (not screen position), the on-screen order is free to be whatever
/// is most intuitive for touch play.
class PadGrid extends StatelessWidget {
  const PadGrid({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        final kit = app.currentKit;
        final pads = kit?.padsForBank(app.currentBank) ?? const [];

        return AspectRatio(
          aspectRatio: 1,
          child: GridView.builder(
            padding: const EdgeInsets.all(4),
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              mainAxisSpacing: 6,
              crossAxisSpacing: 6,
            ),
            itemCount: pads.length,
            itemBuilder: (context, index) {
              return PadButton(padId: pads[index].padId);
            },
          ),
        );
      },
    );
  }
}

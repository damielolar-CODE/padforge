import 'package:flutter/material.dart';

import '../../models/pad.dart';
import '../../state/app_state.dart';
import 'pad_button.dart';

/// Turns a position in the 4x4 grid as it is **drawn** (0 = top-left, reading
/// left to right, top to bottom) into the index of the pad that belongs there.
///
/// ## Why this exists -- the v5 bug fix
///
/// On the MPD218, **pad 1 is the bottom-left pad**. The pads ascend left to
/// right and then *upwards*: 1-4 across the bottom row, 5-8 above them, and
/// 13-16 across the top. PadForge used to draw them in plain reading order, so
/// A1 sat top-left: the screen was a vertical mirror image of the hardware in
/// the user's hands. Hitting the bottom-left hardware pad played the right
/// sample (notes were always matched by MIDI note number) but lit a square
/// three rows away, and the app looked like it was playing the wrong pad. It
/// was reported as "the wrong sample plays" and "only one pad is mapped
/// right" -- the one pad that lands in the same place in both layouts.
///
/// With [bottomLeft] true (the default) the drawn row `r` (0 at the top) holds
/// the pads of hardware row `3 - r`, so:
///
/// ```
///   drawn:  A13 A14 A15 A16      notes 48 49 50 51   <- top of the screen
///           A9  A10 A11 A12            44 45 46 47
///           A5  A6  A7  A8             40 41 42 43
///           A1  A2  A3  A4             36 37 38 39   <- bottom, = hardware pad 1
/// ```
///
/// **Nothing about padId-to-note assignment changes** -- this is purely the
/// order the squares are drawn in. [bottomLeft] false gives the old reading
/// order back for anyone whose controller is configured differently.
int padIndexForGridSlot(int slot, {required bool bottomLeft}) {
  if (!bottomLeft) return slot;
  final row = slot ~/ 4;
  final column = slot % 4;
  return (3 - row) * 4 + column;
}

/// The 4x4 pad grid for the currently-selected bank.
///
/// It fills whatever box its parent gives it (the home screen works that out
/// from the screen height) and divides it into four equal rows of four equal
/// pads with `Expanded`, so it can never overflow and never needs to scroll,
/// on any phone.
class PadGrid extends StatelessWidget {
  const PadGrid({super.key});

  /// Gap between pads. Kept small so the pads themselves stay as big as
  /// possible on a small screen.
  static const double _gap = 5;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        final kit = app.currentKit;
        // Sorted by pad number rather than trusted to be in file order: the
        // whole point of this widget is that slot N holds pad N, and a kit.json
        // that listed its pads out of order would otherwise scramble the grid.
        final pads = List<Pad>.from(kit?.padsForBank(app.currentBank) ?? const [])
          ..sort((a, b) => a.numberInBank.compareTo(b.numberInBank));
        final bottomLeft = app.padLayoutBottomLeft;

        return Column(
          children: [
            for (var row = 0; row < 4; row++) ...[
              if (row > 0) const SizedBox(height: _gap),
              Expanded(
                child: Row(
                  children: [
                    for (var column = 0; column < 4; column++) ...[
                      if (column > 0) const SizedBox(width: _gap),
                      Expanded(
                        child: _slot(pads, row * 4 + column, bottomLeft),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ],
        );
      },
    );
  }

  Widget _slot(List<Pad> pads, int slot, bool bottomLeft) {
    final index = padIndexForGridSlot(slot, bottomLeft: bottomLeft);
    if (index < 0 || index >= pads.length) {
      return const SizedBox.shrink();
    }
    return PadButton(padId: pads[index].padId);
  }
}

import 'dart:async';

import 'package:flutter/material.dart';

import '../../services/pro_store.dart';
import '../../tape/record_source.dart';
import '../../tape/tape_deck.dart';
import '../../tape/take_recorder.dart';
import '../screens/recordings_screen.dart';
import '../theme/app_theme.dart';
import 'loop_waveform.dart';
import 'paywall_sheet.dart';
import 'tape_reels.dart';

/// The tape deck that sits across the top of the main screen.
///
/// It is two machines in one panel:
///
///  * a **looper** -- tap LOOP once to arm it, start playing and it begins
///    recording on your first hit, tap LOOP again to close the loop and it
///    repeats forever. After that the same pad overdubs: tap to start a new
///    layer over the top, tap to keep it, as many times as you like. UNDO takes
///    the last layer back off. STOP silences it (or throws away a layer still
///    being recorded); holding either pad for most of a second wipes it.
///  * an **unlimited recorder** -- the round REC button records until you press
///    it again, and saves the take into the Recordings list.
///
/// Both obey the **source** selector: PADS (the default -- no microphone
/// involved at all), MIC, or BOTH.
///
/// Visually it is a compact reel-to-reel deck: two turning reels on the left,
/// an LCD readout on the right, then the **loop display** (the big one -- see
/// [LoopWaveformView]), one control strip, and the transport buttons.
///
/// ## Layout rules this file sticks to (v5, rebalanced in v7)
///
/// The panel is given a **fixed height** by the home screen, which works that
/// height out from the size of the phone. Inside it, every row is an
/// `Expanded` with a flex weight, so the whole deck scales with whatever
/// height it is handed and **cannot overflow** -- there is no fixed dp height
/// anywhere in the column. Inside a row, every caption is a
/// `FittedBox(scaleDown)` and every column is `Flexible`, so a large system
/// text scale shrinks the lettering instead of bursting the row.
///
/// ### The v7 height budget, and why it changed
///
/// v5 weighted the rows 34 reels+LCD / 12 waveform / 13 source / 13 quantise /
/// 26 transport = 98, with four 4dp gaps. On a 320x568 phone the deck is
/// 182.8dp, of which 8 is margin, 12 is padding and 16 is gaps, leaving 146.8
/// of flex -- so the waveform got `146.8 x 12/98 =` **18dp**, and 6 of those go
/// on its own border and inset. That is why the user could not see it. v7 is:
///
/// | row | flex | 320x568 | 390x844 | 430x932 |
/// |---|---|---|---|---|
/// | reels + LCD | 30 | 46.6 | 73.2 | 79.8 |
/// | **loop display** | **30** | **46.6** | **73.2** | **79.8** |
/// | source + quantise | 13 | 20.2 | 31.7 | 34.6 |
/// | transport | 24 | 37.3 | 58.6 | 63.9 |
///
/// 97 parts, three 4dp gaps, and the flex available is
/// `deck - 8 margin - 12 padding - 12 gaps`: **150.8** for a 182.8dp deck on
/// 320x568, **236.8** for a 268.8dp deck on 390x844, **258** for the capped
/// 290dp deck on 430x932. The rows are `Expanded`, so they sum to the height
/// available **by construction** -- there is no screen size at which this
/// column can overflow, whatever the arithmetic above says.
///
/// The fold-out tempo/length/threshold controls used to expand the panel
/// inline, which cannot work now that nothing scrolls; TUNE opens them in a
/// bottom sheet instead.
///
/// ## Rebuild rules this file sticks to (v5)
///
/// A playing loop must not rebuild this panel. The deck notifies its listeners
/// only when something structural changes (state, layers, settings); the moving
/// playhead arrives separately on `TapeDeck.transportTicks`, and only three
/// things listen to it: the reels, the two clock lines of the LCD (via
/// [_LcdLine], which rebuilds only when its *text* changes), and the waveform
/// painter. Everything expensive is inside a [RepaintBoundary].
class TapeDeckPanel extends StatefulWidget {
  const TapeDeckPanel({super.key});

  @override
  State<TapeDeckPanel> createState() => _TapeDeckPanelState();
}

class _TapeDeckPanelState extends State<TapeDeckPanel> {
  StreamSubscription<String>? _messageSub;
  StreamSubscription<String>? _recorderMessageSub;

  @override
  void initState() {
    super.initState();
    _messageSub = TapeDeck.instance.messages.listen(_showMessage);
    // The recorder auto-stops a free take at its length cap; that notice comes
    // through here, since the UI is not the caller in that case.
    _recorderMessageSub = TakeRecorder.instance.messages.listen(_showMessage);
  }

  @override
  void dispose() {
    _messageSub?.cancel();
    _recorderMessageSub?.cancel();
    super.dispose();
  }

  void _showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          duration: const Duration(milliseconds: 1800),
          content: Text(
            message,
            style: lcdTextStyle(fontSize: 15, color: AppColors.lcdText),
          ),
        ),
      );
  }

  Future<void> _toggleTakeRecorder() async {
    final recorder = TakeRecorder.instance;
    if (recorder.isRecording) {
      final path = await recorder.stop();
      if (!mounted) return;
      final name = path == null ? 'take' : path.split('/').last;
      final notice = recorder.notice;
      _showMessage(notice == null ? 'Saved $name' : 'Saved $name - $notice');
    } else {
      final started = await recorder.start(source: TapeDeck.instance.source);
      if (!mounted) return;
      if (!started) {
        _showMessage(recorder.errorMessage ?? 'Could not start recording');
      } else if (recorder.notice != null) {
        _showMessage(recorder.notice!);
      }
    }
  }

  void _openTuneSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.panel,
      isScrollControlled: true,
      builder: (sheetContext) => const _TapeSettingsSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final deck = TapeDeck.instance;
    return ListenableBuilder(
      listenable: Listenable.merge([deck, TakeRecorder.instance, ProStore.instance]),
      builder: (context, _) {
        final state = deck.state;
        final isPro = ProStore.instance.isPro;
        return Container(
          margin: const EdgeInsets.fromLTRB(10, 4, 10, 4),
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.black.withValues(alpha: 0.55)),
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF262220), AppColors.chassis],
            ),
            boxShadow: const [
              BoxShadow(color: AppColors.bevelShadow, offset: Offset(0, 3), blurRadius: 6),
            ],
          ),
          // Flex weights, not fixed heights: the deck fits whatever box the
          // home screen gives it, on any phone, and can never overflow. See the
          // class doc for the v7 budget -- 30 reels+LCD / 30 loop display /
          // 13 source+quantise / 24 transport, plus three 4dp gaps.
          child: Column(
            children: [
              Expanded(
                flex: 30,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: 5,
                      child: _ReelsBay(
                        recording: deck.isCapturing || TakeRecorder.instance.isRecording,
                        spinning:
                            deck.isTransportRunning || TakeRecorder.instance.isRecording,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Expanded(flex: 6, child: _TapeLcd()),
                  ],
                ),
              ),
              const SizedBox(height: 4),
              const Expanded(flex: 30, child: LoopWaveformView()),
              const SizedBox(height: 4),
              const Expanded(flex: 13, child: _SourceQuantizeStrip()),
              const SizedBox(height: 4),
              Expanded(
                flex: 24,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: 5,
                      child: _TapePad(
                        label: deck.loopPadLabel,
                        icon: _loopPadIcon(state),
                        active: _loopPadLit(state),
                        activeColor: _loopPadColor(state),
                        // Only an overdub pulses: recording the base pass is
                        // steady red, laying a layer over a running loop
                        // breathes, so the two never look alike.
                        pulsing: state == LoopState.overdubbing,
                        // Recording the base loop and playing it back are free;
                        // only the overdub entry point (tapping LOOP while the
                        // loop is PLAYING) is gated behind Pro.
                        onTap: () {
                          if (state == LoopState.playing && !isPro) {
                            showPaywall(context, highlight: 'Overdub');
                            return;
                          }
                          deck.tapLoopPad();
                        },
                        onHoldComplete: () => deck.clearAll(),
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      flex: 4,
                      child: _TapePad(
                        label: 'STOP',
                        icon: Icons.stop,
                        active: false,
                        activeColor: AppColors.amber,
                        onTap: () => deck.tapStopPad(),
                        onHoldComplete: () => deck.clearAll(),
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      flex: 3,
                      child: _SmallDeckButton(
                        icon: isPro ? Icons.undo : Icons.lock_outline,
                        label: 'UNDO',
                        active: false,
                        activeColor: AppColors.amber,
                        // Free users see UNDO live (not greyed) so a tap can
                        // explain it is Pro; Pro users get the real "is there a
                        // layer to remove?" enablement.
                        enabled: isPro ? deck.canUndo : true,
                        onTap: () {
                          if (!isPro) {
                            showPaywall(context, highlight: 'Undo');
                            return;
                          }
                          deck.undoLayer();
                        },
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      flex: 3,
                      child: _SmallDeckButton(
                        icon: TakeRecorder.instance.isRecording
                            ? Icons.stop_circle_outlined
                            : Icons.fiber_smart_record,
                        label: TakeRecorder.instance.isRecording
                            ? TakeRecorder.instance.elapsedLabel
                            : 'REC',
                        active: TakeRecorder.instance.isRecording,
                        activeColor: AppColors.danger,
                        onTap: _toggleTakeRecorder,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      flex: 3,
                      child: _SmallDeckButton(
                        icon: Icons.tune,
                        label: 'TUNE',
                        active: false,
                        activeColor: AppColors.amber,
                        onTap: _openTuneSheet,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Expanded(
                      flex: 3,
                      child: _SmallDeckButton(
                        icon: Icons.album_outlined,
                        label: 'TAPES',
                        active: false,
                        activeColor: AppColors.amber,
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(
                              builder: (_) => const RecordingsScreen(),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// The reels, with their progress fed from the transport tick rather than from
/// a rebuild of the whole panel.
///
/// This little widget is the only thing in the deck that rebuilds while a loop
/// plays, and all it does is hand three numbers to a painter that is already
/// wrapped in a [RepaintBoundary].
class _ReelsBay extends StatelessWidget {
  final bool spinning;
  final bool recording;

  const _ReelsBay({required this.spinning, required this.recording});

  @override
  Widget build(BuildContext context) {
    final deck = TapeDeck.instance;
    return ListenableBuilder(
      listenable: deck.transportTicks,
      builder: (context, _) => TapeReelsView(
        spinning: spinning,
        // The record lamp is lit for an overdub too, while the reels keep
        // turning -- which is exactly what an overdub is: the tape rolling
        // *and* recording.
        recording: recording,
        progress: deck.progress,
      ),
    );
  }
}

/// The LOOP pad's icon, which -- like its label -- describes what the next tap
/// will do, not what the deck is doing now.
IconData _loopPadIcon(LoopState state) {
  switch (state) {
    case LoopState.empty:
      return Icons.fiber_manual_record;
    case LoopState.armed:
      return Icons.radio_button_checked;
    case LoopState.recording:
      return Icons.flag_outlined;
    case LoopState.playing:
      return Icons.layers;
    case LoopState.overdubbing:
      return Icons.layers_clear;
    case LoopState.stopped:
      return Icons.play_arrow;
  }
}

/// The pad's colour, which is the fastest way to read the state across a room:
/// amber waiting, red recording the base pass, red (and pulsing, see
/// [_TapePad]) while a layer is going down on top, green while it just plays.
Color _loopPadColor(LoopState state) {
  switch (state) {
    case LoopState.recording:
    case LoopState.overdubbing:
      return AppColors.danger;
    case LoopState.playing:
      return AppColors.success;
    case LoopState.empty:
    case LoopState.armed:
    case LoopState.stopped:
      return AppColors.amber;
  }
}

bool _loopPadLit(LoopState state) =>
    state == LoopState.armed ||
    state == LoopState.recording ||
    state == LoopState.overdubbing ||
    state == LoopState.playing;

/// One row carrying both face-level settings: **what gets recorded** (pads,
/// microphone or both) and **quantise**.
///
/// Up to v6 these were two rows. The waveform display was 12/98 of the deck --
/// about 18dp on a small phone, which is why the user could not see it -- and
/// the honest way to give it a display's worth of height was to take a row
/// back. Nothing was lost:
///
///  * SOURCE keeps its three explicit buttons, because "why is my voice in the
///    loop?" was one of the two biggest complaints this app has had and the
///    answer has to be readable without opening anything.
///  * QUANTISE becomes one wide button that **cycles** OFF -> 1/4 -> 1/8 ->
///    1/16 -> OFF and still says exactly what it is (`QNT 1/16` / `QNT OFF`),
///    which was the point of the v5 rewrite. Every division is still directly
///    selectable in the TUNE sheet, and the LCD's bottom line spells out what
///    quantise did to the loop that closed.
///
/// Widths: the quantise button gets 5 parts to SOURCE's 3 each, so on a 320dp
/// phone (288dp of content, 3 gaps of 4) it is `(288-12)/14*5 = 98dp` against
/// 59dp per source button -- comfortable for `QNT 1/16` at 13pt, and every
/// caption is a `FittedBox(scaleDown)` regardless.
class _SourceQuantizeStrip extends StatelessWidget {
  const _SourceQuantizeStrip();

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([TapeDeck.instance, ProStore.instance]),
      builder: (context, _) {
        final deck = TapeDeck.instance;
        final isPro = ProStore.instance.isPro;
        return Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (final option in RecordSource.values) ...[
              Expanded(
                flex: 3,
                child: _SegButton(
                  label: recordSourceLabel(option),
                  selected: deck.source == option,
                  onTap: () => deck.setSource(option),
                ),
              ),
              const SizedBox(width: 4),
            ],
            Expanded(
              flex: 5,
              // Quantise is a Pro control. Free users see a padlock caption and
              // a tap opens the paywall instead of cycling the grid.
              child: _SegButton(
                label: isPro ? deck.quantizeLabel : 'QNT \u{1F512}',
                selected: deck.quantize && isPro,
                onTap: () {
                  if (!isPro) {
                    showPaywall(context, highlight: 'Quantize');
                    return;
                  }
                  deck.cycleQuantize();
                },
              ),
            ),
          ],
        );
      },
    );
  }
}

/// The little cream-on-dark readout: what the deck is doing, at what tempo,
/// how far through the loop it is, and what quantise did to it.
///
/// The two moving lines are [_LcdLine]s driven by `TapeDeck.transportTicks`, so
/// they rebuild when their text changes (about ten times a second for a clock
/// showing tenths) rather than on every frame -- and the rest of the panel does
/// not rebuild at all.
class _TapeLcd extends StatefulWidget {
  const _TapeLcd();

  @override
  State<_TapeLcd> createState() => _TapeLcdState();
}

class _TapeLcdState extends State<_TapeLcd> {
  late final Listenable _live;

  @override
  void initState() {
    super.initState();
    _live = Listenable.merge([TapeDeck.instance, TapeDeck.instance.transportTicks]);
  }

  static String _clock(Duration d) {
    final seconds = d.inMilliseconds / 1000.0;
    return seconds.toStringAsFixed(1).padLeft(4, '0');
  }

  /// The moving line: what the current pass is heading towards.
  String _dynamicLine() {
    final deck = TapeDeck.instance;
    switch (deck.state) {
      case LoopState.recording:
        if (deck.isFreeLength) return '${_clock(deck.position)}s - TAP END';
        final left = deck.barsRemaining;
        return '$left BAR${left == 1 ? '' : 'S'} LEFT';
      case LoopState.overdubbing:
        // Where the layer was dropped in, so it's obvious an overdub can start
        // anywhere in the loop rather than only at the top.
        return 'DUB FROM ${_clock(Duration(milliseconds: deck.overdubStartMs))}s';
      case LoopState.playing:
        return '${_clock(deck.position)} / ${_clock(deck.recordedLoopDuration)}';
      case LoopState.armed:
        return deck.usesMic ? 'WAITING FOR INPUT' : 'HIT A PAD TO START';
      case LoopState.stopped:
        return 'TAP LOOP TO PLAY';
      case LoopState.empty:
        if (TakeRecorder.instance.isRecording) {
          return 'REC ${TakeRecorder.instance.elapsedLabel}';
        }
        return 'TAP LOOP TO ARM';
    }
  }

  /// The bottom line: how many layers deep the loop is, plus what quantise did
  /// to it once it has closed.
  String _statusLine() {
    final deck = TapeDeck.instance;
    final summary = deck.loopSummary;
    // While a pass is actually being captured the live hit count is the more
    // useful number; the rest of the time, what quantise did to the loop is.
    if (summary != null && !deck.isCapturing) {
      return '$summary · L${deck.layerCount}';
    }
    if (deck.usesPads) {
      final hits = deck.eventCount;
      return 'LAYERS ${deck.layerCount}  $hits HIT${hits == 1 ? '' : 'S'}';
    }
    return 'LAYERS ${deck.layerCount}';
  }

  @override
  Widget build(BuildContext context) {
    final deck = TapeDeck.instance;
    return ListenableBuilder(
      listenable: Listenable.merge([deck, TakeRecorder.instance]),
      builder: (context, _) {
        final recording = deck.state == LoopState.recording;
        final overdubbing = deck.state == LoopState.overdubbing;

        return RepaintBoundary(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF14120F),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: AppColors.amberDeep.withValues(alpha: 0.35)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  flex: 3,
                  child: Row(
                    children: [
                      Container(
                        width: 6,
                        height: 6,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: (recording || overdubbing)
                              ? AppColors.danger
                              : (deck.state == LoopState.playing
                                  ? AppColors.success
                                  : AppColors.lcdTextDim),
                        ),
                      ),
                      const SizedBox(width: 5),
                      Expanded(
                        child: _fitted(
                          deck.stateLabel,
                          fontSize: 19,
                          color: AppColors.amber,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: _fitted(
                    '${deck.bpm.toStringAsFixed(0)} BPM  ${deck.loopLengthLabel}',
                    fontSize: 14,
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: _LcdLine(
                    listenable: _live,
                    text: _dynamicLine,
                    fontSize: 12,
                    color: AppColors.lcdTextDim,
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: _LcdLine(
                    listenable: _live,
                    text: _statusLine,
                    fontSize: 11,
                    color: AppColors.lcdTextDim,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// One line of LCD text, scaled down to fit and never overflowing.
Widget _fitted(String text, {double fontSize = 14, Color? color}) {
  return Align(
    alignment: Alignment.centerLeft,
    child: FittedBox(
      fit: BoxFit.scaleDown,
      alignment: Alignment.centerLeft,
      child: Text(
        text,
        maxLines: 1,
        style: lcdTextStyle(fontSize: fontSize, color: color ?? AppColors.lcdText),
      ),
    ),
  );
}

/// A line of LCD text driven by a [Listenable] that **rebuilds only when the
/// text it would show actually changes**.
///
/// The transport ticks about fifteen times a second. A clock showing tenths of
/// a second changes ten times a second; the "3 BARS LEFT" line changes about
/// once a second. Without this, every tick would relayout every line whether
/// or not anything had changed -- which is the sort of thing that quietly eats
/// a frame budget on a cheap phone and makes pads feel late.
class _LcdLine extends StatefulWidget {
  final Listenable listenable;
  final String Function() text;
  final double fontSize;
  final Color color;

  const _LcdLine({
    required this.listenable,
    required this.text,
    this.fontSize = 12,
    this.color = AppColors.lcdTextDim,
  });

  @override
  State<_LcdLine> createState() => _LcdLineState();
}

class _LcdLineState extends State<_LcdLine> {
  late String _value;

  @override
  void initState() {
    super.initState();
    _value = widget.text();
    widget.listenable.addListener(_check);
  }

  @override
  void didUpdateWidget(covariant _LcdLine oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.listenable, widget.listenable)) {
      oldWidget.listenable.removeListener(_check);
      widget.listenable.addListener(_check);
    }
    // A build is about to happen anyway, so refresh the cached text in place
    // rather than asking for another one.
    _value = widget.text();
  }

  @override
  void dispose() {
    widget.listenable.removeListener(_check);
    super.dispose();
  }

  void _check() {
    if (!mounted) return;
    final next = widget.text();
    if (next == _value) return;
    setState(() => _value = next);
  }

  @override
  Widget build(BuildContext context) {
    return _fitted(_value, fontSize: widget.fontSize, color: widget.color);
  }
}

/// The fold-out controls (TUNE): tempo, loop length and -- in MIC/BOTH only --
/// the input threshold, plus the help text.
///
/// These live in a bottom sheet rather than inline in the panel, because the
/// instrument screen no longer scrolls: anything that changes height has to
/// happen somewhere that is allowed to.
class _TapeSettingsSheet extends StatelessWidget {
  const _TapeSettingsSheet();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListenableBuilder(
        listenable: Listenable.merge([TapeDeck.instance, ProStore.instance]),
        builder: (context, _) => _buildControls(context),
      ),
    );
  }

  Widget _buildControls(BuildContext context) {
    final deck = TapeDeck.instance;
    final locked = deck.isTempoLocked;
    // Loop length and quantise are Pro; tempo/tap-tempo and the mic threshold
    // stay free. A tap on a locked control opens the paywall.
    final isPro = ProStore.instance.isPro;
    final lockGlyph = isPro ? '' : ' \u{1F512}';

    Widget label(String text) => SizedBox(
          width: 62,
          child: Text(
            text,
            maxLines: 1,
            overflow: TextOverflow.clip,
            style: lcdTextStyle(fontSize: 13, color: AppColors.amber),
          ),
        );

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('TAPE DECK', style: lcdTextStyle(fontSize: 20, color: AppColors.amber)),
          const SizedBox(height: 12),
          SizedBox(
            height: 34,
            child: Row(
              children: [
                label('TEMPO'),
                _MiniButton(label: '-', onTap: () => deck.nudgeBpm(-1)),
                const SizedBox(width: 6),
                SizedBox(
                  width: 46,
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      deck.bpm.toStringAsFixed(0),
                      maxLines: 1,
                      style: lcdTextStyle(fontSize: 20, color: AppColors.lcdText),
                    ),
                  ),
                ),
                _MiniButton(label: '+', onTap: () => deck.nudgeBpm(1)),
                const SizedBox(width: 10),
                Expanded(
                  child: _SegButton(
                    label: 'TAP TEMPO',
                    selected: false,
                    onTap: deck.tapTempo,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          // Loop length. FREE is the default: the second tap on LOOP decides.
          // Fixed lengths (4/8/16 bars) are a Pro feature.
          SizedBox(
            height: 30,
            child: Row(
              children: [
                label('LENGTH$lockGlyph'),
                for (final bars in TapeDeck.selectableBars) ...[
                  Expanded(
                    child: _SegButton(
                      label: bars == TapeDeck.freeBars ? 'FREE' : '$bars',
                      selected: deck.bars == bars,
                      enabled: isPro && !locked,
                      onTap: () {
                        if (!isPro) {
                          showPaywall(context, highlight: 'Quantize');
                          return;
                        }
                        deck.setBars(bars);
                      },
                    ),
                  ),
                  if (bars != TapeDeck.selectableBars.last) const SizedBox(width: 4),
                ],
              ],
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 30,
            child: Row(
              children: [
                label('QUANTISE$lockGlyph'),
                Expanded(
                  child: _SegButton(
                    label: isPro ? deck.quantizeLabel : 'QNT \u{1F512}',
                    selected: deck.quantize && isPro,
                    onTap: () {
                      if (!isPro) {
                        showPaywall(context, highlight: 'Quantize');
                        return;
                      }
                      deck.toggleQuantize();
                    },
                  ),
                ),
                const SizedBox(width: 4),
                for (final grid in QuantizeGrid.values) ...[
                  Expanded(
                    child: _SegButton(
                      label: grid.label,
                      selected: deck.quantize && deck.quantizeGrid == grid && isPro,
                      onTap: () {
                        if (!isPro) {
                          showPaywall(context, highlight: 'Quantize');
                          return;
                        }
                        if (!deck.quantize) deck.toggleQuantize();
                        deck.setQuantizeGrid(grid);
                      },
                    ),
                  ),
                  if (grid != QuantizeGrid.values.last) const SizedBox(width: 4),
                ],
              ],
            ),
          ),
          if (deck.usesMic) ...[
            const SizedBox(height: 6),
            // Deliberately *not* height-constrained: a Material Slider wants
            // ~48dp and will happily size itself down into a smaller box, but
            // then its thumb overlay gets clipped. The Row sizes to the Slider.
            Row(
              children: [
                label('START'),
                Expanded(
                  child: SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      trackHeight: 3,
                      thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
                    ),
                    child: Slider(
                      min: TapeDeck.minThresholdDb,
                      max: TapeDeck.maxThresholdDb,
                      value: deck.thresholdDb,
                      onChanged: (value) => deck.setThresholdDb(value),
                    ),
                  ),
                ),
                SizedBox(
                  width: 46,
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerRight,
                    child: Text(
                      '${deck.thresholdDb.toStringAsFixed(0)} dB',
                      maxLines: 1,
                      style: lcdTextStyle(fontSize: 13, color: AppColors.lcdText),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const _InputLevelMeter(),
            const SizedBox(height: 6),
            Text(
              'Headphones recommended for overdubs.',
              style: lcdTextStyle(fontSize: 12, color: AppColors.lcdTextDim),
            ),
          ],
          const SizedBox(height: 10),
          Text(
            _helpText(deck),
            style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
          ),
        ],
      ),
    );
  }

  String _helpText(TapeDeck deck) {
    final start = deck.usesMic
        ? 'recording starts on your first pad hit or the moment the input '
            'crosses the START level'
        : 'recording starts on your first pad hit -- the microphone is never '
            'opened in PADS mode';
    final end = deck.isFreeLength
        ? 'tap LOOP again to close the loop'
        : 'it closes itself after ${deck.bars} bars, or on a second tap';
    final lengthRule = deck.isFreeLength
        ? 'the loop is rounded to whole bars'
        : 'the loop is exactly ${deck.bars} bars long';
    final snap = deck.quantize
        ? ' QUANTISE is on: every hit snaps to the nearest '
            '${deck.quantizeGrid.label} of a bar, and $lengthRule. Your '
            'original timing is kept, so turning quantise off gives it back.'
        : ' QUANTISE is off, so hits play exactly as you played them and the '
            'loop is exactly as long as you played it.';
    return 'Tap LOOP to arm: $start, then $end.$snap After that the pad reads '
        'DUB: tap it to record another layer over the loop, tap it again to '
        'keep that layer. UNDO removes the last layer (up to '
        '${TapeDeck.maxOverdubLayers} of them), STOP during a dub throws the '
        'one in progress away, and holding either pad clears everything.';
  }
}

/// A horizontal bar showing how loud the microphone currently is, with a
/// marker where the start threshold sits. Only shown in MIC/BOTH mode, and
/// only live while the mic is actually open.
///
/// It listens to the deck's level notifier rather than to the deck, so a
/// twitching meter never rebuilds anything else.
class _InputLevelMeter extends StatelessWidget {
  const _InputLevelMeter();

  @override
  Widget build(BuildContext context) {
    final deck = TapeDeck.instance;
    return ListenableBuilder(
      listenable: Listenable.merge([deck, deck.inputLevelNotifier]),
      builder: (context, _) => _buildMeter(context),
    );
  }

  Widget _buildMeter(BuildContext context) {
    final deck = TapeDeck.instance;
    const minDb = TapeDeck.minThresholdDb;
    const maxDb = TapeDeck.maxThresholdDb;
    double toFraction(double db) =>
        ((db - minDb) / (maxDb - minDb)).clamp(0.0, 1.0).toDouble();

    final level = deck.isListening ? toFraction(deck.inputLevelDb) : 0.0;
    final threshold = toFraction(deck.thresholdDb);
    final over = deck.isListening && deck.inputLevelDb >= deck.thresholdDb;

    return Row(
      children: [
        SizedBox(
          width: 62,
          child: Text(
            'LEVEL',
            maxLines: 1,
            overflow: TextOverflow.clip,
            style: lcdTextStyle(fontSize: 13, color: AppColors.amber),
          ),
        ),
        Expanded(
          child: SizedBox(
            height: 14,
            child: LayoutBuilder(
              builder: (context, constraints) {
                final width = constraints.maxWidth;
                return Stack(
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF14120F),
                        borderRadius: BorderRadius.circular(3),
                        border: Border.all(color: Colors.black.withValues(alpha: 0.6)),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      top: 0,
                      bottom: 0,
                      width: width * level,
                      child: Container(
                        decoration: BoxDecoration(
                          color: over ? AppColors.success : AppColors.amber,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ),
                    Positioned(
                      left: (width * threshold)
                          .clamp(0.0, width > 2 ? width - 2 : 0.0)
                          .toDouble(),
                      top: 0,
                      bottom: 0,
                      width: 2,
                      child: Container(color: AppColors.danger),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
        SizedBox(
          width: 46,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerRight,
            child: Text(
              deck.isListening ? '${deck.inputLevelDb.toStringAsFixed(0)} dB' : 'IDLE',
              maxLines: 1,
              style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
            ),
          ),
        ),
      ],
    );
  }
}

/// One of the two big tape-deck pads. Tap for whatever its label says; hold it
/// for [TapeDeck.holdToClearDuration] and a fill sweeps across it, then the
/// loop is wiped.
class _TapePad extends StatefulWidget {
  final String label;
  final IconData icon;
  final bool active;

  /// Breathes the pad's glow in and out. Used only while overdubbing, so
  /// "recording a new layer over a running loop" cannot be mistaken for plain
  /// playback -- or for recording the very first pass.
  final bool pulsing;
  final Color activeColor;
  final VoidCallback onTap;
  final VoidCallback onHoldComplete;

  const _TapePad({
    required this.label,
    required this.icon,
    required this.active,
    required this.activeColor,
    required this.onTap,
    required this.onHoldComplete,
    this.pulsing = false,
  });

  @override
  State<_TapePad> createState() => _TapePadState();
}

class _TapePadState extends State<_TapePad> with TickerProviderStateMixin {
  late final AnimationController _hold;
  late final AnimationController _pulse;
  bool _cleared = false;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _hold = AnimationController(vsync: this, duration: TapeDeck.holdToClearDuration);
    _hold.addStatusListener(_onHoldStatus);
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 620),
    );
    if (widget.pulsing) _pulse.repeat(reverse: true);
  }

  @override
  void didUpdateWidget(covariant _TapePad oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.pulsing == oldWidget.pulsing) return;
    if (widget.pulsing) {
      _pulse.repeat(reverse: true);
    } else {
      // Stop the ticker *and* settle the value, so a pad that has finished
      // overdubbing doesn't stay frozen half-lit.
      _pulse.stop();
      _pulse.value = 0.0;
    }
  }

  void _onHoldStatus(AnimationStatus status) {
    if (status == AnimationStatus.completed && !_cleared) {
      _cleared = true;
      widget.onHoldComplete();
    }
  }

  @override
  void dispose() {
    _hold.removeStatusListener(_onHoldStatus);
    _hold.dispose();
    _pulse.dispose();
    super.dispose();
  }

  void _down() {
    _cleared = false;
    setState(() => _pressed = true);
    _hold.forward(from: 0);
  }

  void _up() {
    final wasCleared = _cleared;
    _hold.reset();
    setState(() => _pressed = false);
    if (!wasCleared) widget.onTap();
  }

  void _cancel() {
    _hold.reset();
    _cleared = false;
    setState(() => _pressed = false);
  }

  @override
  Widget build(BuildContext context) {
    final lit = widget.active || _pressed;
    return RepaintBoundary(
      child: GestureDetector(
        onTapDown: (_) => _down(),
        onTapUp: (_) => _up(),
        onTapCancel: _cancel,
        child: LayoutBuilder(
          builder: (context, constraints) {
            // The transport row's height comes from the screen, so the icon
            // sizes itself from the box it was given rather than assuming.
            final iconSize = (constraints.maxHeight * 0.36).clamp(10.0, 20.0).toDouble();
            return AnimatedBuilder(
              animation: Listenable.merge([_hold, _pulse]),
              builder: (context, child) {
                // 0 when not overdubbing, otherwise a slow in-and-out breath.
                final pulse = widget.pulsing ? _pulse.value : 0.0;
                return Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: lit
                          ? [widget.activeColor, AppColors.amberDeep]
                          : [AppColors.padFace, const Color(0xFF221F1A)],
                    ),
                    border: Border.all(color: Colors.black.withValues(alpha: 0.5)),
                    boxShadow: [
                      if (lit)
                        BoxShadow(
                          color: widget.activeColor.withValues(alpha: 0.45 + 0.45 * pulse),
                          blurRadius: 14.0 + 12.0 * pulse,
                          spreadRadius: 1.0 + 2.0 * pulse,
                        ),
                    ],
                  ),
                  // Clipped so the "hold to clear" fill follows the rounded
                  // corners.
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Stack(
                      children: [
                        // "Hold to clear" progress sweep.
                        if (_hold.value > 0)
                          Positioned.fill(
                            child: FractionallySizedBox(
                              alignment: Alignment.centerLeft,
                              widthFactor: _hold.value,
                              child: Container(color: AppColors.danger.withValues(alpha: 0.55)),
                            ),
                          ),
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  widget.icon,
                                  size: iconSize,
                                  color: lit ? AppColors.chassis : AppColors.lcdText,
                                ),
                                // scaleDown rather than ellipsis: a longer
                                // caption like "END DUB" shrinks to fit instead
                                // of being cut. Flexible as well as FittedBox,
                                // so a very large system text scale shrinks the
                                // caption rather than bursting the row.
                                Flexible(
                                  child: FittedBox(
                                    fit: BoxFit.scaleDown,
                                    child: Text(
                                      _hold.value > 0.05 ? 'HOLD TO CLEAR' : widget.label,
                                      maxLines: 1,
                                      style: lcdTextStyle(
                                        fontSize: _hold.value > 0.05 ? 11 : 14,
                                        fontWeight: FontWeight.bold,
                                        color: lit ? AppColors.chassis : AppColors.lcdTextDim,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

/// A narrow secondary button on the transport row (UNDO / REC / TUNE / TAPES).
///
/// With [enabled] false it greys itself right down and stops responding, which
/// is how UNDO says "there is no layer to take off" without disappearing and
/// re-shuffling the whole row.
class _SmallDeckButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final bool enabled;
  final Color activeColor;
  final VoidCallback onTap;

  const _SmallDeckButton({
    required this.icon,
    required this.label,
    required this.active,
    required this.activeColor,
    required this.onTap,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    final Color foreground;
    if (active) {
      foreground = AppColors.chassis;
    } else if (enabled) {
      foreground = AppColors.lcdText;
    } else {
      foreground = AppColors.lcdTextDim.withValues(alpha: 0.45);
    }
    return InkWell(
      onTap: enabled ? onTap : null,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        decoration: BoxDecoration(
          color: active
              ? activeColor
              : (enabled ? AppColors.padFace : AppColors.padFace.withValues(alpha: 0.5)),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.black.withValues(alpha: 0.45)),
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final iconSize = (constraints.maxHeight * 0.34).clamp(9.0, 18.0).toDouble();
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: iconSize, color: foreground),
                // Flexible + scaleDown, not a bare Text: at a very large system
                // text scale a fixed caption would grow past the transport row
                // and produce a vertical RenderFlex overflow.
                Flexible(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: lcdTextStyle(
                        fontSize: 10,
                        color: active ? AppColors.chassis : foreground,
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

/// A segment of one of the little selector rows (PADS / MIC / BOTH, FREE / 4 /
/// 8 / 16, QNT 1/16). Meant to be dropped inside an `Expanded` in a stretched
/// `Row`, so it takes whatever box it is given -- **no fixed height**, because
/// the deck's rows are sized from the screen -- and scales its caption down to
/// fit.
class _SegButton extends StatelessWidget {
  final String label;
  final bool selected;
  final bool enabled;
  final VoidCallback onTap;

  const _SegButton({
    required this.label,
    required this.selected,
    required this.onTap,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    final foreground = selected
        ? AppColors.chassis
        : (enabled ? AppColors.lcdText : AppColors.lcdTextDim);
    return InkWell(
      onTap: enabled ? onTap : null,
      borderRadius: BorderRadius.circular(6),
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 3),
        decoration: BoxDecoration(
          color: selected ? AppColors.amber : AppColors.padFace,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: selected
                ? AppColors.amberDeep
                : Colors.black.withValues(alpha: 0.45),
          ),
        ),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            label,
            maxLines: 1,
            style: lcdTextStyle(
              fontSize: 13,
              color: foreground,
              fontWeight: selected ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }
}

/// Small fixed-width button used inside the TUNE sheet (the -/+ tempo nudges).
class _MiniButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _MiniButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(6),
      child: Container(
        width: 34,
        height: 30,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.padFace,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: Colors.black.withValues(alpha: 0.45)),
        ),
        child: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: lcdTextStyle(fontSize: 14, color: AppColors.lcdText),
        ),
      ),
    );
  }
}

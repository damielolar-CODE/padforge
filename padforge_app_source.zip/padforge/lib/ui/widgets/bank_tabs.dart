import 'package:flutter/material.dart';

import '../../models/kit.dart';
import '../../state/app_state.dart';
import '../theme/app_theme.dart';

/// The A / B / C bank selector, styled like the bank buttons on an MPC-style
/// pad controller.
class BankTabs extends StatelessWidget {
  const BankTabs({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        return Row(
          children: Kit.banks.map((bank) {
            final selected = app.currentBank == bank;
            return Expanded(
              child: GestureDetector(
                onTap: () => app.selectBank(bank),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: selected ? AppColors.amber : AppColors.panel,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: selected ? AppColors.amberDeep : Colors.black.withValues(alpha: 0.4),
                    ),
                  ),
                  child: Center(
                    child: Text(
                      'BANK $bank',
                      style: lcdTextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: selected ? AppColors.chassis : AppColors.lcdTextDim,
                      ),
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

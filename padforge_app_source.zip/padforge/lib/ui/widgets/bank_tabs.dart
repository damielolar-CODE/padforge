import 'package:flutter/material.dart';

import '../../models/kit.dart';
import '../../services/pro_store.dart';
import '../../state/app_state.dart';
import '../theme/app_theme.dart';
import 'paywall_sheet.dart';

/// The A / B / C bank selector, styled like the bank buttons on an MPC-style
/// pad controller.
///
/// Bank A is free; banks B and C are part of PadForge Pro. For a free user the
/// two locked tabs show a padlock and open the paywall instead of switching, so
/// the free instrument is a full-featured single bank of 16 pads.
class BankTabs extends StatelessWidget {
  const BankTabs({super.key});

  /// Bank "A" is always free; the other two are Pro-only.
  static bool _bankLocked(String bank, bool isPro) => bank != 'A' && !isPro;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([AppState.instance, ProStore.instance]),
      builder: (context, _) {
        final app = AppState.instance;
        final isPro = ProStore.instance.isPro;
        // Stretched, not padded: the row takes the height the home screen
        // gave it and the captions scale down inside, so it cannot overflow.
        return Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: Kit.banks.map((bank) {
            final selected = app.currentBank == bank;
            final locked = _bankLocked(bank, isPro);
            return Expanded(
              child: GestureDetector(
                onTap: () {
                  if (locked) {
                    showPaywall(context, highlight: 'Bank $bank');
                    return;
                  }
                  app.selectBank(bank);
                },
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  decoration: BoxDecoration(
                    color: selected ? AppColors.amber : AppColors.panel,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: selected ? AppColors.amberDeep : Colors.black.withValues(alpha: 0.4),
                    ),
                  ),
                  child: Center(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            bank,
                            maxLines: 1,
                            style: lcdTextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: selected ? AppColors.chassis : AppColors.lcdTextDim,
                            ),
                          ),
                          if (locked) ...[
                            const SizedBox(width: 3),
                            Icon(
                              Icons.lock_outline,
                              size: 12,
                              color: selected ? AppColors.chassis : AppColors.lcdTextDim,
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}

import 'package:flutter/material.dart';

import '../../state/app_state.dart';
import '../screens/kit_manager_screen.dart';
import '../theme/app_theme.dart';

/// Bottom mini-toolbar: import samples, toggle MIDI Learn, and jump to kit
/// management/editing.
class BottomToolbar extends StatelessWidget {
  const BottomToolbar({super.key});

  Future<void> _importSamples(BuildContext context) async {
    final assigned = await AppState.instance.importSamplesAutoAssign();
    if (!context.mounted) return;
    final message = assigned.isEmpty
        ? 'No samples imported (pick .wav files, and make sure some pads are empty).'
        : 'Imported ${assigned.length} sample(s) to: ${assigned.join(", ")}';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        return Container(
          color: AppColors.panel,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Row(
            children: [
              Expanded(
                child: _ToolbarButton(
                  icon: Icons.file_upload_outlined,
                  label: 'Import',
                  onTap: () => _importSamples(context),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _ToolbarButton(
                  icon: Icons.settings_input_component,
                  label: app.learnModeArmed ? 'Learning...' : 'MIDI Learn',
                  active: app.learnModeArmed,
                  onTap: () => app.toggleLearnMode(),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _ToolbarButton(
                  icon: Icons.edit_outlined,
                  label: 'Edit Kit',
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const KitManagerScreen()),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ToolbarButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _ToolbarButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: active ? AppColors.amber : AppColors.padFace,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: active ? AppColors.amberDeep : Colors.black.withValues(alpha: 0.4)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 18, color: active ? AppColors.chassis : AppColors.lcdText),
            const SizedBox(height: 4),
            Text(
              label,
              style: lcdTextStyle(
                fontSize: 12,
                color: active ? AppColors.chassis : AppColors.lcdTextDim,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

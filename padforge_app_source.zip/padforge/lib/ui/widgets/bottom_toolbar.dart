import 'package:flutter/material.dart';

import '../../state/app_state.dart';
import '../screens/automap_screen.dart';
import '../screens/kit_manager_screen.dart';
import '../theme/app_theme.dart';

/// Bottom mini-toolbar: import samples, toggle MIDI Learn, run the auto-map
/// wizard on the current bank, and jump to kit management/editing.
///
/// **Width budget.** Four buttons, each an `Expanded`, with three 8dp gaps
/// inside 8dp of horizontal padding: on a 320dp phone that is
/// `(320 - 16 - 24) / 4 = 70dp` per button. Every caption is a
/// `FittedBox(scaleDown)`, so a large system text scale shrinks the lettering
/// rather than overflowing the row.
class BottomToolbar extends StatelessWidget {
  const BottomToolbar({super.key});

  Future<void> _importSamples(BuildContext context) async {
    final assigned = await AppState.instance.importSamplesAutoAssign();
    if (!context.mounted) return;
    final message = assigned.isEmpty
        ? 'No samples imported (pick .wav files, and make sure some pads are empty).'
        : 'Imported ${assigned.length} sample(s) to: ${assigned.join(", ")}';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        return Container(
          color: AppColors.panel,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
          child: Row(
            children: [
              Expanded(
                child: _ToolbarButton(
                  icon: Icons.file_upload_outlined,
                  label: 'Import',
                  onTap: () => _importSamples(context),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _ToolbarButton(
                  icon: Icons.settings_input_component,
                  label: app.learnModeArmed ? 'Learning...' : 'MIDI Learn',
                  active: app.learnModeArmed,
                  onTap: () => app.toggleLearnMode(),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _ToolbarButton(
                  icon: Icons.grid_on,
                  label: 'Auto-map',
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => AutoMapScreen(bank: app.currentBank),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _ToolbarButton(
                  icon: Icons.edit_outlined,
                  label: 'Edit Kit',
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const KitManagerScreen()),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ToolbarButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _ToolbarButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: active ? AppColors.amber : AppColors.padFace,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: active ? AppColors.amberDeep : Colors.black.withValues(alpha: 0.4)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: active ? AppColors.chassis : AppColors.lcdText),
            const SizedBox(height: 2),
            // scaleDown so a large system text scale shrinks the caption
            // instead of growing the toolbar and stealing height from the pads.
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                label,
                maxLines: 1,
                style: lcdTextStyle(
                  fontSize: 11,
                  color: active ? AppColors.chassis : AppColors.lcdTextDim,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Hand-drawn vintage reel-to-reel tape transport.
///
/// Everything here is painted with a [CustomPainter] rather than assembled out
/// of images, so it stays crisp at any size and can be animated cheaply:
///
///  * two reels, each with a spoked flange, a metal hub with screws, and a
///    wound "annulus" of tape whose radius grows and shrinks as tape moves
///    from one reel to the other,
///  * a tape path strung between them that dips over a head block in the
///    middle with a slight sag, the way real tape hangs,
///  * a red-lit tint while recording so the state is readable at a glance.
///
/// The painter is deliberately dumb: it draws exactly what it is told. The
/// spinning and the tape-position maths live in the widget above it
/// ([TapeReelsView]).
class TapeReelsPainter extends CustomPainter {
  /// Where the reels are right now. The painter holds the model rather than a
  /// snapshot of its values, and hands it to `CustomPainter`'s `repaint:`
  /// argument, so a turning reel repaints **without rebuilding any widget**:
  /// the animation clock pokes the model, the model notifies the painter, and
  /// the element tree is never touched. Before v5 every frame of the reels ran
  /// a `setState`, on the same thread that has to service pad hits.
  final ReelModel model;

  TapeReelsPainter(this.model) : super(repaint: model);

  double get rotation => model.rotation;
  double get supplyFill => model.supplyFill;
  double get takeupFill => model.takeupFill;
  bool get recording => model.recording;
  bool get active => model.active;

  static const Color _flangeLight = Color(0xFF4C4238);
  static const Color _flangeDark = Color(0xFF201D19);
  static const Color _spoke = Color(0xFF5A4E42);
  static const Color _hubLight = Color(0xFF7A6A58);
  static const Color _hubDark = Color(0xFF2A2621);
  static const Color _tape = Color(0xFF3A2C22);
  static const Color _tapeEdge = Color(0xFF15120F);

  @override
  void paint(Canvas canvas, Size size) {
    final width = size.width;
    final height = size.height;
    if (width <= 0 || height <= 0) return;

    final radius = math.min(height * 0.44, width * 0.23);
    if (radius <= 2) return;

    final centreY = height * 0.46;
    final leftCentre = Offset(width * 0.26, centreY);
    final rightCentre = Offset(width * 0.74, centreY);

    final hubRadius = radius * 0.34;
    final supplyOuter = hubRadius + (radius * 0.9 - hubRadius) * _clamp01(supplyFill);
    final takeupOuter = hubRadius + (radius * 0.9 - hubRadius) * _clamp01(takeupFill);

    _drawTapePath(canvas, size, leftCentre, rightCentre, supplyOuter, takeupOuter, centreY, radius);
    _drawHeadBlock(canvas, size, centreY + radius * 0.95);

    _drawReel(canvas, leftCentre, radius, hubRadius, supplyOuter, rotation);
    _drawReel(canvas, rightCentre, radius, hubRadius, takeupOuter, rotation);

    _drawLamp(canvas, Offset(width * 0.5, centreY - radius * 0.72));
  }

  double _clamp01(double value) => value.clamp(0.0, 1.0).toDouble();

  void _drawReel(
    Canvas canvas,
    Offset centre,
    double radius,
    double hubRadius,
    double tapeOuter,
    double angle,
  ) {
    // Soft drop shadow so the reel sits on the chassis rather than floating.
    canvas.drawCircle(
      centre.translate(0, radius * 0.06),
      radius,
      Paint()
        ..color = Colors.black.withValues(alpha: 0.45)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );

    // Flange body.
    canvas.drawCircle(
      centre,
      radius,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-0.45, -0.55),
          colors: [_flangeLight, _flangeDark],
        ).createShader(Rect.fromCircle(center: centre, radius: radius)),
    );

    // Wound tape.
    if (tapeOuter > hubRadius + 0.5) {
      canvas.drawCircle(centre, tapeOuter, Paint()..color = _tape);
      final striation = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = _tapeEdge.withValues(alpha: 0.35);
      for (var r = hubRadius + 2; r < tapeOuter; r += 3) {
        canvas.drawCircle(centre, r, striation);
      }
      canvas.drawCircle(
        centre,
        tapeOuter,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2
          ..color = AppColors.amber.withValues(alpha: 0.22),
      );
    }

    canvas.save();
    canvas.translate(centre.dx, centre.dy);
    canvas.rotate(angle);

    // Three spoke arms, which is what actually reads as "the reel is turning".
    final spokePaint = Paint()..color = _spoke;
    for (var i = 0; i < 3; i++) {
      canvas.save();
      canvas.rotate(i * 2 * math.pi / 3);
      final path = Path()
        ..moveTo(-radius * 0.11, 0)
        ..lineTo(radius * 0.11, 0)
        ..lineTo(radius * 0.06, -radius * 0.94)
        ..lineTo(-radius * 0.06, -radius * 0.94)
        ..close();
      canvas.drawPath(path, spokePaint);
      canvas.restore();
    }

    // Metal hub.
    canvas.drawCircle(
      Offset.zero,
      hubRadius,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-0.4, -0.5),
          colors: [_hubLight, _hubDark],
        ).createShader(Rect.fromCircle(center: Offset.zero, radius: hubRadius)),
    );
    canvas.drawCircle(
      Offset.zero,
      hubRadius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = Colors.white.withValues(alpha: 0.16),
    );

    // Screws around the hub.
    final screwFill = Paint()..color = const Color(0xFF9B8C78);
    final screwSlot = Paint()
      ..color = const Color(0xFF1A1714)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    final screwRadius = math.max(1.4, radius * 0.045);
    for (var i = 0; i < 3; i++) {
      final a = i * 2 * math.pi / 3 + math.pi / 6;
      final pos = Offset(math.cos(a), math.sin(a)) * (hubRadius * 0.6);
      canvas.drawCircle(pos, screwRadius, screwFill);
      canvas.drawLine(
        pos.translate(-screwRadius * 0.7, 0),
        pos.translate(screwRadius * 0.7, 0),
        screwSlot,
      );
    }

    // Spindle.
    canvas.drawCircle(Offset.zero, radius * 0.09, Paint()..color = const Color(0xFF14120F));

    canvas.restore();

    // Metallic rim highlight, drawn last so it sits over everything.
    canvas.drawCircle(
      centre,
      radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..shader = SweepGradient(
          colors: [
            Colors.white.withValues(alpha: 0.28),
            Colors.transparent,
            Colors.white.withValues(alpha: 0.12),
            Colors.transparent,
            Colors.white.withValues(alpha: 0.28),
          ],
          stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
        ).createShader(Rect.fromCircle(center: centre, radius: radius)),
    );
  }

  void _drawTapePath(
    Canvas canvas,
    Size size,
    Offset leftCentre,
    Offset rightCentre,
    double supplyOuter,
    double takeupOuter,
    double centreY,
    double radius,
  ) {
    final headY = centreY + radius * 0.95;
    final start = Offset(
      leftCentre.dx + supplyOuter * 0.72,
      centreY + supplyOuter * 0.68,
    );
    final end = Offset(
      rightCentre.dx - takeupOuter * 0.72,
      centreY + takeupOuter * 0.68,
    );
    final headLeft = Offset(size.width * 0.44, headY);
    final headRight = Offset(size.width * 0.56, headY);

    final path = Path()
      ..moveTo(start.dx, start.dy)
      // The little sag between reel and head block.
      ..quadraticBezierTo(
        (start.dx + headLeft.dx) / 2,
        math.max(start.dy, headLeft.dy) + radius * 0.16,
        headLeft.dx,
        headLeft.dy,
      )
      ..lineTo(headRight.dx, headRight.dy)
      ..quadraticBezierTo(
        (headRight.dx + end.dx) / 2,
        math.max(end.dy, headRight.dy) + radius * 0.16,
        end.dx,
        end.dy,
      );

    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(2, radius * 0.09)
        ..strokeCap = StrokeCap.round
        ..color = _tapeEdge,
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(1, radius * 0.045)
        ..strokeCap = StrokeCap.round
        ..color = _tape,
    );
  }

  void _drawHeadBlock(Canvas canvas, Size size, double headY) {
    final blockWidth = size.width * 0.16;
    final blockHeight = math.max(8.0, size.height * 0.13);
    final rect = Rect.fromCenter(
      center: Offset(size.width * 0.5, headY),
      width: blockWidth,
      height: blockHeight,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(3)),
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF574C40), Color(0xFF231F1A)],
        ).createShader(rect),
    );
    final headPaint = Paint()..color = const Color(0xFF9B8C78);
    for (var i = 0; i < 3; i++) {
      final x = rect.left + rect.width * (0.25 + i * 0.25);
      canvas.drawRect(
        Rect.fromLTWH(x - 1, rect.top + 2, 2, rect.height - 4),
        headPaint,
      );
    }
  }

  void _drawLamp(Canvas canvas, Offset centre) {
    final on = recording || active;
    final colour = recording ? AppColors.danger : AppColors.amber;
    if (on) {
      canvas.drawCircle(
        centre,
        6,
        Paint()
          ..color = colour.withValues(alpha: 0.35)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
      );
    }
    canvas.drawCircle(
      centre,
      2.6,
      Paint()..color = on ? colour : AppColors.padFace,
    );
  }

  @override
  bool shouldRepaint(covariant TapeReelsPainter oldDelegate) {
    // Repainting is driven by the model through `repaint:`, so a rebuild that
    // hands over an identical model needs no repaint of its own.
    return !identical(oldDelegate.model, model);
  }
}

/// The reels' live state, and the thing that tells the painter to repaint.
///
/// Deliberately mutable and deliberately *not* a widget: the animation clock
/// writes to it many times a second, and each write repaints one small custom
/// painter instead of rebuilding a subtree.
class ReelModel extends ChangeNotifier {
  double rotation = 0;
  double supplyFill = 1;
  double takeupFill = 0.3;
  bool recording = false;
  bool active = false;

  /// Writes new values and notifies **only if something actually changed**, so
  /// an idle deck costs nothing at all.
  void update({
    double? rotation,
    double? supplyFill,
    double? takeupFill,
    bool? recording,
    bool? active,
  }) {
    var changed = false;
    if (rotation != null && rotation != this.rotation) {
      this.rotation = rotation;
      changed = true;
    }
    if (supplyFill != null && supplyFill != this.supplyFill) {
      this.supplyFill = supplyFill;
      changed = true;
    }
    if (takeupFill != null && takeupFill != this.takeupFill) {
      this.takeupFill = takeupFill;
      changed = true;
    }
    if (recording != null && recording != this.recording) {
      this.recording = recording;
      changed = true;
    }
    if (active != null && active != this.active) {
      this.active = active;
      changed = true;
    }
    if (changed) notifyListeners();
  }
}

/// The animated wrapper around [TapeReelsPainter].
///
/// It owns an [AnimationController] used purely as a per-frame clock. Every
/// frame it nudges the reel speed towards "spinning" or "stopped", so the reels
/// spin up and coast to a halt instead of snapping, and it stops the clock
/// entirely once they've settled so an idle deck costs nothing.
class TapeReelsView extends StatefulWidget {
  /// True while recording or playing.
  final bool spinning;

  /// True while recording specifically (lights the deck red).
  final bool recording;

  /// 0.0-1.0 through the current pass; moves tape from one reel to the other.
  final double progress;

  const TapeReelsView({
    super.key,
    required this.spinning,
    required this.recording,
    required this.progress,
  });

  @override
  State<TapeReelsView> createState() => _TapeReelsViewState();
}

class _TapeReelsViewState extends State<TapeReelsView>
    with SingleTickerProviderStateMixin {
  late final AnimationController _clock;
  final Stopwatch _stopwatch = Stopwatch();
  final ReelModel _model = ReelModel();

  double _angle = 0;
  double _speed = 0;
  Duration _lastElapsed = Duration.zero;

  /// Radians per second at full speed (a leisurely, believable reel speed).
  static const double _fullSpeed = 2.4;

  @override
  void initState() {
    super.initState();
    _clock = AnimationController(vsync: this, duration: const Duration(seconds: 1));
    _clock.addListener(_onFrame);
    _pushToModel();
    if (widget.spinning) _startClock();
  }

  @override
  void didUpdateWidget(covariant TapeReelsView oldWidget) {
    super.didUpdateWidget(oldWidget);
    _pushToModel();
    if (widget.spinning && !_clock.isAnimating) {
      _startClock();
    }
  }

  /// Copies whatever the deck told us into the painter's model. Cheap, and a
  /// no-op when nothing changed.
  void _pushToModel() {
    final progress = widget.progress.clamp(0.0, 1.0).toDouble();
    _model.update(
      rotation: _angle,
      // Tape leaves the supply reel and winds onto the take-up reel.
      supplyFill: 1.0 - 0.7 * progress,
      takeupFill: 0.3 + 0.7 * progress,
      recording: widget.recording,
      active: widget.spinning,
    );
  }

  void _startClock() {
    if (!_stopwatch.isRunning) _stopwatch.start();
    _lastElapsed = _stopwatch.elapsed;
    if (!_clock.isAnimating) _clock.repeat();
  }

  void _stopClock() {
    _clock.stop();
    _stopwatch.stop();
  }

  void _onFrame() {
    final now = _stopwatch.elapsed;
    var dt = (now - _lastElapsed).inMicroseconds / 1000000.0;
    _lastElapsed = now;
    if (dt <= 0) return;
    if (dt > 0.1) dt = 0.1; // after a stall, don't jump

    final target = widget.spinning ? _fullSpeed : 0.0;
    // Exponential approach: quick spin-up, gentle coast down.
    final rate = widget.spinning ? 4.0 : 1.6;
    _speed += (target - _speed) * (1 - math.exp(-dt * rate));
    if (!widget.spinning && _speed.abs() < 0.02) {
      _speed = 0;
      _stopClock();
    }
    _angle = (_angle + _speed * dt) % (2 * math.pi);
    // No setState: the model repaints the painter directly.
    _pushToModel();
  }

  @override
  void dispose() {
    _clock.removeListener(_onFrame);
    _clock.dispose();
    _stopwatch.stop();
    _model.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(
        painter: TapeReelsPainter(_model),
        size: Size.infinite,
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../../state/app_state.dart';
import '../screens/kit_manager_screen.dart';
import '../theme/app_theme.dart';

/// The kit name strip at the top of the home screen. Tapping it opens a
/// quick "switch kit" bottom sheet, with a link through to full kit
/// management (rename / duplicate / delete / import).
class KitStrip extends StatelessWidget {
  const KitStrip({super.key});

  void _showSwitchKitSheet(BuildContext context) {
    final app = AppState.instance;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppColors.panel,
      builder: (sheetContext) {
        return SafeArea(
          child: ListenableBuilder(
            listenable: app,
            builder: (_, __) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text('SWITCH KIT', style: lcdTextStyle(fontSize: 20, color: AppColors.amber)),
                  ),
                  Flexible(
                    child: ListView(
                      shrinkWrap: true,
                      children: app.kitNames.map((name) {
                        final isCurrent = app.currentKit?.folderName == name;
                        return ListTile(
                          leading: Icon(
                            isCurrent ? Icons.radio_button_checked : Icons.radio_button_off,
                            color: isCurrent ? AppColors.amber : AppColors.lcdTextDim,
                          ),
                          title: Text(name, style: const TextStyle(color: AppColors.lcdText)),
                          onTap: () {
                            app.switchKit(name);
                            Navigator.of(sheetContext).pop();
                          },
                        );
                      }).toList(),
                    ),
                  ),
                  const Divider(color: AppColors.padFace),
                  ListTile(
                    leading: const Icon(Icons.tune, color: AppColors.amber),
                    title: const Text('Manage Kits...', style: TextStyle(color: AppColors.lcdText)),
                    onTap: () {
                      Navigator.of(sheetContext).pop();
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const KitManagerScreen()),
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                ],
              );
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final kitName = AppState.instance.currentKit?.name ?? 'No Kit Loaded';
        return InkWell(
          onTap: () => _showSwitchKitSheet(context),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.chassis,
              border: Border.all(color: Colors.black.withValues(alpha: 0.5)),
              borderRadius: BorderRadius.circular(6),
            ),
            margin: const EdgeInsets.fromLTRB(12, 8, 12, 8),
            child: Row(
              children: [
                const Icon(Icons.piano, color: AppColors.amber, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    kitName.toUpperCase(),
                    style: lcdTextStyle(fontSize: 20, color: AppColors.amber),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const Icon(Icons.unfold_more, color: AppColors.lcdTextDim, size: 18),
              ],
            ),
          ),
        );
      },
    );
  }
}

import 'package:flutter/material.dart';

import '../../midi/midi_service.dart';
import '../../state/app_state.dart';
import '../theme/app_theme.dart';

/// Lists available MIDI devices (USB/Bluetooth) and lets the user tap to
/// connect. Used from the Settings screen. If no device is auto-detected as
/// "MPD218", this is how the user picks one manually.
class MidiDevicePicker extends StatelessWidget {
  const MidiDevicePicker({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: MidiService.instance,
      builder: (context, _) {
        final midi = MidiService.instance;
        final devices = midi.availableDevices;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('MIDI DEVICES', style: lcdTextStyle(fontSize: 16, color: AppColors.amber)),
                const Spacer(),
                TextButton.icon(
                  onPressed: () => AppState.instance.refreshMidiDevices(),
                  icon: const Icon(Icons.refresh, size: 18, color: AppColors.lcdTextDim),
                  label: const Text('Rescan', style: TextStyle(color: AppColors.lcdTextDim)),
                ),
              ],
            ),
            const SizedBox(height: 4),
            if (devices.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Text(
                  'No MIDI devices found. Connect your MPD218 via USB (or a '
                  'USB-MIDI adapter) and tap Rescan.',
                  style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
                ),
              )
            else
              Column(
                children: devices.map((device) {
                  final connected = midi.connectedDevice?.id == device.id;
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(
                      connected ? Icons.usb : Icons.usb_off,
                      color: connected ? AppColors.success : AppColors.lcdTextDim,
                    ),
                    title: Text(device.name, style: const TextStyle(color: AppColors.lcdText)),
                    subtitle: Text(
                      connected ? 'Connected' : 'Tap to connect',
                      style: const TextStyle(color: AppColors.lcdTextDim, fontSize: 12),
                    ),
                    onTap: connected ? null : () => AppState.instance.connectToMidiDevice(device),
                  );
                }).toList(),
              ),
            if (midi.isConnected) ...[
              const SizedBox(height: 8),
              TextButton.icon(
                onPressed: () => AppState.instance.disconnectMidi(),
                icon: const Icon(Icons.link_off, color: AppColors.danger, size: 18),
                label: const Text('Disconnect', style: TextStyle(color: AppColors.danger)),
              ),
            ],
          ],
        );
      },
    );
  }
}

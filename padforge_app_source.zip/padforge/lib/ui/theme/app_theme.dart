import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// PadForge's visual identity: a dark hardware-sampler "chassis" look with a
/// warm amber accent, inspired by classic MPC-style drum machines.
class AppColors {
  AppColors._();

  /// Near-black charcoal chassis background.
  static const Color chassis = Color(0xFF1A1816);

  /// Slightly lighter panel color, used for cards/toolbars sitting on top of
  /// the chassis background.
  static const Color panel = Color(0xFF242019);

  /// Pad "off" face color -- a warm dark grey, not pure black, so pads read
  /// as physical buttons rather than flat rectangles.
  static const Color padFace = Color(0xFF2E2A24);

  /// Warm amber/orange accent -- buttons, active states, pad glow.
  static const Color amber = Color(0xFFE8973A);

  /// Slightly deeper amber, used for pressed/active states.
  static const Color amberDeep = Color(0xFFC97A22);

  /// Cream-ish LCD readout text color.
  static const Color lcdText = Color(0xFFF2E9D8);

  /// Dim LCD text, for secondary/inactive readout content.
  static const Color lcdTextDim = Color(0xFF9C9184);

  /// Subtle bevel highlight/shadow colors for the "pressed in" pad look.
  static const Color bevelHighlight = Color(0x33FFFFFF);
  static const Color bevelShadow = Color(0x66000000);

  static const Color danger = Color(0xFFD1503A);
  static const Color success = Color(0xFF6FBE7A);

  // ------------------------------------------------------------------
  // Brand mark (v8)
  //
  // The colours of the PadForge logo -- a 4x4 pad grid whose lit pads climb
  // from the bottom-left pad. These are the *same* stops used by
  // `assets/branding/logo.svg` and `tools/gen_branding.py`; the three files
  // must agree or the app icon and the in-app mark drift apart.
  //
  // They are deliberately separate constants rather than reuses of `amber` /
  // `padFace`: the mark needs a gradient, and its unlit pad is a touch lighter
  // than a real pad face so the grid still reads at 48px on a home screen.
  // ------------------------------------------------------------------

  /// Lit pad, top of the gradient.
  static const Color logoLitTop = Color(0xFFF2A94F);

  /// Lit pad, middle of the gradient (this is [amber]).
  static const Color logoLitMid = amber;

  /// Lit pad, bottom of the gradient (this is [amberDeep]).
  static const Color logoLitBottom = amberDeep;

  /// The struck pad (bottom-left), top of the gradient -- cream, still hot.
  static const Color logoStrikeTop = Color(0xFFF2E8D5);

  /// The struck pad, middle of the gradient, cooling back towards amber.
  static const Color logoStrikeMid = Color(0xFFF0B65E);

  /// Unlit pad, top of the gradient.
  static const Color logoRecessTop = Color(0xFF39332B);

  /// Unlit pad, bottom of the gradient.
  static const Color logoRecessBottom = Color(0xFF29241E);
}

/// Returns a monospace "LCD readout" text style. Tries to use the Google
/// Font "VT323" (a pixel/LCD-style font) via `google_fonts`; if that ever
/// fails to resolve for any reason, falls back to the platform's built-in
/// monospace font so a font hiccup never breaks the UI.
TextStyle lcdTextStyle({
  double fontSize = 16,
  Color color = AppColors.lcdText,
  FontWeight fontWeight = FontWeight.normal,
  double? letterSpacing,
}) {
  try {
    return GoogleFonts.vt323(
      fontSize: fontSize,
      color: color,
      fontWeight: fontWeight,
      letterSpacing: letterSpacing,
    );
  } catch (_) {
    return TextStyle(
      fontFamily: 'monospace',
      fontSize: fontSize,
      color: color,
      fontWeight: fontWeight,
      letterSpacing: letterSpacing,
    );
  }
}

ThemeData buildPadForgeTheme() {
  // Material 3 is the default design language since Flutter 3.16, so no
  // explicit `useMaterial3` flag is needed here.
  final base = ThemeData.dark();
  return base.copyWith(
    scaffoldBackgroundColor: AppColors.chassis,
    primaryColor: AppColors.amber,
    colorScheme: base.colorScheme.copyWith(
      primary: AppColors.amber,
      secondary: AppColors.amberDeep,
      surface: AppColors.panel,
      error: AppColors.danger,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.panel,
      foregroundColor: AppColors.lcdText,
      elevation: 0,
    ),
    textTheme: base.textTheme.apply(
      bodyColor: AppColors.lcdText,
      displayColor: AppColors.lcdText,
    ),
    sliderTheme: base.sliderTheme.copyWith(
      activeTrackColor: AppColors.amber,
      thumbColor: AppColors.amber,
      inactiveTrackColor: AppColors.padFace,
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected) ? AppColors.amber : AppColors.lcdTextDim,
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected) ? AppColors.amberDeep : AppColors.padFace,
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.amber,
        foregroundColor: AppColors.chassis,
        textStyle: const TextStyle(fontWeight: FontWeight.bold),
      ),
    ),
    bottomSheetTheme: const BottomSheetThemeData(backgroundColor: AppColors.panel),
    snackBarTheme: const SnackBarThemeData(backgroundColor: AppColors.padFace),
  );
}

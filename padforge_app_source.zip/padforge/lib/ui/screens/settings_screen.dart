import 'package:flutter/material.dart';

import '../../audio/audio_engine.dart';
import '../../models/kit.dart';
import '../../services/pro_store.dart';
import '../../services/settings_service.dart';
import '../../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/midi_device_picker.dart';
import '../widgets/paywall_sheet.dart';
import 'about_screen.dart';
import 'automap_screen.dart';
import 'midi_monitor_screen.dart';
import 'recordings_screen.dart';

/// Settings: MIDI device connection, the **controller map** (auto-map wizard,
/// live MIDI monitor, and a readout of the note every pad currently answers
/// to), the pad-layout choice, the **audio latency** panel (what the device
/// negotiated, the buffer-size choice, and a latency test), a "Send Test Note"
/// button that proves the MIDI OUT path works, and a way into the recordings
/// list.
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.chassis,
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _ProSection(),
          const SizedBox(height: 24),
          const MidiDevicePicker(),
          const SizedBox(height: 24),
          const _ControllerMapSection(),
          const SizedBox(height: 24),
          Text('PAD LAYOUT', style: lcdTextStyle(fontSize: 16, color: AppColors.amber)),
          const SizedBox(height: 8),
          Text(
            'On the MPD218, pad 1 is the BOTTOM-LEFT pad and the pads count '
            'upwards from there. PadForge draws the grid the same way round, so '
            'the square that lights up is the pad under your finger. Switch to '
            'top-left only if your controller is configured the other way.',
            style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
          ),
          const SizedBox(height: 8),
          const _PadLayoutSelector(),
          const SizedBox(height: 24),
          const _AudioSection(),
          const SizedBox(height: 24),
          Text('MIDI OUT', style: lcdTextStyle(fontSize: 16, color: AppColors.amber)),
          const SizedBox(height: 8),
          Text(
            'PadForge can also send MIDI out over the same USB connection, '
            'so it can trigger other gear or software. Tap below to send a '
            'short test note (middle C).',
            style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: () => AppState.instance.sendTestNote(),
            icon: const Icon(Icons.send),
            label: const Text('Send Test Note'),
          ),
          const SizedBox(height: 24),
          Text('TAPE DECK', style: lcdTextStyle(fontSize: 16, color: AppColors.amber)),
          const SizedBox(height: 8),
          Text(
            'Recordings made with the tape deck\'s REC button are saved as WAV '
            'files in the app\'s Recordings folder. Open the list below to play '
            'them back, share/export them, or delete them.',
            style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const RecordingsScreen()),
              );
            },
            icon: const Icon(Icons.album_outlined),
            label: const Text('Recordings'),
          ),
          const SizedBox(height: 24),
          Text('ABOUT', style: lcdTextStyle(fontSize: 16, color: AppColors.amber)),
          const SizedBox(height: 8),
          Text(
            'PadForge -- a companion sampler for the Akai MPD218.\n'
            'Kits are stored as plain files in the app\'s documents folder '
            '(Kits/<kit name>/kit.json + samples/*.wav), so they are easy to '
            'back up or move between devices.',
            style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
          ),
          const SizedBox(height: 12),
          // The same screen the logo in the status bar opens: version,
          // credits and the copyright line.
          ElevatedButton.icon(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const AboutScreen()),
              );
            },
            icon: const Icon(Icons.info_outline),
            label: const Text('About PadForge'),
          ),
        ],
      ),
    );
  }
}

/// The AUDIO panel: what the audio device actually negotiated, the user's
/// choice of output buffer size, and a latency test.
///
/// ## Why the buffer size is a user setting (v7)
///
/// A smaller output buffer is heard sooner, and the difference between 128 and
/// 1024 frames is the difference between an instrument and a delay pedal. But
/// there is no buffer size that is right for every phone: a flagship holds 128
/// frames comfortably on AAudio's low-latency path, while a budget device will
/// crackle, glitch or refuse to open the device at all. PadForge cannot know
/// which is which -- so it asks, defaults to the safe-ish middle (256), warns
/// about the trade-off in plain words, and steps *up* automatically if the
/// device refuses whatever was asked for.
///
/// The choice cannot apply to a running engine: the buffer size is fixed when
/// the audio device is opened. This panel therefore says "next time PadForge
/// starts" and, if the two disagree, shows both numbers rather than one
/// comforting lie.
class _AudioSection extends StatefulWidget {
  const _AudioSection();

  @override
  State<_AudioSection> createState() => _AudioSectionState();
}

/// One rung of the latency control: a frame count and the word a musician
/// would use for it.
class _BufferOption {
  final int frames;
  final String label;

  const _BufferOption(this.frames, this.label);
}

class _AudioSectionState extends State<_AudioSection> {
  /// The rungs offered by name. The engine's ladder also contains 2048, which
  /// it can still fall back to on its own -- there is just no reason to ask a
  /// user to pick it.
  static const List<_BufferOption> _choices = [
    _BufferOption(128, 'LOWEST'),
    _BufferOption(256, 'LOW'),
    _BufferOption(512, 'NORMAL'),
    _BufferOption(1024, 'SAFE'),
  ];

  Future<void> _choose(int frames) async {
    await SettingsService.instance.setAudioBufferFrames(frames);
    AudioEngine.instance.preferredBufferSize = frames;
    if (!mounted) return;
    setState(() {});
  }

  void _runLatencyTest() {
    final played = AudioEngine.instance.playTestClick();
    if (!mounted) return;
    setState(() {});
    if (!played) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No kit is loaded, so there is nothing to click with.'),
        ),
      );
    }
  }

  /// One buffer's worth of time at the engine's sample rate, e.g. 256 -> "5.8".
  static String _millis(int frames) =>
      (frames * 1000.0 / AudioEngine.instance.sampleRate).toStringAsFixed(1);

  @override
  Widget build(BuildContext context) {
    final engine = AudioEngine.instance;
    final active = engine.activeBufferSize;
    // Formatted up front rather than inside a collection-if, so nothing here
    // depends on null promotion reaching into a list element.
    final bufferMillis = active == null ? null : _millis(active);
    final preferred = engine.preferredBufferSize;
    final dispatch = engine.lastTriggerDispatchMicros;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('AUDIO', style: lcdTextStyle(fontSize: 16, color: AppColors.amber)),
        const SizedBox(height: 8),

        // The negotiated numbers, big, because this is the line a user is
        // asked to quote when they report that the pads feel late.
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          decoration: BoxDecoration(
            color: const Color(0xFF14120F),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: AppColors.amberDeep.withValues(alpha: 0.45)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                engine.isReady
                    ? '${engine.sampleRate} Hz  ·  ${active ?? '?'} FRAMES'
                    : (engine.failureMessage ?? 'AUDIO ENGINE NOT STARTED'),
                maxLines: 2,
                style: lcdTextStyle(
                  fontSize: 22,
                  color: engine.isReady ? AppColors.amber : AppColors.danger,
                  fontWeight: FontWeight.bold,
                ),
              ),
              if (engine.isReady && bufferMillis != null) ...[
                const SizedBox(height: 4),
                Text(
                  'about $bufferMillis ms of output buffer, plus whatever '
                  'your phone and speakers add.',
                  style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
                ),
              ],
              if (engine.bufferSizePending) ...[
                const SizedBox(height: 8),
                Text(
                  'You have chosen $preferred frames; the engine is running at '
                  '${active ?? '?'}. Restart PadForge to apply it -- the buffer '
                  'size is fixed when the audio device opens. If it comes back '
                  'at ${active ?? '?'} again, your device refused the smaller '
                  'buffer and stepped up on its own.',
                  style: lcdTextStyle(fontSize: 13, color: AppColors.amber),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 16),

        Text('AUDIO LATENCY', style: lcdTextStyle(fontSize: 15, color: AppColors.amber)),
        const SizedBox(height: 6),
        Text(
          'How much audio PadForge hands the phone at a time. Smaller is '
          'heard sooner: this is the single biggest thing you can change if '
          'the pads feel late.',
          style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            for (var i = 0; i < _choices.length; i++) ...[
              if (i > 0) const SizedBox(width: 6),
              Expanded(
                child: _BufferChoice(
                  label: _choices[i].label,
                  frames: _choices[i].frames,
                  millis: _millis(_choices[i].frames),
                  selected: preferred == _choices[i].frames,
                  onTap: () => _choose(_choices[i].frames),
                ),
              ),
            ],
          ],
        ),
        const SizedBox(height: 10),
        Text(
          'LOWEST (128) is only for phones that can take it. If you hear '
          'crackling, popping or dropouts -- especially with a loop playing '
          'and both hands on the pads -- step up one and restart. A setting '
          'the device refuses outright is stepped up automatically, which is '
          'why the number at the top can differ from the one you chose.',
          style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
        ),
        const SizedBox(height: 16),

        Text('LATENCY TEST', style: lcdTextStyle(fontSize: 15, color: AppColors.amber)),
        const SizedBox(height: 6),
        Text(
          'Tap the button and listen. What you are judging is the gap between '
          'your finger touching the glass and the sound arriving: at a good '
          'setting it should feel like the sound comes from the tap itself, '
          'not after it. Tap it in a steady rhythm -- lateness is far easier '
          'to hear as a stumble in time than as a single delay. Then try it '
          'with headphones: Bluetooth headphones add 100-200ms all by '
          'themselves and no app setting can remove that.',
          style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
        ),
        const SizedBox(height: 10),
        ElevatedButton.icon(
          onPressed: _runLatencyTest,
          icon: const Icon(Icons.volume_up),
          label: const Text('Play test click'),
        ),
        const SizedBox(height: 10),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: const Color(0xFF14120F),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: AppColors.amberDeep.withValues(alpha: 0.35)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                dispatch < 0
                    ? 'APP TRIGGER TIME: --'
                    : 'APP TRIGGER TIME: ${(dispatch / 1000).toStringAsFixed(2)} ms',
                style: lcdTextStyle(fontSize: 16, color: AppColors.lcdText),
              ),
              const SizedBox(height: 6),
              Text(
                'That is how long PadForge itself took to hand the sound to '
                'the audio engine on the last hit -- it should be a small '
                'fraction of a millisecond. It is NOT the delay you hear. '
                'The audio engine PadForge uses cannot report what the device '
                'does after that, so the app cannot honestly measure the true '
                'round trip and will not pretend to. Use your ears for that, '
                'and the buffer setting above to change it.',
                style: lcdTextStyle(fontSize: 12, color: AppColors.lcdTextDim),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// One of the four latency choices: a name, the frame count, and what that is
/// in milliseconds -- because "256" means nothing to a drummer and "5.8 ms"
/// does.
class _BufferChoice extends StatelessWidget {
  final String label;
  final int frames;
  final String millis;
  final bool selected;
  final VoidCallback onTap;

  const _BufferChoice({
    required this.label,
    required this.frames,
    required this.millis,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final foreground = selected ? AppColors.chassis : AppColors.lcdText;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        decoration: BoxDecoration(
          color: selected ? AppColors.amber : AppColors.padFace,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? AppColors.amberDeep : Colors.black.withValues(alpha: 0.45),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                label,
                maxLines: 1,
                style: lcdTextStyle(
                  fontSize: 13,
                  color: foreground,
                  fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                '$frames',
                maxLines: 1,
                style: lcdTextStyle(fontSize: 15, color: foreground),
              ),
            ),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                '$millis ms',
                maxLines: 1,
                style: lcdTextStyle(
                  fontSize: 11,
                  color: selected
                      ? AppColors.chassis.withValues(alpha: 0.8)
                      : AppColors.lcdTextDim,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// The controller-map panel: run the auto-map wizard on any bank, open the live
/// MIDI monitor, throw the map away, and -- most importantly -- **see the note
/// every pad in the current bank actually answers to right now**.
///
/// That last part is the whole point. PadForge shipped two different guesses at
/// what note numbers an MPD218's factory preset sends and both were wrong on
/// real hardware. A user can now read the truth off this screen and off the
/// monitor instead of diagnosing it by ear.
class _ControllerMapSection extends StatelessWidget {
  const _ControllerMapSection();

  void _openWizard(BuildContext context, String bank) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => AutoMapScreen(bank: bank)),
    );
  }

  Future<void> _confirmClear(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Clear controller map?'),
        content: const Text(
          'Every pad goes back to the note stored in the kit. Nothing about '
          'your kits or samples changes.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Keep it'),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Clear', style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await AppState.instance.clearControllerMap();
    messenger.showSnackBar(
      const SnackBar(content: Text('Controller map cleared -- kit defaults are back.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        final mapped = app.controllerMap.length;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('CONTROLLER MAP', style: lcdTextStyle(fontSize: 16, color: AppColors.amber)),
            const SizedBox(height: 8),
            Text(
              'Which note each pad sends is a property of your controller, not '
              'of your sounds -- so PadForge stores it once, here, and uses it '
              'for every kit. If the wrong sample plays when you hit a pad, run '
              'Auto-map: it asks you to hit each pad in turn and writes down '
              'whatever note actually arrives. Works with an MPD218 on any '
              'preset, and with any other controller.',
              style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
            ),
            const SizedBox(height: 10),
            Text(
              mapped == 0
                  ? 'No pads remapped -- using each kit\'s own note numbers.'
                  : '$mapped pad(s) remapped from your controller.',
              style: lcdTextStyle(
                fontSize: 14,
                color: mapped == 0 ? AppColors.lcdTextDim : AppColors.success,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                for (var i = 0; i < Kit.banks.length; i++) ...[
                  if (i > 0) const SizedBox(width: 8),
                  Expanded(
                    child: _SettingsButton(
                      label: 'AUTO-MAP ${Kit.banks[i]}',
                      primary: true,
                      onTap: () => _openWizard(context, Kit.banks[i]),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _SettingsButton(
                    label: 'MIDI MONITOR',
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(builder: (_) => const MidiMonitorScreen()),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _SettingsButton(
                    label: 'CLEAR MAP',
                    danger: true,
                    onTap: mapped == 0 ? null : () => _confirmClear(context),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              'BANK ${app.currentBank} -- ACTIVE NOTES',
              style: lcdTextStyle(fontSize: 14, color: AppColors.amber),
            ),
            const SizedBox(height: 6),
            Text(
              'Green means the note came from your controller map; dim means it '
              'came from the kit.',
              style: lcdTextStyle(fontSize: 12, color: AppColors.lcdTextDim),
            ),
            const SizedBox(height: 8),
            const _ActiveNoteChips(),
          ],
        );
      },
    );
  }
}

/// One small chip per pad of the current bank: `A1 36`, coloured by where the
/// note came from. A `Wrap` rather than a `Row`, so it reflows on any width
/// instead of overflowing.
///
/// It carries **its own** `ListenableBuilder` even though its parent already
/// has one, because it is used as a `const` widget: `Element.updateChild`
/// short-circuits when the new widget is identical to the old one, so a const
/// child of a rebuilding parent renders once and then freezes forever. (Same
/// trap the tape deck's const LCD lines hit in v2.)
class _ActiveNoteChips extends StatelessWidget {
  const _ActiveNoteChips();

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        final kit = app.currentKit;
        if (kit == null) {
          return Text(
            'No kit loaded.',
            style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
          );
        }
        final pads = kit.padsForBank(app.currentBank)
          ..sort((a, b) => a.numberInBank.compareTo(b.numberInBank));

        return Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final pad in pads)
              _NoteChip(
                padId: pad.padId,
                note: app.activeNoteForPad(pad.padId) ?? pad.note,
                fromController: app.isPadRemapped(pad.padId),
              ),
          ],
        );
      },
    );
  }
}

class _NoteChip extends StatelessWidget {
  final String padId;
  final int note;
  final bool fromController;

  const _NoteChip({
    required this.padId,
    required this.note,
    required this.fromController,
  });

  @override
  Widget build(BuildContext context) {
    final colour = fromController ? AppColors.success : AppColors.lcdTextDim;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.padFace,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: colour.withValues(alpha: 0.5)),
      ),
      child: Text(
        '$padId  $note',
        style: lcdTextStyle(fontSize: 14, color: colour),
      ),
    );
  }
}

/// A flat amber-on-charcoal button used by the controller-map panel. Sized by
/// its parent, caption scaled down rather than clipped.
class _SettingsButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool primary;
  final bool danger;

  const _SettingsButton({
    required this.label,
    required this.onTap,
    this.primary = false,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    final Color background;
    final Color foreground;
    if (!enabled) {
      background = AppColors.padFace;
      foreground = AppColors.lcdTextDim.withValues(alpha: 0.45);
    } else if (primary) {
      background = AppColors.amber;
      foreground = AppColors.chassis;
    } else if (danger) {
      background = AppColors.padFace;
      foreground = AppColors.danger;
    } else {
      background = AppColors.padFace;
      foreground = AppColors.lcdText;
    }

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        height: 42,
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 6),
        decoration: BoxDecoration(
          color: background,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: primary ? AppColors.amberDeep : Colors.black.withValues(alpha: 0.45),
          ),
        ),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            label,
            maxLines: 1,
            style: lcdTextStyle(
              fontSize: 15,
              color: foreground,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }
}

/// The PadForge Pro panel: the upgrade entry point and Restore, or a simple
/// "PRO UNLOCKED" confirmation once the one-time purchase is owned.
///
/// This is the Android mirror of the iOS Settings "PadForge Pro" section:
/// same product, same $4.99 one-time unlock (banks B/C, advanced looper,
/// unlimited recording, and future kit packs).
class _ProSection extends StatelessWidget {
  const _ProSection();

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ProStore.instance,
      builder: (context, _) {
        final store = ProStore.instance;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('PADFORGE PRO', style: lcdTextStyle(fontSize: 16, color: AppColors.amber)),
            const SizedBox(height: 8),
            if (store.isPro) ...[
              Row(
                children: [
                  const Icon(Icons.check_circle, color: AppColors.success, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    store.testerUnlocked && !store.entitlement
                        ? 'PRO UNLOCKED (TESTER)'
                        : 'PRO UNLOCKED - THANK YOU',
                    style: lcdTextStyle(fontSize: 15, color: AppColors.success),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                'All 3 banks, the advanced looper (overdub, undo, quantize), '
                'unlimited recording and every future kit pack are unlocked.',
                style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
              ),
            ] else ...[
              Text(
                'A one-time \$4.99 unlock: all 3 banks (48 pads), the advanced '
                'looper (overdub, undo, quantize), unlimited recording, theme '
                'switching and every future kit pack. Not a subscription.',
                style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: () => showPaywall(context),
                icon: const Icon(Icons.workspace_premium),
                label: Text('Upgrade to PadForge Pro - ${store.displayPrice}'),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () => ProStore.instance.restore(),
                icon: const Icon(Icons.restore),
                label: const Text('Restore purchases'),
              ),
              if (store.lastMessage.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  store.lastMessage,
                  style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
                ),
              ],
            ],
          ],
        );
      },
    );
  }
}

/// The two-way choice between the MPD218's own bottom-left pad order and plain
/// top-left reading order.
class _PadLayoutSelector extends StatelessWidget {
  const _PadLayoutSelector();

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final bottomLeft = AppState.instance.padLayoutBottomLeft;
        return Row(
          children: [
            Expanded(
              child: _LayoutOption(
                label: 'MPD218\n(bottom-left)',
                selected: bottomLeft,
                onTap: () => AppState.instance.setPadLayoutBottomLeft(true),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _LayoutOption(
                label: 'Top-left',
                selected: !bottomLeft,
                onTap: () => AppState.instance.setPadLayoutBottomLeft(false),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _LayoutOption extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _LayoutOption({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          color: selected ? AppColors.amber : AppColors.padFace,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: selected ? AppColors.amberDeep : Colors.black.withValues(alpha: 0.45),
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: lcdTextStyle(
            fontSize: 14,
            color: selected ? AppColors.chassis : AppColors.lcdText,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/midi_device_picker.dart';

/// Settings screen: MIDI device connection management, plus a "Send Test
/// Note" button that proves the MIDI OUT path works (useful for wiring
/// PadForge up to other MIDI gear/software, not just receiving from the
/// MPD218).
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.chassis,
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const MidiDevicePicker(),
          const SizedBox(height: 24),
          Text('MIDI OUT', style: lcdTextStyle(fontSize: 16, color: AppColors.amber)),
          const SizedBox(height: 8),
          Text(
            'PadForge can also send MIDI out over the same USB connection, '
            'so it can trigger other gear or software. Tap below to send a '
            'short test note (middle C).',
            style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: () => AppState.instance.sendTestNote(),
            icon: const Icon(Icons.send),
            label: const Text('Send Test Note'),
          ),
          const SizedBox(height: 24),
          Text('ABOUT', style: lcdTextStyle(fontSize: 16, color: AppColors.amber)),
          const SizedBox(height: 8),
          Text(
            'PadForge -- a companion sampler for the Akai MPD218.\n'
            'Kits are stored as plain files in the app\'s documents folder '
            '(Kits/<kit name>/kit.json + samples/*.wav), so they are easy to '
            'back up or move between devices.',
            style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
          ),
        ],
      ),
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../midi/midi_events.dart';
import '../../midi/midi_service.dart';
import '../theme/app_theme.dart';

/// One decoded MIDI message, formatted for display and for the clipboard.
///
/// Pure data: it holds only strings that have already been rendered, so the
/// list never has to re-decode anything while it scrolls.
class MidiLogEntry {
  /// `NOTE ON`, `NOTE OFF` or `CC`.
  final String type;

  /// `NOTE 42` or `CC 3` -- the number the user actually needs.
  final String numberLabel;

  /// `VEL 118` or `VAL 64`.
  final String valueLabel;

  /// 1-16, as printed on hardware (the wire uses 0-15).
  final int channel;

  /// Note On messages are the interesting ones; the rest are drawn dimmer.
  final bool emphasised;

  const MidiLogEntry({
    required this.type,
    required this.numberLabel,
    required this.valueLabel,
    required this.channel,
    required this.emphasised,
  });

  factory MidiLogEntry.fromNote(MidiNoteEvent event) {
    return MidiLogEntry(
      type: event.isOn ? 'NOTE ON' : 'NOTE OFF',
      numberLabel: 'NOTE ${event.note}',
      valueLabel: 'VEL ${event.velocity}',
      channel: event.channel + 1,
      emphasised: event.isOn,
    );
  }

  factory MidiLogEntry.fromCc(MidiCcEvent event) {
    return MidiLogEntry(
      type: 'CC',
      numberLabel: 'CC ${event.cc}',
      valueLabel: 'VAL ${event.value}',
      channel: event.channel + 1,
      emphasised: false,
    );
  }

  /// The big readout at the top: `NOTE 42  VEL 118  CH 1`.
  String get headline => '$numberLabel  $valueLabel  CH $channel';

  /// One line of the copyable log.
  String get asText => '$type  $numberLabel  $valueLabel  CH $channel';
}

/// A live view of everything arriving on the MIDI cable.
///
/// This exists because PadForge shipped *two* wrong guesses at what note
/// numbers an MPD218 sends: rather than guess a third time, show the user the
/// ground truth and let them copy it. It is also the fastest way to tell "the
/// controller is not connected" apart from "the controller is connected and
/// sending numbers we did not expect".
///
/// It is deliberately **only alive while it is on screen**: both subscriptions
/// are attached in [State.initState] and cancelled in [State.dispose], so the
/// rest of the app pays nothing for it.
class MidiMonitorScreen extends StatefulWidget {
  const MidiMonitorScreen({super.key});

  @override
  State<MidiMonitorScreen> createState() => _MidiMonitorScreenState();
}

class _MidiMonitorScreenState extends State<MidiMonitorScreen> {
  /// Enough to see a whole bank being played, small enough that the list stays
  /// cheap and a paste stays readable.
  static const int _maxEntries = 50;

  final List<MidiLogEntry> _entries = <MidiLogEntry>[];

  StreamSubscription<MidiNoteEvent>? _noteSub;
  StreamSubscription<MidiCcEvent>? _ccSub;

  @override
  void initState() {
    super.initState();
    _noteSub = MidiService.instance.noteEvents.listen(_onNote);
    _ccSub = MidiService.instance.ccEvents.listen(_onCc);
  }

  @override
  void dispose() {
    _noteSub?.cancel();
    _ccSub?.cancel();
    super.dispose();
  }

  void _onNote(MidiNoteEvent event) => _add(MidiLogEntry.fromNote(event));

  void _onCc(MidiCcEvent event) => _add(MidiLogEntry.fromCc(event));

  void _add(MidiLogEntry entry) {
    // The stream is a broadcast stream that outlives this screen, so a late
    // event after dispose is entirely possible. Never setState on a dead State.
    if (!mounted) return;
    setState(() {
      _entries.insert(0, entry);
      if (_entries.length > _maxEntries) {
        _entries.removeRange(_maxEntries, _entries.length);
      }
    });
  }

  void _clear() {
    setState(_entries.clear);
  }

  Future<void> _copy() async {
    final messenger = ScaffoldMessenger.of(context);
    if (_entries.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Nothing to copy yet -- hit a pad first.')),
      );
      return;
    }
    final buffer = StringBuffer('PadForge MIDI monitor -- newest first\n');
    for (final entry in _entries) {
      buffer.writeln(entry.asText);
    }
    await Clipboard.setData(ClipboardData(text: buffer.toString()));
    if (!mounted) return;
    messenger.showSnackBar(
      SnackBar(content: Text('Copied ${_entries.length} message(s) to the clipboard.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final latest = _entries.isEmpty ? null : _entries.first;
    return Scaffold(
      backgroundColor: AppColors.chassis,
      appBar: AppBar(
        title: const Text('MIDI Monitor'),
        actions: [
          IconButton(
            tooltip: 'Copy log',
            onPressed: _copy,
            icon: const Icon(Icons.copy),
          ),
          IconButton(
            tooltip: 'Clear',
            onPressed: _clear,
            icon: const Icon(Icons.delete_outline),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Fixed height, and everything inside it scales down, so the
              // readout can never push the list off the bottom of the screen.
              SizedBox(
                height: 92,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF14120F),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.amberDeep.withValues(alpha: 0.45)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SizedBox(
                        height: 16,
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: Alignment.centerLeft,
                          child: Text(
                            latest == null ? 'WAITING FOR MIDI' : latest.type,
                            maxLines: 1,
                            style: lcdTextStyle(fontSize: 14, color: AppColors.lcdTextDim),
                          ),
                        ),
                      ),
                      Expanded(
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: Alignment.centerLeft,
                          child: Text(
                            latest?.headline ?? '--',
                            maxLines: 1,
                            style: lcdTextStyle(
                              fontSize: 38,
                              color: AppColors.amber,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              // maxLines + ellipsis, so an enormous system text scale shrinks
              // the blurb rather than squeezing the list into a negative
              // height (which is what a RenderFlex overflow actually is).
              Text(
                'Hit pads and turn knobs -- newest message at the top. The copy '
                'button puts the last $_maxEntries messages on the clipboard.',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
              ),
              const SizedBox(height: 10),
              Expanded(
                child: _entries.isEmpty
                    ? Center(
                        child: Text(
                          'NO MIDI YET',
                          style: lcdTextStyle(fontSize: 18, color: AppColors.lcdTextDim),
                        ),
                      )
                    : ListView.builder(
                        itemCount: _entries.length,
                        itemBuilder: (context, index) => _LogRow(entry: _entries[index]),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LogRow extends StatelessWidget {
  final MidiLogEntry entry;

  const _LogRow({required this.entry});

  @override
  Widget build(BuildContext context) {
    final colour = entry.emphasised ? AppColors.lcdText : AppColors.lcdTextDim;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(
            width: 78,
            child: Text(
              entry.type,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: lcdTextStyle(
                fontSize: 14,
                color: entry.emphasised ? AppColors.amber : AppColors.lcdTextDim,
              ),
            ),
          ),
          Expanded(
            child: Text(
              entry.numberLabel,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: lcdTextStyle(fontSize: 15, color: colour),
            ),
          ),
          Expanded(
            child: Text(
              entry.valueLabel,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: lcdTextStyle(fontSize: 15, color: colour),
            ),
          ),
          SizedBox(
            width: 46,
            child: Text(
              'CH ${entry.channel}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
              style: lcdTextStyle(fontSize: 14, color: AppColors.lcdTextDim),
            ),
          ),
        ],
      ),
    );
  }
}

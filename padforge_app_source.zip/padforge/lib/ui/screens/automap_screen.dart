import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../midi/midi_events.dart';
import '../../midi/midi_service.dart';
import '../../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/pad_grid.dart';

/// The Auto-map wizard: walks one bank, pad by pad, and records what note each
/// physical pad actually sends.
///
/// ## Why this replaced guessing
///
/// v4 assumed the MPD218's factory preset sends notes 36-51 with pad 1 at the
/// top left. v5 kept the notes and fixed the grid to bottom-left origin. On the
/// user's actual hardware only pads 1 and 2 then lined up -- which proves the
/// notes are **not** a contiguous ascending run at all (if they were, the v5
/// grid would have made all sixteen right). A third guess would be a third bug.
///
/// So this screen measures instead: it asks for one pad at a time, writes down
/// whatever note arrives, and saves the lot into the global controller map. It
/// works with an MPD218 on any preset, and with any other controller entirely.
///
/// ## The rules that keep the result honest
///
///  * **Repeat guard.** Pad hits bounce; a second copy of the note we just
///    captured, within [_repeatGuardMs], is ignored silently rather than being
///    treated as the answer for the *next* pad.
///  * **Duplicates warn, they do not corrupt.** A note already claimed by an
///    earlier slot in this run is refused with an inline message, so a
///    double-assignment can never be saved by accident.
///  * **Nothing is written until Save.** The summary at the end is the exact
///    table that will be stored, and it can be copied to the clipboard.
class AutoMapScreen extends StatefulWidget {
  /// Which bank ("A", "B" or "C") this run maps. Running it three times maps
  /// all 48 pads.
  final String bank;

  const AutoMapScreen({super.key, required this.bank});

  @override
  State<AutoMapScreen> createState() => _AutoMapScreenState();
}

class _AutoMapScreenState extends State<AutoMapScreen> {
  /// A stray second copy of the note just captured, arriving within this many
  /// milliseconds, is a bouncing pad rather than the user's next answer.
  static const int _repeatGuardMs = 300;

  static const int _padsPerBank = 16;

  /// The note captured for each pad of the bank, indexed 0..15 for pads 1..16.
  /// Null means "not captured" -- either not reached yet, or skipped.
  final List<int?> _captured = List<int?>.filled(_padsPerBank, null);

  /// Which pad we are asking for, 0-based. Meaningless once [_done] is true.
  int _slot = 0;

  /// True once all 16 slots have been visited: the summary is showing.
  bool _done = false;

  String? _warning;
  String? _confirmation;

  int? _guardNote;
  DateTime? _guardAt;

  StreamSubscription<MidiNoteEvent>? _noteSub;

  @override
  void initState() {
    super.initState();
    _noteSub = MidiService.instance.noteEvents.listen(_onNote);
    // While this screen is up, an incoming note must not play a pad: the user
    // is being asked to hit pad 3, and hearing pad 11 fire would be confusing
    // at best and would get recorded into an armed loop at worst.
    AppState.instance.setPadTriggeringSuspended(true);
  }

  @override
  void dispose() {
    _noteSub?.cancel();
    AppState.instance.setPadTriggeringSuspended(false);
    super.dispose();
  }

  String _padIdFor(int slot) => '${widget.bank}${slot + 1}';

  void _onNote(MidiNoteEvent event) {
    if (!event.isOn || event.velocity == 0) return;
    // The stream outlives this screen; never touch a disposed State.
    if (!mounted || _done) return;

    final now = DateTime.now();
    final guardAt = _guardAt;
    if (_guardNote == event.note &&
        guardAt != null &&
        now.difference(guardAt).inMilliseconds < _repeatGuardMs) {
      return;
    }

    final existing = _captured.indexOf(event.note);
    if (existing != -1 && existing != _slot) {
      setState(() {
        _confirmation = null;
        _warning = 'NOTE ${event.note} is already PAD ${existing + 1}. '
            'Hit a different pad, or tap SKIP.';
      });
      return;
    }

    setState(() {
      _captured[_slot] = event.note;
      _guardNote = event.note;
      _guardAt = now;
      _warning = null;
      _confirmation = 'PAD ${_slot + 1} = NOTE ${event.note}';
      if (_slot >= _padsPerBank - 1) {
        _done = true;
      } else {
        _slot++;
      }
    });
  }

  void _skip() {
    if (_done) return;
    setState(() {
      _captured[_slot] = null;
      _warning = null;
      _confirmation = 'PAD ${_slot + 1} left unmapped';
      _guardNote = null;
      _guardAt = null;
      if (_slot >= _padsPerBank - 1) {
        _done = true;
      } else {
        _slot++;
      }
    });
  }

  void _back() {
    if (!_done && _slot == 0) return;
    setState(() {
      if (_done) {
        _done = false;
        _slot = _padsPerBank - 1;
      } else {
        _slot--;
      }
      _captured[_slot] = null;
      _warning = null;
      _confirmation = null;
      _guardNote = null;
      _guardAt = null;
    });
  }

  Future<void> _save() async {
    final navigator = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final result = <String, int?>{};
    for (var i = 0; i < _padsPerBank; i++) {
      result[_padIdFor(i)] = _captured[i];
    }
    await AppState.instance.applyAutoMap(result);
    if (!mounted) return;
    final mapped = _captured.where((note) => note != null).length;
    navigator.pop();
    messenger.showSnackBar(
      SnackBar(content: Text('Bank ${widget.bank}: $mapped of $_padsPerBank pads mapped.')),
    );
  }

  Future<void> _copySummary() async {
    final messenger = ScaffoldMessenger.of(context);
    final buffer = StringBuffer('PadForge auto-map -- BANK ${widget.bank}\n');
    for (var i = 0; i < _padsPerBank; i++) {
      final note = _captured[i];
      final padNumber = (i + 1).toString().padLeft(2);
      buffer.writeln('PAD $padNumber -> ${note == null ? 'skipped' : 'note $note'}');
    }
    await Clipboard.setData(ClipboardData(text: buffer.toString()));
    if (!mounted) return;
    messenger.showSnackBar(
      const SnackBar(content: Text('Mapping copied to the clipboard.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.chassis,
      appBar: AppBar(title: Text('Auto-map bank ${widget.bank}')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: LayoutBuilder(
            builder: (context, constraints) => _done
                ? _buildSummary(constraints.maxHeight)
                : _buildCapture(constraints.maxHeight, constraints.maxWidth),
          ),
        ),
      ),
    );
  }

  // --- The capture step ---------------------------------------------------

  /// ## Height budget (why this cannot overflow)
  ///
  /// Every fixed row is capped at both an absolute dp value *and* a fraction of
  /// the available height `h`. The fractions are
  /// `0.15 + 0.10 + 0.11 + 0.13 = 0.49` for the four rows plus `4 x 0.02 = 0.08`
  /// for the gaps, so the fixed parts can never exceed **0.57h** and the
  /// diagram is always at least 0.43h tall. There is no screen size, and no
  /// system text scale, at which the column can be asked for more room than it
  /// has -- which is the only way a RenderFlex overflow happens.
  ///
  /// Worked through on the smallest phone worth supporting, 320x568: the status
  /// bar takes ~24 and the app bar 56, so the body is ~488, and this widget's
  /// own 12dp padding leaves `h = 464`. Prompt `min(56, 69.6) = 56`, subtitle
  /// `min(34, 46.4) = 34`, status `min(40, 51.0) = 40`, footer
  /// `min(48, 60.3) = 48`, gaps `4 x min(8, 9.3) = 32`; total **210**, leaving
  /// **254** for the diagram against a content width of 296. So the square is
  /// 254dp and each cell is `(254 - 3 x 5) / 4 =` **59.75dp**.
  Widget _buildCapture(double maxHeight, double maxWidth) {
    final h = math.max(0.0, maxHeight);
    final promptH = math.min(56.0, h * 0.15);
    final subtitleH = math.min(34.0, h * 0.10);
    final statusH = math.min(40.0, h * 0.11);
    final footerH = math.min(48.0, h * 0.13);
    final gap = math.min(8.0, h * 0.02);
    final diagramH = math.max(0.0, h - promptH - subtitleH - statusH - footerH - gap * 4);
    final side = math.min(diagramH, math.max(0.0, maxWidth));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: promptH,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              'Hit PAD ${_slot + 1}',
              maxLines: 1,
              style: lcdTextStyle(
                fontSize: 42,
                color: AppColors.amber,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        SizedBox(height: gap),
        SizedBox(
          height: subtitleH,
          // Listens to the MIDI service so that plugging the controller in
          // while this screen is open updates the line straight away.
          child: ListenableBuilder(
            listenable: MidiService.instance,
            builder: (context, _) {
              final connected = MidiService.instance.isConnected;
              return FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  connected
                      ? 'BANK ${widget.bank}  --  PAD ${_slot + 1} OF $_padsPerBank\n'
                          'PAD 1 is the BOTTOM-LEFT pad on your controller'
                      : 'NO CONTROLLER CONNECTED\nPlug it in, then come back',
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  style: lcdTextStyle(fontSize: 14, color: AppColors.lcdTextDim),
                ),
              );
            },
          ),
        ),
        SizedBox(height: gap),
        SizedBox(
          height: diagramH,
          child: Center(
            child: SizedBox(
              width: side,
              height: side,
              child: _BankDiagram(
                captured: _captured,
                activeSlot: _slot,
                visitedUpTo: _slot,
              ),
            ),
          ),
        ),
        SizedBox(height: gap),
        SizedBox(
          height: statusH,
          child: Center(child: _statusLine()),
        ),
        SizedBox(height: gap),
        SizedBox(
          height: footerH,
          child: Row(
            children: [
              Expanded(
                child: _WizardButton(
                  label: 'BACK',
                  enabled: _slot > 0,
                  onTap: _back,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _WizardButton(label: 'SKIP', onTap: _skip),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _WizardButton(
                  label: 'CANCEL',
                  danger: true,
                  onTap: () => Navigator.of(context).pop(),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _statusLine() {
    final warning = _warning;
    final confirmation = _confirmation;
    final String text;
    final Color colour;
    if (warning != null) {
      text = warning;
      colour = AppColors.danger;
    } else if (confirmation != null) {
      text = confirmation;
      colour = AppColors.success;
    } else {
      text = 'Waiting for a hit...';
      colour = AppColors.lcdTextDim;
    }
    return FittedBox(
      fit: BoxFit.scaleDown,
      child: Text(
        text,
        textAlign: TextAlign.center,
        maxLines: 2,
        style: lcdTextStyle(fontSize: 16, color: colour),
      ),
    );
  }

  // --- The summary step ---------------------------------------------------

  /// Same shape of budget as [_buildCapture]: the header and footer are capped
  /// at a fraction of `h` as well as at a dp value (0.09 + 0.13 + 2 x 0.02 =
  /// 0.26 at most), so the scrollable table always gets at least 0.74h.
  Widget _buildSummary(double maxHeight) {
    final h = math.max(0.0, maxHeight);
    final headerH = math.min(34.0, h * 0.09);
    final footerH = math.min(48.0, h * 0.13);
    final gap = math.min(8.0, h * 0.02);
    final listH = math.max(0.0, h - headerH - footerH - gap * 2);
    final mapped = _captured.where((note) => note != null).length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: headerH,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              'BANK ${widget.bank}  --  $mapped OF $_padsPerBank MAPPED',
              maxLines: 1,
              style: lcdTextStyle(fontSize: 20, color: AppColors.amber),
            ),
          ),
        ),
        SizedBox(height: gap),
        SizedBox(
          height: listH,
          child: ListView.builder(
            itemCount: _padsPerBank,
            itemBuilder: (context, index) => _SummaryRow(
              padId: _padIdFor(index),
              padNumber: index + 1,
              note: _captured[index],
            ),
          ),
        ),
        SizedBox(height: gap),
        SizedBox(
          height: footerH,
          child: Row(
            children: [
              Expanded(child: _WizardButton(label: 'BACK', onTap: _back)),
              const SizedBox(width: 8),
              Expanded(child: _WizardButton(label: 'COPY', onTap: _copySummary)),
              const SizedBox(width: 8),
              Expanded(
                child: _WizardButton(
                  label: 'SAVE',
                  primary: true,
                  onTap: _save,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// The 4x4 diagram, drawn in the MPD218's own physical arrangement: **pad 1
/// bottom-left**, counting left to right and then upwards.
///
/// It reuses `padIndexForGridSlot` -- the same function the real pad grid uses,
/// and the one covered by `test/pad_layout_test.dart` -- so the diagram and the
/// instrument can never disagree about which square is pad 1.
class _BankDiagram extends StatelessWidget {
  final List<int?> captured;
  final int activeSlot;

  /// Slots below this index have been visited already; a null capture in one of
  /// them means the user skipped it, not that we have not got there yet.
  final int visitedUpTo;

  const _BankDiagram({
    required this.captured,
    required this.activeSlot,
    required this.visitedUpTo,
  });

  static const double _gap = 5;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (var row = 0; row < 4; row++) ...[
          if (row > 0) const SizedBox(height: _gap),
          Expanded(
            child: Row(
              children: [
                for (var column = 0; column < 4; column++) ...[
                  if (column > 0) const SizedBox(width: _gap),
                  Expanded(child: _cell(row * 4 + column)),
                ],
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _cell(int drawnSlot) {
    final slot = padIndexForGridSlot(drawnSlot, bottomLeft: true);
    final note = captured[slot];
    final isActive = slot == activeSlot;
    final isSkipped = note == null && slot < visitedUpTo;

    final Color background;
    final Color border;
    final Color textColour;
    if (isActive) {
      background = AppColors.amber;
      border = AppColors.amberDeep;
      textColour = AppColors.chassis;
    } else if (note != null) {
      background = AppColors.padFace;
      border = AppColors.success;
      textColour = AppColors.success;
    } else {
      background = AppColors.padFace;
      border = Colors.black.withValues(alpha: 0.45);
      textColour = AppColors.lcdTextDim;
    }

    final String detail;
    if (note != null) {
      detail = 'NOTE $note';
    } else if (isSkipped) {
      detail = 'SKIPPED';
    } else if (isActive) {
      detail = 'HIT IT';
    } else {
      detail = '--';
    }

    return DecoratedBox(
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: border, width: isActive ? 2.5 : 1),
        boxShadow: [
          if (isActive)
            BoxShadow(
              color: AppColors.amber.withValues(alpha: 0.5),
              blurRadius: 14,
              spreadRadius: 1,
            ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 3),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Both lines are Flexible + scaleDown, so a cell as small as ~40dp
            // shrinks its lettering rather than overflowing.
            Flexible(
              flex: 3,
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  'PAD ${slot + 1}',
                  maxLines: 1,
                  style: lcdTextStyle(
                    fontSize: 17,
                    color: textColour,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            Flexible(
              flex: 2,
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  detail,
                  maxLines: 1,
                  style: lcdTextStyle(fontSize: 12, color: textColour),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String padId;
  final int padNumber;
  final int? note;

  const _SummaryRow({
    required this.padId,
    required this.padNumber,
    required this.note,
  });

  @override
  Widget build(BuildContext context) {
    final mapped = note != null;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 74,
            child: Text(
              'PAD $padNumber',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: lcdTextStyle(fontSize: 17, color: AppColors.lcdText),
            ),
          ),
          SizedBox(
            width: 44,
            child: Text(
              padId,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: lcdTextStyle(fontSize: 15, color: AppColors.lcdTextDim),
            ),
          ),
          Expanded(
            child: Text(
              mapped ? 'NOTE $note' : 'not mapped',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.right,
              style: lcdTextStyle(
                fontSize: 17,
                color: mapped ? AppColors.success : AppColors.lcdTextDim,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// A flat amber-on-charcoal button sized entirely by its parent, with a caption
/// that scales down instead of overflowing.
class _WizardButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool enabled;
  final bool primary;
  final bool danger;

  const _WizardButton({
    required this.label,
    required this.onTap,
    this.enabled = true,
    this.primary = false,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final Color background;
    final Color foreground;
    if (!enabled) {
      background = AppColors.padFace;
      foreground = AppColors.lcdTextDim.withValues(alpha: 0.5);
    } else if (primary) {
      background = AppColors.amber;
      foreground = AppColors.chassis;
    } else if (danger) {
      background = AppColors.padFace;
      foreground = AppColors.danger;
    } else {
      background = AppColors.padFace;
      foreground = AppColors.lcdText;
    }

    return InkWell(
      onTap: enabled ? onTap : null,
      borderRadius: BorderRadius.circular(8),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: background,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: primary ? AppColors.amberDeep : Colors.black.withValues(alpha: 0.45),
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                label,
                maxLines: 1,
                style: lcdTextStyle(
                  fontSize: 18,
                  color: foreground,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

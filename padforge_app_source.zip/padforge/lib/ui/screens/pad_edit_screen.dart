import 'package:flutter/material.dart';

import '../../services/sample_import_service.dart';
import '../../state/app_state.dart';
import '../theme/app_theme.dart';

/// Full-screen editor for a single pad, opened by long-pressing a pad on
/// the home screen.
///
/// Shows the assigned sample (filename only -- no waveform, per spec),
/// the MIDI note it's mapped to (with a one-tap "Learn" button, plus a
/// manual numeric entry fallback under "Advanced"), a volume slider, and a
/// choke group picker.
class PadEditScreen extends StatefulWidget {
  final String padId;

  const PadEditScreen({super.key, required this.padId});

  @override
  State<PadEditScreen> createState() => _PadEditScreenState();
}

class _PadEditScreenState extends State<PadEditScreen> {
  bool _showAdvanced = false;
  final TextEditingController _noteController = TextEditingController();

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _changeSample() async {
    final files = await SampleImportService.pickWavFiles(allowMultiple: false);
    if (files.isEmpty) return;
    await AppState.instance.assignSampleToPad(widget.padId, files.first);
  }

  void _clearSample() {
    AppState.instance.updatePad(widget.padId, clearSample: true);
  }

  void _applyManualNote() {
    final parsed = int.tryParse(_noteController.text.trim());
    if (parsed == null || parsed < 0 || parsed > 127) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a MIDI note number between 0 and 127.')),
      );
      return;
    }
    // Writes to the **global controller map**, exactly like Learn does, so the
    // two can never disagree and the choice follows the user into every kit.
    // The kit's own `note` field is left alone as the shipped default.
    AppState.instance.assignControllerNote(parsed, widget.padId);
    _noteController.clear();
    FocusScope.of(context).unfocus();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.chassis,
      appBar: AppBar(title: Text('Edit Pad ${widget.padId}')),
      body: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          final app = AppState.instance;
          final pad = app.currentKit?.padById(widget.padId);
          if (pad == null) {
            return const Center(child: Text('Pad not found.'));
          }
          final isLearning = app.isLearningPad(widget.padId);
          // What will *actually* fire this pad right now: the controller map's
          // note if there is one, the kit's own otherwise. Printing this (and
          // saying where it came from) is what turns "the wrong sample plays"
          // into a fact you can read off the screen.
          final activeNote = app.activeNoteForPad(widget.padId) ?? pad.note;
          final remapped = app.isPadRemapped(widget.padId);

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _SectionLabel('SAMPLE'),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: _panelDecoration(),
                child: Row(
                  children: [
                    const Icon(Icons.audiotrack, color: AppColors.amber),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        pad.sampleFileName,
                        style: lcdTextStyle(fontSize: 16, color: AppColors.lcdText),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    TextButton(onPressed: _changeSample, child: const Text('Change')),
                    if (pad.hasSample)
                      TextButton(
                        onPressed: _clearSample,
                        child: const Text('Clear', style: TextStyle(color: AppColors.danger)),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              _SectionLabel('MIDI NOTE'),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: _panelDecoration(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            'NOTE $activeNote',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: lcdTextStyle(fontSize: 22, color: AppColors.amber),
                          ),
                        ),
                        ElevatedButton.icon(
                          onPressed: () => app.startPadLearn(widget.padId),
                          icon: const Icon(Icons.hearing, size: 18),
                          label: Text(isLearning ? 'Listening...' : 'Learn'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      remapped
                          ? 'From your controller map. This kit\'s own default '
                              'is note ${pad.note}.'
                          : 'From this kit (no controller mapping for this pad).',
                      style: lcdTextStyle(
                        fontSize: 13,
                        color: remapped ? AppColors.success : AppColors.lcdTextDim,
                      ),
                    ),
                    if (remapped)
                      TextButton(
                        onPressed: () => app.clearControllerNoteForPad(widget.padId),
                        child: const Text('Use the kit default instead'),
                      ),
                    if (isLearning)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(
                          'Hit the pad on your controller now...',
                          style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
                        ),
                      ),
                    TextButton(
                      onPressed: () => setState(() => _showAdvanced = !_showAdvanced),
                      child: Text(_showAdvanced ? 'Hide advanced' : 'Advanced: enter note number manually'),
                    ),
                    if (_showAdvanced)
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _noteController,
                              keyboardType: TextInputType.number,
                              style: const TextStyle(color: AppColors.lcdText),
                              decoration: const InputDecoration(
                                labelText: 'MIDI note (0-127)',
                                labelStyle: TextStyle(color: AppColors.lcdTextDim),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          ElevatedButton(onPressed: _applyManualNote, child: const Text('Set')),
                        ],
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              _SectionLabel('VOLUME'),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: _panelDecoration(),
                child: Row(
                  children: [
                    const Icon(Icons.volume_up, color: AppColors.lcdTextDim),
                    Expanded(
                      child: Slider(
                        value: pad.volume.clamp(0.0, 1.0).toDouble(),
                        onChanged: (v) => app.updatePad(widget.padId, volume: v),
                      ),
                    ),
                    SizedBox(
                      width: 42,
                      child: Text(
                        '${(pad.volume * 100).round()}%',
                        style: lcdTextStyle(fontSize: 14, color: AppColors.lcdText),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              _SectionLabel('CHOKE GROUP'),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: _panelDecoration(),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Pads sharing a choke group cut each other off (e.g. open/closed hi-hat).',
                        style: lcdTextStyle(fontSize: 12, color: AppColors.lcdTextDim),
                      ),
                    ),
                    DropdownButton<int?>(
                      dropdownColor: AppColors.panel,
                      value: pad.chokeGroup,
                      hint: const Text('None', style: TextStyle(color: AppColors.lcdTextDim)),
                      items: [
                        const DropdownMenuItem<int?>(value: null, child: Text('None')),
                        for (var i = 1; i <= 8; i++)
                          DropdownMenuItem<int?>(value: i, child: Text('Group $i')),
                      ],
                      onChanged: (value) {
                        if (value == null) {
                          app.updatePad(widget.padId, clearChoke: true);
                        } else {
                          app.updatePad(widget.padId, chokeGroup: value);
                        }
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              Center(
                child: ElevatedButton.icon(
                  onPressed: () => app.hitPad(widget.padId),
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('Preview'),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  BoxDecoration _panelDecoration() => BoxDecoration(
        color: AppColors.panel,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.black.withValues(alpha: 0.4)),
      );
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(text, style: lcdTextStyle(fontSize: 14, color: AppColors.amber)),
    );
  }
}

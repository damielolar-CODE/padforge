import 'package:flutter/material.dart';

import '../../state/app_state.dart';
import '../theme/app_theme.dart';

/// Full kit management screen: list every installed kit, switch the active
/// one, rename/duplicate/delete kits, and create a brand new kit either
/// blank or from a batch of picked WAV files.
class KitManagerScreen extends StatefulWidget {
  const KitManagerScreen({super.key});

  @override
  State<KitManagerScreen> createState() => _KitManagerScreenState();
}

class _KitManagerScreenState extends State<KitManagerScreen> {
  Future<String?> _promptForName(BuildContext context, {required String title, String initial = ''}) async {
    final controller = TextEditingController(text: initial);
    return showDialog<String>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text(title),
          content: TextField(
            controller: controller,
            autofocus: true,
            style: const TextStyle(color: AppColors.lcdText),
            decoration: const InputDecoration(hintText: 'Kit name'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(controller.text.trim()),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _createBlankKit() async {
    final name = await _promptForName(context, title: 'New Kit');
    if (name == null || name.isEmpty) return;
    await AppState.instance.createBlankKit(name);
  }

  Future<void> _createKitFromFiles() async {
    final name = await _promptForName(context, title: 'New Kit From Files');
    if (name == null || name.isEmpty) return;
    final folder = await AppState.instance.createKitFromPickedFiles(name);
    if (!mounted) return;
    if (folder == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No files were selected.')),
      );
    }
  }

  Future<void> _renameKit(String currentName) async {
    final name = await _promptForName(context, title: 'Rename Kit', initial: currentName);
    if (name == null || name.isEmpty) return;
    await AppState.instance.renameCurrentKit(name);
  }

  Future<void> _duplicateKit(String currentName) async {
    final name = await _promptForName(context, title: 'Duplicate Kit As', initial: '$currentName Copy');
    if (name == null || name.isEmpty) return;
    await AppState.instance.duplicateCurrentKit(name);
  }

  Future<void> _confirmDelete(String folderName) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete Kit?'),
        content: Text('This permanently deletes "$folderName" and all its samples. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Delete', style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await AppState.instance.deleteKit(folderName);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.chassis,
      appBar: AppBar(title: const Text('Manage Kits')),
      body: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          final app = AppState.instance;
          final currentFolder = app.currentKit?.folderName;

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: app.kitNames.length,
                  itemBuilder: (context, index) {
                    final folderName = app.kitNames[index];
                    final isCurrent = folderName == currentFolder;
                    return Card(
                      color: AppColors.panel,
                      margin: const EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        leading: Icon(
                          isCurrent ? Icons.check_circle : Icons.circle_outlined,
                          color: isCurrent ? AppColors.amber : AppColors.lcdTextDim,
                        ),
                        title: Text(folderName, style: const TextStyle(color: AppColors.lcdText)),
                        subtitle: isCurrent
                            ? const Text('Active kit', style: TextStyle(color: AppColors.amber, fontSize: 12))
                            : null,
                        onTap: () => app.switchKit(folderName),
                        trailing: PopupMenuButton<String>(
                          color: AppColors.panel,
                          onSelected: (action) async {
                            if (!isCurrent) {
                              await app.switchKit(folderName);
                            }
                            switch (action) {
                              case 'rename':
                                await _renameKit(folderName);
                                break;
                              case 'duplicate':
                                await _duplicateKit(folderName);
                                break;
                              case 'delete':
                                await _confirmDelete(folderName);
                                break;
                            }
                          },
                          itemBuilder: (context) => const [
                            PopupMenuItem(value: 'rename', child: Text('Rename')),
                            PopupMenuItem(value: 'duplicate', child: Text('Duplicate')),
                            PopupMenuItem(value: 'delete', child: Text('Delete')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _createBlankKit,
                        icon: const Icon(Icons.add),
                        label: const Text('New Blank Kit'),
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _createKitFromFiles,
                        icon: const Icon(Icons.folder_open),
                        label: const Text('New Kit From WAV Files...'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

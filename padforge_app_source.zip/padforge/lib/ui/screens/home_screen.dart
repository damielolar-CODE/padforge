import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/bank_tabs.dart';
import '../widgets/bottom_toolbar.dart';
import '../widgets/kit_strip.dart';
import '../widgets/knob_widget.dart';
import '../widgets/pad_grid.dart';
import '../widgets/status_bar.dart';
import '../widgets/tape_deck.dart';

/// The main PadForge screen, top to bottom: status bar, the tape deck, the kit
/// selector strip (with the bank tabs beside it), the 4x4 pad grid, a row of 6
/// knobs, and the bottom toolbar. It reads as one continuous "MPC chassis"
/// rather than a stack of separate cards.
///
/// ## Nothing scrolls -- and the arithmetic that guarantees it (v5)
///
/// Up to v4 the middle of this screen was a `SingleChildScrollView`: the
/// instrument was taller than a small phone and you scrolled to reach the
/// knobs. Players hated it, and they are right -- you cannot scroll to a pad
/// mid-take. So every piece now sizes itself from the height that is actually
/// available, via [LayoutBuilder]:
///
/// ```
///   available h  = screen - safe areas - status bar - toolbar
///   deck         = clamp(h * 0.40, 150, 290), never more than 45% of h
///   strip        = min(30, h * 0.08)          kit name + bank tabs, one row
///   gaps         = 4 x min(4, h * 0.01)
///   rest         = h - deck - strip - gaps
///   knobs        = clamp(rest * 0.19, 34, 76) but never more than half of rest
///   pads         = rest - knobs               square, capped by the width
/// ```
///
/// Worked through on a 320x568 phone (the smallest still worth supporting):
/// SafeArea leaves ~548; the status bar is ~34 and the toolbar ~46, so
/// `h = 468`. Deck = 187, strip = 30, gaps = 16, rest = 235, knobs = 44, pads =
/// 191 -> a 191dp square holding 4 rows of ~46dp pads. Everything sums to 468
/// **by construction** (`pads = rest - knobs`), so there is no combination of
/// screen size and text scale that can overflow: the only widget that ever
/// exceeds its share is a caption, and every caption in this tree is a
/// `FittedBox(scaleDown)` or `Flexible`.
///
/// The pad grid stays the dominant element and the knobs are the first thing
/// to give up space, which is the order a player would choose.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.chassis,
      body: SafeArea(
        child: Column(
          children: [
            const StatusBar(),
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) => _Instrument(
                  height: constraints.maxHeight,
                  width: constraints.maxWidth,
                ),
              ),
            ),
            const _LearnBanner(),
            const BottomToolbar(),
          ],
        ),
      ),
    );
  }
}

/// The instrument itself, laid out from the height it was given. See
/// [HomeScreen] for the height budget and why it cannot overflow.
class _Instrument extends StatelessWidget {
  final double height;
  final double width;

  const _Instrument({required this.height, required this.width});

  @override
  Widget build(BuildContext context) {
    final h = math.max(0.0, height);

    // Gaps and the kit strip scale with the screen, so even an absurdly short
    // window (a resized desktop, a split-screen phone) still adds up.
    final gap = math.min(4.0, h * 0.01);
    final stripH = math.min(30.0, h * 0.08);

    // v7: the ceiling went from 260 to 290 so the loop display can be a real
    // display on a normal phone. It only ever binds on a tall screen (0.40h
    // reaches 290 at h = 725, i.e. a ~6" phone and up), where there is room to
    // spare: on a 390x844 the pad grid still gets 261dp -- 65dp pads -- after
    // the deck has taken its 290.
    var deckH = h * 0.40;
    if (deckH < 150) deckH = 150;
    if (deckH > 290) deckH = 290;
    // Never let the deck squeeze the pads out on a short screen.
    final deckCeiling = math.max(0.0, h * 0.45);
    if (deckH > deckCeiling) deckH = deckCeiling;

    final rest = math.max(0.0, h - deckH - stripH - gap * 4);
    var knobH = rest * 0.19;
    if (knobH < 34) knobH = 34;
    if (knobH > 76) knobH = 76;
    if (knobH > rest * 0.5) knobH = rest * 0.5;
    final padH = math.max(0.0, rest - knobH);

    // The grid is square, and the width may be the tighter of the two.
    final padSide = math.min(padH, math.max(0.0, width - 20));

    return Column(
      children: [
        SizedBox(height: deckH, child: const TapeDeckPanel()),
        SizedBox(height: gap),
        SizedBox(
          height: stripH,
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(child: KitStrip()),
                SizedBox(width: 6),
                SizedBox(width: 132, child: BankTabs()),
              ],
            ),
          ),
        ),
        SizedBox(height: gap),
        SizedBox(
          height: padH,
          child: Center(
            child: SizedBox(
              width: padSide,
              height: padSide,
              child: const PadGrid(),
            ),
          ),
        ),
        SizedBox(height: gap),
        SizedBox(
          height: knobH,
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: _KnobRow(),
          ),
        ),
        SizedBox(height: gap),
      ],
    );
  }
}

/// The row of six knobs. It sizes each knob from the height it was given --
/// knobs are the first thing to shrink when a phone is short, because a small
/// knob is still perfectly usable and a small pad is not.
class _KnobRow extends StatelessWidget {
  const _KnobRow();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final h = math.max(0.0, constraints.maxHeight);
        final labelH = math.min(13.0, h * 0.28);
        // diameter + 2dp gap + label = exactly the row height, and never wider
        // than a sixth of the row.
        final byHeight = math.max(0.0, h - labelH - 2);
        final byWidth = math.max(0.0, constraints.maxWidth / 6 - 8);
        final diameter = math.min(byHeight, byWidth);

        return DecoratedBox(
          decoration: BoxDecoration(
            color: AppColors.panel,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.black.withValues(alpha: 0.4)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(
              6,
              (i) => KnobWidget(
                knobIndex: i + 1,
                diameter: diameter,
                labelHeight: labelH,
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Shows a small amber banner while MIDI Learn is armed, so it's obvious the
/// next hardware hit/turn is about to get captured.
class _LearnBanner extends StatelessWidget {
  const _LearnBanner();

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        if (!app.learnModeArmed) return const SizedBox.shrink();

        final target = app.learnController.target;
        final String message;
        if (target == null) {
          message = 'MIDI LEARN ARMED -- tap a pad or knob to select it';
        } else {
          message = 'LISTENING -- hit the pad or turn the knob on your MPD218 now';
        }

        return Container(
          width: double.infinity,
          color: AppColors.amber,
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
          child: Text(
            message,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: lcdTextStyle(fontSize: 13, color: AppColors.chassis, fontWeight: FontWeight.bold),
          ),
        );
      },
    );
  }
}

import 'package:flutter/material.dart';

import '../../state/app_state.dart';
import '../theme/app_theme.dart';
import '../widgets/bank_tabs.dart';
import '../widgets/bottom_toolbar.dart';
import '../widgets/kit_strip.dart';
import '../widgets/knob_widget.dart';
import '../widgets/pad_grid.dart';
import '../widgets/status_bar.dart';

/// The main PadForge screen: status bar, kit selector strip, bank tabs,
/// the 4x4 pad grid, a row of 6 knobs, and the bottom toolbar. This is
/// meant to read as one continuous "MPC chassis" rather than a stack of
/// separate cards.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.chassis,
      body: SafeArea(
        child: Column(
          children: [
            const StatusBar(),
            const KitStrip(),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 12),
              child: BankTabs(),
            ),
            const SizedBox(height: 10),
            const Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 12),
                child: Column(
                  children: [
                    PadGrid(),
                    SizedBox(height: 18),
                    _KnobRow(),
                    SizedBox(height: 12),
                  ],
                ),
              ),
            ),
            const _LearnBanner(),
            const BottomToolbar(),
          ],
        ),
      ),
    );
  }
}

class _KnobRow extends StatelessWidget {
  const _KnobRow();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
      decoration: BoxDecoration(
        color: AppColors.panel,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.black.withValues(alpha: 0.4)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(6, (i) => KnobWidget(knobIndex: i + 1)),
      ),
    );
  }
}

/// Shows a small amber banner while MIDI Learn is armed, so it's obvious the
/// next hardware hit/turn is about to get captured.
class _LearnBanner extends StatelessWidget {
  const _LearnBanner();

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final app = AppState.instance;
        if (!app.learnModeArmed) return const SizedBox.shrink();

        final target = app.learnController.target;
        final String message;
        if (target == null) {
          message = 'MIDI LEARN ARMED -- tap a pad or knob to select it';
        } else {
          message = 'LISTENING -- hit the pad or turn the knob on your MPD218 now';
        }

        return Container(
          width: double.infinity,
          color: AppColors.amber,
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          child: Text(
            message,
            textAlign: TextAlign.center,
            style: lcdTextStyle(fontSize: 14, color: AppColors.chassis, fontWeight: FontWeight.bold),
          ),
        );
      },
    );
  }
}

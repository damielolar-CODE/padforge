import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../../services/recordings_repository.dart';
import '../../tape/take_recorder.dart';
import '../theme/app_theme.dart';

/// Lists everything the tape deck's recorder has saved.
///
/// From here you can listen back to a take, delete it, or -- most usefully --
/// hand it to the phone's normal share sheet, which is how you get the audio
/// off the device and into a message, an email, a cloud drive or a DAW.
class RecordingsScreen extends StatefulWidget {
  const RecordingsScreen({super.key});

  @override
  State<RecordingsScreen> createState() => _RecordingsScreenState();
}

class _RecordingsScreenState extends State<RecordingsScreen> {
  List<RecordingFile> _recordings = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final list = await RecordingsRepository.listRecordings();
    if (!mounted) return;
    setState(() {
      _recordings = list;
      _loading = false;
    });
  }

  Future<void> _togglePlay(RecordingFile recording) async {
    final recorder = TakeRecorder.instance;
    if (recorder.playingPath == recording.path) {
      await recorder.stopPlayback();
    } else {
      await recorder.play(recording.path);
    }
  }

  Future<void> _share(RecordingFile recording) async {
    try {
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(recording.path)],
          subject: recording.name,
          text: 'Recorded with PadForge',
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not share that recording: $e')),
      );
    }
  }

  Future<void> _confirmDelete(RecordingFile recording) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppColors.panel,
        title: const Text('Delete recording?'),
        content: Text(
          '"${recording.name}" will be permanently deleted from this device.',
          style: const TextStyle(color: AppColors.lcdText),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Delete', style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await TakeRecorder.instance.delete(recording.path);
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.chassis,
      appBar: AppBar(
        title: const Text('Recordings'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
            onPressed: _refresh,
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: TakeRecorder.instance,
        builder: (context, _) {
          if (_loading) {
            return const Center(
              child: CircularProgressIndicator(color: AppColors.amber),
            );
          }
          if (_recordings.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Text(
                  'No recordings yet.\n\nTap REC on the tape deck to record for as '
                  'long as you like, then come back here to play it, share it or '
                  'delete it.',
                  textAlign: TextAlign.center,
                  style: lcdTextStyle(fontSize: 16, color: AppColors.lcdTextDim),
                ),
              ),
            );
          }

          final playingPath = TakeRecorder.instance.playingPath;
          return ListView.separated(
            padding: const EdgeInsets.symmetric(vertical: 8),
            itemCount: _recordings.length,
            separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.padFace),
            itemBuilder: (context, index) {
              final recording = _recordings[index];
              final isPlaying = playingPath == recording.path;
              return ListTile(
                leading: IconButton(
                  icon: Icon(
                    isPlaying ? Icons.stop_circle : Icons.play_circle,
                    color: AppColors.amber,
                    size: 32,
                  ),
                  tooltip: isPlaying ? 'Stop' : 'Play',
                  onPressed: () => _togglePlay(recording),
                ),
                title: Text(
                  recording.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: lcdTextStyle(fontSize: 16, color: AppColors.lcdText),
                ),
                subtitle: Text(
                  '${recording.prettySize}  ${_formatDate(recording.modified)}',
                  style: lcdTextStyle(fontSize: 13, color: AppColors.lcdTextDim),
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.ios_share, color: AppColors.lcdText),
                      tooltip: 'Share / export',
                      onPressed: () => _share(recording),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: AppColors.danger),
                      tooltip: 'Delete',
                      onPressed: () => _confirmDelete(recording),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }

  static String _formatDate(DateTime when) {
    String two(int value) => value.toString().padLeft(2, '0');
    return '${when.year}-${two(when.month)}-${two(when.day)} '
        '${two(when.hour)}:${two(when.minute)}';
  }
}

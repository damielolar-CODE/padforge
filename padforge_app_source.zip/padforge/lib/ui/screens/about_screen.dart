import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../app_info.dart';
import '../../services/pro_store.dart';
import '../theme/app_theme.dart';
import '../widgets/padforge_logo.dart';

/// The app's business card: the mark, the name, what it is, what version it
/// is, who made it, and the three technical facts worth knowing.
///
/// Reached by tapping the logo in the status bar, and from Settings -> ABOUT.
///
/// ## Why it cannot overflow
///
/// Everything sits in a [SingleChildScrollView], so content that does not fit
/// scrolls rather than producing a RenderFlex overflow -- which is the failure
/// mode this screen is most exposed to, because a user at a 2.0 system text
/// scale can easily make this much text twice as tall as a small phone.
///
/// The [ConstrainedBox] gives the column a *minimum* height of the viewport,
/// which is what lets `MainAxisAlignment.center` centre the card on a tall
/// screen while still allowing it to grow past the viewport (and scroll) on a
/// short one. Centring inside a plain `Column` in a scroll view would not:
/// the column would shrink-wrap and sit at the top.
///
/// The mark is sized from the box it is given (a fraction of both width and
/// height, capped), so it never crowds the text on a small or landscape
/// screen.
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  static const double _padH = 24;
  static const double _padTop = 12;
  static const double _padBottom = 28;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.chassis,
      appBar: AppBar(
        backgroundColor: AppColors.chassis,
        elevation: 0,
        title: Text('About', style: lcdTextStyle(fontSize: 20, color: AppColors.lcdText)),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final logoSize = math.min(
              120.0,
              math.min(constraints.maxWidth * 0.34, constraints.maxHeight * 0.24),
            );
            final minHeight = math.max(
              0.0,
              constraints.maxHeight - _padTop - _padBottom,
            );
            return SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(_padH, _padTop, _padH, _padBottom),
              child: ConstrainedBox(
                constraints: BoxConstraints(minHeight: minHeight),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _TesterLogo(size: math.max(48.0, logoSize)),
                    const SizedBox(height: 18),
                    Text(
                      'PADFORGE',
                      textAlign: TextAlign.center,
                      style: lcdTextStyle(
                        fontSize: 34,
                        color: AppColors.lcdText,
                        letterSpacing: 5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      kAppTagline,
                      textAlign: TextAlign.center,
                      style: lcdTextStyle(fontSize: 15, color: AppColors.lcdTextDim),
                    ),
                    const SizedBox(height: 14),
                    const _VersionChip(),
                    const SizedBox(height: 26),
                    const _Rule(),
                    const SizedBox(height: 16),
                    const _Credit(
                      label: 'AUDIO',
                      body: 'SoLoud polyphonic engine. Every sample stays decoded '
                          'in RAM and a hit starts on finger-down, not finger-up. '
                          'The output buffer size is yours to choose in Settings.',
                    ),
                    const _Credit(
                      label: 'MIDI',
                      body: 'USB and Bluetooth MIDI in and out. Auto-map measures '
                          'what your controller actually sends, so the pad that '
                          'lights is the pad under your finger.',
                    ),
                    const _Credit(
                      label: 'KITS',
                      body: 'Every bundled sample kit is originally synthesised '
                          'for PadForge and royalty-free: no clearance, no sample '
                          'licence, nothing to pay on anything you make with them.',
                    ),
                    const SizedBox(height: 20),
                    const _Rule(),
                    const SizedBox(height: 16),
                    Text(
                      kAppCopyright,
                      textAlign: TextAlign.center,
                      style: lcdTextStyle(
                        fontSize: 14,
                        color: AppColors.lcdTextDim,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// The brand mark, with a hidden **triple-tap tester unlock** (the house
/// convention across every DEESTECH app). Tap the logo three times quickly and
/// a dialog asks for the access code; the correct code turns PadForge Pro on
/// for this device without a purchase. A normal user never discovers it, and a
/// single or double tap does nothing.
class _TesterLogo extends StatefulWidget {
  final double size;

  const _TesterLogo({required this.size});

  @override
  State<_TesterLogo> createState() => _TesterLogoState();
}

class _TesterLogoState extends State<_TesterLogo> {
  int _taps = 0;
  Timer? _resetTimer;

  @override
  void dispose() {
    _resetTimer?.cancel();
    super.dispose();
  }

  void _onTap() {
    _resetTimer?.cancel();
    _taps++;
    if (_taps >= 3) {
      _taps = 0;
      _promptForCode();
      return;
    }
    // Taps must come in quick succession to count as the secret gesture.
    _resetTimer = Timer(const Duration(milliseconds: 700), () => _taps = 0);
  }

  Future<void> _promptForCode() async {
    final controller = TextEditingController();
    final messenger = ScaffoldMessenger.of(context);
    final code = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppColors.panel,
        title: Text('Tester unlock', style: lcdTextStyle(fontSize: 18, color: AppColors.lcdText)),
        content: TextField(
          controller: controller,
          autofocus: true,
          style: lcdTextStyle(fontSize: 15, color: AppColors.lcdText),
          decoration: const InputDecoration(hintText: 'Access code'),
          onSubmitted: (value) => Navigator.of(dialogContext).pop(value),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(controller.text),
            child: const Text('Unlock'),
          ),
        ],
      ),
    );
    if (code == null) return;
    final matched = ProStore.instance.tryTesterCode(code);
    messenger.showSnackBar(
      SnackBar(
        content: Text(matched
            ? 'PadForge Pro unlocked (tester).'
            : 'That code did not match.'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _onTap,
      child: PadForgeLogo(size: widget.size),
    );
  }
}

/// `VERSION 1.0.0` in a hairline amber box -- the one piece of chrome on the
/// screen, because it is the line a support conversation always starts with.
class _VersionChip extends StatelessWidget {
  const _VersionChip();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.amberDeep),
          borderRadius: BorderRadius.circular(4),
        ),
        child: Text(
          'VERSION $kAppVersion',
          style: lcdTextStyle(fontSize: 14, color: AppColors.amber, letterSpacing: 2),
        ),
      ),
    );
  }
}

class _Rule extends StatelessWidget {
  const _Rule();

  @override
  Widget build(BuildContext context) {
    return Container(height: 1, color: const Color(0x33E8973A));
  }
}

/// One line of the credits block: a short amber label in a fixed column, and
/// the prose beside it. The label column is fixed so the three entries line
/// up; the prose is [Expanded] so it wraps instead of overflowing.
class _Credit extends StatelessWidget {
  final String label;
  final String body;

  const _Credit({required this.label, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 62,
            child: Text(
              label,
              style: lcdTextStyle(fontSize: 14, color: AppColors.amber, letterSpacing: 1),
            ),
          ),
          Expanded(
            child: Text(
              body,
              style: lcdTextStyle(fontSize: 14, color: AppColors.lcdTextDim),
            ),
          ),
        ],
      ),
    );
  }
}

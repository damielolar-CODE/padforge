import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_midi_command/flutter_midi_command.dart';
import 'package:path/path.dart' as p;

import '../audio/audio_engine.dart';
import '../midi/controller_map.dart';
import '../midi/midi_events.dart';
import '../midi/midi_learn_controller.dart';
import '../midi/midi_service.dart';
import '../models/kit.dart';
import '../models/pad.dart';
import '../services/kit_repository.dart';
import '../services/pro_store.dart';
import '../services/sample_import_service.dart';
import '../services/settings_service.dart';
import '../tape/take_recorder.dart';
import '../tape/tape_deck.dart';

/// The single source of truth for PadForge's app-wide state.
///
/// This is where MIDI input, the currently-loaded kit, MIDI Learn, and pad
/// hits all come together. UI widgets listen to this with a
/// `ListenableBuilder` (or `AnimatedBuilder`) and call its methods to make
/// things happen (switch banks, hit a pad, start MIDI Learn, etc).
///
/// It's a plain singleton (`AppState.instance`) rather than something wired
/// through `InheritedWidget`/a state-management package, which keeps the
/// wiring simple for an app of this size.
class AppState extends ChangeNotifier {
  AppState._internal() {
    MidiService.instance.addListener(_onMidiServiceChanged);
  }

  static final AppState instance = AppState._internal();

  final MidiLearnController learnController = MidiLearnController();

  /// The global `note -> padId` map for whatever controller is plugged in.
  ///
  /// One map for the whole app, not one per kit -- see [ControllerMap] for why.
  /// Empty by default, in which case every kit's own `note` fields are used, so
  /// a fresh install behaves exactly as it did before this existed.
  final ControllerMap controllerMap = ControllerMap();

  Kit? currentKit;
  List<String> kitNames = [];
  String currentBank = 'A';

  /// True while the global "MIDI Learn" toggle in the bottom toolbar is
  /// armed. While armed, tapping a pad or knob in the UI selects it as the
  /// MIDI Learn target instead of playing/adjusting it.
  bool learnModeArmed = false;

  bool isInitialized = false;

  /// How the 4x4 grid is drawn on screen.
  ///
  /// True (the default) means **bottom-left origin, exactly like the MPD218's
  /// own pads**: A1 is the bottom-left square, A2/A3/A4 run to the right of it,
  /// and A13-A16 are the top row. Getting this wrong is what made the app feel
  /// like it was playing "the wrong sample" -- the sound was right, the square
  /// that lit up was in the mirrored position. False draws plain reading order
  /// (A1 top left) for anyone whose controller is configured differently.
  bool padLayoutBottomLeft = true;

  /// Switches the on-screen grid between MPD218 (bottom-left) order and plain
  /// top-left reading order, and remembers the choice.
  Future<void> setPadLayoutBottomLeft(bool value) async {
    if (padLayoutBottomLeft == value) return;
    padLayoutBottomLeft = value;
    notifyListeners();
    await SettingsService.instance.setPadLayoutBottomLeft(value);
  }

  /// True while a kit's samples are being decoded into memory. The UI shows a
  /// brief "LOADING KIT" readout while this is on -- that preloading is what
  /// makes the pads respond instantly afterwards.
  bool isLoadingKit = false;

  /// Set when the audio engine could not start at all, so the status bar can
  /// say so out loud instead of the app just being mysteriously silent.
  String? get audioEngineError => AudioEngine.instance.failureMessage;

  final StreamController<String> _padHitController = StreamController<String>.broadcast();

  /// Emits a padId every time that pad is triggered (by touch OR by
  /// incoming MIDI). Widgets use this to animate a brief "hit" flash.
  Stream<String> get padHitEvents => _padHitController.stream;

  StreamSubscription<MidiNoteEvent>? _noteSub;
  StreamSubscription<MidiCcEvent>? _ccSub;

  /// Runs once at app startup: loads settings, makes sure at least the
  /// starter kit is installed, loads the last-used (or first available) kit,
  /// starts the MIDI service, and tries to auto-connect to an MPD218 (or
  /// whatever device was last connected).
  Future<void> init() async {
    if (isInitialized) return;
    isInitialized = true;

    await SettingsService.instance.load();
    padLayoutBottomLeft = SettingsService.instance.padLayoutBottomLeft;
    controllerMap.loadJsonString(SettingsService.instance.controllerMapJson);
    TapeDeck.instance.applySavedSettings();

    // PadForge Pro: load the persisted entitlement/tester flag and connect to
    // the billing client. Done before first paint so the feature gates are
    // correct from the very first frame. The recorder is handed a lightweight
    // "am I Pro?" callback it reads on its own timer thread to enforce the free
    // length cap -- the audio hot path is never touched by this.
    await ProStore.instance.init();
    TakeRecorder.instance.isProProvider = () => ProStore.instance.isPro;
    // The audio buffer size can only be chosen while the device is being
    // opened, so the user's "Audio latency" preference has to be applied
    // *before* init() and takes effect on the next launch. See
    // AudioEngine.preferredBufferSize.
    AudioEngine.instance.preferredBufferSize =
        SettingsService.instance.audioBufferFrames ?? AudioEngine.defaultBufferFrames;
    await AudioEngine.instance.init();
    await KitRepository.ensureStarterKitInstalled();
    await refreshKitList();

    // Prefer the last kit the user had open. Failing that, prefer the starter
    // kit by name -- several kits ship with the app, and `kitNames` is sorted
    // alphabetically, so "first" wouldn't be the one we want to open with.
    final lastKit = SettingsService.instance.lastKitName;
    final starterKit = KitRepository.starterKitDisplayName;
    final String? kitToLoad;
    if (lastKit != null && kitNames.contains(lastKit)) {
      kitToLoad = lastKit;
    } else if (kitNames.contains(starterKit)) {
      kitToLoad = starterKit;
    } else {
      kitToLoad = kitNames.isNotEmpty ? kitNames.first : null;
    }
    if (kitToLoad != null) {
      isLoadingKit = true;
      notifyListeners();
      currentKit = await KitRepository.loadKit(kitToLoad);
      await _preloadCurrentKitSamples();
      isLoadingKit = false;
    }

    // The looper re-triggers pads on every pass; it reaches the sampler
    // through this callback so `lib/tape/` never has to know about AppState.
    TapeDeck.instance.onPadTrigger = _triggerPadById;

    await MidiService.instance.init();
    _noteSub = MidiService.instance.noteEvents.listen(_handleIncomingNote);
    _ccSub = MidiService.instance.ccEvents.listen(_handleIncomingCc);

    // Fire-and-forget: don't block first paint on a MIDI scan.
    unawaited(MidiService.instance.autoConnectPreferred(
      preferredNameContains: 'MPD218',
      lastDeviceName: SettingsService.instance.lastDeviceName,
    ));

    notifyListeners();
  }

  void _onMidiServiceChanged() {
    final device = MidiService.instance.connectedDevice;
    if (device != null) {
      unawaited(SettingsService.instance.setLastDeviceName(device.name));
    }
    notifyListeners();
  }

  // --- Kit list / switching -------------------------------------------

  Future<void> refreshKitList() async {
    kitNames = await KitRepository.listKits();
    notifyListeners();
  }

  Future<void> switchKit(String folderName) async {
    isLoadingKit = true;
    notifyListeners();
    currentKit = await KitRepository.loadKit(folderName);
    currentBank = 'A';
    // Decode the new kit into memory (and throw the old one out of memory)
    // before we declare the kit loaded.
    await _preloadCurrentKitSamples();
    await SettingsService.instance.setLastKitName(folderName);
    isLoadingKit = false;
    notifyListeners();
  }

  /// Decodes every sample of the current kit into RAM, replacing whatever kit
  /// was loaded before. Called whenever the kit changes or its samples change.
  Future<void> _preloadCurrentKitSamples() async {
    final kit = currentKit;
    if (kit == null) {
      await AudioEngine.instance.unloadKitSamples();
      return;
    }
    final paths = <String, String>{};
    for (final pad in kit.pads) {
      final relative = pad.samplePath;
      if (relative == null || relative.isEmpty) continue;
      paths[pad.padId] = await KitRepository.absoluteSamplePath(kit, relative);
    }
    await AudioEngine.instance.loadKitSamples(paths);
    // One silent voice, right now, so the player's first real hit doesn't pay
    // any of the one-time cost of the first `play()` call (or of an Android
    // output stream that had wound itself down while the kit was loading).
    AudioEngine.instance.prewarm();
  }

  /// Re-decodes the current kit after its samples changed on disk (an import,
  /// a pad being cleared), showing the brief "loading kit" state while it runs.
  Future<void> _reloadSamplesAfterEdit() async {
    isLoadingKit = true;
    notifyListeners();
    await _preloadCurrentKitSamples();
    isLoadingKit = false;
    notifyListeners();
  }

  Future<void> renameCurrentKit(String newName) async {
    final kit = currentKit;
    if (kit == null) return;
    await KitRepository.renameKit(kit, newName);
    notifyListeners();
  }

  Future<void> duplicateCurrentKit(String newName) async {
    final kit = currentKit;
    if (kit == null) return;
    final newKit = await KitRepository.duplicateKit(kit, newName);
    await refreshKitList();
    await switchKit(newKit.folderName);
  }

  Future<void> createBlankKit(String name) async {
    final kit = await KitRepository.createBlankKit(name);
    await refreshKitList();
    await switchKit(kit.folderName);
  }

  Future<void> deleteKit(String folderName) async {
    final wasCurrent = currentKit?.folderName == folderName;
    await KitRepository.deleteKit(folderName);
    await refreshKitList();
    if (wasCurrent) {
      if (kitNames.isNotEmpty) {
        await switchKit(kitNames.first);
      } else {
        currentKit = null;
        await AudioEngine.instance.unloadKitSamples();
        notifyListeners();
      }
    }
  }

  // --- Banks / pad hits --------------------------------------------------

  void selectBank(String bank) {
    currentBank = bank;
    notifyListeners();
  }

  /// Triggers a pad by id, as if it were hit -- used for on-screen taps.
  /// [velocity] is 1-127, matching MIDI velocity range (defaults to a firm
  /// "full velocity" touch hit).
  ///
  /// Deliberately **not** async: there must be nothing to wait for between the
  /// tap and the sound.
  void hitPad(String padId, {int velocity = 127}) {
    final kit = currentKit;
    if (kit == null) return;
    final pad = kit.padById(padId);
    if (pad == null) return;
    _triggerPad(kit, pad, velocity: velocity);
  }

  /// Plays a pad by id without recording it into a loop. This is what the
  /// looper calls when it re-triggers captured hits, so a loop playing back
  /// doesn't record itself again.
  void _triggerPadById(String padId, int velocity) {
    final kit = currentKit;
    if (kit == null) return;
    final pad = kit.padById(padId);
    if (pad == null) return;
    _triggerPad(kit, pad, velocity: velocity, capture: false);
  }

  /// The hot path. Everything here is synchronous: the sample is already
  /// decoded in memory (see [AudioEngine.loadKitSamples]), so this is just
  /// "start that sound now".
  ///
  /// The order of the three steps matters and is deliberate:
  ///
  ///  1. **make the sound** -- nothing may come before this, not even a stream
  ///     add, because everything before it is latency you can hear;
  ///  2. **timestamp the hit for the looper** -- as close to the sound as
  ///     possible, so a recorded loop matches what was played;
  ///  3. **tell the UI to flash the pad** -- last, because a light arriving a
  ///     millisecond late is invisible while a sound arriving late is not.
  ///
  /// There is no `await` and no `notifyListeners()` anywhere on this path (the
  /// flash goes out on a broadcast stream that only the 16 visible pad widgets
  /// listen to), so a hardware hit never triggers a screen rebuild.
  void _triggerPad(Kit kit, Pad pad, {int velocity = 127, bool capture = true}) {
    if (pad.hasSample) {
      AudioEngine.instance.playPad(
        pad,
        velocityScale: velocity.clamp(1, 127) / 127.0,
        masterVolume: kit.masterVolume,
        playbackRate: kit.playbackRate,
      );
    }
    if (capture) {
      // If the tape deck is arming or recording, this hit becomes part of the
      // loop. Otherwise this is a no-op.
      TapeDeck.instance.capturePadHit(pad.padId, velocity);
    }
    _padHitController.add(pad.padId);
  }

  // --- MIDI input dispatch -----------------------------------------------

  void _handleIncomingNote(MidiNoteEvent event) {
    if (!event.isOn) return;

    // The auto-map wizard owns every incoming note while it is on screen: it
    // must be able to ask "hit pad 1" without the app playing whatever that
    // note currently means.
    if (_padTriggeringSuspended) return;

    final target = learnController.target;
    if (target != null && target.kind == LearnKind.pad) {
      learnController.cancel();
      // MIDI Learn writes to the **global controller map**, not to kit.json --
      // so learning one pad here and auto-mapping the bank later cannot
      // disagree, and the learned note follows the user into every kit.
      unawaited(assignControllerNote(event.note, target.padId!));
      return;
    }
    if (target != null) return; // waiting on a knob learn; ignore notes.

    final kit = currentKit;
    if (kit == null) return;
    // Controller map first, kit's own note assignment as the fallback.
    final kitPad = kit.padByNote(event.note);
    final padId = controllerMap.resolve(event.note, kitPadId: kitPad?.padId);
    if (padId == null) return;
    final pad = (kitPad != null && kitPad.padId == padId) ? kitPad : kit.padById(padId);
    if (pad != null) {
      _triggerPad(kit, pad, velocity: event.velocity);
    }
  }

  void _handleIncomingCc(MidiCcEvent event) {
    final target = learnController.target;
    if (target != null && target.kind == LearnKind.knob) {
      learnController.cancel();
      unawaited(_applyKnobCcLearn(target.knobIndex!, event.cc));
      return;
    }
    if (target != null) return; // waiting on a pad learn; ignore CCs.

    final kit = currentKit;
    if (kit == null) return;
    final knob = kit.knobByCc(event.cc);
    if (knob != null) {
      setKnobValue(knob.index, event.value / 127.0, persist: false);
    }
  }

  Future<void> _applyKnobCcLearn(int knobIndex, int cc) async {
    final kit = currentKit;
    if (kit == null) return;
    final knob = kit.knobByIndex(knobIndex);
    if (knob == null) return;
    knob.cc = cc;
    notifyListeners();
    await KitRepository.saveKit(kit);
  }

  // --- The global controller map -----------------------------------------

  /// Set while the auto-map wizard is on screen. Incoming notes are then the
  /// wizard's business alone -- no pad plays, nothing is captured into a loop.
  bool _padTriggeringSuspended = false;

  /// Deliberately does **not** notify listeners: it is called from a screen's
  /// `initState`/`dispose`, where notifying would rebuild during a build, and
  /// nothing in the UI needs to redraw because of it.
  void setPadTriggeringSuspended(bool value) {
    _padTriggeringSuspended = value;
  }

  Future<void> _persistControllerMap() async {
    await SettingsService.instance.setControllerMapJson(controllerMap.toJsonString());
  }

  /// Points [note] at [padId] in the global map and remembers it. Used by MIDI
  /// Learn and by the pad editor's manual note entry.
  Future<void> assignControllerNote(int note, String padId) async {
    controllerMap.assign(note, padId);
    notifyListeners();
    await _persistControllerMap();
  }

  /// Drops one pad's override, so it answers to its kit's own note again.
  Future<void> clearControllerNoteForPad(String padId) async {
    if (!controllerMap.hasPad(padId)) return;
    controllerMap.clearPad(padId);
    notifyListeners();
    await _persistControllerMap();
  }

  /// Commits a whole run of the auto-map wizard in one go. A null note means
  /// the user skipped that pad, which clears any override it had -- so what is
  /// saved is exactly the table the summary screen showed them.
  Future<void> applyAutoMap(Map<String, int?> notesByPadId) async {
    notesByPadId.forEach((padId, note) {
      if (note == null) {
        controllerMap.clearPad(padId);
      } else {
        controllerMap.assign(note, padId);
      }
    });
    notifyListeners();
    await _persistControllerMap();
  }

  /// Forgets the controller map entirely: every pad goes back to the note in
  /// its kit.
  Future<void> clearControllerMap() async {
    controllerMap.clear();
    notifyListeners();
    await SettingsService.instance.clearControllerMapJson();
  }

  /// The note that will actually trigger [padId] right now -- the controller
  /// map's if it has one, the kit's otherwise. Null only if the pad does not
  /// exist in the current kit.
  ///
  /// This is what the pad editor and Settings print, so a mismatch between the
  /// app and the hardware can be seen rather than guessed at by ear.
  int? activeNoteForPad(String padId) {
    final mapped = controllerMap.noteForPad(padId);
    if (mapped != null) return mapped;
    return currentKit?.padById(padId)?.note;
  }

  /// True when [padId]'s note comes from the controller map rather than the
  /// kit file.
  bool isPadRemapped(String padId) => controllerMap.hasPad(padId);

  // --- MIDI Learn ----------------------------------------------------

  void toggleLearnMode() {
    learnModeArmed = !learnModeArmed;
    if (!learnModeArmed) {
      learnController.cancel();
    }
    notifyListeners();
  }

  void startPadLearn(String padId) {
    learnController.startLearnPad(padId);
    notifyListeners();
  }

  void startKnobLearn(int knobIndex) {
    learnController.startLearnKnob(knobIndex);
    notifyListeners();
  }

  void cancelLearn() {
    learnController.cancel();
    notifyListeners();
  }

  bool isLearningPad(String padId) {
    final target = learnController.target;
    return target != null && target.kind == LearnKind.pad && target.padId == padId;
  }

  bool isLearningKnob(int knobIndex) {
    final target = learnController.target;
    return target != null && target.kind == LearnKind.knob && target.knobIndex == knobIndex;
  }

  // --- Knobs -------------------------------------------------------------

  /// Updates a knob's live value (0.0-1.0). Pass [persist] = true once the
  /// user finishes a drag gesture, so we're not rewriting kit.json on every
  /// pixel of movement.
  void setKnobValue(int index, double value, {bool persist = false}) {
    final kit = currentKit;
    if (kit == null) return;
    final knob = kit.knobByIndex(index);
    if (knob == null) return;
    knob.value = value.clamp(0.0, 1.0).toDouble();
    notifyListeners();
    if (persist) {
      unawaited(KitRepository.saveKit(kit));
    }
  }

  // --- Pad editing ---------------------------------------------------

  Future<void> updatePad(
    String padId, {
    int? note,
    double? volume,
    int? chokeGroup,
    bool clearChoke = false,
    bool clearSample = false,
  }) async {
    final kit = currentKit;
    if (kit == null) return;
    final index = kit.pads.indexWhere((pad) => pad.padId == padId);
    if (index == -1) return;
    final old = kit.pads[index];
    kit.pads[index] = old.copyWith(
      note: note,
      volume: volume,
      chokeGroup: chokeGroup,
      clearChoke: clearChoke,
      clearSample: clearSample,
    );
    notifyListeners();
    await KitRepository.saveKit(kit);
    if (clearSample) {
      // The pad no longer points at a sample, so drop it from memory too.
      await _reloadSamplesAfterEdit();
    }
  }

  // --- Sample import ---------------------------------------------------

  String _uniqueSampleFileName(String dir, String desiredName) {
    var name = desiredName;
    final stem = p.basenameWithoutExtension(desiredName);
    final ext = p.extension(desiredName);
    var counter = 2;
    while (File(p.join(dir, name)).existsSync()) {
      name = '$stem ($counter)$ext';
      counter++;
    }
    return name;
  }

  /// Lets the user pick one or more WAV files and assigns them, in order, to
  /// the current kit's empty pads (skipping pads that already have a
  /// sample). Returns the list of pad ids that got a new sample.
  Future<List<String>> importSamplesAutoAssign() async {
    final kit = currentKit;
    if (kit == null) return [];
    final files = await SampleImportService.pickWavFiles();
    if (files.isEmpty) return [];

    final samplesDir = await KitRepository.samplesDirPath(kit.folderName);
    final assigned = <String>[];
    var fileIndex = 0;

    for (final pad in kit.pads) {
      if (fileIndex >= files.length) break;
      if (pad.hasSample) continue;
      final file = files[fileIndex];
      fileIndex++;
      final path = file.path;
      if (path == null) continue;
      final destName = _uniqueSampleFileName(samplesDir, file.name);
      await File(path).copy(p.join(samplesDir, destName));
      pad.samplePath = 'samples/$destName';
      assigned.add(pad.padId);
    }

    await KitRepository.saveKit(kit);
    await _reloadSamplesAfterEdit();
    return assigned;
  }

  /// Assigns a single, already-picked WAV file to a specific pad (used by
  /// the pad editor's "Change Sample" button).
  Future<bool> assignSampleToPad(String padId, PlatformFile file) async {
    final kit = currentKit;
    final path = file.path;
    if (kit == null || path == null) return false;
    final pad = kit.padById(padId);
    if (pad == null) return false;

    final samplesDir = await KitRepository.samplesDirPath(kit.folderName);
    final destName = _uniqueSampleFileName(samplesDir, file.name);
    await File(path).copy(p.join(samplesDir, destName));
    pad.samplePath = 'samples/$destName';

    await KitRepository.saveKit(kit);
    await _reloadSamplesAfterEdit();
    return true;
  }

  /// Creates a brand new kit from a batch of picked WAV files, assigning
  /// them in order to Bank A, B, then C pads.
  Future<String?> createKitFromPickedFiles(String kitDisplayName) async {
    final files = await SampleImportService.pickWavFiles();
    if (files.isEmpty) return null;

    final folderName = await KitRepository.uniqueFolderName(kitDisplayName);
    final kit = Kit.blank(name: kitDisplayName, folderName: folderName);
    final samplesDir = await KitRepository.samplesDirPath(folderName);

    var index = 0;
    for (final pad in kit.pads) {
      if (index >= files.length) break;
      final file = files[index];
      index++;
      final path = file.path;
      if (path == null) continue;
      final destName = _uniqueSampleFileName(samplesDir, file.name);
      await File(path).copy(p.join(samplesDir, destName));
      pad.samplePath = 'samples/$destName';
    }

    await KitRepository.saveKit(kit);
    await refreshKitList();
    await switchKit(folderName);
    return folderName;
  }

  // --- MIDI device management --------------------------------------------

  Future<void> refreshMidiDevices() => MidiService.instance.refreshDevices();

  Future<void> connectToMidiDevice(MidiDevice device) => MidiService.instance.connect(device);

  void disconnectMidi() => MidiService.instance.disconnect();

  /// Sends a short test Note On/Off pulse out over MIDI OUT, to prove the
  /// outgoing connection works (e.g. to trigger another piece of gear).
  void sendTestNote() {
    MidiService.instance.sendNoteOn(60, 127);
    Future.delayed(const Duration(milliseconds: 200), () {
      MidiService.instance.sendNoteOff(60);
    });
  }

  @override
  void dispose() {
    _noteSub?.cancel();
    _ccSub?.cancel();
    _padHitController.close();
    MidiService.instance.removeListener(_onMidiServiceChanged);
    super.dispose();
  }
}

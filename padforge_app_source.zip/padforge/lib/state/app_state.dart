import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_midi_command/flutter_midi_command.dart';
import 'package:path/path.dart' as p;

import '../audio/audio_engine.dart';
import '../midi/midi_events.dart';
import '../midi/midi_learn_controller.dart';
import '../midi/midi_service.dart';
import '../models/kit.dart';
import '../models/pad.dart';
import '../services/kit_repository.dart';
import '../services/sample_import_service.dart';
import '../services/settings_service.dart';

/// The single source of truth for PadForge's app-wide state.
///
/// This is where MIDI input, the currently-loaded kit, MIDI Learn, and pad
/// hits all come together. UI widgets listen to this with a
/// `ListenableBuilder` (or `AnimatedBuilder`) and call its methods to make
/// things happen (switch banks, hit a pad, start MIDI Learn, etc).
///
/// It's a plain singleton (`AppState.instance`) rather than something wired
/// through `InheritedWidget`/a state-management package, which keeps the
/// wiring simple for an app of this size.
class AppState extends ChangeNotifier {
  AppState._internal() {
    MidiService.instance.addListener(_onMidiServiceChanged);
  }

  static final AppState instance = AppState._internal();

  final MidiLearnController learnController = MidiLearnController();

  Kit? currentKit;
  List<String> kitNames = [];
  String currentBank = 'A';

  /// True while the global "MIDI Learn" toggle in the bottom toolbar is
  /// armed. While armed, tapping a pad or knob in the UI selects it as the
  /// MIDI Learn target instead of playing/adjusting it.
  bool learnModeArmed = false;

  bool isInitialized = false;
  bool isLoadingKit = false;

  final StreamController<String> _padHitController = StreamController<String>.broadcast();

  /// Emits a padId every time that pad is triggered (by touch OR by
  /// incoming MIDI). Widgets use this to animate a brief "hit" flash.
  Stream<String> get padHitEvents => _padHitController.stream;

  StreamSubscription<MidiNoteEvent>? _noteSub;
  StreamSubscription<MidiCcEvent>? _ccSub;

  /// Runs once at app startup: loads settings, makes sure at least the
  /// starter kit is installed, loads the last-used (or first available) kit,
  /// starts the MIDI service, and tries to auto-connect to an MPD218 (or
  /// whatever device was last connected).
  Future<void> init() async {
    if (isInitialized) return;
    isInitialized = true;

    await SettingsService.instance.load();
    await AudioEngine.instance.init();
    await KitRepository.ensureStarterKitInstalled();
    await refreshKitList();

    final lastKit = SettingsService.instance.lastKitName;
    final kitToLoad = (lastKit != null && kitNames.contains(lastKit))
        ? lastKit
        : (kitNames.isNotEmpty ? kitNames.first : null);
    if (kitToLoad != null) {
      currentKit = await KitRepository.loadKit(kitToLoad);
    }

    await MidiService.instance.init();
    _noteSub = MidiService.instance.noteEvents.listen(_handleIncomingNote);
    _ccSub = MidiService.instance.ccEvents.listen(_handleIncomingCc);

    // Fire-and-forget: don't block first paint on a MIDI scan.
    unawaited(MidiService.instance.autoConnectPreferred(
      preferredNameContains: 'MPD218',
      lastDeviceName: SettingsService.instance.lastDeviceName,
    ));

    notifyListeners();
  }

  void _onMidiServiceChanged() {
    final device = MidiService.instance.connectedDevice;
    if (device != null) {
      unawaited(SettingsService.instance.setLastDeviceName(device.name));
    }
    notifyListeners();
  }

  // --- Kit list / switching -------------------------------------------

  Future<void> refreshKitList() async {
    kitNames = await KitRepository.listKits();
    notifyListeners();
  }

  Future<void> switchKit(String folderName) async {
    isLoadingKit = true;
    notifyListeners();
    currentKit = await KitRepository.loadKit(folderName);
    currentBank = 'A';
    await SettingsService.instance.setLastKitName(folderName);
    isLoadingKit = false;
    notifyListeners();
  }

  Future<void> renameCurrentKit(String newName) async {
    final kit = currentKit;
    if (kit == null) return;
    await KitRepository.renameKit(kit, newName);
    notifyListeners();
  }

  Future<void> duplicateCurrentKit(String newName) async {
    final kit = currentKit;
    if (kit == null) return;
    final newKit = await KitRepository.duplicateKit(kit, newName);
    await refreshKitList();
    await switchKit(newKit.folderName);
  }

  Future<void> createBlankKit(String name) async {
    final kit = await KitRepository.createBlankKit(name);
    await refreshKitList();
    await switchKit(kit.folderName);
  }

  Future<void> deleteKit(String folderName) async {
    final wasCurrent = currentKit?.folderName == folderName;
    await KitRepository.deleteKit(folderName);
    await refreshKitList();
    if (wasCurrent) {
      if (kitNames.isNotEmpty) {
        await switchKit(kitNames.first);
      } else {
        currentKit = null;
        notifyListeners();
      }
    }
  }

  // --- Banks / pad hits --------------------------------------------------

  void selectBank(String bank) {
    currentBank = bank;
    notifyListeners();
  }

  /// Triggers a pad by id, as if it were hit -- used for on-screen taps.
  /// [velocity] is 1-127, matching MIDI velocity range (defaults to a firm
  /// "full velocity" touch hit).
  Future<void> hitPad(String padId, {int velocity = 127}) async {
    final kit = currentKit;
    if (kit == null) return;
    final pad = kit.padById(padId);
    if (pad == null) return;
    await _triggerPad(kit, pad, velocity: velocity);
  }

  Future<void> _triggerPad(Kit kit, Pad pad, {int velocity = 127}) async {
    _padHitController.add(pad.padId);
    if (!pad.hasSample) return;
    final path = await KitRepository.absoluteSamplePath(kit, pad.samplePath!);
    await AudioEngine.instance.playPad(
      pad,
      path,
      velocityScale: velocity.clamp(1, 127) / 127.0,
      masterVolume: kit.masterVolume,
      playbackRate: kit.playbackRate,
    );
  }

  // --- MIDI input dispatch -----------------------------------------------

  void _handleIncomingNote(MidiNoteEvent event) {
    if (!event.isOn) return;

    final target = learnController.target;
    if (target != null && target.kind == LearnKind.pad) {
      learnController.cancel();
      unawaited(_applyPadNoteLearn(target.padId!, event.note));
      return;
    }
    if (target != null) return; // waiting on a knob learn; ignore notes.

    final kit = currentKit;
    if (kit == null) return;
    final pad = kit.padByNote(event.note);
    if (pad != null) {
      unawaited(_triggerPad(kit, pad, velocity: event.velocity));
    }
  }

  void _handleIncomingCc(MidiCcEvent event) {
    final target = learnController.target;
    if (target != null && target.kind == LearnKind.knob) {
      learnController.cancel();
      unawaited(_applyKnobCcLearn(target.knobIndex!, event.cc));
      return;
    }
    if (target != null) return; // waiting on a pad learn; ignore CCs.

    final kit = currentKit;
    if (kit == null) return;
    final knob = kit.knobByCc(event.cc);
    if (knob != null) {
      setKnobValue(knob.index, event.value / 127.0, persist: false);
    }
  }

  Future<void> _applyPadNoteLearn(String padId, int note) async {
    final kit = currentKit;
    if (kit == null) return;
    final pad = kit.padById(padId);
    if (pad == null) return;
    pad.note = note;
    notifyListeners();
    await KitRepository.saveKit(kit);
  }

  Future<void> _applyKnobCcLearn(int knobIndex, int cc) async {
    final kit = currentKit;
    if (kit == null) return;
    final knob = kit.knobByIndex(knobIndex);
    if (knob == null) return;
    knob.cc = cc;
    notifyListeners();
    await KitRepository.saveKit(kit);
  }

  // --- MIDI Learn ----------------------------------------------------

  void toggleLearnMode() {
    learnModeArmed = !learnModeArmed;
    if (!learnModeArmed) {
      learnController.cancel();
    }
    notifyListeners();
  }

  void startPadLearn(String padId) {
    learnController.startLearnPad(padId);
    notifyListeners();
  }

  void startKnobLearn(int knobIndex) {
    learnController.startLearnKnob(knobIndex);
    notifyListeners();
  }

  void cancelLearn() {
    learnController.cancel();
    notifyListeners();
  }

  bool isLearningPad(String padId) {
    final target = learnController.target;
    return target != null && target.kind == LearnKind.pad && target.padId == padId;
  }

  bool isLearningKnob(int knobIndex) {
    final target = learnController.target;
    return target != null && target.kind == LearnKind.knob && target.knobIndex == knobIndex;
  }

  // --- Knobs -------------------------------------------------------------

  /// Updates a knob's live value (0.0-1.0). Pass [persist] = true once the
  /// user finishes a drag gesture, so we're not rewriting kit.json on every
  /// pixel of movement.
  void setKnobValue(int index, double value, {bool persist = false}) {
    final kit = currentKit;
    if (kit == null) return;
    final knob = kit.knobByIndex(index);
    if (knob == null) return;
    knob.value = value.clamp(0.0, 1.0).toDouble();
    notifyListeners();
    if (persist) {
      unawaited(KitRepository.saveKit(kit));
    }
  }

  // --- Pad editing ---------------------------------------------------

  Future<void> updatePad(
    String padId, {
    int? note,
    double? volume,
    int? chokeGroup,
    bool clearChoke = false,
    bool clearSample = false,
  }) async {
    final kit = currentKit;
    if (kit == null) return;
    final index = kit.pads.indexWhere((pad) => pad.padId == padId);
    if (index == -1) return;
    final old = kit.pads[index];
    kit.pads[index] = old.copyWith(
      note: note,
      volume: volume,
      chokeGroup: chokeGroup,
      clearChoke: clearChoke,
      clearSample: clearSample,
    );
    notifyListeners();
    await KitRepository.saveKit(kit);
  }

  // --- Sample import ---------------------------------------------------

  String _uniqueSampleFileName(String dir, String desiredName) {
    var name = desiredName;
    final stem = p.basenameWithoutExtension(desiredName);
    final ext = p.extension(desiredName);
    var counter = 2;
    while (File(p.join(dir, name)).existsSync()) {
      name = '$stem ($counter)$ext';
      counter++;
    }
    return name;
  }

  /// Lets the user pick one or more WAV files and assigns them, in order, to
  /// the current kit's empty pads (skipping pads that already have a
  /// sample). Returns the list of pad ids that got a new sample.
  Future<List<String>> importSamplesAutoAssign() async {
    final kit = currentKit;
    if (kit == null) return [];
    final files = await SampleImportService.pickWavFiles();
    if (files.isEmpty) return [];

    final samplesDir = await KitRepository.samplesDirPath(kit.folderName);
    final assigned = <String>[];
    var fileIndex = 0;

    for (final pad in kit.pads) {
      if (fileIndex >= files.length) break;
      if (pad.hasSample) continue;
      final file = files[fileIndex];
      fileIndex++;
      final path = file.path;
      if (path == null) continue;
      final destName = _uniqueSampleFileName(samplesDir, file.name);
      await File(path).copy(p.join(samplesDir, destName));
      pad.samplePath = 'samples/$destName';
      assigned.add(pad.padId);
    }

    await KitRepository.saveKit(kit);
    notifyListeners();
    return assigned;
  }

  /// Assigns a single, already-picked WAV file to a specific pad (used by
  /// the pad editor's "Change Sample" button).
  Future<bool> assignSampleToPad(String padId, PlatformFile file) async {
    final kit = currentKit;
    final path = file.path;
    if (kit == null || path == null) return false;
    final pad = kit.padById(padId);
    if (pad == null) return false;

    final samplesDir = await KitRepository.samplesDirPath(kit.folderName);
    final destName = _uniqueSampleFileName(samplesDir, file.name);
    await File(path).copy(p.join(samplesDir, destName));
    pad.samplePath = 'samples/$destName';

    await KitRepository.saveKit(kit);
    notifyListeners();
    return true;
  }

  /// Creates a brand new kit from a batch of picked WAV files, assigning
  /// them in order to Bank A, B, then C pads.
  Future<String?> createKitFromPickedFiles(String kitDisplayName) async {
    final files = await SampleImportService.pickWavFiles();
    if (files.isEmpty) return null;

    final folderName = await KitRepository.uniqueFolderName(kitDisplayName);
    final kit = Kit.blank(name: kitDisplayName, folderName: folderName);
    final samplesDir = await KitRepository.samplesDirPath(folderName);

    var index = 0;
    for (final pad in kit.pads) {
      if (index >= files.length) break;
      final file = files[index];
      index++;
      final path = file.path;
      if (path == null) continue;
      final destName = _uniqueSampleFileName(samplesDir, file.name);
      await File(path).copy(p.join(samplesDir, destName));
      pad.samplePath = 'samples/$destName';
    }

    await KitRepository.saveKit(kit);
    await refreshKitList();
    await switchKit(folderName);
    return folderName;
  }

  // --- MIDI device management --------------------------------------------

  Future<void> refreshMidiDevices() => MidiService.instance.refreshDevices();

  Future<void> connectToMidiDevice(MidiDevice device) => MidiService.instance.connect(device);

  void disconnectMidi() => MidiService.instance.disconnect();

  /// Sends a short test Note On/Off pulse out over MIDI OUT, to prove the
  /// outgoing connection works (e.g. to trigger another piece of gear).
  void sendTestNote() {
    MidiService.instance.sendNoteOn(60, 127);
    Future.delayed(const Duration(milliseconds: 200), () {
      MidiService.instance.sendNoteOff(60);
    });
  }

  @override
  void dispose() {
    _noteSub?.cancel();
    _ccSub?.cancel();
    _padHitController.close();
    MidiService.instance.removeListener(_onMidiServiceChanged);
    super.dispose();
  }
}

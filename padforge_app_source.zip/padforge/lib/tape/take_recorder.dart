import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:record/record.dart';

import '../audio/audio_engine.dart';
import '../services/recordings_repository.dart';
import 'mic_arbiter.dart';
import 'record_source.dart';
import 'wav_tools.dart';

/// The tape deck's "unlimited" recorder.
///
/// Press record, it records until you press it again, and the take is saved
/// into `Recordings/` with a timestamped name. No length limit, no tempo --
/// that's the looper's job (see `tape_deck.dart`).
///
/// ## What it records
///
/// Like the looper, it takes a [RecordSource]:
///
///  * [RecordSource.pads] -- taps the **audio engine's own master output**, so
///    you get a clean digital render of the pad performance with no microphone
///    involved. This is what you want if you're going to share the take.
///  * [RecordSource.mic] -- the microphone, as before.
///  * [RecordSource.both] -- both, captured separately and then summed into one
///    file (sample by sample, clipped rather than wrapped). Unlike the looper
///    there's no live-feedback concern here, so one file is the friendlier
///    result. If the take is too big to fold together in memory, both files are
///    kept side by side and [notice] says so.
///
/// Engine capture is a newer, experimental corner of `flutter_soloud`, so every
/// path through it has a fallback: if it can't start, we record the microphone
/// instead and set [notice] rather than silently saving nothing.
///
/// It also knows how to play a saved recording back and stop it again, which
/// the Recordings screen uses.
class TakeRecorder extends ChangeNotifier {
  TakeRecorder._internal();

  static final TakeRecorder instance = TakeRecorder._internal();

  /// Sample rate / channel count used for engine capture. The engine itself
  /// runs at 44100 stereo (see [AudioEngine.init]), so asking for the same
  /// thing means no conversion happens on the native side.
  static const int captureSampleRate = 44100;
  static const int captureChannels = 2;

  /// How long a FREE (non-Pro) take may run before it auto-stops, in seconds.
  /// PadForge Pro lifts this entirely (playback is then capped only by the
  /// engine/storage). Mirrors the iOS build's `AudioLooper.freeRecordSeconds`.
  ///
  /// The cap is enforced on the UI-side elapsed timer below -- **never** inside
  /// the mic/engine capture callbacks -- so the audio hot path is untouched.
  static const int freeRecordSeconds = 10;

  /// Reads whether PadForge Pro is active. Wired by `AppState.init` to
  /// `() => ProStore.instance.isPro`. Null (or false) means the free length cap
  /// applies. Read on the recorder's own tick timer, not on any audio thread.
  bool Function()? isProProvider;

  bool get _isPro => isProProvider?.call() ?? false;

  /// Above this combined size, a BOTH take is left as two files instead of
  /// being summed. Folding them together needs both in memory at once *and*
  /// runs a per-sample loop on the UI isolate, so the cap keeps that work down
  /// to a fraction of a second. 60MB of 44.1kHz WAV is roughly 3.5 minutes of
  /// a stereo render plus a mono mic take.
  static const int maxMixBytes = 60 * 1024 * 1024;

  final AudioRecorder _recorder = AudioRecorder();

  bool _isRecording = false;
  RecordSource _source = RecordSource.pads;
  Duration _elapsed = Duration.zero;
  Timer? _tick;
  Stopwatch? _stopwatch;
  String? _errorMessage;
  String? _notice;
  bool _disposed = false;

  // Microphone leg.
  bool _usingMic = false;
  String? _micPath;

  // Engine (master output) leg.
  bool _usingEngine = false;
  StreamSubscription<List<int>>? _engineSub;
  IOSink? _engineSink;
  String? _enginePcmPath;
  String? _engineWavPath;
  int _engineBytes = 0;

  /// Clip id (from [AudioEngine]) of whatever recording is playing back.
  int? _playbackClipId;
  String? _playingPath;
  Timer? _playbackWatch;

  final StreamController<String> _messages = StreamController<String>.broadcast();

  /// Short notices for the UI to flash up -- currently the "hit the free
  /// length limit, saved what you had" message when a take auto-stops. The
  /// manual REC-button stop still shows its own snackbar from the UI, so this
  /// stream only carries things the UI would not otherwise know about.
  Stream<String> get messages => _messages.stream;

  bool get isRecording => _isRecording;

  /// What the take in progress (or the last one) was asked to record.
  RecordSource get source => _source;

  /// True while the pad/engine output is being captured.
  bool get isCapturingEngine => _usingEngine;

  /// True while the microphone is being captured.
  bool get isCapturingMic => _usingMic;

  /// How long the current take has been running.
  Duration get elapsed => _elapsed;

  /// mm:ss readout of [elapsed], for the UI.
  String get elapsedLabel => formatDuration(_elapsed);

  /// Last thing that went wrong (missing mic permission, etc), or null.
  String? get errorMessage => _errorMessage;

  /// Set when the recorder did something other than exactly what was asked --
  /// e.g. engine capture wasn't available so it used the microphone. The UI
  /// shows this so the user is never misled about what got recorded.
  String? get notice => _notice;

  /// Path of the recording currently playing back, or null.
  String? get playingPath => _playingPath;

  /// Formats a duration as mm:ss (or h:mm:ss past an hour).
  static String formatDuration(Duration d) {
    final totalSeconds = d.inSeconds;
    final minutes = totalSeconds ~/ 60;
    final seconds = totalSeconds % 60;
    final two = seconds.toString().padLeft(2, '0');
    if (minutes < 60) return '$minutes:$two';
    final hours = minutes ~/ 60;
    final mins = (minutes % 60).toString().padLeft(2, '0');
    return '$hours:$mins:$two';
  }

  void _notify() {
    if (_disposed) return;
    notifyListeners();
  }

  // --- Recording --------------------------------------------------------

  /// Starts a new unlimited take recording [source]. Returns false (and sets
  /// [errorMessage]) if nothing could be captured at all.
  Future<bool> start({RecordSource source = RecordSource.pads}) async {
    if (_isRecording) return true;

    _errorMessage = null;
    _notice = null;
    _source = source;
    _usingMic = false;
    _usingEngine = false;

    // PADS and BOTH both want the engine's own output.
    if (source != RecordSource.mic) {
      _usingEngine = await _startEngineCapture(
        prefix: source == RecordSource.both ? 'pads' : 'take',
      );
    }

    // MIC and BOTH want the microphone -- and so does PADS, if engine capture
    // turned out not to work, because recording *something* and saying so is
    // better than recording nothing.
    final wantsMic = source != RecordSource.pads || !_usingEngine;
    if (wantsMic) {
      _usingMic = await _startMicCapture(
        prefix: source == RecordSource.both ? 'mic' : 'take',
      );
    }

    if (!_usingMic && !_usingEngine) {
      _errorMessage ??= 'Could not start recording.';
      _notify();
      return false;
    }

    if (source == RecordSource.pads && !_usingEngine) {
      _notice = 'Pad capture is not available on this device - recorded the '
          'microphone instead.';
    } else if (source == RecordSource.both && !_usingEngine) {
      _notice = 'Pad capture is not available - recorded the microphone only.';
    } else if (source == RecordSource.both && !_usingMic) {
      _notice = 'Microphone is not available - recorded the pads only.';
    }

    _isRecording = true;
    _elapsed = Duration.zero;
    _stopwatch = Stopwatch()..start();
    _tick?.cancel();
    _tick = Timer.periodic(const Duration(milliseconds: 200), (_) {
      _elapsed = _stopwatch?.elapsed ?? Duration.zero;
      // Free takes auto-stop at the cap. This is a plain length check on the UI
      // timer -- the capture callbacks never see it -- so the recording path
      // stays exactly as fast as it is for a Pro user.
      if (!_isPro && _elapsed.inMilliseconds >= freeRecordSeconds * 1000) {
        _tick?.cancel();
        _tick = null;
        unawaited(_stopAtFreeLimit());
        return;
      }
      _notify();
    });
    _notify();
    return true;
  }

  /// Auto-stops a free take that has reached [freeRecordSeconds], keeps whatever
  /// was captured, and tells the UI why it stopped.
  Future<void> _stopAtFreeLimit() async {
    final path = await stop();
    final name = path == null ? 'take' : path.split('/').last;
    _emit('Saved $name - FREE LIMIT ${freeRecordSeconds}s, unlock PRO for more');
  }

  void _emit(String message) {
    if (_disposed || _messages.isClosed) return;
    _messages.add(message);
  }

  /// Opens the microphone. Returns false if it is busy or permission was
  /// refused; in [RecordSource.pads] this is never reached, so the permission
  /// prompt only ever appears for a mode that actually needs the mic.
  Future<bool> _startMicCapture({required String prefix}) async {
    if (!MicArbiter.acquire(MicArbiter.takeRecorder)) {
      _errorMessage = 'The looper is using the microphone right now.';
      return false;
    }
    try {
      final allowed = await _recorder.hasPermission();
      if (!allowed) {
        MicArbiter.release(MicArbiter.takeRecorder);
        _errorMessage = 'Microphone permission was denied.';
        return false;
      }

      final path = await RecordingsRepository.newTakePath(prefix: prefix);
      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.wav,
          sampleRate: captureSampleRate,
          numChannels: 1,
        ),
        path: path,
      );
      _micPath = path;
      return true;
    } catch (e) {
      MicArbiter.release(MicArbiter.takeRecorder);
      _errorMessage = 'Could not start the microphone: $e';
      debugPrint('TakeRecorder: mic start failed: $e');
      return false;
    }
  }

  /// Starts tapping the audio engine's master output.
  ///
  /// The chunks arrive as raw PCM, so they are appended to a scratch `.pcm`
  /// file and given a WAV header afterwards (see [_finishEngineCapture]).
  /// Streaming into a headerless file and prepending the header at the end
  /// avoids ever holding a long take in memory, and avoids rewriting bytes in
  /// the middle of a file we're still appending to.
  Future<bool> _startEngineCapture({required String prefix}) async {
    try {
      final stamp = DateTime.now().millisecondsSinceEpoch;
      final pcmPath = await RecordingsRepository.scratchPath('capture_$stamp.pcm');
      final wavPath = await RecordingsRepository.newTakePath(prefix: prefix);

      final stream = AudioEngine.instance.startMasterCapture(
        sampleRate: captureSampleRate,
        channels: captureChannels,
      );
      if (stream == null) return false;

      final sink = File(pcmPath).openWrite();
      _engineBytes = 0;
      _enginePcmPath = pcmPath;
      _engineWavPath = wavPath;
      _engineSink = sink;
      _engineSub = stream.listen(
        (chunk) {
          final target = _engineSink;
          if (target == null) return;
          _engineBytes += chunk.length;
          target.add(chunk);
        },
        onError: (Object e) {
          debugPrint('TakeRecorder: engine capture stream error: $e');
        },
        cancelOnError: false,
      );
      return true;
    } catch (e) {
      debugPrint('TakeRecorder: engine capture start failed: $e');
      AudioEngine.instance.stopMasterCapture();
      _engineSink = null;
      _enginePcmPath = null;
      _engineWavPath = null;
      return false;
    }
  }

  /// Stops the current take and returns the saved file's path (or null).
  Future<String?> stop() async {
    if (!_isRecording) return null;
    _tick?.cancel();
    _tick = null;
    _stopwatch?.stop();
    _stopwatch = null;
    _isRecording = false;

    final micPath = _usingMic ? await _finishMicCapture() : null;
    final enginePath = _usingEngine ? await _finishEngineCapture() : null;
    _usingMic = false;
    _usingEngine = false;

    String? result;
    if (micPath != null && enginePath != null) {
      result = await _mixDown(padsPath: enginePath, micPath: micPath);
      if (result == null) {
        _notice = 'Saved two files: the pads and the microphone, side by side.';
        result = enginePath;
      }
    } else {
      result = enginePath ?? micPath;
    }

    _elapsed = Duration.zero;
    _notify();
    return result;
  }

  Future<String?> _finishMicCapture() async {
    String? path;
    try {
      path = await _recorder.stop();
    } catch (e) {
      debugPrint('TakeRecorder: mic stop failed: $e');
      _errorMessage = 'Recording stopped with an error: $e';
    } finally {
      MicArbiter.release(MicArbiter.takeRecorder);
    }
    path ??= _micPath;
    _micPath = null;
    return path;
  }

  /// Closes the engine capture and turns the scratch PCM into a real WAV by
  /// writing the header and streaming the PCM in behind it.
  Future<String?> _finishEngineCapture() async {
    AudioEngine.instance.stopMasterCapture();
    await _engineSub?.cancel();
    _engineSub = null;

    final sink = _engineSink;
    _engineSink = null;
    if (sink != null) {
      try {
        await sink.flush();
        await sink.close();
      } catch (e) {
        debugPrint('TakeRecorder: closing the capture file failed: $e');
      }
    }

    final pcmPath = _enginePcmPath;
    final wavPath = _engineWavPath;
    final byteCount = _engineBytes;
    _enginePcmPath = null;
    _engineWavPath = null;
    _engineBytes = 0;

    if (pcmPath == null || wavPath == null || byteCount <= 0) {
      await RecordingsRepository.deleteQuietly(pcmPath);
      return null;
    }

    try {
      final out = File(wavPath).openWrite();
      out.add(buildWavHeader(
        sampleRate: captureSampleRate,
        numChannels: captureChannels,
        bitsPerSample: 16,
        dataLength: byteCount,
      ));
      // `pipe` streams the payload through and closes the sink for us, so a
      // long take never has to sit in memory.
      await File(pcmPath).openRead().pipe(out);
      await RecordingsRepository.deleteQuietly(pcmPath);
      return wavPath;
    } catch (e) {
      debugPrint('TakeRecorder: writing the captured WAV failed: $e');
      await RecordingsRepository.deleteQuietly(pcmPath);
      return null;
    }
  }

  /// Sums the pad render and the microphone take into a single file. Returns
  /// null if that isn't sensible (too big, or the two files don't agree on a
  /// sample rate), in which case the caller keeps both files.
  Future<String?> _mixDown({required String padsPath, required String micPath}) async {
    try {
      final padsFile = File(padsPath);
      final micFile = File(micPath);
      final total = (await padsFile.length()) + (await micFile.length());
      if (total > maxMixBytes) return null;

      final mixed = mixWavPair(
        await padsFile.readAsBytes(),
        await micFile.readAsBytes(),
      );
      if (mixed == null) return null;

      final outPath = await RecordingsRepository.newTakePath(prefix: 'mix');
      await File(outPath).writeAsBytes(mixed, flush: true);
      await RecordingsRepository.deleteQuietly(padsPath);
      await RecordingsRepository.deleteQuietly(micPath);
      return outPath;
    } catch (e) {
      debugPrint('TakeRecorder: mixing the two layers failed: $e');
      return null;
    }
  }

  // --- Playback of saved recordings -------------------------------------

  /// Plays a saved recording once. Any recording already playing is stopped.
  Future<void> play(String path) async {
    await stopPlayback();
    final clipId = await AudioEngine.instance.loadClip(path);
    if (clipId == null) {
      _errorMessage = 'Could not open that recording.';
      _notify();
      return;
    }
    _playbackClipId = clipId;
    _playingPath = path;
    AudioEngine.instance.playClip(clipId, volume: 1.0);
    // Watch for the clip running off its own end so the button can flip back
    // from "stop" to "play" by itself.
    _playbackWatch?.cancel();
    _playbackWatch = Timer.periodic(const Duration(milliseconds: 400), (_) {
      final id = _playbackClipId;
      if (id == null) return;
      if (!AudioEngine.instance.isClipVoiceActive(id)) {
        unawaited(stopPlayback());
      }
    });
    _notify();
  }

  Future<void> stopPlayback() async {
    _playbackWatch?.cancel();
    _playbackWatch = null;
    final clipId = _playbackClipId;
    _playbackClipId = null;
    _playingPath = null;
    if (clipId != null) {
      await AudioEngine.instance.unloadClip(clipId);
    }
    _notify();
  }

  /// Deletes a saved recording (stopping it first if it happens to be the one
  /// currently playing).
  Future<void> delete(String path) async {
    if (_playingPath == path) {
      await stopPlayback();
    }
    await RecordingsRepository.deleteRecording(path);
    _notify();
  }

  @override
  void dispose() {
    _disposed = true;
    _tick?.cancel();
    _tick = null;
    _playbackWatch?.cancel();
    _playbackWatch = null;
    _stopwatch?.stop();
    unawaited(_engineSub?.cancel());
    _engineSub = null;
    unawaited(_engineSink?.close());
    _engineSink = null;
    AudioEngine.instance.stopMasterCapture();
    unawaited(_recorder.dispose());
    unawaited(_messages.close());
    super.dispose();
  }
}

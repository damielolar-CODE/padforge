/// The looper's pure-Dart core: what a captured pad hit is, how "quantise"
/// snaps it to a musical grid, and the scheduler that decides which hits are
/// due at any moment of playback.
///
/// **There is nothing from Flutter, `record` or `flutter_soloud` in this
/// file, on purpose.** The looper's two genuinely tricky pieces of logic --
/// snapping hits to the grid, and firing every hit exactly once per pass of
/// the loop even when the timer that drives it stutters -- are the two pieces
/// that cannot be checked by looking at the screen. Keeping them here means
/// they can be unit-tested on any machine with `flutter test`, with no device
/// and no audio hardware (see `test/loop_scheduler_test.dart`).
library;

/// The musical grid QUANTIZE snaps recorded hits onto, in 4/4.
///
/// The numbers are "how many of these fit in one bar": four quarter notes,
/// eight eighths, sixteen sixteenths. 1/16 is the default because that is the
/// classic drum-machine step size -- it tightens a sloppy hi-hat without
/// flattening a deliberately laid-back snare the way 1/8 would.
enum QuantizeGrid {
  quarter(4, '1/4'),
  eighth(8, '1/8'),
  sixteenth(16, '1/16');

  const QuantizeGrid(this.divisionsPerBar, this.label);

  /// How many grid steps make up one bar of 4/4.
  final int divisionsPerBar;

  /// What the button says: "1/4", "1/8", "1/16".
  final String label;
}

/// Parses the grid back out of the string stored in shared preferences.
/// Anything unrecognised falls back to the default, 1/16.
QuantizeGrid quantizeGridFromName(String? name) {
  for (final grid in QuantizeGrid.values) {
    if (grid.name == name) return grid;
  }
  return QuantizeGrid.sixteenth;
}

/// One pad hit captured during loop recording, so pad parts loop back at full
/// digital quality instead of only through the microphone.
///
/// A hit carries **two** positions:
///
///  * [rawOffsetMs] -- when you actually played it. This is what is stored in
///    the layer, and it is never overwritten.
///  * [offsetMs] -- when it is *played back*: the raw offset snapped to the
///    quantise grid when QUANTIZE is on, or simply the raw offset when it is
///    off.
///
/// Keeping both is what makes the QUANTIZE button non-destructive: turning it
/// off gives you your human timing back, because the human timing was never
/// thrown away.
class LoopPadEvent {
  /// Which pad was hit ("A1", "B7", ...).
  final String padId;

  /// Where this hit plays back, in milliseconds from the top of the loop.
  /// Always >= 0 and always less than the loop's length.
  final int offsetMs;

  /// Where the hit was actually played, before any quantising.
  final int rawOffsetMs;

  /// How hard it was hit (MIDI velocity, 1-127).
  final int velocity;

  /// Which layer this hit belongs to: 0 is the base pass, 1 the first overdub,
  /// and so on. UNDO removes the highest layer.
  final int layer;

  LoopPadEvent({
    required this.padId,
    required this.offsetMs,
    required this.velocity,
    int? rawOffsetMs,
    this.layer = 0,
  }) : rawOffsetMs = rawOffsetMs ?? offsetMs;

  /// The same hit, played back at a different point in the loop. Used when the
  /// quantise grid changes (or quantise is switched off): the raw timing rides
  /// along untouched.
  LoopPadEvent withOffset(int newOffsetMs) => LoopPadEvent(
        padId: padId,
        offsetMs: newOffsetMs,
        rawOffsetMs: rawOffsetMs,
        velocity: velocity,
        layer: layer,
      );

  @override
  String toString() =>
      'LoopPadEvent($padId @${offsetMs}ms raw=${rawOffsetMs}ms v$velocity L$layer)';
}

/// Snaps [offsetMs] to the nearest [grid] division of a bar that is [barUs]
/// microseconds long, wrapping a hit that snaps onto the very end of the loop
/// back round to its start.
///
/// The wrap matters: a kick played 8ms *before* the downbeat of the next bar
/// is, musically, that downbeat -- and because the loop repeats, the downbeat
/// of the next bar is position 0 of this one. Dropping it (which is what the
/// old code did to anything past the end) silently ate the most important hit
/// in the bar.
///
/// Everything is computed in microseconds and only rounded to milliseconds at
/// the very end, so a grid that does not divide evenly into whole
/// milliseconds (90 BPM sixteenths are 166.67ms) does not accumulate error
/// across a bar.
int snapOffsetMs({
  required int offsetMs,
  required int barUs,
  required QuantizeGrid grid,
  required int loopMs,
}) {
  if (barUs <= 0 || loopMs <= 0) return offsetMs;
  final stepUs = barUs / grid.divisionsPerBar;
  if (stepUs <= 0) return offsetMs;

  final steps = (offsetMs * 1000.0 / stepUs).round();
  var snapped = (steps * stepUs / 1000.0).round();
  if (snapped < 0) snapped = 0;
  snapped %= loopMs;
  return snapped;
}

/// Normalises a raw offset into the loop (wrapping anything that landed past
/// the end back round to the start), and snaps it if [quantize] is on.
int effectiveOffsetMs({
  required int rawOffsetMs,
  required int loopMs,
  required int barUs,
  required bool quantize,
  required QuantizeGrid grid,
}) {
  if (loopMs <= 0) return rawOffsetMs < 0 ? 0 : rawOffsetMs;
  var offset = rawOffsetMs % loopMs;
  if (offset < 0) offset += loopMs;
  if (!quantize) return offset;
  return snapOffsetMs(
    offsetMs: offset,
    barUs: barUs,
    grid: grid,
    loopMs: loopMs,
  );
}

/// Decides which recorded hits are due, from a single free-running clock.
///
/// ## Why this exists
///
/// Loop playback used to work like this: a timer ticked every 10ms, worked out
/// where in the loop it was, and fired everything up to that point using a
/// cursor that was rewound whenever the pass number changed. That is fine
/// while the timer is punctual. On a busy phone it is not punctual -- a tick
/// can arrive 60ms late -- and then:
///
///  * if a whole pass was skipped (a short loop, a long stall) every hit in it
///    was lost, and
///  * the "rewind the cursor at the seam" rule could fire a hit twice or not
///    at all depending on exactly where the late tick landed.
///
/// This class removes the guesswork. It works on the **absolute** elapsed time
/// of one free-running stopwatch and fires every hit whose position falls in
/// the window `(previous elapsed, current elapsed]`, walking as many loop
/// passes as that window spans. The windows are contiguous and never overlap,
/// so every hit fires exactly once per pass, in order, no matter how badly the
/// ticks jitter -- which is exactly what the unit tests assert.
class LoopScheduler {
  /// Length of one pass of the loop, in milliseconds.
  int _loopMs = 0;

  /// Hits to play, sorted by [LoopPadEvent.offsetMs].
  List<LoopPadEvent> _events = const [];

  /// Absolute elapsed time we have already fired up to and including.
  /// Starts at -1 so that a hit sitting exactly at offset 0 of the very first
  /// pass is still in the first window.
  int _lastElapsedMs = -1;

  int get loopMs => _loopMs;

  /// Elapsed time (ms) the scheduler has fired up to, inclusive.
  int get lastElapsedMs => _lastElapsedMs;

  List<LoopPadEvent> get events => _events;

  /// Restarts the scheduler for a loop of [loopMs] milliseconds. Call this
  /// whenever playback (re)starts from the top.
  void reset({
    required int loopMs,
    List<LoopPadEvent> events = const [],
    int startElapsedMs = -1,
  }) {
    _loopMs = loopMs < 0 ? 0 : loopMs;
    _events = events;
    _lastElapsedMs = startElapsedMs;
  }

  /// Replaces the hit list mid-flight (an overdub layer was committed, a layer
  /// was undone, the quantise grid changed) **without** disturbing where we are
  /// on the timeline.
  ///
  /// Hits in the new list that sit earlier in this pass than the playhead are
  /// simply not in any future window, so they wait for the loop to come round
  /// instead of all firing at once -- which is exactly right for a layer the
  /// user has just finished playing live.
  void setEvents(List<LoopPadEvent> events) {
    _events = events;
  }

  /// Fires every hit due in `(lastElapsedMs, elapsedMs]`.
  ///
  /// [elapsedMs] is the raw reading of the transport stopwatch, i.e. it keeps
  /// growing pass after pass; it is never reduced modulo the loop length by the
  /// caller.
  void advanceTo(int elapsedMs, void Function(LoopPadEvent event) fire) {
    final loopMs = _loopMs;
    if (loopMs <= 0) return;

    var from = _lastElapsedMs;
    final to = elapsedMs;
    if (to <= from) {
      // The clock went backwards (a restart we were not told about). Re-anchor
      // rather than replaying the whole loop.
      if (to < from) _lastElapsedMs = to;
      return;
    }
    _lastElapsedMs = to;
    if (_events.isEmpty) return;

    // After a stall longer than the loop itself, only the most recent pass is
    // worth hearing -- firing a burst of every hit from the last two seconds
    // would sound like a machine gun and would make the stall worse.
    if (to - from > loopMs) from = to - loopMs;

    final firstPass = from < 0 ? 0 : from ~/ loopMs;
    final lastPass = to ~/ loopMs;

    for (var pass = firstPass; pass <= lastPass; pass++) {
      final base = pass * loopMs;
      final lowerExclusive = from - base;
      var upperInclusive = to - base;
      // Offsets are always < loopMs, so clamping the top of a pass to
      // loopMs - 1 covers "everything left in this pass".
      if (upperInclusive >= loopMs) upperInclusive = loopMs - 1;
      if (upperInclusive < 0) continue;

      for (final event in _events) {
        final offset = event.offsetMs;
        if (offset <= lowerExclusive) continue;
        if (offset > upperInclusive) break;
        fire(event);
      }
    }
  }
}

/// Decides who gets the microphone.
///
/// PadForge has two things that want to record: the looper (bar-synced, fixed
/// length) and the take recorder (unlimited). A phone only has one microphone
/// input, and asking the OS to open it twice at once fails in confusing ways,
/// so both go through this tiny gate first.
///
/// It is deliberately as simple as a coat check: whoever holds the ticket owns
/// the mic until they hand it back.
class MicArbiter {
  MicArbiter._();

  /// Name used by the looper when it claims the mic.
  static const String looper = 'looper';

  /// Name used by the unlimited take recorder when it claims the mic.
  static const String takeRecorder = 'recorder';

  static String? _owner;

  /// Who currently holds the mic, or null if it is free.
  static String? get owner => _owner;

  static bool get isBusy => _owner != null;

  /// Tries to claim the mic for [who]. Returns false if somebody else has it.
  static bool acquire(String who) {
    if (_owner != null && _owner != who) return false;
    _owner = who;
    return true;
  }

  /// Hands the mic back. Doing this when you don't hold it is a harmless no-op.
  static void release(String who) {
    if (_owner == who) _owner = null;
  }
}

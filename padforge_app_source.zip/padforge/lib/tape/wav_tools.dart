/// Pure-Dart tools for reading, trimming, padding and mixing WAV files.
///
/// ## Why this exists (plain English)
///
/// The looper's hands-free "start when I play" mode works by cheating: the
/// microphone actually starts recording the moment you arm the loop, *before*
/// you play anything. When your first note crosses the threshold we simply
/// note how far into that recording it happened -- call it `t0` -- and let the
/// recording run for one full loop length after that point.
///
/// What we're left with is a file that begins with `t0` worth of silence (you
/// getting ready). This file's job is to cut that silence off the front, so the
/// loop starts exactly on your first hit with nothing clipped and nothing extra.
///
/// A WAV file is a header describing the audio (how many channels, what sample
/// rate) followed by the raw audio samples. Trimming is therefore just
/// "throw away the first N bytes of audio and write a corrected header".
///
/// There are no Flutter or plugin dependencies in this file on purpose: it is
/// plain Dart, so it can be unit-tested anywhere (see
/// `test/wav_tools_test.dart`).
library;

import 'dart:typed_data';

/// Everything we need to know about a WAV file to cut it up.
class WavInfo {
  /// Samples per second, e.g. 44100.
  final int sampleRate;

  /// 1 for mono, 2 for stereo.
  final int numChannels;

  /// Usually 16 (16-bit PCM).
  final int bitsPerSample;

  /// Byte offset where the raw audio starts.
  final int dataOffset;

  /// How many bytes of raw audio there are.
  final int dataLength;

  const WavInfo({
    required this.sampleRate,
    required this.numChannels,
    required this.bitsPerSample,
    required this.dataOffset,
    required this.dataLength,
  });

  /// How many bytes one "frame" (one sample on every channel) takes.
  int get bytesPerFrame => numChannels * (bitsPerSample ~/ 8);

  /// How many bytes of audio one second occupies.
  int get bytesPerSecond => bytesPerFrame * sampleRate;

  /// How long the audio is.
  Duration get duration {
    if (bytesPerSecond <= 0) return Duration.zero;
    return Duration(microseconds: (dataLength * 1000000 / bytesPerSecond).round());
  }

  @override
  String toString() => 'WavInfo(${sampleRate}Hz, ${numChannels}ch, ${bitsPerSample}bit, '
      'data@$dataOffset len=$dataLength, ${duration.inMilliseconds}ms)';
}

const int _riff = 0x52494646; // "RIFF" read big-endian
const int _wave = 0x57415645; // "WAVE"
const int _fmt = 0x666D7420; // "fmt "
const int _data = 0x64617461; // "data"

/// Reads a WAV file's header. Returns null if [bytes] is not a WAV file we
/// understand (which, for our purposes, means uncompressed PCM).
///
/// This walks the file's chunks properly rather than assuming the classic
/// 44-byte header, because some platforms write extra chunks (e.g. "LIST")
/// between the format description and the audio.
WavInfo? readWavInfo(Uint8List bytes) {
  if (bytes.length < 12) return null;
  final view = ByteData.sublistView(bytes);
  if (view.getUint32(0, Endian.big) != _riff) return null;
  if (view.getUint32(8, Endian.big) != _wave) return null;

  int? sampleRate;
  int? numChannels;
  int? bitsPerSample;
  int? dataOffset;
  int? dataLength;

  var offset = 12;
  while (offset + 8 <= bytes.length) {
    final chunkId = view.getUint32(offset, Endian.big);
    final chunkSize = view.getUint32(offset + 4, Endian.little);
    final payload = offset + 8;

    if (chunkId == _fmt && payload + 16 <= bytes.length) {
      numChannels = view.getUint16(payload + 2, Endian.little);
      sampleRate = view.getUint32(payload + 4, Endian.little);
      bitsPerSample = view.getUint16(payload + 14, Endian.little);
    } else if (chunkId == _data) {
      // A recorder that was killed mid-write can leave a size field that
      // promises more audio than the file actually contains; trust the file.
      final available = bytes.length - payload;
      var len = chunkSize <= available ? chunkSize : available;
      if (len < 0) len = 0;
      dataOffset = payload;
      dataLength = len;
      break;
    }

    // Chunks are padded to an even number of bytes.
    final advance = chunkSize + (chunkSize.isOdd ? 1 : 0);
    if (advance <= 0) break;
    offset = payload + advance;
  }

  if (sampleRate == null ||
      numChannels == null ||
      bitsPerSample == null ||
      dataOffset == null ||
      dataLength == null) {
    return null;
  }
  if (sampleRate <= 0 || numChannels <= 0 || bitsPerSample < 8) return null;

  return WavInfo(
    sampleRate: sampleRate,
    numChannels: numChannels,
    bitsPerSample: bitsPerSample,
    dataOffset: dataOffset,
    dataLength: dataLength,
  );
}

/// Builds a standard 44-byte WAV header for [dataLength] bytes of PCM audio.
Uint8List buildWavHeader({
  required int sampleRate,
  required int numChannels,
  required int bitsPerSample,
  required int dataLength,
}) {
  final header = Uint8List(44);
  final view = ByteData.sublistView(header);
  final bytesPerFrame = numChannels * (bitsPerSample ~/ 8);

  view.setUint32(0, _riff, Endian.big); // "RIFF"
  view.setUint32(4, 36 + dataLength, Endian.little); // ChunkSize
  view.setUint32(8, _wave, Endian.big); // "WAVE"
  view.setUint32(12, _fmt, Endian.big); // "fmt "
  view.setUint32(16, 16, Endian.little); // Subchunk1Size (PCM)
  view.setUint16(20, 1, Endian.little); // AudioFormat = 1 (PCM)
  view.setUint16(22, numChannels, Endian.little);
  view.setUint32(24, sampleRate, Endian.little);
  view.setUint32(28, sampleRate * bytesPerFrame, Endian.little); // ByteRate
  view.setUint16(32, bytesPerFrame, Endian.little); // BlockAlign
  view.setUint16(34, bitsPerSample, Endian.little);
  view.setUint32(36, _data, Endian.big); // "data"
  view.setUint32(40, dataLength, Endian.little); // Subchunk2Size
  return header;
}

/// How many whole frames of audio [d] occupies at [sampleRate]. Negative or
/// zero durations give 0.
///
/// This is the single place where "a moment in time" becomes "a position in the
/// audio". Everything that has to agree about where a given millisecond lands --
/// trimming, padding, and dropping an overdub into the loop -- goes through it,
/// so nothing can ever be a frame out from anything else.
int wavFramesForDuration(Duration d, int sampleRate) {
  if (sampleRate <= 0) return 0;
  final frames = (d.inMicroseconds * sampleRate / 1000000).round();
  return frames <= 0 ? 0 : frames;
}

/// How many bytes of audio [d] occupies at [sampleRate], rounded to a whole
/// frame of [bytesPerFrame] bytes. Shared by [trimWav] and
/// [padWavWithSilence] so the two always agree on where a given moment in time
/// lands -- if they disagreed by a single frame, quantising a loop would leave
/// a click at the seam.
int wavBytesForDuration(Duration d, int sampleRate, int bytesPerFrame) {
  if (bytesPerFrame <= 0) return 0;
  return wavFramesForDuration(d, sampleRate) * bytesPerFrame;
}

/// Builds a valid, completely silent 16-bit WAV of exactly [length].
///
/// The looper uses this when an overdub arrives and there is no master loop
/// audio to mix it into yet (for instance a BOTH loop whose base pass was pad
/// hits only): it lays down a silent bed of exactly the loop's length and mixes
/// the overdub into that, so the first mic layer is still sample-locked to the
/// loop.
Uint8List buildSilentWav({
  required int sampleRate,
  required int numChannels,
  required Duration length,
}) {
  final rate = sampleRate > 0 ? sampleRate : 44100;
  final channels = numChannels > 0 ? numChannels : 1;
  final frames = wavFramesForDuration(length, rate);
  final dataLength = frames * channels * 2;
  final header = buildWavHeader(
    sampleRate: rate,
    numChannels: channels,
    bitsPerSample: 16,
    dataLength: dataLength,
  );
  final out = Uint8List(header.length + dataLength);
  out.setRange(0, header.length, header);
  // A fresh Uint8List is already all zeroes, which is silence for 16-bit PCM.
  return out;
}

/// Returns a new WAV file with the first [start] of audio removed and, if
/// [length] is given, no more than [length] of audio kept.
///
/// Cuts always land on a whole frame boundary, so the result never contains a
/// half sample (which would click). Returns null if [bytes] isn't a WAV file
/// we can read; returns an empty-but-valid WAV if the cut removes everything.
Uint8List? trimWav(
  Uint8List bytes, {
  Duration start = Duration.zero,
  Duration? length,
}) {
  final info = readWavInfo(bytes);
  if (info == null) return null;
  final frameSize = info.bytesPerFrame;
  if (frameSize <= 0) return null;

  int bytesFor(Duration d) => wavBytesForDuration(d, info.sampleRate, frameSize);

  var startBytes = bytesFor(start);
  if (startBytes > info.dataLength) startBytes = info.dataLength;

  var keep = info.dataLength - startBytes;
  if (length != null) {
    final wanted = bytesFor(length);
    if (wanted < keep) keep = wanted;
  }
  if (keep < 0) keep = 0;

  final header = buildWavHeader(
    sampleRate: info.sampleRate,
    numChannels: info.numChannels,
    bitsPerSample: info.bitsPerSample,
    dataLength: keep,
  );

  final out = Uint8List(header.length + keep);
  out.setRange(0, header.length, header);
  if (keep > 0) {
    final from = info.dataOffset + startBytes;
    out.setRange(header.length, header.length + keep, bytes, from);
  }
  return out;
}

/// Returns a new WAV file that is at least [targetLength] long, adding silence
/// on the end if the audio is short.
///
/// ## Why (plain English)
///
/// When the looper quantises a take to the nearest whole bar, the take is
/// usually a fraction of a second *off* -- you tapped a little early or a
/// little late. Too long is easy: cut the extra off with [trimWav]. Too short
/// needs the opposite, which is this: glue enough silence on the end that the
/// file is exactly one whole number of bars, so it loops in time forever.
///
/// Audio that is already at or past [targetLength] is returned unchanged
/// (as a fresh copy with a corrected header). Returns null if [bytes] isn't a
/// WAV file we can read.
Uint8List? padWavWithSilence(Uint8List bytes, {required Duration targetLength}) {
  final info = readWavInfo(bytes);
  if (info == null) return null;
  final frameSize = info.bytesPerFrame;
  if (frameSize <= 0) return null;

  final wanted = wavBytesForDuration(targetLength, info.sampleRate, frameSize);
  final have = info.dataLength;
  final total = wanted > have ? wanted : have;

  final header = buildWavHeader(
    sampleRate: info.sampleRate,
    numChannels: info.numChannels,
    bitsPerSample: info.bitsPerSample,
    dataLength: total,
  );

  final out = Uint8List(header.length + total);
  out.setRange(0, header.length, header);
  if (have > 0) {
    out.setRange(header.length, header.length + have, bytes, info.dataOffset);
  }
  // A fresh Uint8List is already all zeroes, which *is* silence for signed PCM
  // (16/24/32-bit). 8-bit WAV is the odd one out: it is unsigned, so its
  // silence sits at the midpoint, 128.
  if (total > have && info.bitsPerSample == 8) {
    out.fillRange(header.length + have, header.length + total, 128);
  }
  return out;
}

/// Sums two 16-bit PCM WAV files into one, sample by sample, clipping at the
/// edges of the 16-bit range rather than wrapping around (which would sound
/// like a burst of noise).
///
/// Used by the unlimited recorder's "BOTH" mode, where the pad performance and
/// the microphone are captured separately and then folded into a single file.
/// The looper does *not* use this -- it plays its two layers live instead,
/// which keeps the pads digitally clean.
///
/// If one file is mono and the other stereo, the mono one is duplicated across
/// the channels. The result is as long as the longer of the two. Returns null
/// if either file is unreadable, isn't 16-bit, or if the sample rates differ
/// (resampling is out of scope here).
Uint8List? mixWavPair(Uint8List a, Uint8List b) {
  final infoA = readWavInfo(a);
  final infoB = readWavInfo(b);
  if (infoA == null || infoB == null) return null;
  if (infoA.bitsPerSample != 16 || infoB.bitsPerSample != 16) return null;
  if (infoA.sampleRate != infoB.sampleRate) return null;
  if (infoA.numChannels <= 0 || infoB.numChannels <= 0) return null;

  final channels =
      infoA.numChannels > infoB.numChannels ? infoA.numChannels : infoB.numChannels;
  final framesA = infoA.dataLength ~/ infoA.bytesPerFrame;
  final framesB = infoB.dataLength ~/ infoB.bytesPerFrame;
  final frames = framesA > framesB ? framesA : framesB;

  final dataLength = frames * channels * 2;
  final header = buildWavHeader(
    sampleRate: infoA.sampleRate,
    numChannels: channels,
    bitsPerSample: 16,
    dataLength: dataLength,
  );

  final out = Uint8List(header.length + dataLength);
  out.setRange(0, header.length, header);
  if (dataLength == 0) return out;

  final outView = ByteData.sublistView(out);
  final viewA = ByteData.sublistView(a);
  final viewB = ByteData.sublistView(b);

  for (var frame = 0; frame < frames; frame++) {
    for (var channel = 0; channel < channels; channel++) {
      var sum = 0;
      if (frame < framesA) {
        final source = channel < infoA.numChannels ? channel : infoA.numChannels - 1;
        sum += viewA.getInt16(
          infoA.dataOffset + (frame * infoA.numChannels + source) * 2,
          Endian.little,
        );
      }
      if (frame < framesB) {
        final source = channel < infoB.numChannels ? channel : infoB.numChannels - 1;
        sum += viewB.getInt16(
          infoB.dataOffset + (frame * infoB.numChannels + source) * 2,
          Endian.little,
        );
      }
      if (sum > 32767) sum = 32767;
      if (sum < -32768) sum = -32768;
      outView.setInt16(
        header.length + (frame * channels + channel) * 2,
        sum,
        Endian.little,
      );
    }
  }
  return out;
}

/// Sums [overlay] into [loop] starting [offset] into the loop, **wrapping
/// around the end of the loop back to its start**, and returns the new loop.
///
/// ## Why (plain English)
///
/// This is what makes overdubbing work. The loop is a fixed-length piece of
/// tape joined into a circle; an overdub is a strip of new audio you drop onto
/// it starting wherever you happened to be when you engaged the overdub. If the
/// new strip runs off the end of the circle it simply carries on at the
/// beginning -- exactly like a real tape loop passing the record head again.
///
/// Three things this guarantees, all of which matter:
///
///  * **The loop never changes length.** The result is always exactly as long
///    as [loop] was, no matter how long [overlay] is. Loop length is decided
///    once, by the base pass, and nothing afterwards can move it.
///  * **It wraps.** An overlay engaged near the end of the loop lands partly at
///    the end and partly at the start, at the right positions.
///  * **It clips rather than wraps *numerically*.** Two loud layers summing past
///    the 16-bit range are pinned to the maximum, which sounds like distortion;
///    letting them overflow would flip the sign and sound like a burst of white
///    noise.
///
/// If [overlay] is longer than the loop it simply keeps going round, summing
/// onto what it laid down on the previous pass -- which is what actually
/// happened acoustically, so it is the correct result.
///
/// The output keeps [loop]'s sample rate and channel count. A mono overlay
/// going onto a stereo loop is copied to every channel; a stereo overlay onto a
/// mono loop contributes its first channel. Returns null if either file is
/// unreadable, either is not 16-bit, the sample rates differ (resampling is out
/// of scope), or the loop has no audio at all.
Uint8List? mixWavIntoLoop(
  Uint8List loop,
  Uint8List overlay, {
  required Duration offset,
}) {
  final loopInfo = readWavInfo(loop);
  final overlayInfo = readWavInfo(overlay);
  if (loopInfo == null || overlayInfo == null) return null;
  if (loopInfo.bitsPerSample != 16 || overlayInfo.bitsPerSample != 16) return null;
  if (loopInfo.sampleRate != overlayInfo.sampleRate) return null;
  if (loopInfo.numChannels <= 0 || overlayInfo.numChannels <= 0) return null;

  final channels = loopInfo.numChannels;
  final loopFrames = loopInfo.dataLength ~/ loopInfo.bytesPerFrame;
  if (loopFrames <= 0) return null;
  final overlayFrames = overlayInfo.dataLength ~/ overlayInfo.bytesPerFrame;

  final dataLength = loopFrames * channels * 2;
  final header = buildWavHeader(
    sampleRate: loopInfo.sampleRate,
    numChannels: channels,
    bitsPerSample: 16,
    dataLength: dataLength,
  );

  // Start from a straight copy of the loop, then add the overlay on top of it.
  final out = Uint8List(header.length + dataLength);
  out.setRange(0, header.length, header);
  out.setRange(header.length, header.length + dataLength, loop, loopInfo.dataOffset);
  if (overlayFrames <= 0) return out;

  // Where the overlay's first sample belongs, as a frame index inside the loop.
  // wavFramesForDuration floors a negative offset to zero, so this is always in
  // range even if a caller hands us nonsense.
  final start = wavFramesForDuration(offset, loopInfo.sampleRate) % loopFrames;

  final outView = ByteData.sublistView(out);
  final overlayView = ByteData.sublistView(overlay);

  var target = start;
  for (var frame = 0; frame < overlayFrames; frame++) {
    for (var channel = 0; channel < channels; channel++) {
      final sourceChannel =
          channel < overlayInfo.numChannels ? channel : overlayInfo.numChannels - 1;
      final overlaySample = overlayView.getInt16(
        overlayInfo.dataOffset + (frame * overlayInfo.numChannels + sourceChannel) * 2,
        Endian.little,
      );
      if (overlaySample == 0) continue;
      final at = header.length + (target * channels + channel) * 2;
      var sum = outView.getInt16(at, Endian.little) + overlaySample;
      if (sum > 32767) sum = 32767;
      if (sum < -32768) sum = -32768;
      outView.setInt16(at, sum, Endian.little);
    }
    target++;
    if (target >= loopFrames) target = 0;
  }
  return out;
}

/// A drawable summary of a WAV file: for each horizontal pixel bucket of a
/// waveform display, the lowest and highest sample that fell into it.
///
/// This is what a waveform display actually needs. A four-bar loop at 44.1kHz
/// is well over half a million samples; a waveform strip on a phone is maybe
/// 300 pixels wide. Drawing every sample would be 2000 line segments per pixel
/// column, every frame. Reducing to one min/max pair per column up front (and
/// only when the audio changes) means the painter draws 300 short vertical
/// lines and nothing else.
class WavPeaks {
  /// Lowest sample in each bucket, -1.0 .. 1.0.
  final List<double> mins;

  /// Highest sample in each bucket, -1.0 .. 1.0.
  final List<double> maxs;

  const WavPeaks({required this.mins, required this.maxs});

  int get length => mins.length;

  bool get isEmpty => mins.isEmpty;

  bool get isNotEmpty => mins.isNotEmpty;

  /// The loudest excursion anywhere in the envelope, 0.0-1.0. Used to scale a
  /// quiet recording up so it is still *visible* on a small LCD panel.
  double get peakAmplitude {
    var loudest = 0.0;
    for (final value in mins) {
      final magnitude = value < 0 ? -value : value;
      if (magnitude > loudest) loudest = magnitude;
    }
    for (final value in maxs) {
      final magnitude = value < 0 ? -value : value;
      if (magnitude > loudest) loudest = magnitude;
    }
    return loudest > 1.0 ? 1.0 : loudest;
  }
}

/// Re-buckets a [WavPeaks] envelope onto exactly [columns] horizontal columns.
///
/// ## Why this is not just "sample the nearest bucket"
///
/// The deck computes a fixed number of buckets when the audio changes (240 by
/// default); the display it ends up on is whatever width the phone gives it.
/// When the strip is *narrower* than the bucket count, picking one bucket per
/// column throws away every peak that fell in the buckets it skipped -- a snare
/// hit can vanish entirely, and the waveform looks like it is missing audio
/// that is definitely there. So a column that covers several buckets takes the
/// **minimum of their minima and the maximum of their maxima**: the envelope
/// only ever grows when you zoom out, which is what every DAW does.
///
/// When the strip is *wider* than the bucket count the mapping is the other way
/// round -- several columns share one bucket -- which is a plain nearest-bucket
/// read and cannot lose anything.
///
/// Pure arithmetic, no Flutter: see `test/wav_peaks_test.dart`.
WavPeaks resampleWavPeaks(WavPeaks peaks, int columns) {
  if (columns <= 0 || peaks.isEmpty) {
    return const WavPeaks(mins: <double>[], maxs: <double>[]);
  }
  final buckets = peaks.length;
  final mins = List<double>.filled(columns, 0);
  final maxs = List<double>.filled(columns, 0);

  for (var column = 0; column < columns; column++) {
    var start = (buckets * column) ~/ columns;
    var end = (buckets * (column + 1)) ~/ columns;
    if (start >= buckets) start = buckets - 1;
    if (end <= start) end = start + 1;
    if (end > buckets) end = buckets;

    var lo = peaks.mins[start];
    var hi = peaks.maxs[start];
    for (var bucket = start + 1; bucket < end; bucket++) {
      final candidateLo = peaks.mins[bucket];
      final candidateHi = peaks.maxs[bucket];
      if (candidateLo < lo) lo = candidateLo;
      if (candidateHi > hi) hi = candidateHi;
    }
    mins[column] = lo;
    maxs[column] = hi;
  }
  return WavPeaks(mins: mins, maxs: maxs);
}

/// How much to multiply an envelope by so its loudest peak just fills the
/// display, clamped to [maxGain] so a nearly-silent take is not amplified into
/// a wall of noise.
///
/// A phone microphone recording at a sensible level peaks around -12dBFS, which
/// on a 70dp strip is a 17dp squiggle -- technically correct and visually
/// useless. Normalising the *drawing* (never the audio) is what makes the panel
/// read like a DAW.
double envelopeDisplayGain(double peakAmplitude, {double maxGain = 4.0}) {
  if (!peakAmplitude.isFinite || peakAmplitude <= 0.0001) return 1.0;
  final gain = 0.95 / peakAmplitude;
  if (gain < 1.0) return 1.0;
  return gain > maxGain ? maxGain : gain;
}

/// Reduces the 16-bit PCM in [bytes] to [buckets] min/max pairs.
///
/// Channels are merged (the loudest channel in a frame wins), which is what a
/// mono "what did I record" strip wants. Returns null if [bytes] is not a WAV
/// we can read, or is not 16-bit, or contains no audio.
///
/// Cost is one pass over the samples with a stride, so a four-bar stereo loop
/// is a handful of milliseconds. It runs **once per commit** (when a take is
/// rendered or an overdub is mixed in), never per frame.
WavPeaks? computeWavPeaks(Uint8List bytes, {int buckets = 240}) {
  if (buckets <= 0) return null;
  final info = readWavInfo(bytes);
  if (info == null || info.bitsPerSample != 16) return null;
  final bytesPerFrame = info.bytesPerFrame;
  if (bytesPerFrame <= 0) return null;
  final frames = info.dataLength ~/ bytesPerFrame;
  if (frames <= 0) return null;

  final mins = List<double>.filled(buckets, 0);
  final maxs = List<double>.filled(buckets, 0);
  final view = ByteData.sublistView(bytes);

  // With very long audio we look at a subset of frames per bucket rather than
  // all of them: peak shape is preserved and the pass stays quick.
  const maxSamplesPerBucket = 512;

  for (var bucket = 0; bucket < buckets; bucket++) {
    final start = (frames * bucket) ~/ buckets;
    var end = (frames * (bucket + 1)) ~/ buckets;
    if (end <= start) end = start + 1;
    if (end > frames) end = frames;

    var stride = (end - start) ~/ maxSamplesPerBucket;
    if (stride < 1) stride = 1;

    var lo = 0;
    var hi = 0;
    var sawAny = false;
    for (var frame = start; frame < end; frame += stride) {
      for (var channel = 0; channel < info.numChannels; channel++) {
        final at = info.dataOffset + (frame * info.numChannels + channel) * 2;
        if (at + 2 > bytes.length) break;
        final sample = view.getInt16(at, Endian.little);
        if (!sawAny) {
          lo = sample;
          hi = sample;
          sawAny = true;
        } else {
          if (sample < lo) lo = sample;
          if (sample > hi) hi = sample;
        }
      }
    }
    if (!sawAny) continue;
    mins[bucket] = (lo / 32768.0).clamp(-1.0, 1.0).toDouble();
    maxs[bucket] = (hi / 32768.0).clamp(-1.0, 1.0).toDouble();
  }

  return WavPeaks(mins: mins, maxs: maxs);
}

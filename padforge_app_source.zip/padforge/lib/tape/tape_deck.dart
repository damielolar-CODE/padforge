import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:record/record.dart';

import '../audio/audio_engine.dart';
import '../services/recordings_repository.dart';
import '../services/settings_service.dart';
import 'loop_events.dart';
import 'mic_arbiter.dart';
import 'record_source.dart';
import 'wav_tools.dart';

// The pad-hit model, the quantise grid and the playback scheduler live in
// `loop_events.dart` so they can be unit-tested without Flutter or any plugin.
// They are re-exported here so callers only need one import.
export 'loop_events.dart' show LoopPadEvent, QuantizeGrid, quantizeGridFromName;

/// Where the looper is in its life cycle.
///
/// This is the classic **one-switch looper** flow -- the same one a Boss RC
/// style pedal uses. One button does everything, and what it does next depends
/// on where you are:
///
/// ```
///   EMPTY ──tap LOOP──▶ ARMED ──first pad hit (or mic crosses the
///     ▲                   │      threshold in MIC/BOTH)──▶ RECORDING
///     │      tap STOP     │                                    │
///     │◀──────────────────┘                    tap LOOP again ─┤ (or the bar
///     │                                        closes the loop │  count runs
///     │                                                        ▼  out)
///     │                                     ┌──────────────▶ PLAYING ◀────┐
///     │                          tap LOOP   │                 │  ▲        │
///     │                        (END DUB)    │        tap LOOP │  │ tap    │
///     │                                     │           (DUB) │  │ STOP   │
///     │                                OVERDUBBING ◀──────────┘  │        │
///     │                                     │                    │        │
///     │                                     └─tap STOP (cancels  │        │
///     │                                        this pass only)───┘        │
///     │        hold either tape pad for 800ms                             │
///     └────────────── (clears everything) ◀───── STOPPED ◀────────────────┘
///                                                    │  tap LOOP (PLAY)
///                                                    └──────────────▶ PLAYING
/// ```
///
/// So the LOOP pad cycles: **ARM → REC → END REC → DUB → END DUB → DUB → ...**,
/// adding one more layer on every pair of taps, for as long as you like (up to
/// [TapeDeck.maxOverdubLayers]). The pad's caption always says what the *next*
/// tap will do.
///
/// Overdubbing never changes the loop's length: that is decided once, by the
/// base pass, and every layer after it is folded into that same circle of tape.
enum LoopState {
  /// Nothing recorded yet.
  empty,

  /// Waiting for you to start. Nothing has been recorded yet and the loop
  /// clock has not started; it starts the instant the first pad is hit (or, in
  /// MIC/BOTH mode, the microphone crosses the threshold).
  armed,

  /// The loop clock is running and we are capturing the base layer, which is
  /// what fixes the loop's length.
  recording,

  /// The finished loop is playing, over and over, until stopped.
  playing,

  /// The loop is still playing *and* a new layer is being recorded on top of
  /// it, in sync. Ending the overdub folds that layer in and goes back to
  /// [playing]; STOP throws the in-progress layer away instead.
  overdubbing,

  /// A loop exists but is silent. Tapping LOOP plays it again.
  stopped,
}

/// A drawable summary of what is in the loop, for the tape deck's little
/// waveform LCD.
///
/// Two shapes, because a loop is one of two things:
///
///  * a **mic/BOTH loop** has an audio file, so [peaks] holds its min/max
///    envelope (computed once, when the audio changes -- never per frame), and
///  * a **PADS loop** has no audio at all, so there is nothing to draw a
///    waveform of. [hits] holds the loop's pad events instead, which get drawn
///    as a step pattern -- far more useful for a drum loop than a fake
///    waveform would be.
class LoopVisual {
  /// Peak envelope of the loop's master audio, or null in PADS mode.
  final WavPeaks? peaks;

  /// Every pad hit in the loop, at its playback (quantised) position.
  final List<LoopPadEvent> hits;

  /// Loop length in milliseconds, so hits can be placed horizontally.
  final int loopMs;

  /// How many whole bars the loop is, for the bar/beat gridlines. 0 when the
  /// loop's length is not a whole number of bars (quantise off) or there is no
  /// loop at all.
  final int bars;

  /// Beats in a bar. 4 everywhere in PadForge today, but the painter reads it
  /// from here rather than assuming, so a future 3/4 needs no painter change.
  final int beatsPerBar;

  /// Quantise divisions in a bar (4, 8 or 16), or 0 when quantise is off. Draws
  /// the faint step grid the PADS view snaps to.
  final int stepsPerBar;

  /// Tempo the loop was captured at, for the panel's corner readout.
  final double bpm;

  const LoopVisual({
    this.peaks,
    this.hits = const [],
    this.loopMs = 0,
    this.bars = 0,
    this.beatsPerBar = 4,
    this.stepsPerBar = 0,
    this.bpm = 0,
  });

  /// True when there is an audio envelope to draw (a MIC or BOTH loop).
  bool get hasAudio => peaks != null && peaks!.isNotEmpty;

  bool get isEmpty => !hasAudio && hits.isEmpty;
}

/// A [ChangeNotifier] whose only job is to say "something moved".
///
/// The transport uses one of these for the playhead instead of calling
/// `notifyListeners()` on the deck itself. That distinction is the difference
/// between "the reels and the two clock readouts repaint" and "the entire tape
/// deck panel rebuilds twenty times a second", and the second one was stealing
/// time from the pad trigger, which runs on the same thread.
class TickNotifier extends ChangeNotifier {
  void tick() => notifyListeners();
}

/// One recorded layer of the loop: the pad hits it added, plus (in MIC/BOTH)
/// what the master loop audio looked like *before* this layer was mixed into
/// it, which is what makes UNDO possible.
///
/// Mixing the microphone layers down into one master WAV is deliberate: it
/// keeps every layer sample-locked to the loop forever, whereas playing five
/// separate looping sources side by side would let them drift apart. The price
/// is that undoing a layer needs the previous master kept somewhere -- and
/// that is this class. The previous master is just the file that was already on
/// disk, renamed to nothing and simply *not deleted*, so a layer costs no extra
/// work at commit time.
class _LoopLayer {
  /// Pad hits added by this layer (may be empty in MIC mode).
  final List<LoopPadEvent> events;

  /// True when this layer changed the master loop audio.
  final bool changedMaster;

  /// The master WAV that was playing before this layer was mixed in, or null
  /// when there was no master audio at all before it.
  final String? previousMasterPath;

  const _LoopLayer({
    required this.events,
    this.changedMaster = false,
    this.previousMasterPath,
  });
}

/// The tape deck's looper.
///
/// ## What it does, in plain English
///
/// Tap LOOP once and the deck **arms**: it is waiting, but nothing is being
/// recorded yet. The moment you hit a pad (or, if you asked for the
/// microphone, the moment you make a sound louder than the threshold) the loop
/// starts recording from exactly that instant. Tap LOOP a second time and the
/// loop closes there and starts repeating immediately, forever, until you stop
/// it. Hold either tape pad for most of a second to wipe it and start again.
///
/// From then on the LOOP pad **overdubs**: tap it and a new layer starts
/// recording on top of the loop that is already playing; tap it again and that
/// layer is folded in. You can do that as many times as you like (up to
/// [maxOverdubLayers]), and UNDO takes the most recent layer back off.
///
/// ## How a layer is kept, per source
///
///  * **PADS** -- a layer is just more `(pad, offset, velocity)` events, so
///    nothing is ever mixed, nothing degrades, and undo is exact.
///  * **MIC** -- the layer's audio is summed into the master loop WAV at the
///    right offset, wrapping round the end of the loop. The previous master is
///    kept so undo can put it back.
///  * **BOTH** -- both of the above, rolled back together by one undo.
///
/// ## What gets recorded
///
/// That is up to [source]:
///
///  * [RecordSource.pads] (the default) captures *only* your pad hits, as a
///    list of "this pad, this many milliseconds in, this hard", which is
///    re-triggered through the sampler on every pass. The microphone is never
///    opened, so it is digitally clean and there is no permission prompt.
///  * [RecordSource.mic] captures only the microphone, as a WAV file looped
///    seamlessly by the audio engine.
///  * [RecordSource.both] captures both and plays them back as two independent
///    layers -- they are deliberately not mixed into one file.
///
/// ## Quantise (rewritten in v5)
///
/// Up to v4 "quantise" only rounded the loop's *length*, which is not what the
/// word means on any drum machine ever made -- and users said so. With
/// [quantize] on (the default) it now does what it says:
///
///  1. **Every recorded hit snaps to the grid** -- [quantizeGrid], one of 1/4,
///     1/8 or 1/16 of a bar (1/16 by default). This applies to the base pass
///     and to every overdub layer as it is committed. The raw, as-played time
///     of each hit is kept alongside the snapped one
///     ([LoopPadEvent.rawOffsetMs]), so switching quantise off gives you your
///     human timing back rather than destroying it.
///  2. **The loop's length is forced, not rounded.** With a fixed length
///     (4/8/16 bars) the loop is exactly that many bars at the current tempo.
///     In FREE mode the take is rounded to the nearest whole bar, minimum one.
///
/// Mic audio is never time-stretched -- only the loop's length is enforced (by
/// trimming or padding the take). Snapping applies to pad hits, which is where
/// a drummer can actually hear it.
class TapeDeck extends ChangeNotifier {
  TapeDeck._internal();

  static final TapeDeck instance = TapeDeck._internal();

  /// How long you have to hold a tape-deck pad to wipe the loop.
  static const Duration holdToClearDuration = Duration(milliseconds: 800);

  /// The "no fixed length" option in [selectableBars]: the loop is exactly as
  /// long as you play, and only the second tap on LOOP ends it.
  static const int freeBars = 0;

  /// Loop lengths the user can choose between. [freeBars] is the default.
  static const List<int> selectableBars = [freeBars, 4, 8, 16];

  /// Quietest level the threshold slider goes down to (dBFS).
  static const double minThresholdDb = -60;

  /// Loudest level the threshold slider goes up to (dBFS).
  static const double maxThresholdDb = 0;

  /// A second tap this soon after the first is treated as a fumble rather than
  /// a real (and unusably short) loop -- but only when quantise is off, since
  /// quantise would round it up to a whole bar anyway.
  static const Duration minFreeLoopLength = Duration(milliseconds: 250);

  /// How many overdub layers can sit on top of the base layer.
  ///
  /// This is also the undo depth: every one of these layers keeps the master
  /// loop audio from before it was mixed in, so you can undo your way back to
  /// the bare base layer one tap at a time. It is capped rather than unlimited
  /// because each layer holds a whole loop's worth of WAV on disk -- eight of
  /// them is a few megabytes and plenty of rope; unlimited would grow forever.
  static const int maxOverdubLayers = 8;

  final AudioRecorder _recorder = AudioRecorder();

  /// Called to actually make a pad sound during loop playback. `AppState`
  /// plugs itself in here at startup; using a callback (rather than importing
  /// AppState) keeps this file free of any dependency on app-wide state.
  void Function(String padId, int velocity)? onPadTrigger;

  // --- Settings ---------------------------------------------------------

  double _bpm = 90;
  int _bars = freeBars;
  bool _quantize = true;
  QuantizeGrid _quantizeGrid = QuantizeGrid.sixteenth;
  RecordSource _source = RecordSource.pads;
  double _thresholdDb = -30;
  double _inputLevelDb = minThresholdDb;

  double get bpm => _bpm;

  /// Fixed loop length in bars, or [freeBars] (0) for "as long as I play".
  int get bars => _bars;

  /// True when the loop has no preset length and only the second tap ends it.
  bool get isFreeLength => _bars == freeBars;

  /// Whether recorded hits snap to the musical grid (and the loop's length is
  /// forced to whole bars).
  bool get quantize => _quantize;

  /// Which division recorded hits snap to: 1/4, 1/8 or 1/16.
  QuantizeGrid get quantizeGrid => _quantizeGrid;

  /// What the QUANTIZE button says: "QNT 1/16" or "QNT OFF".
  String get quantizeLabel => _quantize ? 'QNT ${_quantizeGrid.label}' : 'QNT OFF';

  /// One grid step at the current tempo, e.g. 166ms for 1/16 at 90 BPM.
  Duration get quantizeStep => Duration(
        microseconds:
            (barDuration.inMicroseconds / _quantizeGrid.divisionsPerBar).round(),
      );

  /// What quantise did to the loop that just closed, e.g.
  /// `QNT 1/16 - 4 BARS`. Null until a loop has been captured; cleared when the
  /// deck is armed again or wiped.
  String? get loopSummary => _loopSummary;

  /// What the looper records: pads, microphone, or both.
  RecordSource get source => _source;

  /// True when [source] needs the microphone. In PADS mode the mic is never
  /// opened at all -- no permission prompt, no room noise.
  bool get usesMic => recordSourceUsesMic(_source);

  /// True when [source] captures pad hits as events.
  bool get usesPads => recordSourceUsesPads(_source);

  double get thresholdDb => _thresholdDb;

  /// Most recent microphone level in dBFS (roughly -60 quiet .. 0 loud). Only
  /// updates while the mic is actually open.
  double get inputLevelDb => _inputLevelDb;

  /// True while the mic is open and the level meter is live.
  bool get isListening =>
      usesMic &&
      (_state == LoopState.armed ||
          _state == LoopState.recording ||
          _state == LoopState.overdubbing);

  /// One bar at the current tempo, assuming 4/4.
  Duration get barDuration =>
      Duration(microseconds: (4 * 60 / _bpm * 1000000).round());

  /// The fixed loop length at the current tempo and bar count, or
  /// [Duration.zero] when the length is FREE.
  Duration get loopDuration => isFreeLength
      ? Duration.zero
      : Duration(microseconds: (_bars * 4 * 60 / _bpm * 1000000).round());

  /// Tempo can't be changed once a loop has been captured, because the
  /// recorded audio and the captured pad hits are already locked to it. It is
  /// still free to change while merely ARMED, since nothing is recorded yet.
  bool get isTempoLocked => _state == LoopState.recording || hasLoop;

  /// True when the microphone can bleed the loop back into a new layer -- i.e.
  /// a mic-using source, where overdubbing through the phone's speaker records
  /// the loop all over again. The UI uses this for its "wear headphones" note.
  bool get micCanBleed => usesMic;

  // --- State ------------------------------------------------------------

  LoopState _state = LoopState.empty;
  LoopState get state => _state;

  /// What the deck is doing, for the LCD.
  String get stateLabel {
    switch (_state) {
      case LoopState.empty:
        return 'EMPTY';
      case LoopState.armed:
        return 'ARMED';
      case LoopState.recording:
        return 'REC';
      case LoopState.overdubbing:
        return 'OVERDUB';
      case LoopState.playing:
        return 'PLAY';
      case LoopState.stopped:
        return 'STOP';
    }
  }

  /// What the **next tap** on the LOOP pad will do. The pad shows this rather
  /// than a fixed "LOOP" caption, because the whole flow hangs on knowing what
  /// the button is about to do -- ambiguity here was the single biggest source
  /// of confusion in testing.
  String get loopPadLabel {
    switch (_state) {
      case LoopState.empty:
        return 'ARM';
      case LoopState.armed:
        return 'REC';
      case LoopState.recording:
        return 'END REC';
      case LoopState.playing:
        return 'DUB';
      case LoopState.overdubbing:
        return 'END DUB';
      case LoopState.stopped:
        return 'PLAY';
    }
  }

  bool get hasLoop =>
      _loopClipId != null || _pendingClipId != null || _events.isNotEmpty;

  /// True while a new layer is being recorded over the top of the loop.
  bool get isOverdubbing => _state == LoopState.overdubbing;

  /// How many layers the loop is made of: 1 is just the base pass, 2 means one
  /// overdub on top of it, and so on. Shown on the LCD as "LAYERS 3".
  int get layerCount => _layers.length;

  /// True when there is an overdub layer that UNDO can take back off. The base
  /// layer can never be undone (clear the loop instead), and undo is only
  /// offered when the deck is settled -- while a layer is actually being
  /// recorded, STOP is the control that throws it away.
  bool get canUndo =>
      _layers.length > 1 &&
      (_state == LoopState.playing || _state == LoopState.stopped);

  /// True whenever the reels should be turning.
  bool get isTransportRunning =>
      _state == LoopState.recording ||
      _state == LoopState.playing ||
      _state == LoopState.overdubbing;

  /// True whenever the record lamp should be lit: capturing the base pass, or
  /// capturing a new layer over the top of a playing loop.
  bool get isCapturing =>
      _state == LoopState.recording || _state == LoopState.overdubbing;

  final StreamController<String> _messages = StreamController<String>.broadcast();

  /// Short "LOOP CLEARED" style notices for the UI to flash up.
  Stream<String> get messages => _messages.stream;

  /// Fires while the transport is moving, roughly 15 times a second.
  ///
  /// **Listen to this, not to the deck, for anything that shows the playhead**
  /// (the reels, the loop clock, the waveform's playhead). The deck's own
  /// `notifyListeners()` is reserved for things that actually change shape --
  /// state, layers, settings -- so a loop simply playing no longer rebuilds
  /// the whole panel on every tick. See VERSION 5 in PROJECT_NOTES.md.
  final TickNotifier transportTicks = TickNotifier();

  /// Microphone level, in dBFS, for the input meter. Separate for the same
  /// reason as [transportTicks].
  final ValueNotifier<double> inputLevelNotifier =
      ValueNotifier<double>(minThresholdDb);

  /// What the waveform display should draw. Rebuilt only when the loop's
  /// contents change -- never on a tick.
  final ValueNotifier<LoopVisual> loopVisual =
      ValueNotifier<LoopVisual>(const LoopVisual());

  /// Decides which recorded hits are due. Pure Dart, unit-tested; see
  /// `lib/tape/loop_events.dart`.
  final LoopScheduler _scheduler = LoopScheduler();

  // Working state for the current pass.
  Duration _position = Duration.zero;
  Duration _t0 = Duration.zero;
  Duration _recordedLoopDuration = Duration.zero;
  int? _loopBars;
  String? _tempRecordingPath;
  String? _loopFilePath;
  int? _loopClipId;

  /// Every pad event of every layer, sorted by offset. Rebuilt from [_layers]
  /// whenever a layer is added or removed, so it can never disagree with them.
  List<LoopPadEvent> _events = [];

  /// Pad hits captured so far in the pass being recorded (base or overdub).
  final List<LoopPadEvent> _capturing = [];

  /// The layers the loop is made of. `_layers[0]` is the base pass and is never
  /// removed by UNDO. Length is capped at `1 + maxOverdubLayers`.
  final List<_LoopLayer> _layers = [];

  // A freshly mixed master loop that is loaded and ready but has not been swapped
  // in yet. See _applyPendingMaster: the swap happens on the loop boundary so the
  // audio and the loop clock never fall out of step.
  String? _pendingMasterPath;
  int? _pendingClipId;

  // The overdub pass in progress.
  String? _overdubTempPath;
  int? _overdubMicOffsetMs;
  int _overdubStartMs = 0;

  Stopwatch? _armClock;
  Stopwatch? _transportClock;
  Timer? _tick;
  Timer? _recordEndTimer;
  StreamSubscription<Amplitude>? _ampSub;

  /// Which pass of the loop playback is on. Only ever compared for change, so
  /// it does not matter that it grows; an int can count loop passes for longer
  /// than any phone will stay awake.
  int _passIndex = 0;

  /// When the playhead readouts were last refreshed, on the transport clock's
  /// own scale. The tick itself runs fast (for hit timing); the UI is refreshed
  /// from it at a fraction of that rate.
  int _lastUiPublishMs = -1;

  /// What quantise did to the loop that just closed, for the LCD.
  String? _loopSummary;

  /// Bumped every time a waveform recompute is started, so a slow read of an
  /// old master can never overwrite a newer one.
  int _visualGeneration = 0;

  bool _busy = false;
  bool _disposed = false;

  final List<DateTime> _taps = [];

  /// How far into the current loop pass we are.
  Duration get position => _position;

  /// The length of the loop that was actually captured (after quantising).
  Duration get recordedLoopDuration => _recordedLoopDuration;

  /// How many whole bars the finished loop came out at, or null when the loop
  /// wasn't quantised (or there is no loop).
  int? get loopBars => _loopBars;

  /// The finished loop's length, spelled out for the LCD -- e.g. "4 BARS 8.0s"
  /// when quantised, "6.3s" when not. Before anything is recorded it shows what
  /// is *set*: "FREE" or "8 BARS".
  String get loopLengthLabel {
    // While recording, _recordedLoopDuration is still zero (the length isn't
    // decided until the loop closes), so this falls through to the *setting*.
    if (_recordedLoopDuration > Duration.zero) {
      final seconds = (_recordedLoopDuration.inMilliseconds / 1000).toStringAsFixed(1);
      final bars = _loopBars;
      if (bars != null) return '$bars BAR${bars == 1 ? '' : 'S'} ${seconds}s';
      return '${seconds}s';
    }
    return isFreeLength ? 'FREE' : '$_bars BARS';
  }

  /// 0.0-1.0 through the current pass; drives the reels. While recording a
  /// FREE-length loop there is no end to head towards, so this cycles once per
  /// bar instead, which keeps the reels moving in time.
  double get progress {
    final Duration total;
    if (_state == LoopState.recording) {
      total = isFreeLength ? barDuration : loopDuration;
    } else if (_state == LoopState.playing || _state == LoopState.overdubbing) {
      total = _recordedLoopDuration > Duration.zero ? _recordedLoopDuration : barDuration;
    } else {
      return 0;
    }
    if (total.inMicroseconds <= 0) return 0;
    var value = _position.inMicroseconds / total.inMicroseconds;
    if (_state == LoopState.recording && isFreeLength) {
      value = value % 1.0;
    }
    return value.clamp(0.0, 1.0).toDouble();
  }

  /// Bars still to go while recording a fixed-length loop (counts down 4, 3,
  /// 2, 1). Meaningless -- and unused -- in FREE mode.
  int get barsRemaining {
    if (isFreeLength) return 0;
    final oneBar = barDuration.inMicroseconds;
    if (oneBar <= 0) return _bars;
    final done = _position.inMicroseconds ~/ oneBar;
    final left = _bars - done;
    return left < 0 ? 0 : left;
  }

  /// How many bars the current FREE take has been running for, rounded up --
  /// what quantise is heading towards, so the LCD can show it live.
  int get barsElapsed {
    final oneBar = barDuration.inMicroseconds;
    if (oneBar <= 0) return 0;
    return (_position.inMicroseconds / oneBar).ceil();
  }

  /// Number of pad hits in the loop, including the ones being added by a pass
  /// that is still in progress.
  int get eventCount {
    if (_state == LoopState.recording) return _capturing.length;
    if (_state == LoopState.overdubbing) return _events.length + _capturing.length;
    return _events.length;
  }

  /// Where in the loop the overdub in progress was engaged, in milliseconds.
  /// Shown on the LCD so it is obvious the layer is being dropped in mid-loop
  /// rather than from the top.
  int get overdubStartMs => _overdubStartMs;

  /// Where we are in the loop right now, in milliseconds from the loop's start.
  ///
  /// This is *the* authoritative answer to "where is the tape". [_transportClock]
  /// is a single free-running stopwatch started when playback began; the loop
  /// position is simply its elapsed time modulo the loop's length. Everything
  /// that has to line up with the loop -- an overdub's starting offset, a pad
  /// hit's stored position, where a recorded layer gets mixed in -- is derived
  /// from this one number, so nothing can drift relative to anything else.
  int _loopPositionMs() {
    final clock = _transportClock;
    final loopMs = _recordedLoopDuration.inMilliseconds;
    if (clock == null || loopMs <= 0) return 0;
    final elapsed = clock.elapsedMilliseconds;
    if (elapsed <= 0) return 0;
    return elapsed - (elapsed ~/ loopMs) * loopMs;
  }

  void _notify() {
    if (_disposed) return;
    notifyListeners();
  }

  void _say(String message) {
    if (_disposed || _messages.isClosed) return;
    _messages.add(message);
  }

  /// Sets the microphone level and tells the meter (only the meter).
  void _setInputLevel(double db) {
    _inputLevelDb = db;
    if (_disposed) return;
    inputLevelNotifier.value = db;
  }

  // --- Settings controls ------------------------------------------------

  /// Sets the tempo, clamped to something musically sane.
  void setBpm(double value) {
    if (isTempoLocked) {
      _say('Clear the loop before changing tempo');
      return;
    }
    final clamped = value.clamp(40.0, 240.0).toDouble();
    if ((clamped - _bpm).abs() < 0.01) return;
    _bpm = clamped;
    _notify();
  }

  void nudgeBpm(double delta) => setBpm(_bpm + delta);

  /// Sets the loop length: [freeBars] for FREE, or 4 / 8 / 16 bars. With a
  /// fixed length the recording also stops itself once that many bars have
  /// gone by; the second tap on LOOP still ends it early.
  void setBars(int value) {
    if (isTempoLocked) {
      _say('Clear the loop before changing length');
      return;
    }
    if (!selectableBars.contains(value) || value == _bars) return;
    _bars = value;
    _notify();
  }

  /// Turns quantise on or off.
  ///
  /// This is **not** just a setting for the next take: the raw, as-played
  /// timing of every hit already in the loop is kept alongside its snapped
  /// position, so flipping this re-times the loop that is already playing --
  /// on gives you the grid, off gives you your own feel back. Nothing is lost
  /// either way.
  void toggleQuantize() {
    _quantize = !_quantize;
    unawaited(SettingsService.instance.setQuantizeOn(_quantize));
    _rebuildEvents();
    _updateLoopSummary();
    _say(_quantize
        ? 'Quantise ON - hits snap to ${_quantizeGrid.label}'
        : 'Quantise OFF - hits play exactly as you played them');
    _notify();
  }

  /// One button's worth of quantise: **OFF -> 1/4 -> 1/8 -> 1/16 -> OFF**.
  ///
  /// The deck's face has one row for the source *and* quantise now (the
  /// waveform display took the row quantise used to have all to itself), so the
  /// four separate quantise buttons became one that cycles -- the same
  /// arrangement a hardware groovebox uses when it is short of a button. Every
  /// division is still directly selectable in the TUNE sheet, and the LCD
  /// always spells out which one is live.
  void cycleQuantize() {
    if (!_quantize) {
      // Off -> on at the first division.
      _quantizeGrid = QuantizeGrid.values.first;
      unawaited(SettingsService.instance.setQuantizeGridName(_quantizeGrid.name));
      toggleQuantize();
      return;
    }
    final index = QuantizeGrid.values.indexOf(_quantizeGrid);
    if (index < 0 || index >= QuantizeGrid.values.length - 1) {
      // Past the last division: back to off.
      toggleQuantize();
      return;
    }
    setQuantizeGrid(QuantizeGrid.values[index + 1]);
  }

  /// Chooses the division hits snap to (1/4, 1/8, 1/16). Re-times the loop
  /// that is already playing, for the same reason as [toggleQuantize].
  void setQuantizeGrid(QuantizeGrid grid) {
    if (grid == _quantizeGrid) return;
    _quantizeGrid = grid;
    unawaited(SettingsService.instance.setQuantizeGridName(grid.name));
    if (_quantize) {
      _rebuildEvents();
      _updateLoopSummary();
      _say('Quantise ${grid.label}');
    }
    _notify();
  }

  /// Chooses what gets recorded. Refused while a loop exists (or is being
  /// made), because half the loop would then be from a different source --
  /// clear it first.
  void setSource(RecordSource value) {
    if (value == _source) return;
    if (_state != LoopState.empty) {
      _say('Clear the loop before changing the source');
      return;
    }
    _source = value;
    _setInputLevel(minThresholdDb);
    _notify();
  }

  /// Tap this button in time with the music a few times and the tempo follows.
  /// Taps more than two seconds apart start a fresh measurement.
  void tapTempo() {
    final now = DateTime.now();
    if (_taps.isNotEmpty && now.difference(_taps.last) > const Duration(seconds: 2)) {
      _taps.clear();
    }
    _taps.add(now);
    if (_taps.length > 5) _taps.removeAt(0);
    if (_taps.length >= 2) {
      var totalMs = 0;
      for (var i = 1; i < _taps.length; i++) {
        totalMs += _taps[i].difference(_taps[i - 1]).inMilliseconds;
      }
      final averageMs = totalMs / (_taps.length - 1);
      if (averageMs > 0) {
        setBpm(60000 / averageMs);
      }
    }
    _notify();
  }

  /// Threshold (in dBFS) the microphone has to cross before an armed loop
  /// starts counting. Only used in MIC/BOTH mode.
  void setThresholdDb(double value) {
    final clamped = value.clamp(minThresholdDb, maxThresholdDb).toDouble();
    if ((clamped - _thresholdDb).abs() < 0.01) return;
    _thresholdDb = clamped;
    _notify();
  }

  /// Restores the quantise settings saved on the last run. Called once by
  /// `AppState.init`, after [SettingsService.load] has finished.
  void applySavedSettings() {
    final settings = SettingsService.instance;
    _quantize = settings.quantizeOn ?? _quantize;
    _quantizeGrid = quantizeGridFromName(settings.quantizeGridName);
    _notify();
  }

  // --- The two tape-deck pads -------------------------------------------

  /// What the big LOOP pad does, which depends on where we are in the state
  /// machine -- see [loopPadLabel], which is what the pad actually says.
  ///
  /// The full cycle from cold: **ARM → REC → END REC → DUB → END DUB → DUB →
  /// END DUB → ...**, one more layer for every pair of taps.
  Future<void> tapLoopPad() async {
    if (_busy) return;
    switch (_state) {
      case LoopState.empty:
        await _arm();
        break;
      case LoopState.armed:
        // Impatient start: don't wait for a pad hit, go now.
        _beginRecording();
        break;
      case LoopState.recording:
        await endRecording();
        break;
      case LoopState.stopped:
        await _startPlayback();
        break;
      case LoopState.playing:
        // The loop keeps playing; a new layer starts recording over it.
        await _startOverdub();
        break;
      case LoopState.overdubbing:
        await endOverdub();
        break;
    }
  }

  /// What the STOP pad does.
  Future<void> tapStopPad() async {
    if (_busy) return;
    switch (_state) {
      case LoopState.playing:
        await _stopPlayback();
        break;
      case LoopState.overdubbing:
        // Throw away the layer being recorded, but not the ones already
        // committed -- this is the escape hatch for a botched overdub.
        await _cancelOverdub();
        break;
      case LoopState.armed:
        await _cancelTake(message: 'Arming cancelled');
        break;
      case LoopState.recording:
        await _cancelTake(message: 'Recording discarded');
        break;
      case LoopState.empty:
      case LoopState.stopped:
        break;
    }
  }

  /// Hold-to-clear: throws away every layer -- the recorded audio, the undo
  /// history and the captured pad hits -- and returns the deck to EMPTY.
  Future<void> clearAll() async {
    if (_busy) return;
    _busy = true;
    try {
      _stopTick();
      _recordEndTimer?.cancel();
      _recordEndTimer = null;
      await _ampSub?.cancel();
      _ampSub = null;
      await _closeMic();

      final clipId = _loopClipId;
      final pendingClipId = _pendingClipId;
      _loopClipId = null;
      _pendingClipId = null;
      if (clipId != null) {
        await AudioEngine.instance.unloadClip(clipId);
      }
      if (pendingClipId != null) {
        await AudioEngine.instance.unloadClip(pendingClipId);
      }

      // Every master that any layer could have been undone back to goes too --
      // this is the one place that is allowed to delete them all.
      final files = <String?>[
        _tempRecordingPath,
        _overdubTempPath,
        _loopFilePath,
        _pendingMasterPath,
        for (final layer in _layers) layer.previousMasterPath,
      ];
      for (final path in files) {
        await RecordingsRepository.deleteQuietly(path);
      }
      _tempRecordingPath = null;
      _overdubTempPath = null;
      _loopFilePath = null;
      _pendingMasterPath = null;

      _layers.clear();
      _events = const [];
      _capturing.clear();
      _scheduler.reset(loopMs: 0);
      _overdubMicOffsetMs = null;
      _overdubStartMs = 0;
      _passIndex = 0;
      _position = Duration.zero;
      _t0 = Duration.zero;
      _recordedLoopDuration = Duration.zero;
      _loopBars = null;
      _loopSummary = null;
      _armClock = null;
      _transportClock = null;
      _setInputLevel(minThresholdDb);
      _visualGeneration++;
      loopVisual.value = const LoopVisual();
      _state = LoopState.empty;
      _say('LOOP CLEARED');
      _notify();
    } finally {
      _busy = false;
    }
  }

  // --- Arming / recording -----------------------------------------------

  /// Closes the microphone if we have it open. A no-op in PADS mode, where we
  /// never opened it in the first place.
  Future<void> _closeMic() async {
    if (MicArbiter.owner != MicArbiter.looper) return;
    try {
      await _recorder.stop();
    } catch (e) {
      debugPrint('TapeDeck: stopping the recorder failed: $e');
    } finally {
      MicArbiter.release(MicArbiter.looper);
    }
  }

  Future<void> _arm() async {
    _busy = true;
    try {
      _capturing.clear();
      _events = const [];
      _layers.clear();
      _scheduler.reset(loopMs: 0);
      _position = Duration.zero;
      _t0 = Duration.zero;
      _recordedLoopDuration = Duration.zero;
      _loopBars = null;
      _loopSummary = null;
      _visualGeneration++;
      loopVisual.value = const LoopVisual();
      _setInputLevel(minThresholdDb);

      // PADS mode: no microphone at all. Nothing to open, nothing to ask
      // permission for -- we simply wait for the first pad hit.
      if (!usesMic) {
        _armClock = Stopwatch()..start();
        _state = LoopState.armed;
        _say('Armed - hit a pad to start');
        _notify();
        return;
      }

      if (!MicArbiter.acquire(MicArbiter.looper)) {
        _say('The recorder is using the microphone');
        return;
      }

      // Only now, the first time a mic-using mode is actually engaged, do we
      // ask the OS for the microphone.
      final allowed = await _recorder.hasPermission();
      if (!allowed) {
        MicArbiter.release(MicArbiter.looper);
        _say('Microphone permission denied');
        return;
      }

      final dir = await RecordingsRepository.loopDir();
      final tempPath = p.join(
        dir.path,
        'loop_take_${DateTime.now().millisecondsSinceEpoch}.wav',
      );

      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.wav,
          sampleRate: 44100,
          numChannels: 1,
        ),
        path: tempPath,
      );

      _tempRecordingPath = tempPath;
      _armClock = Stopwatch()..start();
      _state = LoopState.armed;
      _startTick();

      await _ampSub?.cancel();
      _ampSub = _recorder
          .onAmplitudeChanged(const Duration(milliseconds: 50))
          .listen(_onAmplitude, onError: (Object e) {
        debugPrint('TapeDeck: amplitude stream error: $e');
      });

      _say('Armed - play to start');
      _notify();
    } catch (e) {
      MicArbiter.release(MicArbiter.looper);
      _state = LoopState.empty;
      debugPrint('TapeDeck: arming failed: $e');
      _say('Could not open the microphone');
      _notify();
    } finally {
      _busy = false;
    }
  }

  void _onAmplitude(Amplitude amplitude) {
    if (!usesMic) return;
    final raw = amplitude.current;
    final level = raw.isFinite ? raw.clamp(-80.0, 0.0).toDouble() : -80.0;
    // Only the meter changes, so only the meter is told -- a level update must
    // not rebuild the deck (and it certainly must not do so while a loop is
    // playing over the top of an overdub).
    _setInputLevel(level);
    if (_state == LoopState.armed && level >= _thresholdDb) {
      _beginRecording();
    }
  }

  /// The loop clock starts here, at t=0. [_t0] records how far into the raw
  /// microphone file this moment is, so the "waiting to start" portion can be
  /// snipped off the front later.
  void _beginRecording() {
    if (_state != LoopState.armed) return;
    _t0 = _armClock?.elapsed ?? Duration.zero;
    _transportClock = Stopwatch()..start();
    _position = Duration.zero;
    _recordedLoopDuration = Duration.zero;
    _loopBars = null;
    _state = LoopState.recording;

    _recordEndTimer?.cancel();
    _recordEndTimer = null;
    if (!isFreeLength) {
      // A fixed length still auto-stops, exactly as it used to. The second tap
      // on LOOP can always end it early.
      _recordEndTimer = Timer(loopDuration, () => unawaited(endRecording()));
    }

    _startTick();
    _say(isFreeLength ? 'Recording - tap END to close the loop' : 'Recording $_bars bars');
    _notify();
  }

  /// Called by `AppState` every time a pad is hit by hand or by hardware MIDI.
  /// Silently does nothing unless we're arming or recording.
  ///
  /// A pad hit always *starts* an armed loop, whatever the source -- it is the
  /// most reliable "I have begun" signal there is. Whether the hit is also
  /// *stored* depends on the source: MIC mode records only the microphone.
  ///
  /// While overdubbing the offset is taken **modulo the loop length**, so a hit
  /// played three quarters of the way round lands three quarters of the way
  /// round, no matter which pass of the loop you were on when you played it.
  void capturePadHit(String padId, int velocity) {
    if (_state == LoopState.armed) {
      _beginRecording();
      if (usesPads) {
        _capturing.add(LoopPadEvent(padId: padId, offsetMs: 0, velocity: velocity));
      }
      return;
    }
    if (!usesPads) return;

    if (_state == LoopState.recording) {
      final clock = _transportClock;
      if (clock == null) return;
      var offset = clock.elapsedMilliseconds;
      if (offset < 0) offset = 0;
      _capturing.add(LoopPadEvent(padId: padId, offsetMs: offset, velocity: velocity));
      return;
    }

    if (_state == LoopState.overdubbing) {
      _capturing.add(LoopPadEvent(
        padId: padId,
        offsetMs: _loopPositionMs(),
        velocity: velocity,
        layer: _layers.length,
      ));
    }
  }

  /// Closes the loop: works out its final length, renders the take to match,
  /// and starts playing it back straight away.
  ///
  /// Called by the second tap on LOOP, and by the auto-stop timer when a fixed
  /// bar count is selected.
  Future<void> endRecording() async {
    if (_state != LoopState.recording) return;

    final raw = _transportClock?.elapsed ?? Duration.zero;
    if (!_quantize && raw < minFreeLoopLength) {
      // Almost certainly a double tap rather than a 0.1s loop.
      _say('Too short - keep playing');
      return;
    }

    _busy = true;
    try {
      _stopTick();
      _recordEndTimer?.cancel();
      _recordEndTimer = null;
      await _ampSub?.cancel();
      _ampSub = null;

      String? rawPath;
      if (usesMic) {
        try {
          rawPath = await _recorder.stop();
        } catch (e) {
          debugPrint('TapeDeck: recorder stop failed: $e');
        } finally {
          MicArbiter.release(MicArbiter.looper);
        }
        rawPath ??= _tempRecordingPath;
      }

      final length = _finalLength(raw);
      _recordedLoopDuration = length;

      // The base layer keeps every hit at its raw, as-played time.
      // _rebuildEvents (below, once the layer exists) is what turns those into
      // playback positions: wrapped into the loop and, with quantise on,
      // snapped to the grid. Nothing is ever dropped for landing a few
      // milliseconds past the end -- musically that hit belongs on the
      // downbeat, which is position 0 of the next pass.
      final captured = List<LoopPadEvent>.from(_capturing);
      _capturing.clear();

      if (rawPath != null) {
        final loopPath = await _renderTake(rawPath, length);
        await RecordingsRepository.deleteQuietly(rawPath);
        _tempRecordingPath = null;
        if (loopPath != null) {
          _loopFilePath = loopPath;
          _loopClipId = await AudioEngine.instance.loadClip(loopPath);
        }
      }

      if (_loopClipId == null && captured.isEmpty) {
        // Nothing usable came out of it: don't leave a stray render behind.
        await RecordingsRepository.deleteQuietly(_loopFilePath);
        _loopFilePath = null;
        _layers.clear();
        _events = const [];
        _state = LoopState.empty;
        _recordedLoopDuration = Duration.zero;
        _loopBars = null;
        _say('Nothing was recorded');
        _notify();
        return;
      }

      // Layer 0. It is the one layer UNDO can never remove -- and the one that
      // fixes the loop's length for every layer that follows.
      _layers
        ..clear()
        ..add(_LoopLayer(
          events: captured,
          changedMaster: _loopClipId != null,
        ));
      _rebuildEvents();
      _updateLoopSummary();
      unawaited(_refreshVisual());

      _say(_loopSummary ?? 'LOOP $loopLengthLabel');
    } finally {
      _busy = false;
    }
    await _startPlayback();
  }

  /// Works out how long the finished loop should be.
  ///
  /// With quantise **on**:
  ///
  ///  * a fixed length (4 / 8 / 16 bars) is **enforced exactly** -- the loop is
  ///    that many bars at the current tempo, full stop. Ending the take early
  ///    or letting the auto-stop timer land a few milliseconds out no longer
  ///    changes the length, which is what "quantise to the number of bars I
  ///    selected" has to mean if two loops are ever to line up;
  ///  * FREE rounds to the nearest whole bar, never shorter than one.
  ///
  /// With quantise **off** the loop is exactly as long as you played.
  Duration _finalLength(Duration raw) {
    final barUs = barDuration.inMicroseconds;
    if (_quantize && barUs > 0) {
      if (!isFreeLength) {
        _loopBars = _bars;
        return Duration(microseconds: _bars * barUs);
      }
      var wholeBars = (raw.inMicroseconds / barUs).round();
      if (wholeBars < 1) wholeBars = 1;
      _loopBars = wholeBars;
      return Duration(microseconds: wholeBars * barUs);
    }
    _loopBars = null;
    return raw;
  }

  /// Writes the one-line "here is what quantise just did" the LCD shows after a
  /// loop closes, e.g. `QNT 1/16 - 4 BARS` or `QNT OFF - 6.3s`.
  void _updateLoopSummary() {
    if (_recordedLoopDuration <= Duration.zero) {
      _loopSummary = null;
      return;
    }
    final bars = _loopBars;
    final seconds = (_recordedLoopDuration.inMilliseconds / 1000).toStringAsFixed(1);
    final length = bars != null ? '$bars BAR${bars == 1 ? '' : 'S'}' : '${seconds}s';
    _loopSummary = '$quantizeLabel · $length';
  }

  /// Turns the raw microphone take into a file that is exactly [length] long:
  /// the "waiting for you to start" portion is cut off the front, anything past
  /// the end is trimmed, and if the take came up short the end is padded with
  /// silence. Returns the new file's path, or null.
  Future<String?> _renderTake(String rawPath, Duration length) async {
    try {
      final file = File(rawPath);
      if (!await file.exists()) return null;
      final bytes = await file.readAsBytes();

      final trimmed = trimWav(bytes, start: _t0, length: length);
      if (trimmed == null) return null;
      final rendered = padWavWithSilence(trimmed, targetLength: length) ?? trimmed;
      if (rendered.length <= 44) return null;

      final dir = await RecordingsRepository.loopDir();
      final outPath = p.join(
        dir.path,
        'loop_${DateTime.now().millisecondsSinceEpoch}.wav',
      );
      await File(outPath).writeAsBytes(rendered, flush: true);
      return outPath;
    } catch (e) {
      debugPrint('TapeDeck: rendering the loop take failed: $e');
      return null;
    }
  }

  // --- Overdubbing ------------------------------------------------------

  /// The master loop audio a new layer should be mixed on top of: whatever is
  /// staged to be swapped in next if there is anything, otherwise what is
  /// playing. Overdubbing again before the previous layer has reached the loop
  /// seam therefore still stacks properly.
  String? _masterForMixing() => _pendingMasterPath ?? _loopFilePath;

  /// True when [path] is still some layer's undo target, and so must not be
  /// deleted. Every master file is either the one playing, the one staged, or a
  /// layer's way back -- this is the check that keeps undo from being handed a
  /// file that has already been cleaned up.
  bool _isMasterReferenced(String path) =>
      _layers.any((layer) => layer.previousMasterPath == path);

  /// Starts recording a new layer over the top of the loop that is playing.
  ///
  /// The loop does not stop, restart or change length; recording simply begins
  /// wherever the playhead happens to be, and wraps around the end of the loop
  /// as many times as you let it run.
  Future<void> _startOverdub() async {
    if (_state != LoopState.playing) return;
    if (_recordedLoopDuration <= Duration.zero) {
      _say('Nothing to overdub onto');
      return;
    }
    if (_layers.length > maxOverdubLayers) {
      _say('$maxOverdubLayers overdub layers is the limit - undo one first');
      return;
    }

    _busy = true;
    try {
      _capturing.clear();
      _overdubMicOffsetMs = null;
      _overdubStartMs = _loopPositionMs();

      if (usesMic) {
        if (!MicArbiter.acquire(MicArbiter.looper)) {
          _say('The recorder is using the microphone');
          return;
        }
        final allowed = await _recorder.hasPermission();
        if (!allowed) {
          MicArbiter.release(MicArbiter.looper);
          _say('Microphone permission denied');
          return;
        }

        final dir = await RecordingsRepository.loopDir();
        final path = p.join(
          dir.path,
          'overdub_${DateTime.now().millisecondsSinceEpoch}.wav',
        );
        await _recorder.start(
          const RecordConfig(
            encoder: AudioEncoder.wav,
            sampleRate: 44100,
            numChannels: 1,
          ),
          path: path,
        );
        _overdubTempPath = path;

        // Read the loop clock *after* start() has returned, not before: opening
        // the microphone takes a moment on a phone, and the first sample in the
        // file belongs at the position the loop had reached by then, not at the
        // position it had when the pad was tapped.
        _overdubMicOffsetMs = _loopPositionMs();

        await _ampSub?.cancel();
        _ampSub = _recorder
            .onAmplitudeChanged(const Duration(milliseconds: 50))
            .listen(_onAmplitude, onError: (Object e) {
          debugPrint('TapeDeck: amplitude stream error: $e');
        });
      }

      _state = LoopState.overdubbing;
      _say(usesMic
          ? 'Overdubbing - use headphones, tap END DUB to keep it'
          : 'Overdubbing - tap END DUB to keep it');
      _notify();
    } catch (e) {
      MicArbiter.release(MicArbiter.looper);
      debugPrint('TapeDeck: starting the overdub failed: $e');
      _state = LoopState.playing;
      _say('Could not start the overdub');
      _notify();
    } finally {
      _busy = false;
    }
  }

  /// Ends the overdub and folds the layer into the loop.
  ///
  /// Pad events join the others straight away; mixed-down microphone audio is
  /// staged and swapped in at the next loop seam (see [_applyPendingMaster]).
  Future<void> endOverdub() async {
    if (_state != LoopState.overdubbing) return;

    _busy = true;
    try {
      String? rawPath;
      if (usesMic) {
        await _ampSub?.cancel();
        _ampSub = null;
        try {
          rawPath = await _recorder.stop();
        } catch (e) {
          debugPrint('TapeDeck: stopping the overdub recorder failed: $e');
        } finally {
          MicArbiter.release(MicArbiter.looper);
        }
        rawPath ??= _overdubTempPath;
      }
      _overdubTempPath = null;

      final events = List<LoopPadEvent>.from(_capturing);
      _capturing.clear();

      final micOffsetMs = _overdubMicOffsetMs;
      _overdubMicOffsetMs = null;

      var changedMaster = false;
      String? previousMaster;
      if (rawPath != null && micOffsetMs != null) {
        previousMaster = _masterForMixing();
        changedMaster = await _mixOverdubIntoMaster(
          rawPath,
          Duration(milliseconds: micOffsetMs),
        );
        if (!changedMaster) previousMaster = null;
      }
      await RecordingsRepository.deleteQuietly(rawPath);

      _state = LoopState.playing;
      if (events.isEmpty && !changedMaster) {
        _say('Nothing was added');
        _notify();
        return;
      }

      _layers.add(_LoopLayer(
        events: events,
        changedMaster: changedMaster,
        previousMasterPath: previousMaster,
      ));
      _rebuildEvents();
      _say('LAYERS ${_layers.length}');
      _notify();
    } finally {
      _busy = false;
    }
  }

  /// Throws away the layer being recorded, leaving every committed layer alone.
  Future<void> _cancelOverdub() async {
    if (_state != LoopState.overdubbing) return;
    _busy = true;
    try {
      await _ampSub?.cancel();
      _ampSub = null;
      await _closeMic();
      await RecordingsRepository.deleteQuietly(_overdubTempPath);
      _overdubTempPath = null;
      _overdubMicOffsetMs = null;
      _capturing.clear();
      _state = LoopState.playing;
      _say('Overdub cancelled');
      _notify();
    } finally {
      _busy = false;
    }
  }

  /// Sums the overdub take into the master loop WAV at [offset] into the loop,
  /// wrapping round the end, and stages the result. Returns true if the master
  /// actually changed.
  ///
  /// The mix is written to a **new** file rather than over the old one, for two
  /// reasons: the old file is what UNDO restores, and the audio engine keeps a
  /// decoded copy of a file in memory, so overwriting the path it was loaded
  /// from would change nothing you can hear.
  Future<bool> _mixOverdubIntoMaster(String overdubPath, Duration offset) async {
    try {
      final file = File(overdubPath);
      if (!await file.exists()) return false;
      final overlay = await file.readAsBytes();
      final overlayInfo = readWavInfo(overlay);
      if (overlayInfo == null || overlayInfo.dataLength <= 0) return false;

      Uint8List? master;
      final basePath = _masterForMixing();
      if (basePath != null) {
        final baseFile = File(basePath);
        if (await baseFile.exists()) master = await baseFile.readAsBytes();
      }
      // No master audio yet (a BOTH loop whose base pass was pads only): lay
      // down a silent bed of exactly the loop's length and mix onto that.
      final bed = master ??
          buildSilentWav(
            sampleRate: overlayInfo.sampleRate,
            numChannels: overlayInfo.numChannels,
            length: _recordedLoopDuration,
          );

      final mixed = mixWavIntoLoop(bed, overlay, offset: offset);
      if (mixed == null || mixed.length <= 44) return false;

      final dir = await RecordingsRepository.loopDir();
      final outPath = p.join(
        dir.path,
        'loop_${DateTime.now().millisecondsSinceEpoch}_${_layers.length}.wav',
      );
      await File(outPath).writeAsBytes(mixed, flush: true);

      final clipId = await AudioEngine.instance.loadClip(outPath);
      if (clipId == null) {
        await RecordingsRepository.deleteQuietly(outPath);
        return false;
      }

      // Supersede a master that was staged but has not reached the seam yet.
      // Its *file* stays -- it is about to become this layer's undo target.
      final superseded = _pendingClipId;
      _pendingClipId = clipId;
      _pendingMasterPath = outPath;
      if (superseded != null) {
        unawaited(AudioEngine.instance.unloadClip(superseded));
      }
      return true;
    } catch (e) {
      debugPrint('TapeDeck: mixing the overdub into the loop failed: $e');
      return false;
    }
  }

  /// Swaps a freshly mixed master in for the one playing.
  ///
  /// Called only where it is safe: at the loop seam, or when nothing is
  /// sounding. The old master's decoded copy is freed but **its file is kept**,
  /// because that file is a layer's way back.
  void _applyPendingMaster({required bool play}) {
    final newClipId = _pendingClipId;
    final newPath = _pendingMasterPath;
    if (newClipId == null && newPath == null) return;

    final oldClipId = _loopClipId;
    _pendingClipId = null;
    _pendingMasterPath = null;
    _loopClipId = newClipId;
    _loopFilePath = newPath;

    // Silence the outgoing master **before** the new one starts. This used to
    // rely on `unloadClip`, which stops the voice inside an async gap -- so for
    // a frame or two both masters were sounding at once and the loop doubled
    // on itself at the seam. `stopClipNow` reaches the mixer synchronously.
    if (oldClipId != null) {
      AudioEngine.instance.stopClipNow(oldClipId);
    }
    if (play && newClipId != null) {
      AudioEngine.instance.playClip(newClipId, volume: 1.0, looping: true);
    }
    if (oldClipId != null) {
      unawaited(AudioEngine.instance.unloadClip(oldClipId));
    }
    unawaited(_refreshVisual());
  }

  /// Takes the most recently committed overdub layer back off the loop.
  ///
  /// Pad hits from that layer disappear; mixed-down audio is restored from the
  /// master that was kept before the layer was folded in. The base layer can
  /// never be removed this way -- hold a tape pad to clear everything instead.
  Future<void> undoLayer() async {
    if (_busy) return;
    if (!canUndo) {
      _say(_layers.length > 1
          ? 'Undo the layer once the overdub has finished'
          : 'Only the base layer is left');
      return;
    }

    _busy = true;
    try {
      final layer = _layers.removeLast();

      // Anything staged but not yet audible can only have come from the layer
      // being removed, so it goes with it.
      final stagedClipId = _pendingClipId;
      final stagedPath = _pendingMasterPath;
      _pendingClipId = null;
      _pendingMasterPath = null;
      if (stagedClipId != null) {
        await AudioEngine.instance.unloadClip(stagedClipId);
      }
      if (stagedPath != null && !_isMasterReferenced(stagedPath)) {
        await RecordingsRepository.deleteQuietly(stagedPath);
      }

      final restorePath = layer.previousMasterPath;
      final currentPath = _loopFilePath;
      if (layer.changedMaster && currentPath != restorePath) {
        final oldClipId = _loopClipId;
        _loopClipId = null;
        _loopFilePath = null;
        if (oldClipId != null) {
          await AudioEngine.instance.unloadClip(oldClipId);
        }
        if (currentPath != null && !_isMasterReferenced(currentPath)) {
          await RecordingsRepository.deleteQuietly(currentPath);
        }
        if (restorePath != null) {
          _loopFilePath = restorePath;
          _loopClipId = await AudioEngine.instance.loadClip(restorePath);
        }
      }

      _rebuildEvents();
      unawaited(_refreshVisual());

      if (_state == LoopState.playing) {
        // Restart from the top. The master audio has just been swapped for a
        // different file, and starting it and the loop clock together at zero
        // is the only way to be certain they are in step.
        await _stopPlayback();
        await _startPlayback();
      }

      _say(_layers.length > 1
          ? 'LAYER REMOVED - LAYERS ${_layers.length}'
          : 'BACK TO THE BASE LAYER');
      _notify();
    } finally {
      _busy = false;
    }
  }

  /// Rebuilds the flat, playback-ordered event list from the layers that are
  /// left.
  ///
  /// This is where quantise actually happens. Layers always store the raw,
  /// as-played time of every hit; this turns those into playback positions --
  /// wrapped into the loop and, when quantise is on, snapped to the grid -- and
  /// sorts by the result. Doing it from the layers every time (rather than
  /// editing one list in place) means undo can never leave a stray event
  /// behind, and toggling quantise can never destroy the human timing.
  void _rebuildEvents() {
    final loopMs = _recordedLoopDuration.inMilliseconds;
    final barUs = barDuration.inMicroseconds;
    final merged = <LoopPadEvent>[];
    for (final layer in _layers) {
      for (final event in layer.events) {
        merged.add(event.withOffset(effectiveOffsetMs(
          rawOffsetMs: event.rawOffsetMs,
          loopMs: loopMs,
          barUs: barUs,
          quantize: _quantize,
          grid: _quantizeGrid,
        )));
      }
    }
    merged.sort((a, b) => a.offsetMs.compareTo(b.offsetMs));
    _events = merged;
    _scheduler.setEvents(merged);
    _publishVisual();
  }

  /// Republishes the waveform/step display from whatever is currently in the
  /// loop, keeping the audio envelope that is already computed.
  void _publishVisual() {
    if (_disposed) return;
    loopVisual.value = _buildVisual(loopVisual.value.peaks);
  }

  /// How many whole bars the finished loop is, for the waveform's gridlines.
  ///
  /// With quantise on this is exact ([_loopBars]). With quantise off the loop
  /// is whatever length it was played at, so the bar count is *derived* from
  /// the tempo and rounded -- gridlines that are approximately right are far
  /// more useful than no gridlines, and the panel labels them as bars either
  /// way. Returns 0 when there is nothing sensible to divide.
  int _visualBars() {
    final fixed = _loopBars;
    if (fixed != null && fixed > 0) return fixed;
    final loopMs = _recordedLoopDuration.inMilliseconds;
    final barMs = barDuration.inMilliseconds;
    if (loopMs <= 0 || barMs <= 0) return 0;
    final bars = (loopMs / barMs).round();
    return bars < 1 ? 1 : bars;
  }

  /// Assembles the drawable summary from whatever is currently in the loop.
  /// [peaks] is passed in rather than read, so [_refreshVisual] can hand over a
  /// freshly computed envelope and [_publishVisual] can keep the old one.
  LoopVisual _buildVisual(WavPeaks? peaks) {
    return LoopVisual(
      peaks: peaks,
      hits: _events,
      loopMs: _recordedLoopDuration.inMilliseconds,
      bars: _visualBars(),
      stepsPerBar: _quantize ? _quantizeGrid.divisionsPerBar : 0,
      bpm: _bpm,
    );
  }

  /// Recomputes the master loop's peak envelope, off the trigger path.
  ///
  /// This reads a file and walks its samples, so it deliberately happens only
  /// when the audio actually changes -- a take being rendered, an overdub being
  /// mixed in, a layer being undone -- and never while anything is being
  /// played. A generation counter means a slow read of an old master can't
  /// overwrite a newer one.
  Future<void> _refreshVisual() async {
    final generation = ++_visualGeneration;
    final path = _loopFilePath;
    WavPeaks? peaks;
    if (path != null) {
      try {
        final file = File(path);
        if (await file.exists()) {
          peaks = computeWavPeaks(await file.readAsBytes());
        }
      } catch (e) {
        debugPrint('TapeDeck: could not read the loop for its waveform: $e');
      }
    }
    if (_disposed || generation != _visualGeneration) return;
    loopVisual.value = _buildVisual(peaks);
  }

  // --- Playback ---------------------------------------------------------

  Future<void> _startPlayback() async {
    if (_recordedLoopDuration <= Duration.zero) {
      _say('Nothing to play');
      return;
    }
    // A master mixed while the loop was stopped becomes the one we play.
    _applyPendingMaster(play: false);
    final clipId = _loopClipId;
    if (clipId != null) {
      AudioEngine.instance.playClip(clipId, volume: 1.0, looping: true);
    }
    _passIndex = 0;
    _position = Duration.zero;
    _transportClock = Stopwatch()..start();
    // Start the scheduler just before t=0 so a hit sitting exactly on the
    // downbeat of the first pass still fires.
    _scheduler.reset(
      loopMs: _recordedLoopDuration.inMilliseconds,
      events: _events,
    );
    _state = LoopState.playing;
    _startTick();
    _notify();
  }

  Future<void> _stopPlayback() async {
    _stopTick();
    final clipId = _loopClipId;
    if (clipId != null) {
      await AudioEngine.instance.stopClip(clipId);
    }
    // Nothing is sounding, so a staged master can be swapped in right now.
    _applyPendingMaster(play: false);
    _transportClock = null;
    _position = Duration.zero;
    _scheduler.reset(loopMs: _recordedLoopDuration.inMilliseconds, events: _events);
    _state = LoopState.stopped;
    transportTicks.tick();
    _notify();
  }

  /// Cancels arming or an in-progress recording and throws away the take.
  Future<void> _cancelTake({required String message}) async {
    _busy = true;
    try {
      _stopTick();
      _recordEndTimer?.cancel();
      _recordEndTimer = null;
      await _ampSub?.cancel();
      _ampSub = null;
      await _closeMic();
      await RecordingsRepository.deleteQuietly(_tempRecordingPath);
      _tempRecordingPath = null;
      _capturing.clear();
      _position = Duration.zero;
      _armClock = null;
      _transportClock = null;
      _setInputLevel(minThresholdDb);
      _state = hasLoop ? LoopState.stopped : LoopState.empty;
      _say(message);
      _notify();
    } finally {
      _busy = false;
    }
  }

  // --- The transport clock ----------------------------------------------

  /// How often the transport wakes up.
  ///
  /// 8ms is the timing resolution of a replayed pad hit, so it wants to be
  /// small. What it costs is deliberately almost nothing: the tick reads a
  /// stopwatch, asks the scheduler for anything due (usually nothing), and
  /// returns. It does **not** rebuild the UI -- that happens at
  /// [_uiPublishIntervalMs] instead. Before v5 the tick called
  /// `notifyListeners()` twenty times a second, which rebuilt the whole tape
  /// deck panel and was stealing time from the pad trigger on the same thread.
  static const int _tickMs = 8;

  /// How often the playhead readouts (reels, clocks, waveform playhead) are
  /// refreshed. ~15Hz is smooth for a reel and a tenths-of-a-second clock.
  static const int _uiPublishIntervalMs = 66;

  /// Tick period when nothing has to be replayed on time -- while arming,
  /// while recording, or for a mic-only loop. There is no reason to wake the
  /// thread 125 times a second just to move a reel.
  static const int _idleTickMs = 33;

  void _startTick() {
    _tick?.cancel();
    _lastUiPublishMs = -1;
    // Only pad replay needs millisecond-grade timing, and only while the loop
    // is actually turning. Everything else just moves a reel and a clock.
    final needsHitTiming = usesPads &&
        (_state == LoopState.playing || _state == LoopState.overdubbing);
    _tick = Timer.periodic(
      Duration(milliseconds: needsHitTiming ? _tickMs : _idleTickMs),
      (_) => _onTick(),
    );
  }

  void _stopTick() {
    _tick?.cancel();
    _tick = null;
  }

  void _onTick() {
    switch (_state) {
      case LoopState.armed:
        // Nothing to advance; the loop clock hasn't started. Keep refreshing
        // so the level meter animates.
        _publishPosition(_armClock?.elapsedMilliseconds ?? 0);
        break;
      case LoopState.recording:
        final elapsed = _transportClock?.elapsedMilliseconds ?? 0;
        _position = Duration(milliseconds: elapsed);
        _publishPosition(elapsed);
        break;
      case LoopState.playing:
      case LoopState.overdubbing:
        // Overdubbing is playback that also happens to be capturing, so the
        // loop keeps turning exactly as it does while merely playing.
        _advancePlayback();
        break;
      case LoopState.empty:
      case LoopState.stopped:
        _stopTick();
        break;
    }
  }

  /// Moves the playhead and fires whatever pad hits fell due.
  ///
  /// One free-running stopwatch is the only clock. [LoopScheduler] turns its
  /// reading into "which hits are due", firing everything in the window since
  /// the last tick -- however many loop passes that window happens to span.
  /// Nothing accumulates, so nothing drifts, and a late tick catches up
  /// instead of dropping hits.
  void _advancePlayback() {
    final clock = _transportClock;
    final loopMs = _recordedLoopDuration.inMilliseconds;
    if (clock == null || loopMs <= 0) return;

    final elapsed = clock.elapsedMilliseconds;
    final pass = elapsed ~/ loopMs;
    final position = elapsed - pass * loopMs;

    _scheduler.advanceTo(elapsed, _fireEvent);

    if (pass != _passIndex) {
      _passIndex = pass;
      // The seam is the one moment where a freshly mixed master can be swapped
      // in with the audio and the clock still in step.
      _applyPendingMaster(play: true);
    }

    _position = Duration(milliseconds: position);
    _publishPosition(elapsed);
  }

  void _fireEvent(LoopPadEvent event) {
    onPadTrigger?.call(event.padId, event.velocity);
  }

  /// Refreshes the playhead readouts, at most every [_uiPublishIntervalMs].
  ///
  /// [nowMs] is any monotonically increasing millisecond reading; it is only
  /// used to rate-limit.
  void _publishPosition(int nowMs) {
    if (_disposed) return;
    if (_lastUiPublishMs >= 0 && nowMs - _lastUiPublishMs < _uiPublishIntervalMs) {
      return;
    }
    _lastUiPublishMs = nowMs;
    transportTicks.tick();
  }

  @override
  void dispose() {
    _disposed = true;
    _stopTick();
    _recordEndTimer?.cancel();
    _recordEndTimer = null;
    unawaited(_ampSub?.cancel());
    _ampSub = null;
    unawaited(_recorder.dispose());
    unawaited(_messages.close());
    transportTicks.dispose();
    inputLevelNotifier.dispose();
    loopVisual.dispose();
    super.dispose();
  }
}

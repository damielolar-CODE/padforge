/// What the tape deck actually records.
///
/// ## Why this exists (plain English)
///
/// Version 2 of the tape deck always opened the microphone, even when all you
/// wanted was to loop the pads you were tapping. That meant every loop had the
/// room -- and whatever the phone's speaker was playing -- baked into it. This
/// enum is the fix: you choose what gets captured, and by default the
/// microphone is not involved at all.
///
/// It lives in its own tiny file so both the looper (`tape_deck.dart`) and the
/// unlimited recorder (`take_recorder.dart`) can use it without either one
/// having to import the other.
library;

/// The three things the deck can record.
enum RecordSource {
  /// **Pads only.** Nothing but the pad performance is captured, as a list of
  /// "this pad, this many milliseconds in, this hard". The microphone is never
  /// opened, so no permission prompt and no room noise. This is the default.
  pads,

  /// **Microphone only.** The classic looper behaviour: whatever the mic hears
  /// becomes the loop. Pad hits are not captured as events.
  mic,

  /// **Both**, as two independent layers played back together -- the mic take
  /// as an audio file and the pad hits re-triggered through the sampler. They
  /// are deliberately *not* mixed down into one file in the looper: layering
  /// keeps the pads digitally clean.
  both,
}

/// Short label for the UI's three-way selector.
String recordSourceLabel(RecordSource source) {
  switch (source) {
    case RecordSource.pads:
      return 'PADS';
    case RecordSource.mic:
      return 'MIC';
    case RecordSource.both:
      return 'BOTH';
  }
}

/// True when this source needs the microphone open. Used to decide whether to
/// ask for the microphone permission at all -- in [RecordSource.pads] we never
/// touch it.
bool recordSourceUsesMic(RecordSource source) => source != RecordSource.pads;

/// True when this source captures pad hits as events.
bool recordSourceUsesPads(RecordSource source) => source != RecordSource.mic;

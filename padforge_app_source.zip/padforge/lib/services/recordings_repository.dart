import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// One saved recording on disk.
class RecordingFile {
  /// Full path to the WAV file.
  final String path;

  /// Just the file name, e.g. "take_20260810_142233.wav".
  final String name;

  /// Size in bytes (used to show a rough "how big is this" figure).
  final int sizeBytes;

  /// When the file was written.
  final DateTime modified;

  const RecordingFile({
    required this.path,
    required this.name,
    required this.sizeBytes,
    required this.modified,
  });

  /// A friendly size like "1.4 MB".
  String get prettySize {
    if (sizeBytes < 1024) return '$sizeBytes B';
    if (sizeBytes < 1024 * 1024) return '${(sizeBytes / 1024).toStringAsFixed(0)} KB';
    return '${(sizeBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}

/// All the file handling for the tape deck's recorder.
///
/// Recordings are plain WAV files in `<app documents>/Recordings/`, and the
/// looper's working files live in `<app documents>/Recordings/.loop/` (kept
/// separate so half-finished loop takes never show up in the recordings list).
///
/// Like `KitRepository`, this class is pure file I/O -- no audio, no UI.
class RecordingsRepository {
  RecordingsRepository._();

  static const String folderName = 'Recordings';
  static const String loopFolderName = '.loop';

  static Future<Directory> recordingsDir() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, folderName));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  /// Scratch folder for the looper's temporary and finished loop takes.
  static Future<Directory> loopDir() async {
    final root = await recordingsDir();
    final dir = Directory(p.join(root.path, loopFolderName));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  /// Timestamped file name for a new take, e.g. "take_20260810_142233.wav".
  static String timestampedName({String prefix = 'take'}) {
    final now = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    final stamp = '${now.year}${two(now.month)}${two(now.day)}'
        '_${two(now.hour)}${two(now.minute)}${two(now.second)}';
    return '${prefix}_$stamp.wav';
  }

  /// Full path for a brand-new take file (the file itself isn't created here;
  /// the recorder plugin writes it).
  ///
  /// [prefix] names what the file holds, so a "both" take that could not be
  /// mixed down leaves two obviously-labelled files side by side: `pads_...`
  /// and `mic_...` rather than two mystery `take_...`s.
  static Future<String> newTakePath({String prefix = 'take'}) async {
    final dir = await recordingsDir();
    return p.join(dir.path, timestampedName(prefix: prefix));
  }

  /// Full path for a scratch file in the hidden loop folder. Used for the raw
  /// PCM the engine capture writes before it gets a WAV header.
  static Future<String> scratchPath(String name) async {
    final dir = await loopDir();
    return p.join(dir.path, name);
  }

  /// Every saved recording, newest first.
  static Future<List<RecordingFile>> listRecordings() async {
    final dir = await recordingsDir();
    final out = <RecordingFile>[];
    await for (final entity in dir.list()) {
      if (entity is! File) continue;
      final name = p.basename(entity.path);
      if (!name.toLowerCase().endsWith('.wav')) continue;
      if (name.startsWith('.')) continue;
      final stat = await entity.stat();
      out.add(RecordingFile(
        path: entity.path,
        name: name,
        sizeBytes: stat.size,
        modified: stat.modified,
      ));
    }
    out.sort((a, b) => b.modified.compareTo(a.modified));
    return out;
  }

  static Future<void> deleteRecording(String path) async {
    final file = File(path);
    if (await file.exists()) {
      await file.delete();
    }
  }

  /// Deletes a file if it exists, swallowing errors -- used for scratch files
  /// where failing to clean up should never surface to the user.
  static Future<void> deleteQuietly(String? path) async {
    if (path == null) return;
    try {
      final file = File(path);
      if (await file.exists()) {
        await file.delete();
      }
    } catch (_) {
      // Nothing useful to do; a stale scratch file is harmless.
    }
  }
}

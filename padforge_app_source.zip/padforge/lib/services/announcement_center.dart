/// DEESTECH in-app announcements -- the NETWORK + PLUGIN half.
///
/// On launch the app fetches one small hosted JSON file, picks the first
/// announcement that targets PadForge and is in its date window and has not
/// been dismissed on this device, and publishes it as [current]. The banner
/// widget listens to this center and draws whatever is current.
///
/// It fails SILENTLY in every failure mode -- offline, a 404, a timeout, a
/// malformed feed, a plugin that is not ready -- by catching everything and
/// simply leaving [current] as it was (usually null, so no banner). Nothing
/// here is ever awaited on the app's start path, so it can never delay or
/// block launch.
///
/// The decision of WHICH entry to show lives in the pure, unit-tested
/// `announcement_feed.dart`; this file only does the I/O around it.
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'announcement_feed.dart';
import 'pro_store.dart';

/// Singleton [ChangeNotifier] holding the one currently-showing announcement.
/// Mirrors the DEES TAPE iOS `AnnouncementCenter` and its Android twin, so the
/// shared feed behaves identically across the family.
class AnnouncementCenter extends ChangeNotifier {
  AnnouncementCenter._() {
    // When the user unlocks Pro mid-session (purchase, restore, or tester
    // code), a Pro upsell that is currently on screen should vanish at once.
    ProStore.instance.addListener(_onProChanged);
  }

  /// The one instance every widget reads.
  static final AnnouncementCenter instance = AnnouncementCenter._();

  /// This app's slug in the shared feed. DEESTECH targets PadForge messages at
  /// `apps: ["padforge"]`.
  static const String appSlug = 'padforge';

  static const String _feedUrl = 'https://deestechholdings.com/announcements.json';

  /// On-device record of dismissed ids, remembered forever.
  static const String _dismissedKey = 'padforge_ann_dismissed_v1';

  /// Hard cap on the feed we will read, so a bad/huge response cannot hurt us.
  static const int _maxBytes = 512 * 1024;

  /// Test seam: when set, the feed text comes from here instead of the network.
  @visibleForTesting
  Future<String> Function()? debugFeedLoader;

  Announcement? _current;
  Announcement? get current => _current;

  bool _refreshing = false;

  /// Fetch the feed and (re)compute [current]. Safe to call on every launch;
  /// a second call while one is in flight is ignored.
  Future<void> refresh() async {
    if (_refreshing) return;
    _refreshing = true;
    try {
      final loader = debugFeedLoader;
      final raw = loader != null ? await loader() : await _fetch();
      final items = parseAnnouncementFeed(raw);
      final dismissed = await _dismissedIds();
      final pick = selectAnnouncement(
        items,
        today: todayString(),
        dismissed: dismissed,
        appSlug: appSlug,
        isPro: ProStore.instance.isPro,
      );
      _setCurrent(pick);
    } catch (_) {
      // Offline / bad feed / plugin not ready: show nothing, app unaffected.
    } finally {
      _refreshing = false;
    }
  }

  /// User tapped the dismiss control. Remember the id forever and clear it if
  /// it is the one on screen.
  Future<void> dismiss(Announcement a) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final ids = (prefs.getStringList(_dismissedKey) ?? const <String>[]).toSet()
        ..add(a.id);
      await prefs.setStringList(_dismissedKey, ids.toList(growable: false));
    } catch (_) {
      // If persistence fails we still hide it for this session.
    }
    if (_current?.id == a.id) _setCurrent(null);
  }

  /// Opens the announcement's CTA link in the browser / App Store.
  ///
  /// Scope decision (see PROJECT_NOTES V9): only real web links (`http`/
  /// `https`) are opened. A custom scheme such as `padforge://x` would need an
  /// in-app router that does not exist yet, so a CTA with a non-web url simply
  /// shows no button rather than a dead one. [canOpen] is what the banner asks
  /// before drawing the button.
  static bool canOpen(Announcement a) {
    final raw = a.url;
    if (raw == null || raw.isEmpty) return false;
    final cta = a.cta;
    if (cta == null || cta.isEmpty) return false;
    final uri = Uri.tryParse(raw);
    return uri != null && (uri.scheme == 'http' || uri.scheme == 'https');
  }

  Future<void> openCta(Announcement a) async {
    if (!canOpen(a)) return;
    final uri = Uri.parse(a.url!);
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      // A device with no browser, or a launch refusal: do nothing.
    }
  }

  Future<Set<String>> _dismissedIds() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return (prefs.getStringList(_dismissedKey) ?? const <String>[]).toSet();
    } catch (_) {
      return <String>{};
    }
  }

  Future<String> _fetch() async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      final request = await client.getUrl(Uri.parse(_feedUrl));
      final response = await request.close().timeout(const Duration(seconds: 8));
      if (response.statusCode != 200) {
        throw HttpException('status ${response.statusCode}');
      }
      final bytes = <int>[];
      await for (final chunk in response) {
        bytes.addAll(chunk);
        if (bytes.length > _maxBytes) {
          throw const HttpException('feed too large');
        }
      }
      return utf8.decode(bytes);
    } finally {
      client.close(force: true);
    }
  }

  void _onProChanged() {
    final c = _current;
    if (c != null && isProUpsell(c) && ProStore.instance.isPro) {
      _setCurrent(null);
    }
  }

  void _setCurrent(Announcement? a) {
    if (identical(_current, a)) return;
    if (_current?.id == a?.id) {
      _current = a;
      return;
    }
    _current = a;
    notifyListeners();
  }
}

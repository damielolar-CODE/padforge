/// DEESTECH in-app announcements -- the PURE logic half.
///
/// This file is deliberately **pure Dart**: no Flutter, no plugins, nothing
/// but `dart:convert`. That is the same discipline `controller_map.dart`
/// follows, and for the same reason -- every decision this module makes (which
/// announcement to show, whether it is in its date window, whether it has been
/// dismissed) is then provable in a unit test with no device, no network and
/// no `SharedPreferences`. The networky / plugin-y half lives next door in
/// `announcement_center.dart` and calls into here.
///
/// The shared hosted feed (owned and edited by DEESTECH, not by the app) is a
/// single JSON file:
///
/// ```json
/// {"version":1,"updated":"2026-10-30","announcements":[
///   {"id":"...","title":"...","body":"...","apps":["padforge"],
///    "style":"info|update|promo","cta":"...","url":"https://...",
///    "startDate":"2026-10-30","endDate":"2026-11-30"}
/// ]}
/// ```
///
/// Everything except `id`, `title` and `body` is optional.
library;

import 'dart:convert';

/// One announcement, exactly as it appears in the shared feed.
class Announcement {
  final String id;
  final String title;
  final String body;

  /// Slugs this targets. `null`/missing or a list containing `"all"` means
  /// every app. A non-null list that does not contain this app's slug (and
  /// not `"all"`) means the entry is for other apps and is skipped here.
  final List<String>? apps;

  /// `"info" | "update" | "promo"` -- advisory only; the banner does not
  /// change behaviour on it (it is used by [isProUpsell] as a heuristic).
  final String? style;

  /// Optional call-to-action button label and link.
  final String? cta;
  final String? url;

  /// Inclusive `yyyy-MM-dd` visibility window. Either may be omitted.
  final String? startDate;
  final String? endDate;

  /// `"free"` = only show to users who do not own Pro; `null`/`"all"` =
  /// everyone. Lets a Pro upsell never nag someone who has already paid.
  final String? audience;

  const Announcement({
    required this.id,
    required this.title,
    required this.body,
    this.apps,
    this.style,
    this.cta,
    this.url,
    this.startDate,
    this.endDate,
    this.audience,
  });

  /// Builds one entry from a decoded JSON map. Throws [FormatException] if the
  /// three required string fields are missing or not strings -- the caller
  /// ([parseAnnouncementFeed]) catches that and simply drops the bad entry.
  factory Announcement.fromMap(Map<String, dynamic> m) {
    String req(String k) {
      final v = m[k];
      if (v is! String || v.isEmpty) {
        throw FormatException('announcement missing "$k"');
      }
      return v;
    }

    String? opt(String k) {
      final v = m[k];
      return v is String ? v : null;
    }

    List<String>? apps;
    final rawApps = m['apps'];
    if (rawApps is List) {
      apps = rawApps.whereType<String>().toList(growable: false);
    }

    return Announcement(
      id: req('id'),
      title: req('title'),
      body: req('body'),
      apps: apps,
      style: opt('style'),
      cta: opt('cta'),
      url: opt('url'),
      startDate: opt('startDate'),
      endDate: opt('endDate'),
      audience: opt('audience'),
    );
  }
}

/// Parses the raw feed text into a list of announcements, **defensively**: a
/// single malformed entry is dropped rather than discarding the whole feed,
/// and anything that is not a well-formed feed throws (the center treats a
/// throw as "show nothing"). Order is preserved -- selection depends on it.
List<Announcement> parseAnnouncementFeed(String raw) {
  final decoded = jsonDecode(raw);
  if (decoded is! Map) {
    throw const FormatException('feed root is not an object');
  }
  final list = decoded['announcements'];
  if (list is! List) {
    throw const FormatException('feed has no "announcements" array');
  }
  final out = <Announcement>[];
  for (final item in list) {
    if (item is! Map) continue;
    try {
      out.add(Announcement.fromMap(item.cast<String, dynamic>()));
    } catch (_) {
      // Skip just this entry; a typo in one message must not silence the rest.
    }
  }
  return out;
}

/// A Pro upsell is an entry explicitly aimed at free users (`audience:"free"`)
/// or, lacking an explicit audience, a `promo` whose id/title mentions Pro.
/// Kept identical to the DEES TAPE iOS/Android twins so the one shared feed
/// behaves the same in every app.
bool isProUpsell(Announcement a) {
  final au = a.audience;
  if (au != null) return au == 'free';
  final mentionsPro =
      a.id.toLowerCase().contains('-pro') || a.title.toLowerCase().contains(' pro');
  return a.style == 'promo' && mentionsPro;
}

/// Picks the FIRST announcement that should be shown, or `null` for none.
///
/// An entry is shown when ALL of these hold, checked in feed order:
///  * it has not been [dismissed] on this device;
///  * it targets this app -- [Announcement.apps] is null, contains `"all"`,
///    or contains [appSlug];
///  * [today] (a `yyyy-MM-dd` string) is within its inclusive
///    start/end window, if either bound is present;
///  * it is not a Pro upsell being shown to a user who already owns Pro.
///
/// `yyyy-MM-dd` strings compare chronologically under plain [String.compareTo],
/// which is why the dates are kept as strings and never parsed.
Announcement? selectAnnouncement(
  List<Announcement> all, {
  required String today,
  required Set<String> dismissed,
  required String appSlug,
  bool isPro = false,
}) {
  for (final a in all) {
    if (dismissed.contains(a.id)) continue;

    final apps = a.apps;
    if (apps != null && !apps.contains('all') && !apps.contains(appSlug)) {
      continue;
    }

    final start = a.startDate;
    if (start != null && start.isNotEmpty && today.compareTo(start) < 0) {
      continue;
    }
    final end = a.endDate;
    if (end != null && end.isNotEmpty && today.compareTo(end) > 0) {
      continue;
    }

    if (isPro && isProUpsell(a)) continue;

    return a;
  }
  return null;
}

/// `yyyy-MM-dd` for the given instant (local time by default), with no `intl`
/// dependency. Used as the clock for [selectAnnouncement].
String todayString([DateTime? now]) {
  final d = now ?? DateTime.now();
  final y = d.year.toString().padLeft(4, '0');
  final m = d.month.toString().padLeft(2, '0');
  final day = d.day.toString().padLeft(2, '0');
  return '$y-$m-$day';
}

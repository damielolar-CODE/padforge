import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

import 'settings_service.dart';

/// PadForge Pro -- the one-time, non-consumable in-app purchase, and the single
/// flag the whole app gates on.
///
/// ## What "Pro" is
///
/// One boolean, [isPro]. It is true when EITHER the store says this account owns
/// `com.deestechhq.padforge.pro`, OR the house tester unlock has been entered on
/// this device. Everything else in the app just reads [ProStore.instance.isPro].
///
/// This mirrors the iOS build's `StoreManager` exactly -- same product id, same
/// tester code, same "entitlement OR tester" rule -- so the two platforms unlock
/// the identical set of features.
///
/// ## How it is wired
///
/// It is a plain singleton [ChangeNotifier] (`ProStore.instance`), exactly like
/// [AppState], [TapeDeck] and [TakeRecorder], so the UI observes it with a
/// `ListenableBuilder` and there is no state-management package to add. The
/// billing work talks to `in_app_purchase`; a persisted copy of the entitlement
/// lives in [SettingsService] so an offline relaunch still knows Pro is owned.
///
/// **It never touches the audio/MIDI hot paths.** The gates all live in the UI
/// and read [isPro]; the trigger, looper and recorder engines are only handed a
/// `() => isPro` callback where they need to know (the recorder's free length
/// cap), which they read on their own timing thread, not inside a hit.
class ProStore extends ChangeNotifier {
  ProStore._internal();

  static final ProStore instance = ProStore._internal();

  /// The Play/App Store product identifier. The PRICE is set in the store
  /// console; the app only ever reads what the store reports. Matches iOS.
  static const String proProductId = 'com.deestechhq.padforge.pro';

  /// The house tester unlock code (triple-tap the logo on the About screen).
  static const String testerCode = 'Deestechaccess';

  /// Shown before the real product has loaded, or if the store is offline.
  static const String fallbackPrice = r'$4.99';

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  ProductDetails? _product;
  bool _entitlement = false;
  bool _testerUnlocked = false;
  bool _available = false;
  bool _purchaseInFlight = false;
  bool _initialized = false;
  String _lastMessage = '';

  /// True when the store entitlement for Pro is present (or was, and is
  /// remembered from a previous launch).
  bool get entitlement => _entitlement;

  /// True when the tester unlock has been used on this device.
  bool get testerUnlocked => _testerUnlocked;

  /// **The one flag the whole app gates on.**
  bool get isPro => _entitlement || _testerUnlocked;

  /// True while a purchase is in flight, so the paywall can show a spinner.
  bool get purchaseInFlight => _purchaseInFlight;

  /// True once the billing client has reported itself available.
  bool get storeAvailable => _available;

  /// A short line for the paywall / settings to echo back to the user.
  String get lastMessage => _lastMessage;

  /// Localised price string, e.g. "$4.99", or the fallback before load.
  String get displayPrice => _product?.price ?? fallbackPrice;

  /// Loads the persisted flags, connects to the billing client, subscribes to
  /// the purchase stream and queries the product. Safe to call more than once.
  /// Called once from [AppState.init] after [SettingsService.load].
  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;

    // Persisted entitlement first, so gating is correct from the very first
    // frame even if the billing client is slow or the device is offline.
    _entitlement = SettingsService.instance.proEntitled;
    _testerUnlocked = SettingsService.instance.proTesterUnlocked;
    notifyListeners();

    try {
      _available = await _iap.isAvailable();
    } catch (e) {
      debugPrint('ProStore: isAvailable failed: $e');
      _available = false;
    }
    if (!_available) return;

    // Listen for purchase/restore updates (including ones that arrive outside a
    // buy call -- another device, a pending approval that clears later).
    _sub = _iap.purchaseStream.listen(
      _onPurchaseUpdates,
      onDone: () => _sub?.cancel(),
      onError: (Object e) => debugPrint('ProStore: purchaseStream error: $e'),
    );

    await _loadProduct();
  }

  Future<void> _loadProduct() async {
    try {
      final response = await _iap.queryProductDetails({proProductId});
      if (response.productDetails.isNotEmpty) {
        _product = response.productDetails.first;
        notifyListeners();
      }
    } catch (e) {
      // A store hiccup is never fatal: keep the fallback price and let the user
      // try again. Nothing in the app depends on the product existing.
      debugPrint('ProStore: queryProductDetails failed: $e');
    }
  }

  // --- Tester unlock -----------------------------------------------------

  /// Checks a typed code and, if it matches, turns Pro on for this device and
  /// remembers it. Returns whether it matched.
  bool tryTesterCode(String code) {
    final matched = code.trim() == testerCode;
    if (matched) {
      _testerUnlocked = true;
      unawaited(SettingsService.instance.setProTesterUnlocked(true));
      _lastMessage = 'PRO UNLOCKED (TESTER)';
      notifyListeners();
    }
    return matched;
  }

  // --- Purchase / restore ------------------------------------------------

  /// Kicks off the one-time purchase of PadForge Pro. The outcome arrives on
  /// the purchase stream ([_onPurchaseUpdates]), which is what actually flips
  /// the entitlement -- so a purchase completed on another device still lands.
  Future<void> buyPro() async {
    if (isPro) return;
    if (!_available) {
      _lastMessage = 'STORE NOT AVAILABLE - TRY AGAIN LATER';
      notifyListeners();
      return;
    }
    final product = _product;
    if (product == null) {
      _lastMessage = 'STORE NOT READY - TRY AGAIN';
      notifyListeners();
      // Have another go at loading it, in case the first query missed.
      await _loadProduct();
      return;
    }
    _purchaseInFlight = true;
    _lastMessage = '';
    notifyListeners();
    try {
      final param = PurchaseParam(productDetails: product);
      // Non-consumable: bought once, owned forever.
      await _iap.buyNonConsumable(purchaseParam: param);
    } catch (e) {
      debugPrint('ProStore: buyNonConsumable failed: $e');
      _purchaseInFlight = false;
      _lastMessage = 'PURCHASE FAILED - TRY AGAIN';
      notifyListeners();
    }
  }

  /// Restores a previous purchase (a reinstall, a new device). The results
  /// arrive on the purchase stream.
  Future<void> restore() async {
    if (!_available) {
      _lastMessage = 'STORE NOT AVAILABLE - TRY AGAIN LATER';
      notifyListeners();
      return;
    }
    _lastMessage = 'RESTORING...';
    notifyListeners();
    try {
      await _iap.restorePurchases();
      // If nothing comes back on the stream shortly, say so rather than leave
      // the user staring at "RESTORING...".
      Future.delayed(const Duration(seconds: 4), () {
        if (_lastMessage == 'RESTORING...') {
          _lastMessage = _entitlement ? 'PURCHASES RESTORED' : 'NO PURCHASE FOUND';
          notifyListeners();
        }
      });
    } catch (e) {
      debugPrint('ProStore: restorePurchases failed: $e');
      _lastMessage = 'COULD NOT RESTORE - TRY AGAIN';
      notifyListeners();
    }
  }

  void _onPurchaseUpdates(List<PurchaseDetails> purchases) {
    for (final purchase in purchases) {
      switch (purchase.status) {
        case PurchaseStatus.pending:
          _purchaseInFlight = true;
          _lastMessage = 'PURCHASE PENDING APPROVAL';
          notifyListeners();
          break;
        case PurchaseStatus.error:
          _purchaseInFlight = false;
          _lastMessage = 'PURCHASE FAILED - TRY AGAIN';
          notifyListeners();
          break;
        case PurchaseStatus.canceled:
          _purchaseInFlight = false;
          _lastMessage = '';
          notifyListeners();
          break;
        case PurchaseStatus.purchased:
        case PurchaseStatus.restored:
          if (purchase.productID == proProductId) {
            _grantEntitlement(
              purchase.status == PurchaseStatus.restored
                  ? 'PURCHASES RESTORED'
                  : 'THANK YOU - PRO UNLOCKED',
            );
          }
          break;
      }
      // Always acknowledge/complete a finished transaction, or the store keeps
      // re-delivering it (and on Android leaves the purchase un-acknowledged,
      // which auto-refunds it after three days).
      if (purchase.pendingCompletePurchase) {
        unawaited(_iap.completePurchase(purchase));
      }
    }
  }

  void _grantEntitlement(String message) {
    _entitlement = true;
    _purchaseInFlight = false;
    _lastMessage = message;
    unawaited(SettingsService.instance.setProEntitled(true));
    notifyListeners();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}

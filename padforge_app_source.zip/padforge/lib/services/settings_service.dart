import 'package:shared_preferences/shared_preferences.dart';

/// Tiny wrapper around `shared_preferences` for the couple of things
/// PadForge needs to remember between launches: which kit was open last,
/// and which MIDI device it was last connected to.
class SettingsService {
  SettingsService._internal();

  static final SettingsService instance = SettingsService._internal();

  static const _kLastKitFolder = 'padforge.lastKitFolder';
  static const _kLastDeviceName = 'padforge.lastDeviceName';

  SharedPreferences? _prefs;

  String? lastKitName;
  String? lastDeviceName;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    lastKitName = _prefs?.getString(_kLastKitFolder);
    lastDeviceName = _prefs?.getString(_kLastDeviceName);
  }

  Future<void> setLastKitName(String folderName) async {
    lastKitName = folderName;
    await _prefs?.setString(_kLastKitFolder, folderName);
  }

  Future<void> setLastDeviceName(String name) async {
    lastDeviceName = name;
    await _prefs?.setString(_kLastDeviceName, name);
  }
}

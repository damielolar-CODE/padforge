import 'package:shared_preferences/shared_preferences.dart';

/// Tiny wrapper around `shared_preferences` for the handful of things PadForge
/// needs to remember between launches: which kit was open last, which MIDI
/// device it was last connected to, which way round the pad grid is drawn, and
/// the quantise settings.
class SettingsService {
  SettingsService._internal();

  static final SettingsService instance = SettingsService._internal();

  static const _kLastKitFolder = 'padforge.lastKitFolder';
  static const _kLastDeviceName = 'padforge.lastDeviceName';
  static const _kPadLayoutBottomLeft = 'padforge.padLayoutBottomLeft';
  static const _kQuantizeGrid = 'padforge.quantizeGrid';
  static const _kQuantizeOn = 'padforge.quantizeOn';
  static const _kControllerMap = 'padforge.controllerMap';
  static const _kAudioBufferFrames = 'padforge.audioBufferFrames';
  static const _kProEntitled = 'padforge.proEntitled';
  static const _kProTesterUnlocked = 'padforge.proTesterUnlocked';

  SharedPreferences? _prefs;

  String? lastKitName;
  String? lastDeviceName;

  /// True when the on-screen grid is drawn the way the MPD218 is physically
  /// laid out: **pad 1 at the bottom left**, ascending left to right and then
  /// upwards. This is the default, and it is the setting that makes hitting a
  /// hardware pad light the pad in the same physical position on screen.
  ///
  /// False draws the grid in plain reading order (pad 1 top left), for a unit
  /// that has been reconfigured or for someone who simply prefers it.
  bool padLayoutBottomLeft = true;

  /// Name of the [QuantizeGrid] enum value last selected ("sixteenth", ...).
  String? quantizeGridName;

  /// Whether quantise was on last time. Null when never set (the deck's own
  /// default, on, then applies).
  bool? quantizeOn;

  /// The global controller map (`note -> padId`) as compact JSON, exactly as
  /// `ControllerMap.toJsonString` wrote it. Null means "never mapped anything",
  /// in which case every kit's own `note` fields are used as-is.
  ///
  /// This is deliberately **one setting for the whole app**, not something
  /// stored per kit: which note a pad sends is a fact about the hardware in
  /// front of the user, and re-learning it for every kit would be absurd.
  String? controllerMapJson;

  /// Output buffer size, in frames, the audio engine should ask the device for
  /// on the next start (the "Audio latency" control in Settings). Null means
  /// "never chosen", in which case [AudioEngine.defaultBufferFrames] applies.
  ///
  /// It cannot take effect until the engine restarts -- the buffer size is
  /// fixed when the audio device is opened -- which is why the Settings screen
  /// says so out loud rather than implying the change is live.
  int? audioBufferFrames;

  /// True once the App Store / Play entitlement for PadForge Pro has been seen
  /// on this device. Persisted so the app still knows the user owns Pro on an
  /// offline launch, before the billing client has had a chance to answer.
  bool proEntitled = false;

  /// True when the house tester unlock code has been entered on this device.
  bool proTesterUnlocked = false;

  Future<void> load() async {
    _prefs = await SharedPreferences.getInstance();
    lastKitName = _prefs?.getString(_kLastKitFolder);
    lastDeviceName = _prefs?.getString(_kLastDeviceName);
    padLayoutBottomLeft = _prefs?.getBool(_kPadLayoutBottomLeft) ?? true;
    quantizeGridName = _prefs?.getString(_kQuantizeGrid);
    quantizeOn = _prefs?.getBool(_kQuantizeOn);
    controllerMapJson = _prefs?.getString(_kControllerMap);
    audioBufferFrames = _prefs?.getInt(_kAudioBufferFrames);
    proEntitled = _prefs?.getBool(_kProEntitled) ?? false;
    proTesterUnlocked = _prefs?.getBool(_kProTesterUnlocked) ?? false;
  }

  Future<void> setProEntitled(bool value) async {
    proEntitled = value;
    await _prefs?.setBool(_kProEntitled, value);
  }

  Future<void> setProTesterUnlocked(bool value) async {
    proTesterUnlocked = value;
    await _prefs?.setBool(_kProTesterUnlocked, value);
  }

  Future<void> setAudioBufferFrames(int frames) async {
    audioBufferFrames = frames;
    await _prefs?.setInt(_kAudioBufferFrames, frames);
  }

  Future<void> setLastKitName(String folderName) async {
    lastKitName = folderName;
    await _prefs?.setString(_kLastKitFolder, folderName);
  }

  Future<void> setLastDeviceName(String name) async {
    lastDeviceName = name;
    await _prefs?.setString(_kLastDeviceName, name);
  }

  Future<void> setPadLayoutBottomLeft(bool value) async {
    padLayoutBottomLeft = value;
    await _prefs?.setBool(_kPadLayoutBottomLeft, value);
  }

  Future<void> setQuantizeGridName(String value) async {
    quantizeGridName = value;
    await _prefs?.setString(_kQuantizeGrid, value);
  }

  Future<void> setQuantizeOn(bool value) async {
    quantizeOn = value;
    await _prefs?.setBool(_kQuantizeOn, value);
  }

  Future<void> setControllerMapJson(String value) async {
    controllerMapJson = value;
    await _prefs?.setString(_kControllerMap, value);
  }

  /// Drops the controller map entirely, so every pad falls back to the note in
  /// its kit again.
  Future<void> clearControllerMapJson() async {
    controllerMapJson = null;
    await _prefs?.remove(_kControllerMap);
  }
}

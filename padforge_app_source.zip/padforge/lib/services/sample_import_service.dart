import 'package:file_picker/file_picker.dart';

/// Wraps the OS file picker so the rest of the app doesn't need to know
/// anything about `file_picker`'s API directly. Used to let the user import
/// WAV samples from their phone's Files app (Android) or Files app / iCloud
/// Drive (iOS).
class SampleImportService {
  /// Opens the system file picker, restricted to `.wav` files. Returns an
  /// empty list if the user cancels.
  static Future<List<PlatformFile>> pickWavFiles({bool allowMultiple = true}) async {
    final result = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['wav'],
      allowMultiple: allowMultiple,
    );
    if (result == null) return [];
    // Only keep files that actually resolved to a readable path on disk.
    return result.files.where((f) => f.path != null).toList();
  }
}

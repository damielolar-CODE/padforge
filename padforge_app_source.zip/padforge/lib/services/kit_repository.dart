import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/kit.dart';

/// Everything to do with reading and writing Kits on disk.
///
/// A Kit lives at `<app documents>/Kits/<folderName>/kit.json`, with its WAV
/// files in `<app documents>/Kits/<folderName>/samples/`. Kits are ordinary
/// files, so a user can also manage them by connecting their phone to a
/// computer and browsing into the app's document storage if they want to.
///
/// This class is pure I/O -- it doesn't know about MIDI, audio playback, or
/// UI state. See `lib/state/app_state.dart` for the app-wide state that ties
/// this together with everything else.
class KitRepository {
  KitRepository._();

  static const String kitsFolderName = 'Kits';

  // Where the bundled starter kit lives inside the Flutter asset bundle.
  static const String _starterKitAssetDir = 'assets/kits/vintage_kit';
  static const String starterKitDisplayName = 'Vintage Kit';

  // Exact filenames written by tools/synth_vintage_kit.py -- kept as an
  // explicit list (rather than reading AssetManifest.json at runtime) so
  // installing the starter kit doesn't depend on manifest file formats that
  // have changed between Flutter versions.
  static const List<String> _starterKitSampleFiles = [
    'kick.wav',
    'snare.wav',
    'closed_hat.wav',
    'open_hat.wav',
    'clap.wav',
    'rimshot.wav',
    'low_tom.wav',
    'mid_tom.wav',
    'hi_tom.wav',
    'crash.wav',
    'ride.wav',
    'cowbell.wav',
    'shaker.wav',
    'vintage_blip_1.wav',
    'vintage_blip_2.wav',
    'vintage_stab.wav',
  ];

  static Future<Directory> _kitsRootDir() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, kitsFolderName));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  static Future<Directory> kitDir(String folderName) async {
    final root = await _kitsRootDir();
    return Directory(p.join(root.path, folderName));
  }

  static Future<String> samplesDirPath(String folderName) async {
    final dir = await kitDir(folderName);
    final samplesDir = Directory(p.join(dir.path, 'samples'));
    if (!await samplesDir.exists()) {
      await samplesDir.create(recursive: true);
    }
    return samplesDir.path;
  }

  /// Lists installed kits by folder name, sorted alphabetically. A folder
  /// only counts as an installed kit if it contains a readable `kit.json`.
  static Future<List<String>> listKits() async {
    final root = await _kitsRootDir();
    final names = <String>[];
    await for (final entity in root.list()) {
      if (entity is Directory) {
        final kitJson = File(p.join(entity.path, 'kit.json'));
        if (await kitJson.exists()) {
          names.add(p.basename(entity.path));
        }
      }
    }
    names.sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return names;
  }

  static Future<Kit> loadKit(String folderName) async {
    final dir = await kitDir(folderName);
    final file = File(p.join(dir.path, 'kit.json'));
    final jsonStr = await file.readAsString();
    final map = jsonDecode(jsonStr) as Map<String, dynamic>;
    return Kit.fromJson(map, folderName: folderName);
  }

  static Future<void> saveKit(Kit kit) async {
    final dir = await kitDir(kit.folderName);
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    final file = File(p.join(dir.path, 'kit.json'));
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(kit.toJson()));
  }

  /// Full absolute path to a pad's sample file on disk. Callers should check
  /// [Pad.hasSample] first.
  static Future<String> absoluteSamplePath(Kit kit, String relativeSamplePath) async {
    final dir = await kitDir(kit.folderName);
    return p.join(dir.path, relativeSamplePath);
  }

  static Future<bool> sampleFileExists(Kit kit, String relativeSamplePath) async {
    final path = await absoluteSamplePath(kit, relativeSamplePath);
    return File(path).exists();
  }

  static String _sanitizeFolderName(String name) {
    final cleaned = name.trim().replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    return cleaned.isEmpty ? 'Untitled Kit' : cleaned;
  }

  /// Picks a folder name based on [desiredName] that doesn't collide with an
  /// existing kit folder, appending " (2)", " (3)", etc. as needed.
  static Future<String> uniqueFolderName(String desiredName) async {
    final root = await _kitsRootDir();
    final base = _sanitizeFolderName(desiredName);
    var candidate = base;
    var suffix = 2;
    while (await Directory(p.join(root.path, candidate)).exists()) {
      candidate = '$base ($suffix)';
      suffix++;
    }
    return candidate;
  }

  static Future<Kit> createBlankKit(String displayName) async {
    final folderName = await uniqueFolderName(displayName);
    final kit = Kit.blank(name: displayName, folderName: folderName);
    await samplesDirPath(folderName);
    await saveKit(kit);
    return kit;
  }

  static Future<Kit> duplicateKit(Kit source, String newDisplayName) async {
    final newFolder = await uniqueFolderName(newDisplayName);
    final srcDir = await kitDir(source.folderName);
    final dstDir = await kitDir(newFolder);
    await _copyDirectoryContents(srcDir, dstDir);
    final newKit = source.copyWith(name: newDisplayName, folderName: newFolder);
    await saveKit(newKit);
    return newKit;
  }

  static Future<void> _copyDirectoryContents(Directory src, Directory dst) async {
    if (!await dst.exists()) {
      await dst.create(recursive: true);
    }
    await for (final entity in src.list()) {
      final name = p.basename(entity.path);
      if (entity is Directory) {
        await _copyDirectoryContents(entity, Directory(p.join(dst.path, name)));
      } else if (entity is File) {
        await entity.copy(p.join(dst.path, name));
      }
    }
  }

  /// Renames a kit's display name (the `name` field inside kit.json). The
  /// on-disk folder name is intentionally left unchanged so nothing else
  /// that references the folder (e.g. the "last used kit" setting) breaks.
  static Future<void> renameKit(Kit kit, String newDisplayName) async {
    kit.name = newDisplayName;
    await saveKit(kit);
  }

  static Future<void> deleteKit(String folderName) async {
    final dir = await kitDir(folderName);
    if (await dir.exists()) {
      await dir.delete(recursive: true);
    }
  }

  /// If no kits exist yet (first launch), copies the bundled "Vintage Kit"
  /// starter samples + kit.json out of the asset bundle and into the
  /// documents directory, so it shows up as a normal, editable, deletable
  /// kit just like any user-created one.
  static Future<void> ensureStarterKitInstalled() async {
    final existing = await listKits();
    if (existing.isNotEmpty) return;
    await _installStarterKitFromAssets();
  }

  static Future<void> _installStarterKitFromAssets() async {
    final folderName = await uniqueFolderName(starterKitDisplayName);
    final destDir = await kitDir(folderName);
    final destSamplesDir = Directory(p.join(destDir.path, 'samples'));
    await destSamplesDir.create(recursive: true);

    for (final fileName in _starterKitSampleFiles) {
      final byteData = await rootBundle.load('$_starterKitAssetDir/samples/$fileName');
      final bytes = byteData.buffer.asUint8List(byteData.offsetInBytes, byteData.lengthInBytes);
      final outFile = File(p.join(destSamplesDir.path, fileName));
      await outFile.writeAsBytes(bytes);
    }

    final kitJsonStr = await rootBundle.loadString('$_starterKitAssetDir/kit.json');
    final map = jsonDecode(kitJsonStr) as Map<String, dynamic>;
    final kit = Kit.fromJson(map, folderName: folderName);
    kit.name = starterKitDisplayName;
    await saveKit(kit);
  }
}

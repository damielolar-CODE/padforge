import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../models/kit.dart';

/// Everything to do with reading and writing Kits on disk.
///
/// A Kit lives at `<app documents>/Kits/<folderName>/kit.json`, with its WAV
/// files in `<app documents>/Kits/<folderName>/samples/`. Kits are ordinary
/// files, so a user can also manage them by connecting their phone to a
/// computer and browsing into the app's document storage if they want to.
///
/// This class is pure I/O -- it doesn't know about MIDI, audio playback, or
/// UI state. See `lib/state/app_state.dart` for the app-wide state that ties
/// this together with everything else.
class KitRepository {
  KitRepository._();

  static const String kitsFolderName = 'Kits';

  // Where the bundled kits live inside the Flutter asset bundle. Every folder
  // listed here must also be declared in pubspec.yaml's `flutter: assets:`
  // section, or its files won't be in the bundle at runtime.
  static const String _kitAssetRoot = 'assets/kits';

  /// Asset folder name -> display name, for every kit shipped inside the app,
  /// in the order they're installed on first launch. The first entry is the
  /// starter kit: the one selected when the app opens for the very first time.
  static const Map<String, String> bundledKits = {
    'vintage_kit': 'Vintage Kit',
    'modern_pop_kit': 'Modern Pop',
    'lofi_kit': 'Lo-Fi Vibes',
  };

  static String get starterKitDisplayName => bundledKits.values.first;

  // Exact filenames written by the tools/synth_*_kit.py generators -- kept as
  // explicit lists (rather than reading AssetManifest.json at runtime) so
  // installing a bundled kit doesn't depend on manifest file formats that have
  // changed between Flutter versions. Keep these in sync with the generators.
  static const Map<String, List<String>> _bundledKitSampleFiles = {
    // tools/synth_vintage_kit.py -- bank A (GM drum map, notes 36-51) then bank B.
    'vintage_kit': [
      'kick.wav',
      'rimshot.wav',
      'snare.wav',
      'clap.wav',
      'snare_alt.wav',
      'tom_floor.wav',
      'hat_closed.wav',
      'tom_floor_hi.wav',
      'hat_pedal.wav',
      'tom_low.wav',
      'hat_open.wav',
      'tom_lowmid.wav',
      'tom_himid.wav',
      'crash.wav',
      'tom_high.wav',
      'ride.wav',
      'kick_long.wav',
      'kick_punch.wav',
      'snare_gated.wav',
      'snare_noise.wav',
      'clap_wide.wav',
      'cowbell.wav',
      'clave.wav',
      'woodblock.wav',
      'conga_hi.wav',
      'conga_lo.wav',
      'maracas.wav',
      'shaker.wav',
      'tambourine.wav',
      'crash_short.wav',
      'zap.wav',
      'noise_sweep.wav',
    ],
    // tools/synth_modern_pop_kit.py -- bank A (GM drum map, notes 36-51) then bank B.
    'modern_pop_kit': [
      'kick.wav',
      'rim.wav',
      'snare.wav',
      'clap.wav',
      'snare_arena.wav',
      'tom_floor.wav',
      'hat_closed.wav',
      'tom_floor_hi.wav',
      'hat_pedal.wav',
      'tom_low.wav',
      'hat_open.wav',
      'tom_lowmid.wav',
      'tom_himid.wav',
      'crash.wav',
      'tom_high.wav',
      'ride.wav',
      '808_c1.wav',
      '808_d1.wav',
      '808_eb1.wav',
      '808_f1.wav',
      '808_g1.wav',
      '808_ab1.wav',
      '808_bb1.wav',
      '808_c2.wav',
      'sub_drop.wav',
      'snap.wav',
      'impact.wav',
      'riser.wav',
      'downlifter.wav',
      'stab_minor.wav',
      'bell.wav',
      'pluck.wav',
    ],
    // tools/synth_lofi_kit.py -- bank A (GM drum map, notes 36-51) then bank B.
    'lofi_kit': [
      'kick.wav',
      'rim.wav',
      'snare.wav',
      'clap.wav',
      'snare_brush.wav',
      'tom_floor.wav',
      'hat_closed.wav',
      'tom_floor_hi.wav',
      'hat_pedal.wav',
      'tom_low.wav',
      'hat_open.wav',
      'tom_lowmid.wav',
      'tom_himid.wav',
      'crash.wav',
      'tom_high.wav',
      'ride.wav',
      'rhodes_cmaj7.wav',
      'rhodes_dm7.wav',
      'rhodes_fmaj7.wav',
      'rhodes_g7.wav',
      'rhodes_am7.wav',
      'bass_upright_c2.wav',
      'bass_upright_g1.wav',
      'guitar_muted.wav',
      'mallet_soft.wav',
      'warm_sub.wav',
      'kick_thump.wav',
      'perc_tick.wav',
      'tape_stop.wav',
      'dust_swell.wav',
      'vinyl_crackle.wav',
      'tape_hiss.wav',
    ],
  };

  static Future<Directory> _kitsRootDir() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, kitsFolderName));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  static Future<Directory> kitDir(String folderName) async {
    final root = await _kitsRootDir();
    return Directory(p.join(root.path, folderName));
  }

  static Future<String> samplesDirPath(String folderName) async {
    final dir = await kitDir(folderName);
    final samplesDir = Directory(p.join(dir.path, 'samples'));
    if (!await samplesDir.exists()) {
      await samplesDir.create(recursive: true);
    }
    return samplesDir.path;
  }

  /// Lists installed kits by folder name, sorted alphabetically. A folder
  /// only counts as an installed kit if it contains a readable `kit.json`.
  static Future<List<String>> listKits() async {
    final root = await _kitsRootDir();
    final names = <String>[];
    await for (final entity in root.list()) {
      if (entity is Directory) {
        final kitJson = File(p.join(entity.path, 'kit.json'));
        if (await kitJson.exists()) {
          names.add(p.basename(entity.path));
        }
      }
    }
    names.sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return names;
  }

  static Future<Kit> loadKit(String folderName) async {
    final dir = await kitDir(folderName);
    final file = File(p.join(dir.path, 'kit.json'));
    final jsonStr = await file.readAsString();
    final map = jsonDecode(jsonStr) as Map<String, dynamic>;
    return Kit.fromJson(map, folderName: folderName);
  }

  static Future<void> saveKit(Kit kit) async {
    final dir = await kitDir(kit.folderName);
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    final file = File(p.join(dir.path, 'kit.json'));
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(kit.toJson()));
  }

  /// Full absolute path to a pad's sample file on disk. Callers should check
  /// [Pad.hasSample] first.
  static Future<String> absoluteSamplePath(Kit kit, String relativeSamplePath) async {
    final dir = await kitDir(kit.folderName);
    return p.join(dir.path, relativeSamplePath);
  }

  static Future<bool> sampleFileExists(Kit kit, String relativeSamplePath) async {
    final path = await absoluteSamplePath(kit, relativeSamplePath);
    return File(path).exists();
  }

  static String _sanitizeFolderName(String name) {
    final cleaned = name.trim().replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    return cleaned.isEmpty ? 'Untitled Kit' : cleaned;
  }

  /// Picks a folder name based on [desiredName] that doesn't collide with an
  /// existing kit folder, appending " (2)", " (3)", etc. as needed.
  static Future<String> uniqueFolderName(String desiredName) async {
    final root = await _kitsRootDir();
    final base = _sanitizeFolderName(desiredName);
    var candidate = base;
    var suffix = 2;
    while (await Directory(p.join(root.path, candidate)).exists()) {
      candidate = '$base ($suffix)';
      suffix++;
    }
    return candidate;
  }

  static Future<Kit> createBlankKit(String displayName) async {
    final folderName = await uniqueFolderName(displayName);
    final kit = Kit.blank(name: displayName, folderName: folderName);
    await samplesDirPath(folderName);
    await saveKit(kit);
    return kit;
  }

  static Future<Kit> duplicateKit(Kit source, String newDisplayName) async {
    final newFolder = await uniqueFolderName(newDisplayName);
    final srcDir = await kitDir(source.folderName);
    final dstDir = await kitDir(newFolder);
    await _copyDirectoryContents(srcDir, dstDir);
    final newKit = source.copyWith(name: newDisplayName, folderName: newFolder);
    await saveKit(newKit);
    return newKit;
  }

  static Future<void> _copyDirectoryContents(Directory src, Directory dst) async {
    if (!await dst.exists()) {
      await dst.create(recursive: true);
    }
    await for (final entity in src.list()) {
      final name = p.basename(entity.path);
      if (entity is Directory) {
        await _copyDirectoryContents(entity, Directory(p.join(dst.path, name)));
      } else if (entity is File) {
        await entity.copy(p.join(dst.path, name));
      }
    }
  }

  /// Renames a kit's display name (the `name` field inside kit.json). The
  /// on-disk folder name is intentionally left unchanged so nothing else
  /// that references the folder (e.g. the "last used kit" setting) breaks.
  static Future<void> renameKit(Kit kit, String newDisplayName) async {
    kit.name = newDisplayName;
    await saveKit(kit);
  }

  static Future<void> deleteKit(String folderName) async {
    final dir = await kitDir(folderName);
    if (await dir.exists()) {
      await dir.delete(recursive: true);
    }
  }

  /// If no kits exist yet (first launch), copies every bundled kit's samples +
  /// kit.json out of the asset bundle and into the documents directory, so
  /// they show up as normal, editable, deletable kits just like user-created
  /// ones.
  ///
  /// Only runs when the user has no kits at all -- once they've started
  /// editing, we never write over their `Kits/` folder.
  static Future<void> ensureStarterKitInstalled() async {
    final existing = await listKits();
    if (existing.isNotEmpty) return;
    for (final assetDirName in bundledKits.keys) {
      await _installBundledKitFromAssets(assetDirName);
    }
  }

  static Future<void> _installBundledKitFromAssets(String assetDirName) async {
    final displayName = bundledKits[assetDirName] ?? assetDirName;
    final sampleFiles = _bundledKitSampleFiles[assetDirName] ?? const <String>[];
    final assetDir = '$_kitAssetRoot/$assetDirName';

    final folderName = await uniqueFolderName(displayName);
    final destDir = await kitDir(folderName);
    final destSamplesDir = Directory(p.join(destDir.path, 'samples'));
    await destSamplesDir.create(recursive: true);

    for (final fileName in sampleFiles) {
      final byteData = await rootBundle.load('$assetDir/samples/$fileName');
      final bytes = byteData.buffer.asUint8List(byteData.offsetInBytes, byteData.lengthInBytes);
      final outFile = File(p.join(destSamplesDir.path, fileName));
      await outFile.writeAsBytes(bytes);
    }

    final kitJsonStr = await rootBundle.loadString('$assetDir/kit.json');
    final map = jsonDecode(kitJsonStr) as Map<String, dynamic>;
    final kit = Kit.fromJson(map, folderName: folderName);
    kit.name = displayName;
    await saveKit(kit);
  }
}

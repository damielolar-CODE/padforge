import 'knob.dart';
import 'pad.dart';

/// A "Kit" is a full set of 48 pads (3 banks of 16) plus 6 knob definitions.
///
/// On disk, each kit lives as a folder under the app's documents directory:
///   Kits/<folderName>/kit.json
///   Kits/<folderName>/samples/*.wav
///
/// [folderName] is the actual directory name on disk (stable, used to locate
/// files) while [name] is the friendly display name shown in the UI -- they
/// can differ, e.g. after a rename that doesn't touch the folder.
class Kit {
  String name;
  final String folderName;
  List<Pad> pads;
  List<KnobDef> knobs;

  Kit({
    required this.name,
    required this.folderName,
    required this.pads,
    required this.knobs,
  });

  static const List<String> banks = ['A', 'B', 'C'];

  /// Akai MPD218 factory-default note numbers: Bank A = 36-51, B = 52-67,
  /// C = 68-83. Every newly-created kit starts out mapped this way so it
  /// "just works" with a stock MPD218 before the user ever touches MIDI
  /// Learn.
  static int defaultNoteFor(String bank, int numberInBank) {
    final bankIndex = banks.indexOf(bank);
    return 36 + (bankIndex * 16) + (numberInBank - 1);
  }

  factory Kit.fromJson(Map<String, dynamic> json, {required String folderName}) {
    final padsJson = json['pads'] as List<dynamic>? ?? const [];
    final knobsJson = json['knobs'] as List<dynamic>? ?? const [];
    return Kit(
      name: json['name'] as String? ?? folderName,
      folderName: folderName,
      pads: padsJson
          .map((e) => Pad.fromJson(e as Map<String, dynamic>))
          .toList(),
      knobs: knobsJson.isEmpty
          ? _defaultKnobs()
          : knobsJson.map((e) => KnobDef.fromJson(e as Map<String, dynamic>)).toList(),
    );
  }

  Map<String, dynamic> toJson() => {
        'schemaVersion': 1,
        'name': name,
        'pads': pads.map((p) => p.toJson()).toList(),
        'knobs': knobs.map((k) => k.toJson()).toList(),
      };

  /// Creates a brand-new kit with all 48 pads present but empty (no sample
  /// assigned), mapped to the MPD218 factory-default note numbers, and the
  /// standard 6 knobs.
  factory Kit.blank({required String name, required String folderName}) {
    final pads = <Pad>[];
    for (final bank in banks) {
      for (var i = 1; i <= 16; i++) {
        pads.add(Pad(padId: '$bank$i', note: defaultNoteFor(bank, i)));
      }
    }
    return Kit(name: name, folderName: folderName, pads: pads, knobs: _defaultKnobs());
  }

  static List<KnobDef> _defaultKnobs() => [
        KnobDef(index: 1, label: 'Master Vol', cc: 70, function: KnobFunction.masterVolume, value: 1.0),
        KnobDef(index: 2, label: 'Pitch/Speed', cc: 71, function: KnobFunction.pitchSpeed, value: 0.5),
        KnobDef(index: 3, label: 'Knob 3', cc: 72, function: KnobFunction.assignable, value: 0.5),
        KnobDef(index: 4, label: 'Knob 4', cc: 73, function: KnobFunction.assignable, value: 0.5),
        KnobDef(index: 5, label: 'Knob 5', cc: 74, function: KnobFunction.assignable, value: 0.5),
        KnobDef(index: 6, label: 'Knob 6', cc: 75, function: KnobFunction.assignable, value: 0.5),
      ];

  /// Pads belonging to one bank ("A", "B" or "C"), in pad-number order.
  /// Relies on [pads] always being stored in creation order (A1..A16,
  /// B1..B16, C1..C16) which every code path that builds a Kit preserves.
  List<Pad> padsForBank(String bank) => pads.where((p) => p.bank == bank).toList();

  Pad? padById(String padId) {
    for (final pad in pads) {
      if (pad.padId == padId) return pad;
    }
    return null;
  }

  /// First pad mapped to [note], regardless of whether it has a sample
  /// assigned. Returns null if nothing is mapped to that note.
  Pad? padByNote(int note) {
    for (final pad in pads) {
      if (pad.note == note) return pad;
    }
    return null;
  }

  KnobDef? knobByIndex(int index) {
    for (final knob in knobs) {
      if (knob.index == index) return knob;
    }
    return null;
  }

  KnobDef? knobByCc(int cc) {
    for (final knob in knobs) {
      if (knob.cc == cc) return knob;
    }
    return null;
  }

  /// Current master volume (0.0-1.0), driven by whichever knob is assigned
  /// the [KnobFunction.masterVolume] function. Defaults to full volume if no
  /// such knob exists.
  double get masterVolume {
    for (final knob in knobs) {
      if (knob.function == KnobFunction.masterVolume) return knob.value.clamp(0.0, 1.0).toDouble();
    }
    return 1.0;
  }

  /// Current playback rate multiplier, driven by whichever knob is assigned
  /// the [KnobFunction.pitchSpeed] function. Knob value 0.0-1.0 maps to a
  /// 0.5x-1.5x playback rate, with the knob's mid-point (0.5) being normal
  /// speed/pitch.
  double get playbackRate {
    for (final knob in knobs) {
      if (knob.function == KnobFunction.pitchSpeed) {
        return 0.5 + knob.value.clamp(0.0, 1.0).toDouble() * 1.0;
      }
    }
    return 1.0;
  }

  Kit copyWith({String? name, String? folderName}) {
    return Kit(
      name: name ?? this.name,
      folderName: folderName ?? this.folderName,
      pads: pads
          .map((p) => Pad(
                padId: p.padId,
                note: p.note,
                samplePath: p.samplePath,
                volume: p.volume,
                chokeGroup: p.chokeGroup,
              ))
          .toList(),
      knobs: knobs
          .map((k) => KnobDef(
                index: k.index,
                label: k.label,
                cc: k.cc,
                function: k.function,
                value: k.value,
              ))
          .toList(),
    );
  }
}

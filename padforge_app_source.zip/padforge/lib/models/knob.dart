/// What a knob controls, at the kit level.
///
/// Kept intentionally simple (per the v1 design goal of not overbuilding a
/// mixing engine): only two knobs do anything to audio playback right now
/// ([masterVolume] and [pitchSpeed]). The rest are "assignable" -- they are
/// still fully MIDI-mappable and renamable, they just don't drive an audio
/// parameter yet. That keeps room for future versions without breaking the
/// kit file format.
enum KnobFunction { masterVolume, pitchSpeed, assignable }

KnobFunction knobFunctionFromString(String? value) {
  switch (value) {
    case 'masterVolume':
      return KnobFunction.masterVolume;
    case 'pitchSpeed':
      return KnobFunction.pitchSpeed;
    default:
      return KnobFunction.assignable;
  }
}

String knobFunctionToString(KnobFunction function) {
  switch (function) {
    case KnobFunction.masterVolume:
      return 'masterVolume';
    case KnobFunction.pitchSpeed:
      return 'pitchSpeed';
    case KnobFunction.assignable:
      return 'assignable';
  }
}

/// One of the six on-screen/hardware knobs belonging to a [Kit].
class KnobDef {
  /// Position in the row of knobs, 1-6.
  final int index;

  /// User-facing label, e.g. "Master Vol". Renamable for assignable knobs.
  String label;

  /// MIDI CC (control change) number this knob listens to / sends on.
  int cc;

  /// What this knob affects.
  KnobFunction function;

  /// Current value, normalized 0.0-1.0. This is what the physical knob's
  /// position (or an on-screen drag) maps to.
  double value;

  KnobDef({
    required this.index,
    required this.label,
    required this.cc,
    required this.function,
    this.value = 0.5,
  });

  factory KnobDef.fromJson(Map<String, dynamic> json) {
    final index = (json['index'] as num).toInt();
    return KnobDef(
      index: index,
      label: json['label'] as String? ?? 'Knob $index',
      cc: (json['cc'] as num).toInt(),
      function: knobFunctionFromString(json['function'] as String?),
      value: (json['value'] as num?)?.toDouble() ?? 0.5,
    );
  }

  Map<String, dynamic> toJson() => {
        'index': index,
        'label': label,
        'cc': cc,
        'function': knobFunctionToString(function),
        'value': value,
      };

  KnobDef copyWith({
    String? label,
    int? cc,
    KnobFunction? function,
    double? value,
  }) {
    return KnobDef(
      index: index,
      label: label ?? this.label,
      cc: cc ?? this.cc,
      function: function ?? this.function,
      value: value ?? this.value,
    );
  }
}

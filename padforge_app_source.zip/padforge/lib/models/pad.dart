/// A single sample pad.
///
/// A [Kit] has 48 of these (banks A/B/C, 16 pads each, named "A1".."C16").
/// Each pad remembers which sample file it plays, which incoming MIDI note
/// number triggers it, how loud it plays, and (optionally) a "choke group" --
/// pads that share a choke group cut each other off when hit, which is how
/// classic drum machines do the open-hat / closed-hat "choke" behavior.
class Pad {
  /// Stable identifier like "A1", "B16", "C4". Never changes after creation.
  final String padId;

  /// MIDI note number (0-127) that triggers this pad.
  int note;

  /// Path to the sample file, relative to the kit's folder, e.g.
  /// "samples/kick.wav". Null means the pad is empty (no sound assigned).
  String? samplePath;

  /// Playback volume for this pad, 0.0 (silent) - 1.0 (full volume).
  double volume;

  /// Optional choke group number. When a pad with a choke group is hit, any
  /// other currently-sounding pad sharing that same choke group is
  /// immediately stopped. Null means "no choke group" (plays independently).
  int? chokeGroup;

  Pad({
    required this.padId,
    required this.note,
    this.samplePath,
    this.volume = 1.0,
    this.chokeGroup,
  });

  /// Bank letter this pad belongs to, e.g. "A" for pad "A7".
  String get bank => padId.substring(0, 1);

  /// The pad's number within its bank, e.g. 7 for pad "A7".
  int get numberInBank => int.parse(padId.substring(1));

  /// Just the filename (no folder) for display in the UI, or a placeholder
  /// if no sample is assigned yet.
  String get sampleFileName {
    final path = samplePath;
    if (path == null || path.isEmpty) return '(empty)';
    final parts = path.split('/');
    return parts.isEmpty ? path : parts.last;
  }

  bool get hasSample => samplePath != null && samplePath!.isNotEmpty;

  /// A short, all-caps name for the sample, for printing on the pad itself:
  /// "KICK", "SNARE", "CL HAT", "FLR TOM".
  ///
  /// A beatmaker reading the grid wants to know what the pad *plays*; "A7"
  /// tells them nothing they cannot count for themselves. Two small rules keep
  /// the result readable on a pad that may be only ~45dp wide:
  ///
  ///  * a trailing drum-kit modifier moves to the front and is abbreviated the
  ///    way it is on hardware, so `hat_closed` reads "CL HAT" rather than
  ///    "HAT CLOSED";
  ///  * long words are shortened ("noise" -> "NZ").
  ///
  /// Anything unrecognised is simply upper-cased, so a user's own imported
  /// sample still gets a sensible label. Returns "--" for an empty pad. The
  /// caller scales the text down to fit, so a long label is never fatal.
  String get sampleShortLabel {
    if (!hasSample) return '--';
    var name = sampleFileName;
    final dot = name.lastIndexOf('.');
    if (dot > 0) name = name.substring(0, dot);
    final words = name
        .split(RegExp(r'[_\-\s]+'))
        .where((word) => word.isNotEmpty)
        .toList();
    if (words.isEmpty) return name.toUpperCase();

    if (words.length == 2) {
      final modifier = _leadingModifiers[words[1].toLowerCase()];
      if (modifier != null) return '$modifier ${_short(words[0])}';
    }
    return words.map(_short).join(' ');
  }

  static String _short(String word) =>
      _abbreviations[word.toLowerCase()] ?? word.toUpperCase();

  /// Words that describe *how* the drum was played, which read better in front
  /// of the drum's name -- exactly as they are printed on hardware.
  static const Map<String, String> _leadingModifiers = {
    'closed': 'CL',
    'open': 'OP',
    'pedal': 'PDL',
    'short': 'SHRT',
    'long': 'LNG',
    'wide': 'WD',
    'gated': 'GT',
    'alt': 'ALT',
    'punch': 'PCH',
    'floor': 'FLR',
    'high': 'HI',
    'low': 'LO',
    'hi': 'HI',
    'lo': 'LO',
    'himid': 'HIMID',
    'lowmid': 'LOMID',
  };

  /// General shortenings, applied to every word.
  static const Map<String, String> _abbreviations = {
    'closed': 'CL',
    'open': 'OP',
    'pedal': 'PDL',
    'short': 'SHRT',
    'long': 'LNG',
    'wide': 'WD',
    'gated': 'GT',
    'punch': 'PCH',
    'floor': 'FLR',
    'high': 'HI',
    'low': 'LO',
    'himid': 'HIMID',
    'lowmid': 'LOMID',
    'noise': 'NZ',
    'sweep': 'SWP',
    'rimshot': 'RIM',
    'tambourine': 'TAMB',
    'woodblock': 'WOOD',
    'maracas': 'MARCS',
    'cowbell': 'COWBEL',
  };

  factory Pad.fromJson(Map<String, dynamic> json) {
    return Pad(
      padId: json['padId'] as String,
      note: (json['note'] as num).toInt(),
      samplePath: json['sample'] as String?,
      volume: (json['volume'] as num?)?.toDouble() ?? 1.0,
      chokeGroup: (json['chokeGroup'] as num?)?.toInt(),
    );
  }

  Map<String, dynamic> toJson() => {
        'padId': padId,
        'note': note,
        'sample': samplePath,
        'volume': volume,
        'chokeGroup': chokeGroup,
      };

  /// Returns a copy of this pad with the given fields replaced.
  ///
  /// Use [clearSample] / [clearChoke] to explicitly set those fields back to
  /// null (since passing `null` for [samplePath] / [chokeGroup] normally
  /// just means "leave unchanged").
  Pad copyWith({
    int? note,
    String? samplePath,
    bool clearSample = false,
    double? volume,
    int? chokeGroup,
    bool clearChoke = false,
  }) {
    return Pad(
      padId: padId,
      note: note ?? this.note,
      samplePath: clearSample ? null : (samplePath ?? this.samplePath),
      volume: volume ?? this.volume,
      chokeGroup: clearChoke ? null : (chokeGroup ?? this.chokeGroup),
    );
  }
}

/// A single sample pad.
///
/// A [Kit] has 48 of these (banks A/B/C, 16 pads each, named "A1".."C16").
/// Each pad remembers which sample file it plays, which incoming MIDI note
/// number triggers it, how loud it plays, and (optionally) a "choke group" --
/// pads that share a choke group cut each other off when hit, which is how
/// classic drum machines do the open-hat / closed-hat "choke" behavior.
class Pad {
  /// Stable identifier like "A1", "B16", "C4". Never changes after creation.
  final String padId;

  /// MIDI note number (0-127) that triggers this pad.
  int note;

  /// Path to the sample file, relative to the kit's folder, e.g.
  /// "samples/kick.wav". Null means the pad is empty (no sound assigned).
  String? samplePath;

  /// Playback volume for this pad, 0.0 (silent) - 1.0 (full volume).
  double volume;

  /// Optional choke group number. When a pad with a choke group is hit, any
  /// other currently-sounding pad sharing that same choke group is
  /// immediately stopped. Null means "no choke group" (plays independently).
  int? chokeGroup;

  Pad({
    required this.padId,
    required this.note,
    this.samplePath,
    this.volume = 1.0,
    this.chokeGroup,
  });

  /// Bank letter this pad belongs to, e.g. "A" for pad "A7".
  String get bank => padId.substring(0, 1);

  /// The pad's number within its bank, e.g. 7 for pad "A7".
  int get numberInBank => int.parse(padId.substring(1));

  /// Just the filename (no folder) for display in the UI, or a placeholder
  /// if no sample is assigned yet.
  String get sampleFileName {
    final path = samplePath;
    if (path == null || path.isEmpty) return '(empty)';
    final parts = path.split('/');
    return parts.isEmpty ? path : parts.last;
  }

  bool get hasSample => samplePath != null && samplePath!.isNotEmpty;

  factory Pad.fromJson(Map<String, dynamic> json) {
    return Pad(
      padId: json['padId'] as String,
      note: (json['note'] as num).toInt(),
      samplePath: json['sample'] as String?,
      volume: (json['volume'] as num?)?.toDouble() ?? 1.0,
      chokeGroup: (json['chokeGroup'] as num?)?.toInt(),
    );
  }

  Map<String, dynamic> toJson() => {
        'padId': padId,
        'note': note,
        'sample': samplePath,
        'volume': volume,
        'chokeGroup': chokeGroup,
      };

  /// Returns a copy of this pad with the given fields replaced.
  ///
  /// Use [clearSample] / [clearChoke] to explicitly set those fields back to
  /// null (since passing `null` for [samplePath] / [chokeGroup] normally
  /// just means "leave unchanged").
  Pad copyWith({
    int? note,
    String? samplePath,
    bool clearSample = false,
    double? volume,
    int? chokeGroup,
    bool clearChoke = false,
  }) {
    return Pad(
      padId: padId,
      note: note ?? this.note,
      samplePath: clearSample ? null : (samplePath ?? this.samplePath),
      volume: volume ?? this.volume,
      chokeGroup: clearChoke ? null : (chokeGroup ?? this.chokeGroup),
    );
  }
}

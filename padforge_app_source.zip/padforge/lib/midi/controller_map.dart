import 'dart:convert';

/// A global, kit-independent map of `MIDI note -> padId`.
///
/// ## Why this exists (the v6 architectural fix)
///
/// Up to v5 the note a pad listened to lived in `kit.json`, one copy per kit.
/// That is the wrong place for it: **which note a pad sends is a property of
/// the controller, not of the sounds.** A user whose MPD218 is on a non-factory
/// preset had to re-learn all 16 pads for every kit they owned, and PadForge
/// shipped a *guess* at the factory note layout that turned out to be wrong on
/// real hardware twice running.
///
/// So the note<->pad relationship moved here: one map, stored once, applied to
/// every kit. The `note` fields in `kit.json` stay exactly as shipped and are
/// used as the **fallback** for any note this map says nothing about, so an
/// untouched install behaves precisely as it did before.
///
/// ## The two invariants
///
/// 1. **A note triggers at most one pad.** Assigning a note that was already
///    pointing somewhere else moves it.
/// 2. **A pad is reached by at most one note.** Assigning a pad that already
///    had a note releases the old one. This is what makes "PAD n -> note n" a
///    well-formed summary table and [noteForPad] answerable, and it is what
///    stops a remapped pad from *also* still answering to its kit default (see
///    [resolve]).
///
/// Pure Dart -- no Flutter, no plugins -- so all of it is unit-testable
/// (`test/controller_map_test.dart`).
class ControllerMap {
  ControllerMap();

  /// Bumped if the stored shape ever changes. Readers ignore anything they do
  /// not understand rather than throwing, so an old build reading a new map
  /// degrades to "no map" instead of crashing.
  static const int schemaVersion = 1;

  final Map<int, String> _noteToPad = <int, String>{};
  final Map<String, int> _padToNote = <String, int>{};

  /// The whole map as `note -> padId`, read-only. Ordering is insertion order.
  Map<int, String> get entries => Map<int, String>.unmodifiable(_noteToPad);

  /// How many notes are mapped.
  int get length => _noteToPad.length;

  bool get isEmpty => _noteToPad.isEmpty;

  bool get isNotEmpty => _noteToPad.isNotEmpty;

  bool hasNote(int note) => _noteToPad.containsKey(note);

  bool hasPad(String padId) => _padToNote.containsKey(padId);

  String? padIdForNote(int note) => _noteToPad[note];

  int? noteForPad(String padId) => _padToNote[padId];

  /// The one function the hot path calls: which pad should [note] trigger?
  ///
  /// [kitPadId] is what the *kit* says (i.e. `kit.padByNote(note)?.padId`), and
  /// the resolution order is:
  ///
  ///  1. **the controller map wins** if it has an entry for this note;
  ///  2. otherwise **fall back to the kit's own note assignment**, so a fresh
  ///     install with no map at all keeps working exactly as it always did;
  ///  3. except that the fallback is **suppressed for a pad the map has
  ///     explicitly claimed**. Without this rule, remapping pad A1 to note 42
  ///     would leave A1 *also* answering to its kit default of 36 -- two notes
  ///     firing one pad, which is precisely the sort of ghost trigger this
  ///     whole feature exists to remove.
  ///
  /// Returns null when nothing should be triggered.
  String? resolve(int note, {String? kitPadId}) {
    final mapped = _noteToPad[note];
    if (mapped != null) return mapped;
    if (kitPadId == null) return null;
    if (_padToNote.containsKey(kitPadId)) return null;
    return kitPadId;
  }

  /// Points [note] at [padId], enforcing both invariants above.
  void assign(int note, String padId) {
    final previousNote = _padToNote[padId];
    if (previousNote != null && previousNote != note) {
      _noteToPad.remove(previousNote);
    }
    final previousPad = _noteToPad[note];
    if (previousPad != null && previousPad != padId) {
      _padToNote.remove(previousPad);
    }
    _noteToPad[note] = padId;
    _padToNote[padId] = note;
  }

  /// Forgets whatever note was pointing at [padId], so the pad goes back to
  /// its kit default.
  void clearPad(String padId) {
    final note = _padToNote.remove(padId);
    if (note != null) _noteToPad.remove(note);
  }

  /// Forgets [note] entirely.
  void clearNote(int note) {
    final padId = _noteToPad.remove(note);
    if (padId != null) _padToNote.remove(padId);
  }

  /// Back to kit defaults everywhere.
  void clear() {
    _noteToPad.clear();
    _padToNote.clear();
  }

  /// Replaces the whole map in one go (used by tests and by an import).
  void replaceAll(Map<int, String> newEntries) {
    clear();
    newEntries.forEach(assign);
  }

  /// Compact JSON: `{"v":1,"map":{"36":"A1","37":"A2"}}`. Keys are strings
  /// because JSON object keys always are.
  String toJsonString() {
    final raw = <String, String>{};
    for (final entry in _noteToPad.entries) {
      raw['${entry.key}'] = entry.value;
    }
    return jsonEncode(<String, dynamic>{'v': schemaVersion, 'map': raw});
  }

  /// Reads a map written by [toJsonString]. **Never throws**: anything
  /// malformed, truncated or from a future schema simply leaves the map empty,
  /// which means "use the kit defaults" -- the safe answer.
  void loadJsonString(String? source) {
    clear();
    if (source == null || source.isEmpty) return;
    try {
      final decoded = jsonDecode(source);
      if (decoded is! Map) return;
      final raw = decoded['map'];
      if (raw is! Map) return;
      raw.forEach((key, value) {
        final note = int.tryParse('$key');
        if (note == null || note < 0 || note > 127) return;
        if (value is! String || value.isEmpty) return;
        assign(note, value);
      });
    } catch (_) {
      clear();
    }
  }

  factory ControllerMap.fromJsonString(String? source) =>
      ControllerMap()..loadJsonString(source);

  /// Human-readable lines, one per mapped note, for the clipboard. Sorted by
  /// note so a paste is easy to read.
  List<String> describeLines() {
    final notes = _noteToPad.keys.toList()..sort();
    return [for (final note in notes) 'note $note -> ${_noteToPad[note]}'];
  }
}

import 'package:flutter/foundation.dart';

/// What kind of thing is currently waiting to be MIDI-learned.
enum LearnKind { pad, knob }

/// Describes exactly which pad or knob is currently "armed" for MIDI Learn.
class LearnTarget {
  final LearnKind kind;
  final String? padId;
  final int? knobIndex;

  const LearnTarget._(this.kind, this.padId, this.knobIndex);

  const LearnTarget.pad(String padId) : this._(LearnKind.pad, padId, null);

  const LearnTarget.knob(int knobIndex) : this._(LearnKind.knob, null, knobIndex);
}

/// Tracks MIDI Learn state: is learn mode active, and if so, which pad or
/// knob is waiting to be assigned?
///
/// The actual "capture the next note/CC and save it" logic lives in
/// `AppState`, since that's where kit data and the MIDI event streams both
/// live. This class just owns the small bit of UI-facing state: what is
/// currently being learned, so pads/knobs can show a "listening..." glow.
class MidiLearnController extends ChangeNotifier {
  LearnTarget? _target;

  LearnTarget? get target => _target;

  bool get isActive => _target != null;

  void startLearnPad(String padId) {
    _target = LearnTarget.pad(padId);
    notifyListeners();
  }

  void startLearnKnob(int knobIndex) {
    _target = LearnTarget.knob(knobIndex);
    notifyListeners();
  }

  void cancel() {
    if (_target != null) {
      _target = null;
      notifyListeners();
    }
  }
}

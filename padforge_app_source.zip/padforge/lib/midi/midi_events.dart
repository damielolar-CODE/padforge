/// Small, plain data classes describing incoming MIDI messages, decoded from
/// the raw 3-byte packets that `flutter_midi_command` hands us.

/// A Note On or Note Off message (a pad hit / release on the hardware).
class MidiNoteEvent {
  final int note;
  final int velocity;
  final bool isOn;
  final int channel;

  const MidiNoteEvent({
    required this.note,
    required this.velocity,
    required this.isOn,
    required this.channel,
  });

  @override
  String toString() => 'MidiNoteEvent(note: $note, velocity: $velocity, isOn: $isOn, ch: $channel)';
}

/// A Control Change message (a knob turn on the hardware).
class MidiCcEvent {
  final int cc;
  final int value;
  final int channel;

  const MidiCcEvent({
    required this.cc,
    required this.value,
    required this.channel,
  });

  @override
  String toString() => 'MidiCcEvent(cc: $cc, value: $value, ch: $channel)';
}

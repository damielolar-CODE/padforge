import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter_midi_command/flutter_midi_command.dart';

import 'midi_events.dart';

/// Thin wrapper around the `flutter_midi_command` plugin.
///
/// This is the ONLY file that talks directly to the MIDI plugin -- everything
/// else in the app (audio engine, UI, kit editing) talks to this class
/// instead. That keeps the "how do we actually get bytes on and off a USB
/// MIDI cable" details in one place.
///
/// Responsibilities:
///  - Scan for connected MIDI devices (USB on Android, Core MIDI on iOS).
///  - Auto-connect to a device whose name contains "MPD218" if one is found.
///  - Decode incoming raw MIDI bytes into [MidiNoteEvent] / [MidiCcEvent]
///    streams that the rest of the app can listen to.
///  - Send outgoing Note On/Off and Control Change messages.
class MidiService extends ChangeNotifier {
  MidiService._internal();

  static final MidiService instance = MidiService._internal();

  final MidiCommand _midiCommand = MidiCommand();

  /// All MIDI devices currently visible to the OS (connected or not).
  List<MidiDevice> availableDevices = [];

  /// The device we're currently connected to, if any.
  MidiDevice? connectedDevice;

  /// True while a scan/connect operation is in flight, so the UI can show a
  /// "Scanning..." indicator instead of a flat "Not Connected".
  bool isScanning = false;

  final StreamController<MidiNoteEvent> _noteEventsController = StreamController<MidiNoteEvent>.broadcast();
  final StreamController<MidiCcEvent> _ccEventsController = StreamController<MidiCcEvent>.broadcast();

  /// Fires for every Note On / Note Off message received from any connected
  /// MIDI device.
  Stream<MidiNoteEvent> get noteEvents => _noteEventsController.stream;

  /// Fires for every Control Change (knob) message received.
  Stream<MidiCcEvent> get ccEvents => _ccEventsController.stream;

  StreamSubscription<MidiPacket>? _dataSub;
  StreamSubscription<MidiSetupChange>? _setupSub;
  bool _initialized = false;

  bool get isConnected => connectedDevice != null;

  String get statusLabel {
    if (isConnected) return connectedDevice!.name;
    if (isScanning) return 'Scanning...';
    return 'Not Connected';
  }

  /// Starts listening for MIDI data/setup changes and does an initial device
  /// scan. Safe to call more than once.
  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;
    try {
      _dataSub = _midiCommand.onMidiPacketReceived?.listen(_handleData);
      _setupSub = _midiCommand.onMidiSetupChanged?.listen((_) {
        refreshDevices();
      });
    } catch (e) {
      debugPrint('MidiService: failed to attach listeners: $e');
    }
    await refreshDevices();
  }

  /// Re-scans for available MIDI devices (e.g. after plugging in a USB
  /// controller). USB devices normally just appear in this list without
  /// needing an explicit "scan" the way Bluetooth MIDI does.
  Future<void> refreshDevices() async {
    isScanning = true;
    notifyListeners();
    try {
      final devices = await _midiCommand.devices;
      availableDevices = devices ?? [];
    } catch (e) {
      debugPrint('MidiService: failed to list devices: $e');
      availableDevices = [];
    }
    isScanning = false;
    notifyListeners();
  }

  MidiDevice? _findDeviceByName(String needle, {bool exact = false}) {
    for (final device in availableDevices) {
      if (exact) {
        if (device.name == needle) return device;
      } else {
        if (device.name.toUpperCase().contains(needle.toUpperCase())) return device;
      }
    }
    return null;
  }

  /// Tries to connect automatically: first to a device whose name contains
  /// [preferredNameContains] (e.g. "MPD218"), then falls back to a device
  /// matching [lastDeviceName] (the last one the user connected to). Returns
  /// true if a connection was made.
  Future<bool> autoConnectPreferred({
    String? preferredNameContains,
    String? lastDeviceName,
  }) async {
    await refreshDevices();

    MidiDevice? target;
    if (preferredNameContains != null) {
      target = _findDeviceByName(preferredNameContains);
    }
    target ??= (lastDeviceName != null) ? _findDeviceByName(lastDeviceName, exact: true) : null;

    if (target != null) {
      await connect(target);
      return true;
    }
    return false;
  }

  Future<void> connect(MidiDevice device) async {
    try {
      await _midiCommand.connectToDevice(device);
      connectedDevice = device;
      notifyListeners();
    } catch (e) {
      debugPrint('MidiService: failed to connect to ${device.name}: $e');
    }
  }

  void disconnect() {
    final device = connectedDevice;
    if (device == null) return;
    try {
      _midiCommand.disconnectDevice(device);
    } catch (e) {
      debugPrint('MidiService: failed to disconnect: $e');
    }
    connectedDevice = null;
    notifyListeners();
  }

  void _handleData(MidiPacket packet) {
    final data = packet.data;
    if (data.isEmpty) return;

    // Standard MIDI channel voice messages are 3 bytes: status, data1, data2.
    // The high nibble of the status byte is the message type, the low
    // nibble is the channel (0-15).
    final status = data[0];
    final messageType = status & 0xF0;
    final channel = status & 0x0F;

    if (messageType == 0x90 && data.length >= 3) {
      // Note On -- some hardware sends "Note On, velocity 0" instead of a
      // real Note Off, so treat that case as a note-off too.
      final note = data[1];
      final velocity = data[2];
      _noteEventsController.add(MidiNoteEvent(note: note, velocity: velocity, isOn: velocity > 0, channel: channel));
    } else if (messageType == 0x80 && data.length >= 3) {
      _noteEventsController.add(MidiNoteEvent(note: data[1], velocity: data[2], isOn: false, channel: channel));
    } else if (messageType == 0xB0 && data.length >= 3) {
      _ccEventsController.add(MidiCcEvent(cc: data[1], value: data[2], channel: channel));
    }
  }

  // --- MIDI OUT -------------------------------------------------------

  /// Sends a Note On message. [velocity] and [note] are clamped to the
  /// valid 0-127 MIDI range.
  void sendNoteOn(int note, int velocity, {int channel = 0}) {
    _send([0x90 | (channel & 0x0F), note & 0x7F, velocity.clamp(0, 127).toInt()]);
  }

  void sendNoteOff(int note, {int channel = 0}) {
    _send([0x80 | (channel & 0x0F), note & 0x7F, 0]);
  }

  void sendCC(int cc, int value, {int channel = 0}) {
    _send([0xB0 | (channel & 0x0F), cc & 0x7F, value.clamp(0, 127).toInt()]);
  }

  void _send(List<int> bytes) {
    try {
      _midiCommand.sendData(Uint8List.fromList(bytes));
    } catch (e) {
      debugPrint('MidiService: failed to send MIDI data $bytes: $e');
    }
  }

  @override
  void dispose() {
    _dataSub?.cancel();
    _setupSub?.cancel();
    _noteEventsController.close();
    _ccEventsController.close();
    super.dispose();
  }
}

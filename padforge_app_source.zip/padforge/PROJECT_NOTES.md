# PadForge -- Project Notes

Plain-English summary for whoever picks this up next (toolchain install +
build). Written by the agent that authored the source tree.

---

# VERSION 8 -- BRANDING: a logo, a wordmark, and an About screen

Up to v7 PadForge shipped Flutter's default launcher icon and the words
"PADFORGE //" in 16pt text. This version gives the product an actual mark, an
app icon set for both stores, and a business card.

## 1. The mark: "the struck pad and the rising step"

A **4x4 pad grid** whose lit pads form an **ascending staircase** from the
bottom-left pad upwards and to the right (column heights 1, 2, 3, 4). The
bottom-left pad is drawn in **cream**: it is the pad that has just been hit.

Three concepts were drawn before this one was picked:

| concept | why it lost |
|---|---|
| A letter **P** built from lit pads | a P needs a counter (the hole), and in a 4x4 grid the counter is one cell. It survives at 192px and turns to mush at 48. It also empties a whole column, so the mark looks off-balance. |
| A **play triangle** | a triangle has no clean apex on an even (4-row) grid -- the tip lands between rows, so it reads as an arrow *or* a plus depending on which cells you light. |
| A **syncopated step pattern** (columns 2,4,1,3) | reads correctly as a sequencer, but the silhouette is arbitrary: nobody can redraw it from memory, which is the whole job of a logo. |

The staircase wins because it is **one rule** -- `lit if row >= 3 - col` --
and it reads three ways at once: a play/forward wedge, a rising velocity ramp,
and a step pattern. It is also *true*: the MPD218's **pad 1 is bottom-left**
and its pads count upwards from there, which is exactly the direction the mark
climbs, and exactly the grid origin `padIndexForGridSlot` draws (v5, section
1). The six unlit pads in the top-left corner are what keep it reading as a
**grid** rather than as a generic triangle.

Deliberately absent: any stroke thinner than a pad, any lettering, any detail
smaller than a cell gap. All three vanish at 48px on a phone home screen,
which is the size that actually decides whether an icon works.

## 2. Palette

Unchanged from the app: chassis `#1A1816`, panel `#242019`, amber `#E8973A`,
amber-deep `#C97A22`, cream `#F2E8D5`. The mark adds *gradient stops* only,
all additive in `AppColors` (`logoLitTop/Mid/Bottom`, `logoStrikeTop/Mid`,
`logoRecessTop/Bottom`). The unlit pad in the mark (`#39332B -> #29241E`) is a
touch lighter than a real pad face (`#2E2A24`) for one reason: at 48px an
unlit pad at the true pad colour disappears into the chassis and the grid
stops reading as a grid.

## 3. Where the assets live

```
assets/branding/logo.svg                   master vector, 1024 viewBox,
                                           hand-authored, NOT bundled in the
                                           app (nothing loads it at runtime)
tools/gen_branding.py                      renders every raster from the same
                                           geometry + verifies what it wrote
branding/android/mipmap-mdpi/ic_launcher.png      48
branding/android/mipmap-hdpi/ic_launcher.png      72
branding/android/mipmap-xhdpi/ic_launcher.png     96
branding/android/mipmap-xxhdpi/ic_launcher.png   144
branding/android/mipmap-xxxhdpi/ic_launcher.png  192
branding/ios/AppIcon.appiconset/Contents.json     19 entries
branding/ios/AppIcon.appiconset/Icon-App-*.png    15 files, 20..1024 px
branding/preview/padforge_icon_preview.png        contact sheet for humans;
                                                  ships nowhere
```

`branding/` is deliberately **outside** `android/` and `ios/`, because CI
regenerates both of those with `flutter create`. Nothing in `branding/` is a
Flutter asset and nothing is listed in `pubspec.yaml`: the in-app mark is
painted, not loaded (section 5).

Android icons are a **rounded-square plate with transparent corners** (the
legacy `ic_launcher.png` convention). iOS icons are **full-bleed squares in
RGB with no alpha channel at all** -- iOS applies its own mask, and the App
Store rejects an icon with transparency.

## 4. What CI must copy, exactly

After `flutter create` / `flutter pub get`, before `flutter build`:

```bash
# Android launcher icons (overwrite the Flutter default robot icons)
cp -f branding/android/mipmap-mdpi/ic_launcher.png    android/app/src/main/res/mipmap-mdpi/ic_launcher.png
cp -f branding/android/mipmap-hdpi/ic_launcher.png    android/app/src/main/res/mipmap-hdpi/ic_launcher.png
cp -f branding/android/mipmap-xhdpi/ic_launcher.png   android/app/src/main/res/mipmap-xhdpi/ic_launcher.png
cp -f branding/android/mipmap-xxhdpi/ic_launcher.png  android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png
cp -f branding/android/mipmap-xxxhdpi/ic_launcher.png android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
# ...or simply:  cp -rf branding/android/mipmap-* android/app/src/main/res/

# iOS app icon set (replace the whole set, so no stale file is left behind)
rm -rf ios/Runner/Assets.xcassets/AppIcon.appiconset
cp -r branding/ios/AppIcon.appiconset ios/Runner/Assets.xcassets/AppIcon.appiconset
```

Notes for whoever wires this:

* The **Android manifest already says `android:label="PadForge"`** in all three
  copies (`android/app/src/main/AndroidManifest.xml`,
  `android_extras/AndroidManifest_reference.xml`,
  `ci_overlay/android_main/AndroidManifest.xml`) and already points at
  `@mipmap/ic_launcher`, so the copy above is the whole Android job.
* **iOS display name**: `ios/Runner/Info.plist` has
  `CFBundleDisplayName = PadForge`, and `CFBundleName` was changed from
  `padforge` to **`PadForge`** in v8 (it is what shows under the icon if
  `CFBundleDisplayName` is ever dropped). `ios_host/Info.plist` already had
  both. If CI regenerates `Info.plist` from scratch, it must re-apply both
  keys.
* The stale icons still sitting in `ios/Runner/Assets.xcassets/AppIcon.appiconset`
  and `android/app/src/main/res/mipmap-*` are the **old** v1 design. They are
  harmless only if the copy step above actually runs -- if it is skipped, the
  old icon ships.
* `tools/gen_app_icon.py` (v1, wrote straight into `android/` and `ios/` with
  the old design) has been **deleted**. Regenerate with
  `python3 tools/gen_branding.py`; it needs Pillow and numpy and it verifies
  its own output.

## 5. In-app branding

* `lib/ui/widgets/padforge_logo.dart` -- `PadForgeLogo` (a `CustomPainter`, so
  it is sharp at any size and any DPI; no raster is ever loaded for in-app
  use) and `PadForgeLockup` (the mark + the `PADFORGE` wordmark). The painter
  uses the same 1024-unit geometry as `logo.svg` and `gen_branding.py`.
  **Change one, change all three.**
* `lib/ui/widgets/status_bar.dart` -- the plain `PADFORGE // ...` text is gone;
  the bar now starts with the lockup and **tapping it opens About**. The MIDI
  dot and the status line follow it, and the gear is unchanged.
* **The bar's height is unchanged.** It is `4 + content + 4` where the content
  height is set by its tallest child, and that is still the settings gear at
  `BoxConstraints.tightFor(height: 30)`. The mark is **18dp** and the wordmark
  16pt inside a 30dp tap target, so nothing here is taller than 30 and the
  ~38dp figure every layout budget in this document assumes still holds. The
  row is additionally wrapped in `MediaQuery.withClampedTextScaling(
  maxScaleFactor: 1.2)`: at a 3.0 system text scale the wordmark plus the
  status line would be wider than a 320dp phone (a RenderFlex overflow) and
  taller than 30dp (which would push the pads down). Every other screen still
  scales freely.
* The tap target is 30dp tall rather than Material's 48, because the bar is
  38dp tall in total and the pads need the rest. It is ~85dp wide, and the
  same screen is also reachable from Settings -> ABOUT -> **About PadForge**.

## 6. The About screen (`lib/ui/screens/about_screen.dart`)

The mark large and centred on the chassis background, `PADFORGE`, the tagline
(*MPC-style sampler for the Akai MPD218*), a `VERSION x.y.z` chip, a three-line
credits block (audio engine / MIDI / **kits are originally synthesised and
royalty-free**), and the copyright line
**`DEESTECH HOLDINGS LLC © 2026`**, reproduced exactly (the sign is
written as a unicode escape in `kAppCopyright` so no tool can mangle it).

It **cannot overflow**: everything is inside a `SingleChildScrollView`, and
the `ConstrainedBox(minHeight: viewport)` + `MainAxisAlignment.center` pattern
is what lets the card sit centred on a tall screen while still scrolling on a
short one (a bare `Column` in a scroll view shrink-wraps and sticks to the
top). The mark is sized as `min(120, 0.34w, 0.24h)`, so it gives way before
the text does.

## 7. The version string

`lib/app_info.dart` holds `kAppName`, `kAppVersion`, `kAppTagline`,
`kAppVendor` and `kAppCopyright` -- one place, no second copies.

**`kAppVersion` must be bumped together with `version:` in `pubspec.yaml`.**
A Flutter app cannot read `pubspec.yaml` at runtime (it is not bundled) and
the usual fix, `package_info_plus`, is a new pub package this project is not
adding. So the constant is guarded instead: `test/app_info_test.dart` reads
`pubspec.yaml` off disk and **fails** if the two disagree, and also asserts
the copyright line character by character (including the copyright sign at
index 22). If `flutter test` runs in CI, drift cannot survive a build.

## 8. Files added / touched in v8

| file | what |
|---|---|
| `assets/branding/logo.svg` | new -- the master vector mark |
| `tools/gen_branding.py` | new -- renders + verifies every icon size |
| `branding/**` | new -- the generated Android/iOS icon sets |
| `lib/ui/widgets/padforge_logo.dart` | new -- `PadForgeLogo`, `PadForgeLockup` |
| `lib/ui/screens/about_screen.dart` | new -- the About screen |
| `lib/app_info.dart` | new -- name, version, tagline, vendor, copyright |
| `test/app_info_test.dart` | new -- version/pubspec and copyright guards |
| `lib/ui/widgets/status_bar.dart` | lockup replaces the plain text, opens About |
| `lib/main.dart` | the splash's placeholder `Icons.grid_view_rounded` became the real mark |
| `lib/ui/screens/settings_screen.dart` | ABOUT section gained an "About PadForge" button |
| `lib/ui/theme/app_theme.dart` | additive: seven `logo*` gradient-stop colours |
| `ios/Runner/Info.plist` | `CFBundleName`: `padforge` -> `PadForge` |
| `tools/gen_app_icon.py` | deleted (superseded) |

## 9. What is most likely to bite (v8 edition)

1. **The CI copy step is the whole delivery.** No copy, no branding: the app
   still builds and still ships the old default icon, silently.
2. **`Contents.json` and the PNGs must stay in sync.** `gen_branding.py`
   asserts both directions (every name exists on disk, every PNG on disk is
   named) and exits non-zero otherwise, so regenerate rather than hand-editing.
3. **No adaptive icon** (`mipmap-anydpi-v26`) is shipped. Flutter's Android
   template does not generate one either, so the legacy `ic_launcher.png` is
   what launchers use; on Android 8+ some launchers shrink a legacy icon
   inside their own shape. The mark's grid fits inside the circle inscribed in
   the square (corner distance 509 of a 512 radius), so it survives a circular
   mask -- but a proper adaptive foreground/background pair would look better
   and is the obvious follow-up.
4. **The 30dp tap target** on the logo is under Material's 48dp minimum. That
   is a deliberate trade against the pad grid's height, and About is also in
   Settings for anyone who misses it.
5. Everything in the v7, v6, v5, v4, v3 and v2 risk lists still applies.

---

# VERSION 7 -- the pads waited for your finger to leave, and the display was 18 pixels tall

v7 fixes three reports from the same session: *"the pads are laggy, on screen
as well as on the MPD218"*, and *"the waveform is not showing up and too
small"*. Two of the three had a single, findable cause each. Neither was in the
audio engine.

## 1. THE BIG ONE: the on-screen pads triggered on finger-**lift**

`lib/ui/widgets/pad_button.dart` played the sample from
`GestureDetector.onTap`:

```dart
GestureDetector(
  onTap: _handleTap,                 // <-- fires on pointer UP
  onTapDown: (_) => setState(...),   // only lit the lamp
)
```

**`onTap` fires when the finger is lifted.** So every on-screen hit was delayed
by however long the player held the pad down: ~80ms for a quick stab, several
hundred for anything expressive, and *unbounded* if they rested a finger. No
audio buffer size can fix that; it is not audio latency at all. This is why the
user said the on-screen pads felt exactly as late as the hardware ones -- they
were late for a completely different reason, which is also why the v5 latency
work did not move the needle for them.

### The fix, and why it is a `Listener` and not `onTapDown`

```dart
Listener(                            // NOT a gesture recogniser
  behavior: HitTestBehavior.opaque,
  onPointerDown: _handlePointerDown, // sound starts HERE, in the dispatch
  onPointerUp: (_) => _release(),    // only clears the pressed look
  onPointerCancel: (_) => _release(),
  child: GestureDetector(
    behavior: HitTestBehavior.opaque,
    onLongPress: _handleLongPress,   // long press ONLY
    child: ...,
  ),
)
```

* `Listener` does not enter the **gesture arena**. Its callback runs inside the
  pointer-down dispatch itself, synchronously, in the same turn as the touch
  event. `onTapDown` would have been better than `onTap` but is still not
  right: a `TapGestureRecognizer` can be held in the arena while a competing
  recogniser (an ancestor scrollable, an edge-swipe back gesture) disambiguates,
  and `onTapDown` only fires once the tap has won or timed out.
* **Long press still works.** A `Listener` observes events, it does not consume
  them, and `GestureDetector` is itself built on a `Listener`, so both render
  objects sit in the same hit-test path. The inner (deeper) one is dispatched
  first -- it registers the long-press recogniser -- and the outer one then
  plays the sound. Holding a pad sounds it immediately and opens the editor half
  a second later, which is how a hardware pad with a shift function behaves.
* **`HitTestBehavior.opaque` is a second real bug fixed here.**
  `GestureDetector` defaults to `deferToChild`, and the only thing inside a pad
  that hit-tests itself is its caption text (`RenderParagraph`). Taps landing on
  the empty part of a pad -- the corners, the space around a short label -- were
  **missed entirely**. That is very likely part of what the user experienced as
  "unreliable", and it was never reported as its own bug because it looks like
  the same problem.
* **No `setState` on the trigger path.** The pressed highlight is now a
  `ValueNotifier<int>` merged into the `AnimatedBuilder`'s listenable. A
  `setState` here would rebuild the pad's whole subtree, including re-laying-out
  its caption, on the very frame the sound has to start, on the same thread.
  It is a **count** of pointers, not a bool, so a second finger landing on a pad
  during a roll does not un-light it when the first lifts.
* **Velocity from touch.** `_velocityFor` defaults to a firm **110** and only
  lets a *usable* pressure reading modulate the top of the range (96..127).
  Phones have no velocity sensor; Android's `pressure` is derived from the
  contact patch and says more about finger size than intent, so a device quirk
  must never be able to make the instrument feel weak. Devices reporting no
  range (`pressureMin == pressureMax`) get the flat 110.
* **Retriggering** was already correct and still is: every hit calls
  `SoLoud.play` again, creating a new voice, so a second tap over a ringing
  first one layers rather than being swallowed. v7 also raises SoLoud's max
  active voices from its default of **16** to **32** (`setMaxActiveVoiceCount`,
  checked against 4.1.6's `soloud.dart`) -- at 16, a two-handed roll on a long
  sample genuinely runs out, and SoLoud's documented behaviour when it does is
  to *stop the oldest voice of that sample*, heard as a note cut short.

## 2. Audio output latency

### 2.1 The buffer size is now the user's choice, and visible

`AudioEngine.bufferLadder` is `[128, 256, 512, 1024, 2048]` (128 is new).
Settings -> **AUDIO** now shows:

* the negotiated numbers in 22pt amber -- `44100 Hz · 256 FRAMES` -- plus
  "about 5.8 ms of output buffer, **plus whatever your phone and speakers
  add**";
* an **AUDIO LATENCY** control with four named rungs: **LOWEST 128 (2.9ms) /
  LOW 256 (5.8ms) / NORMAL 512 (11.6ms) / SAFE 1024 (23.2ms)**, each showing
  both the frame count and the milliseconds, because "256" means nothing to a
  drummer and "5.8 ms" does;
* a plain-words warning that LOWEST can crackle, pop or drop out on some
  phones, and what to do about it (step up one and restart);
* an explicit line when the choice and reality disagree: *"You have chosen 128
  frames. Restart PadForge to use it -- the buffer size is fixed when the audio
  device opens."*

Persisted as `padforge.audioBufferFrames` through `SettingsService`, applied by
`AppState.init` **before** `AudioEngine.init()`, because the buffer size can
only be chosen while the device is being opened. The engine starts at the
chosen rung and steps **up** through the rest of the ladder if the device
refuses -- it never retries something the device has already said no to.
`preferredBufferSize`'s setter snaps anything off the ladder up to the next
rung, so a corrupt setting cannot ask for something absurd.

### 2.2 Pre-warm

`AudioEngine.prewarm()` plays **one silent voice** (`volume: 0.0`) as soon as a
kit finishes decoding, so the player's first audible hit does not pay the
one-time cost of the first `play()` call, or of an Android output stream that
wound itself down while the kit was loading. It is deliberately **not** stopped:
a one-shot sample retires its own voice at its end, which keeps the device
running for a few hundred milliseconds rather than letting it idle straight back
down. Checked against flutter_soloud 4.1.6: `volume` is a real named argument to
`SoLoud.play`, and a zero-volume voice is mixed like any other.

### 2.3 The trigger path, audited again

Touch: `Listener.onPointerDown` -> `AppState.hitPad` -> `_triggerPad` ->
`AudioEngine.playPad` -> `SoLoud.instance.play`. MIDI:
`MidiService._handleData` -> broadcast stream -> `_handleIncomingNote` ->
`_triggerPad` -> the same two calls. **No `await`, no `notifyListeners()`, no
file access, no allocation of any consequence** on either. The one thing left
that is not constant-time is `Kit.padById` / `Kit.padByNote`, which are linear
scans of at most 48 pads comparing 2-3 character strings -- deliberately left
alone, because `kit.pads[i]` is mutated in place by the pad editor and any
cached index would have to be invalidated on every edit, which is a correctness
risk in exchange for well under a microsecond.

### 2.4 The latency test, and what the app refuses to pretend

Settings -> **LATENCY TEST** plays a real kit sample through the same call the
pads use, and explains how to judge it: tap in a steady rhythm (lateness reads
as a stumble in time far more clearly than as a single delay), then try it on
headphones, and remember that Bluetooth adds 100-200ms all by itself.

It also shows **APP TRIGGER TIME** -- measured with a reused `Stopwatch` around
the `SoLoud.instance.play` call -- and says in as many words that this is *not*
the delay you hear. **flutter_soloud 4.1.6 exposes no way to ask the device
what its true output latency is.** There is no such getter anywhere in its Dart
API or its FFI bindings (`getBufferSize` is about a `BufferStream`'s size in
bytes, not the device); `init()` takes a buffer size and never reports what the
backend actually negotiated. So the panel shows the part PadForge is
responsible for, labels it honestly, and states that the rest cannot be measured
from inside the app. A fabricated round-trip number would be worse than none.

**Confidence:** the pointer-down fix is certain (it is a category error, not a
tuning question). The voice-count raise and the pre-warm are safe but their
effect is small. The buffer control is the one with real upside *and* real
downside -- 128 frames will glitch on some phones, which is exactly why it is
opt-in with a warning rather than the default.

## 3. The waveform display: why it was not showing

It was showing. It was **18 logical pixels tall**.

The deck's rows were weighted 34 reels+LCD / 12 waveform / 13 source /
13 quantise / 26 transport = 98, with four 4dp gaps. On a 320x568 phone the
deck is 182.8dp, of which 8 is margin, 12 is padding and 16 is gaps -- leaving
146.8 of flex, so the waveform got `146.8 x 12/98 =` **17.98dp**. Its own
border and 2dp inset take 6 of that, leaving a 12dp drawing area:

* the `NO LOOP` caption is 11pt and lands right on the edge of the painter's own
  `painter.height < size.height` guard -- and past it, so **not drawn at all**,
  whenever the VT323 pixel font falls back to the platform monospace, which
  lays out taller. The empty state could therefore be a bare dark stripe;
* a hit-pattern row was a 1-2px dash;
* an audio envelope was a 14px-tall squiggle.

So "not showing up" and "too small" were the same bug, and it was a **height
budget** bug rather than a painting one. (Everything the v5 painter computed was
correct: `computeWavPeaks` ran, `TapeDeck.loopVisual` was populated on commit,
the playhead moved.)

### 3.1 The space

Deck rows are now **30 reels+LCD / 30 loop display / 13 source+quantise /
24 transport = 97**, with three 4dp gaps, and the home screen's deck ceiling
went from 260 to **290** (it only binds on a 6"+ phone, where there is room).

| row | flex | 320x568 | 390x844 | 430x932 |
|---|---|---|---|---|
| reels + LCD | 30 | 46.6 | 73.2 | 79.8 |
| **loop display** | **30** | **46.6** | **73.2** | **79.8** |
| source + quantise | 13 | 20.2 | 31.7 | 34.6 |
| transport | 24 | 37.3 | 58.6 | 63.9 |

Flex available is `deck - 8 margin - 12 padding - 12 gaps`: **150.8** for the
182.8dp deck on 320x568, **236.8** for the 268.8dp deck on 390x844, **258** for
the capped 290dp deck on 430x932. Every row is `Expanded`, so they sum to the
height available **by construction**: RenderFlex cannot overflow here at any
screen size or text scale.

Full 320x568 budget, unchanged except for the deck's internals:
`h = 548 - 38 status - 53 toolbar = 457`; deck `457 x 0.40 = 182.8`, strip 30,
4 gaps 16, rest 228.2, knobs 43.4, pads **184.8** square (46dp pads). On
390x844: `h = 672`, deck 268.8, pads 289.3 (71dp). On 430x932: `h = 748`, deck
290 (capped), knobs 76 (capped), pads 336 (82dp). The deck's share is still
capped at 45% of `h`, so a short window can never squeeze the pads out.

**The row that paid for it** was QUANTIZE. SOURCE keeps its three explicit
buttons ("why is my voice in the loop?" is one of the two biggest complaints
this app has had). Quantise becomes one wide button that **cycles**
OFF -> 1/4 -> 1/8 -> 1/16 -> OFF (`TapeDeck.cycleQuantize`) and still says
exactly what it is -- `QNT 1/16` / `QNT OFF` -- which was the whole point of the
v5 rewrite. Every division is still directly selectable in the TUNE sheet, and
the LCD's bottom line still spells out what quantise did to the loop that
closed. Widths at 320dp: 3 parts each for SOURCE, 5 for quantise, so
`(288-12)/14` gives 59dp per source button and 98dp for `QNT 1/16`.

### 3.2 The display

`lib/ui/widgets/loop_waveform.dart` is a rewrite:

* **Inset dark LCD panel** (`#0E0D0B`), amber-deep border, inner shadow,
  clipped to its own radius.
* **Audio loops** draw a filled peak envelope with a bright cream outline,
  either side of a **centre zero line**, built as **one closed `Path`** (out
  along the top edge, back along the bottom) rather than three draw calls per
  column -- ~290 columns at ~15 repaints a second makes that worth having.
* **Bar / beat / step gridlines** derived from the loop's bar count and tempo:
  bar lines brightest, beat lines dimmer, quantise-step lines faintest and
  **only drawn when they are at least 4px apart** (below that a grid is noise).
  `LoopVisual` gained `bars`, `beatsPerBar`, `stepsPerBar` and `bpm`;
  `TapeDeck._visualBars()` uses the exact bar count when quantise fixed it and
  derives one from the tempo when it did not.
* **PADS loops** (which have no audio at all -- drawing a fake waveform would be
  a lie) get a **step / piano-roll grid**: one row band per pad that has hits,
  alternate rows shaded, a pad-id caption at the left when the row is at least
  9dp tall, and a rounded mark at every hit whose height and colour follow
  velocity. Rows are sorted the way a human reads pad ids (`A2` before `A10`,
  `A16` before `B1`), so a new overdub on a pad that already has hits lands in
  the row it belongs to.
* **Empty state** is a flat centre line and `NO LOOP`, sized from the panel
  rather than fixed, so it can no longer be skipped for not fitting. While a
  take is being recorded it says `RECORDING` over a filling red wash instead --
  the panel is never blank at the one moment the user is watching it hardest.
* **Playhead** is a 1.6px amber line with a soft halo either side, bright enough
  to find on a lit stage.
* **Corner captions** (`AUDIO` / `PADS` on the left, `4 BARS 90 BPM` on the
  right) when the panel is tall and wide enough to carry them without covering
  the trace.

### 3.3 Cost control

* Peaks are still computed **once per commit** by the deck
  (`TapeDeck._refreshVisual`, generation-counted so a slow read of an old master
  cannot overwrite a newer one) and never per frame.
* New: `resampleWavPeaks` re-buckets that cached envelope onto the panel's exact
  pixel width, and the result is cached in a `_WaveformCache` held by the
  **State** (keyed on `identical(peaks)` + column count), so it is recomputed
  only when the audio or the width changes.
  This matters for correctness, not just speed: the deck computes 240 buckets
  and a phone strip is ~290px wide *or* ~180px narrow. Picking the nearest
  bucket per column -- what v5 did -- **silently drops peaks** when the strip is
  narrower than the bucket count, so a snare can vanish and the display looks
  like it is missing audio that is definitely there. Each column now takes the
  min of the minima and the max of the maxima of the buckets it covers, which is
  what every DAW does when you zoom out.
* `envelopeDisplayGain` scales the *drawing* (never the audio) so a take
  peaking at -20dBFS is still visible, capped at 4x so near-silence is not
  amplified into a wall.
* Row captions are laid out once and cached as `TextPainter`s (at most a few
  dozen, disposed with the State), rather than re-laid-out ~15 times a second.
* Still a `CustomPainter` with a `repaint:` listenable inside a
  `RepaintBoundary`: a moving playhead repaints this one panel and touches no
  element in the widget tree.

`test/wav_peaks_test.dart` (new, 16 tests, pure Dart) covers
`computeWavPeaks`, `resampleWavPeaks` (narrowing keeps every peak, widening
repeats without inventing, identity, one-column collapse, degenerate inputs) and
`envelopeDisplayGain` (including the invariant that `gain x peak <= 1.0`, i.e.
the trace can never be drawn outside the panel).

## 4. Files touched in v7

| file | what |
|---|---|
| `lib/ui/widgets/pad_button.dart` | pointer-down trigger, opaque hit test, ValueNotifier press state, touch velocity |
| `lib/ui/widgets/loop_waveform.dart` | rewritten display: envelope path, grid, step view, empty/recording state, caches |
| `lib/ui/widgets/tape_deck.dart` | row weights 30/30/13/24, SOURCE+QUANTISE merged into one strip |
| `lib/tape/tape_deck.dart` | `LoopVisual` gained bars/beats/steps/bpm, `_visualBars`, `_buildVisual`, `cycleQuantize` |
| `lib/tape/wav_tools.dart` | `resampleWavPeaks`, `envelopeDisplayGain`, `WavPeaks.peakAmplitude` |
| `lib/audio/audio_engine.dart` | 128-frame rung, `preferredBufferSize`, `prewarm`, `playTestClick`, dispatch timing, 32 voices |
| `lib/services/settings_service.dart` | `audioBufferFrames` |
| `lib/ui/screens/settings_screen.dart` | the AUDIO panel: readout, latency control, latency test |
| `lib/ui/screens/home_screen.dart` | deck ceiling 260 -> 290 |
| `lib/state/app_state.dart` | applies the saved buffer size before init; pre-warms after a kit loads |
| `test/wav_peaks_test.dart` | new |

## 5. What to check first on a device (v7)

1. **Tap a pad and let your finger rest on it.** The sound must arrive on the
   way *down*, not when you lift. This is the whole release.
2. Tap the **corner** of a pad, away from the lettering. It must fire.
3. **Hold** a pad: it should sound at once and open the pad editor about half a
   second later.
4. Settings -> AUDIO: what does it say it negotiated? Try **LOWEST 128**,
   restart, and play hard with a loop running -- if it crackles, step up.
5. Record a PADS loop on three or four pads. The display must show one labelled
   row per pad with marks on the gridlines, and the playhead must sweep it.
6. Record a MIC loop. The display must show a filled waveform on a centre line.
7. Rotate through every phone size available: nothing scrolls, nothing
   overflows, the display is a display and not a stripe.

## 6. What is most likely to bite (v7 edition)

1. **128 frames on a mid-range Android.** Underruns are heard as crackle or as
   dropouts under load, and the device may accept the buffer and *then*
   struggle -- which the automatic step-up cannot catch, because it only
   handles an outright refusal. Mitigated by the warning and by 256 remaining
   the default.
2. **Long-press-while-sounding.** Holding a pad now makes a sound before the
   editor opens. That is intended and is how hardware behaves, but someone who
   only ever long-pressed to edit will notice.
3. **Pressure-derived velocity.** A device reporting a wide pressure range but
   a low reading at touch-down gives 96-ish instead of 110. Still loud; still
   musical; but it is device-dependent by nature.
4. **A loop spread over many pads** makes many rows in the step view, and below
   ~5dp of row height the marks are 2px and can overlap their neighbours. It
   still reads as a pattern; it stops reading as separate lanes.
5. **The status bar's height is assumed to be ~38dp** in the budget above. The
   branding work landing alongside this adds a logo there; the arithmetic is
   proportional (`deck = 0.40h`) so it degrades gracefully, but if the status
   bar grows a lot, every worked example above shifts down by that amount.
6. Everything in the v6, v5, v4, v3 and v2 risk lists still applies.

---

# VERSION 6 -- stop guessing the controller, measure it

v6 exists because PadForge guessed what note numbers an Akai MPD218 sends and
**was wrong twice in a row on the user's actual hardware**. This version deletes
the guess from the architecture rather than replacing it with a third one.

## 1. Why guessing was abandoned (read this before "fixing" the note numbers)

The history is worth keeping, because it is the proof that no further guess can
work:

* **v4** assumed pads 1-16 send notes 36-51 with pad 1 **top-left**. Wrong: the
  on-screen grid was a vertical mirror of the hardware.
* **v5** kept the notes and fixed the grid to **bottom-left origin** (pad 1
  bottom-left, ascending left to right then upwards). That is definitely the
  MPD218's physical arrangement, and `test/pad_layout_test.dart` proves the app
  draws it.
* The user then reported: *"mapping was only good on pad 1 and pad 2, the rest
  are still off."*

That last sentence is the whole argument. **If the hardware really sent
36,37,38...51 in simple ascending order, the v5 bottom-left grid would have made
all sixteen pads correct** -- the mapping is a pure function of the note run and
the grid origin, and both were then right. Exactly two correct and then
divergence is only possible if the note sequence is *not* contiguous ascending.
Their unit is on a non-default preset, or the factory map is not what the whole
industry's documentation says it is. Either way, the note numbers are **data
about a particular piece of hardware**, and data belongs in a measurement, not
in a constant.

So: v6 measures.

## 2. The global controller map (`lib/midi/controller_map.dart`)

Up to v5 the note a pad answered to lived in `kit.json`, one copy per kit. That
is the wrong home for it. **Which note a pad sends is a property of the
controller, not of the sounds.** A user with a non-factory preset had to redo
MIDI Learn for all 16 pads in *every kit they owned*, and the bundled kits
shipped the wrong numbers to everyone.

`ControllerMap` is a single `note -> padId` map for the whole app, persisted
once through `SettingsService` (`padforge.controllerMap`) as compact JSON:

```json
{"v":1,"map":{"36":"A1","42":"A2"}}
```

It is **pure Dart** -- no Flutter, no plugins, no imports beyond
`dart:convert` -- which is what makes all of its behaviour unit-testable in
`test/controller_map_test.dart` without a device.

### Resolution order (`ControllerMap.resolve`)

Called on the hot path from `AppState._handleIncomingNote`:

1. **The controller map wins** if it has an entry for the incoming note.
2. **Otherwise fall back to the kit's own `note` field**, so an untouched
   install behaves exactly as it always did and the three bundled kits keep
   working out of the box.
3. **Except:** the fallback is suppressed for a pad the map has explicitly
   claimed. Without rule 3, remapping A1 to note 42 would leave A1 *also*
   answering to its kit default of 36 -- two notes firing one pad, which is the
   precise class of ghost trigger this feature exists to remove.

```dart
String? resolve(int note, {String? kitPadId}) {
  final mapped = _noteToPad[note];
  if (mapped != null) return mapped;              // 1
  if (kitPadId == null) return null;
  if (_padToNote.containsKey(kitPadId)) return null; // 3
  return kitPadId;                                // 2
}
```

### Two invariants, enforced in `assign`

* **A note triggers at most one pad.** Assigning a note that pointed elsewhere
  moves it.
* **A pad is reached by at most one note.** Assigning a pad that already had a
  note releases the old one.

The second one is what makes `PAD n -> note` a well-formed summary table, makes
`noteForPad` answerable (Change 4 depends on it), and makes rule 3 above
meaningful. Both are covered by tests, including the swap case
(`A1<->A2` re-run) that would otherwise leave an orphan.

### What was deliberately *not* done

* **`kit.json` is never rewritten.** Its `note` fields stay as the shipped
  default. Nothing in `assets/kits/` changed.
* **MIDI Learn no longer writes to the kit** either: `_applyPadNoteLearn` is
  gone and learn goes through `AppState.assignControllerNote`, the same call the
  wizard and the pad editor's manual entry use. One writer, so the two features
  cannot disagree.

`AppState` gained: `controllerMap`, `assignControllerNote`,
`clearControllerNoteForPad`, `applyAutoMap`, `clearControllerMap`,
`activeNoteForPad`, `isPadRemapped`, and `setPadTriggeringSuspended`.

## 3. The Auto-Map wizard (`lib/ui/screens/automap_screen.dart`)

Reachable from the bottom toolbar (**Auto-map**, next to MIDI Learn, runs on the
currently selected bank) and from Settings (three buttons, one per bank, so all
48 pads can be mapped).

The flow, per bank:

```
  Hit PAD 1  ->  note arrives  ->  green "PAD 1 = NOTE 42"  ->  Hit PAD 2 ... 16
      |                                                              |
   SKIP (leave unmapped, advance)                                    v
   BACK (clear the previous pad and redo it)                    SUMMARY TABLE
   CANCEL (pop, nothing written)                            BACK / COPY / SAVE
```

* The 4x4 diagram is drawn through the **same `padIndexForGridSlot`** the real
  pad grid uses, so the diagram and the instrument can never disagree about
  which square is pad 1. The target cell is filled amber with a glow, captured
  cells show `NOTE nn` in green, skipped cells say `SKIPPED`, and the subtitle
  says in words that **PAD 1 is the BOTTOM-LEFT pad**.
* **Repeat guard.** A second copy of the note just captured, arriving within
  **300ms**, is ignored *silently* -- pads bounce, and a bounce must not become
  the answer for the next slot.
* **Duplicates warn, they never corrupt.** A note already claimed by another
  slot in this run is refused with an inline red line naming the slot that has
  it, rather than being written twice.
* **Nothing is saved until SAVE.** The summary is the exact table that will be
  stored. **COPY** puts it on the clipboard (`Clipboard.setData`, no new
  package) as `PAD 01 -> note 42` lines -- that is how the real numbers get back
  to whoever is maintaining the shipped defaults.
* While the wizard is on screen, `AppState.setPadTriggeringSuspended(true)`
  stops incoming notes playing pads: being asked for pad 3 and hearing pad 11
  fire is confusing, and worse, it would land in an armed loop. It is reset in
  `dispose`, which also cancels the note subscription.

## 4. The MIDI Monitor (`lib/ui/screens/midi_monitor_screen.dart`)

Settings -> CONTROLLER MAP -> **MIDI MONITOR**. Ground truth, on the phone:

* A large readout at the top -- `NOTE 42  VEL 118  CH 1` at 38pt amber -- because
  the user is hitting pads and glancing at the screen.
* Below it, the last **50** messages newest-first: type (`NOTE ON` / `NOTE OFF` /
  `CC`), the note or CC **number**, velocity or value, and channel (printed
  1-16, as hardware prints it, not the wire's 0-15).
* **Clear** and **Copy** in the app bar. Copy writes the whole log as plain text
  to the clipboard so it can be pasted into a bug report.
* It costs nothing when closed: both stream subscriptions are attached in
  `initState` and cancelled in `dispose`, and every `setState` is `mounted`-
  guarded because the broadcast streams outlive the screen.

## 5. The mapping is now visible (Change 4)

* **Pad editor** prints `NOTE nn` -- the note that will *actually* fire the pad --
  plus a line saying where it came from (`From your controller map. This kit's
  own default is note 36.`) and a **Use the kit default instead** button when it
  is overridden. The "Advanced: enter note manually" field writes to the
  controller map too.
* **Settings -> CONTROLLER MAP** shows `n pad(s) remapped`, and a `Wrap` of one
  chip per pad of the current bank (`A1  36`), **green when the note came from
  the controller map and dim when it came from the kit**. A mismatch is now
  something you read, not something you diagnose by ear.

## 6. Layout arithmetic (nothing scrolls awkwardly, nothing overflows)

The wizard's capture step is a `LayoutBuilder` + `Column` where every fixed row
is capped at **both** an absolute dp value and a fraction of the available
height `h`:

| row | cap | fraction |
|---|---|---|
| `Hit PAD n` prompt | 56 | 0.15h |
| bank / progress subtitle | 34 | 0.10h |
| status (confirm / warning) | 40 | 0.11h |
| footer (BACK / SKIP / CANCEL) | 48 | 0.13h |
| 4 gaps | 8 each | 0.02h each |

The fractions sum to at most **0.57h**, so the diagram always gets at least
0.43h and the column's children sum to exactly `h` **by construction** -- there
is no screen size and no system text scale at which it can be asked for more
room than it has.

**Worked example, 320x568.** Status bar ~24 + app bar 56 leaves a 488 body; this
screen's own 12dp padding leaves `h = 464`. Prompt `min(56, 69.6) = 56`,
subtitle `min(34, 46.4) = 34`, status `min(40, 51) = 40`, footer
`min(48, 60.3) = 48`, gaps `4 x min(8, 9.3) = 32`; total 210, leaving **254** for
the diagram against a content width of 296 -- so a **254dp square**, each cell
`(254 - 3 x 5) / 4 = 59.75dp`. Both lines in a cell are `Flexible` +
`FittedBox(scaleDown)`, so even a 40dp cell shrinks its lettering instead of
overflowing. The summary step uses the same shape (0.09h header + 0.13h footer +
2 x 0.02h gaps = at most 0.26h), leaving 0.74h for a scrolling table -- a 16-row
table is *meant* to scroll.

The bottom toolbar went from three buttons to four:
`(320 - 16 padding - 24 gaps) / 4 = 70dp` each, captions still
`FittedBox(scaleDown)`.

`_ActiveNoteChips` carries **its own** `ListenableBuilder` even though its parent
has one, because it is constructed `const`: `Element.updateChild` short-circuits
on an identical widget, so a `const` child of a rebuilding parent renders once
and then freezes. Same trap the tape deck's const LCD lines hit in v2.

## 7. Files added in v6

| file | what |
|---|---|
| `lib/midi/controller_map.dart` | `ControllerMap` -- resolution, both invariants, JSON round trip. Pure Dart. |
| `lib/ui/screens/automap_screen.dart` | the wizard: prompt, bottom-left diagram, repeat guard, duplicate warning, summary + copy + save |
| `lib/ui/screens/midi_monitor_screen.dart` | `MidiLogEntry` + the live monitor |
| `test/controller_map_test.dart` | 22 tests: resolution order, ghost-trigger suppression, duplicates, swaps, round trip, malformed input, clearing |

Modified: `lib/state/app_state.dart` (resolution + the map's public API),
`lib/services/settings_service.dart` (`controllerMapJson`),
`lib/ui/screens/settings_screen.dart` (the CONTROLLER MAP panel),
`lib/ui/screens/pad_edit_screen.dart` (active note + source + kit-default
reset), `lib/ui/widgets/bottom_toolbar.dart` (the fourth button).

## 8. What to check first on a device (v6)

1. Settings -> CONTROLLER MAP -> **MIDI MONITOR**. Hit pads 1..16 in order and
   read the note numbers off the screen. **Copy and send them** -- that is the
   data that was missing for two releases.
2. **Auto-map** from the toolbar. Hit each pad as prompted; every square should
   turn green with the note printed on it. Save, then play: the square that
   lights must be the pad under your finger, and it must be the sound you
   expect.
3. Double-hit a pad hard during the wizard: it must **not** skip a slot.
4. Hit an already-used pad: you must get the red duplicate warning, not a
   silent bad mapping.
5. Settings: the bank's chips should now be green with your real numbers.
   **CLEAR MAP** must put the kit's numbers back.
6. Switch kits: the mapping must survive (that is the whole point of it being
   global).

## 9. What is most likely to bite (v6 edition)

1. **A controller that sends the same note for several pads** (some presets do
   this for pad banks). The wizard refuses the duplicate and the user has to
   SKIP; the map then simply has fewer entries. Correct, but it will look like
   a failure to them.
2. **Notes the map does not cover still fall through to the kit.** That is
   deliberate (rule 2 above) and is what keeps a fresh install working, but on
   a partially mapped bank an unexpected note can still fire a kit pad. Rule 3
   stops the *duplicate* case; it cannot stop an entirely unrelated note.
3. **Note Off is ignored everywhere**, as it always has been. A pad that
   latches on the hardware will look like a repeat in the monitor.
4. **The monitor calls `setState` per message.** A knob sweep is ~100 CC/s; a
   50-row list rebuild is cheap, but if it ever janks, coalesce behind a 50ms
   timer (and remember to cancel it in `dispose`).
5. Everything from the v5, v4, v3 and v2 risk lists still applies.

---

# VERSION 5 -- the grid was mirrored, latency, real quantise, waveform, one screen

v5 is a bug-fix release driven by a user playing the app on an Android phone
with an MPD218 in front of them. Five of the six items below are things that
were *wrong*, not things that were missing.

## 1. THE BIG ONE: the pad grid was mirrored (`lib/ui/widgets/pad_grid.dart`)

**On the MPD218, pad 1 is the BOTTOM-LEFT pad.** The pads ascend left to right
and then *upwards*: 1-4 across the bottom, 5-8 above them, 13-16 across the
top. PadForge drew them with a `GridView.builder` in list order, so A1 sat
top-left and the screen was a **vertical mirror image** of the hardware under
the player's hands.

The sound was always right (hits are matched by MIDI note number, never by
screen position) but the square that lit up was up to three rows away from the
pad being struck, so the app looked and felt like it was playing the wrong
sample. The user reported it as "the wrong sample plays" and "only one pad is
accurately mapped" -- the one pad that happens to land in the same place in
both layouts.

The fix is `padIndexForGridSlot(slot, bottomLeft:)`, a pure function tested in
`test/pad_layout_test.dart`:

```
   drawn slot 0..3    -> pads 13..16   (notes 48-51)   top of the screen
   drawn slot 4..7    -> pads  9..12   (notes 44-47)
   drawn slot 8..11   -> pads  5..8    (notes 40-43)
   drawn slot 12..15  -> pads  1..4    (notes 36-39)   bottom = hardware pad 1
```

`padId <-> note` assignment is **untouched** (A1..A16 = 36..51, B = 52..67,
C = 68..83) and no kit file was edited. This is purely the order the squares
are drawn in.

Two supporting changes:

* **Pads are labelled with the sample, not the pad id.** `Pad.sampleShortLabel`
  turns `hat_closed.wav` into `CL HAT`, `tom_floor.wav` into `FLR TOM`,
  `kick.wav` into `KICK`; the pad id sits small and dim in the corner. Both
  lines are `Flexible` + `FittedBox(scaleDown)`, so no label can overflow a pad
  however small the pad or however large the system text scale.
* **Settings -> PAD LAYOUT** switches between `MPD218 (bottom-left)` (default)
  and `Top-left`, persisted through `SettingsService` for a unit configured
  the other way round.

## 2. Latency (`lib/audio/audio_engine.dart`, `lib/tape/`, `lib/ui/`)

The Dart trigger path was already synchronous and stayed that way. What v3/v4
had added on top of it was **constant UI work on the same thread the trigger
runs on**. Five changes, in rough order of expected effect:

1. **The transport stopped rebuilding the world.** The looper's tick used to
   call `notifyListeners()` on the deck twenty times a second, and the deck is
   what the whole tape panel listens to -- so a playing loop rebuilt the reels,
   the LCD, both control strips and six buttons, 20x/second, forever. The deck
   now notifies its listeners **only when something structural changes**
   (state, layers, settings). The moving playhead goes out separately on
   `TapeDeck.transportTicks` at ~15Hz, and exactly three things listen to it:
   the reels, two LCD lines, and the waveform painter.
2. **The reels repaint without rebuilding.** `TapeReelsPainter` now takes a
   `ReelModel` (a `ChangeNotifier`) and passes it to `CustomPainter`'s
   `repaint:` argument. The animation clock writes to the model; the model
   repaints the painter; **no `setState`, no element-tree work**. The clock
   still stops itself entirely when the reels have coasted to a halt, so an
   idle deck costs nothing.
3. **The LCD only relayouts when its text changes.** `_LcdLine` caches the
   string it last showed and calls `setState` only when a new one differs.
4. **Everything continuously repainting is inside a `RepaintBoundary`:** reels,
   waveform, LCD, each pad, each knob.
5. **Pad flashes are local.** Each `PadButton` is its own `RepaintBoundary`,
   its caption is passed to `AnimatedBuilder` as `child` (so the flash never
   re-lays-out text), and a hit still triggers **no** `notifyListeners()`
   anywhere -- it goes out on the `padHitEvents` broadcast stream that only the
   16 visible pads listen to.

Engine-side:

* **Buffer ladder now starts at 256** frames (`[256, 512, 1024, 2048]`), ~5.8ms
  at 44.1kHz, falling back exactly as before if the device refuses.
  `AudioEngine.activeBufferSize` records the rung that worked and
  `latencyDebugLine` renders it; **Settings -> AUDIO** shows
  `44100 Hz - 256 frames (~5.8 ms buffer)` so a user can report what their
  phone actually negotiated.
* **Android low-latency path:** read from the plugin's own source
  (`flutter_soloud/lib/src/soloud.dart`, v4.1.7). `androidAAudioAttributes` has
  exactly two values -- `mediaMusic` and `unmanaged` -- and its own doc comment
  says it is **ignored unless `lowLatency: false`**. There is no "game" or
  "low latency" attribute to pick: the low-latency profile is selected by
  `lowLatency: true`, which uses AAudio's MMAP path and which PadForge already
  passes. So we keep `lowLatency: true` and pass `mediaMusic` explicitly with a
  comment explaining why it is the right (and inert) choice. Switching to
  `unmanaged` would only matter if we managed `AudioAttributes` ourselves via
  `audio_session`, which we do not; switching to `lowLatency: false` would make
  latency *worse* in exchange for screen-recordability.
* **MIDI path audited end to end.** `MidiService._handleData` -> broadcast
  stream -> `AppState._handleIncomingNote` -> `_triggerPad`: no `await`, no
  `notifyListeners()`, no file access. `_triggerPad`'s three steps were
  re-ordered so the **sound is started first**, the hit is timestamped for the
  looper second, and the UI flash goes out last.

## 3. Loop playback (`lib/tape/loop_events.dart`, `lib/tape/tape_deck.dart`)

Two real bugs, plus a structural change so the timing can be tested.

**Bug A -- hits could be skipped or doubled near the seam.** Playback used a
cursor (`_nextEventIndex`) that was rewound whenever the pass number changed.
That is correct only while the 10ms timer is punctual. It is not punctual on a
phone: a tick can arrive 60ms late, and then a *whole pass* of a short loop
could be stepped over (every hit in it lost), while a hit within a tick of the
seam could fire on both sides of the rewind.

Replaced by `LoopScheduler` (pure Dart, no Flutter, no plugins), which works on
the **absolute** elapsed time of the one transport stopwatch and fires every
hit whose position falls in the window `(previous elapsed, current elapsed]`,
walking as many passes as that window spans:

```dart
for (pass = from ~/ loopMs; pass <= to ~/ loopMs; pass++) {
  fire every event with (from - pass*loopMs) < offset <= min(to - pass*loopMs, loopMs-1)
}
```

Because the windows are contiguous and never overlap, **every hit fires exactly
once per pass, in order**, whatever the jitter. A stall longer than one loop is
clamped to one loop's worth of catch-up so a suspended app does not machine-gun
on resume. Committing a layer mid-pass needs no special case any more: hits
behind the playhead are simply not in any future window, so the player never
hears the notes they just played echoed straight back.

`test/loop_scheduler_test.dart` drives it across 12 passes with ticks jittering
5-45ms and asserts the once-per-pass property, the ordering, the no-burst
clamp, a 200ms loop ticked every 250ms, and the mid-pass commit case.

**Bug B -- the master swap doubled the loop for a frame.** At the seam,
`_applyPendingMaster` started the freshly mixed master and then called
`unloadClip` on the old one -- but `unloadClip` stops the old voice *after* an
async gap, so both were audible together for a frame or two. That is exactly
the "doubled / out-of-sync layers" the user described. `AudioEngine.stopClipNow`
now silences the outgoing master synchronously (the plugin's `stop()` reaches
native before its Future ever yields), before the new one starts.

Also: the transport tick is **8ms while pad hits are actually being replayed**
(it costs almost nothing now that it no longer notifies anything) and **33ms**
otherwise -- arming, recording, or a mic-only loop, where nothing needs
millisecond timing and the tick only moves a reel. `_reindexEvents` is gone
(the absolute-window model makes it unnecessary), and UNDO now refreshes the
waveform.

## 4. Quantise, rewritten (BUG 4 -- "not sure it's doing anything")

The user was right: v4's "quantise" only rounded the loop's *length*. It never
touched a single hit. On any drum machine, quantise means snapping hits to a
grid. It now does:

1. **Every hit snaps to the grid.** New selector next to the button: **1/4,
   1/8, 1/16** (default 1/16). Snapping applies to the base pass and to every
   overdub layer as it is committed.
2. **It is non-destructive.** `LoopPadEvent` carries both `rawOffsetMs` (as
   played) and `offsetMs` (as played back). Layers always store the raw
   timing; `_rebuildEvents()` derives the playback offsets. Turning quantise
   off, or changing the division, re-derives them -- so your human feel comes
   back rather than being destroyed.
3. **A hit that snaps onto the end of the loop wraps round to the start**
   rather than being dropped, which is what v4 did to the most important hit in
   the bar.
4. **Length is forced, not rounded.** With a fixed length (4/8/16) the loop is
   *exactly* that many bars at the current tempo. FREE still rounds to the
   nearest whole bar, minimum one. Quantise off leaves the length alone.
5. **It says what it is doing.** The button reads `QNT 1/16` / `QNT OFF`, and
   when a loop closes the LCD (and a snackbar) confirms `QNT 1/16 - 4 BARS`.
   The setting persists between launches.

Mic audio is never time-stretched -- only the loop's length is enforced, by
trimming or padding the take, exactly as before. Snapping applies to pad hits
in PADS and BOTH.

## 5. Waveform LCD (`lib/ui/widgets/loop_waveform.dart`)

A dark inset strip on the deck, cream trace, thin amber playhead:

* **Audio loops** draw a peak envelope. `computeWavPeaks` (in `wav_tools.dart`,
  pure Dart) reduces the WAV to one min/max pair per bucket -- never every
  sample -- and the deck computes it **once per commit** (`_refreshVisual`),
  caching it in `TapeDeck.loopVisual`. A generation counter stops a slow read of
  an old master overwriting a newer one.
* **PADS loops have no audio at all**, so they draw the loop's hit pattern
  instead: one mark per hit, height by velocity, stacked by layer, on grid lines
  at the quantise division. For a drum loop that is more useful than a waveform.
* Empty state is a flat centre line and `NO LOOP`.
* `RepaintBoundary` + a `CustomPainter` `repaint:` listenable, so the playhead
  moves without rebuilding anything.

## 6. One screen, no scrolling (`lib/ui/screens/home_screen.dart`)

The instrument no longer scrolls on any phone. Everything sizes itself from the
height that is actually available:

```
  available h  = screen - safe areas - status bar - toolbar
  deck         = clamp(h * 0.40, 150, 260), never more than 45% of h
  strip        = min(30, h * 0.08)          kit name + bank tabs on ONE row
  gaps         = 4 x min(4, h * 0.01)
  rest         = h - deck - strip - gaps
  knobs        = clamp(rest * 0.19, 34, 76), never more than half of rest
  pads         = rest - knobs               square, capped by (width - 20)
```

**Worked example, 320x568 (the smallest phone worth supporting).** SafeArea
leaves ~548 usable. Status bar: 4 + max(30, ~19 text) + 4 = **38** (the gear is
constrained down from Material's 48dp minimum, which is where most of that
saving comes from). Bottom toolbar: 5 + [6 + 16 icon + 2 + ~13 text + 6] + 5 =
**53**. So `h = 548 - 38 - 53 = 457`.

| piece | height |
|---|---|
| tape deck | 457 x 0.40 = **182.8** (inside 150..260, under the 205.6 ceiling) |
| kit strip + bank tabs | min(30, 36.6) = **30** |
| 4 gaps | 4 x min(4, 4.57) = **16** |
| rest | 457 - 182.8 - 30 - 16 = **228.2** |
| knobs | 228.2 x 0.19 = **43.4** (above the 34 floor, under the 76 cap and under half of rest) |
| pads | 228.2 - 43.4 = **184.8**, and the width allows 320 - 20 = 300, so a **184.8dp square** |

Total: 182.8 + 30 + 16 + 43.4 + 184.8 = **457** -- it adds up by construction,
because `pads = rest - knobs`, and the deck can never exceed 45% of `h` while
the strip and gaps are capped at 8% and 4%, so `rest` can never go negative.
Each pad is (184.8 - 3 gaps x 5) / 4 = **42dp**, tappable. Inside the deck,
182.8 - 12 padding - 16 gaps = 154.8 of flex: reels/LCD 53.7, waveform 19,
source 20.5, quantise 20.5, transport 41. On a 430x932 phone the same
arithmetic gives a 260dp deck (capped) and a ~330dp pad grid (80dp pads): the
same instrument, simply bigger.

Inside the deck the same rule applies one level down: **no fixed dp heights at
all**, every row is an `Expanded` with a flex weight (34 reels+LCD / 12
waveform / 13 source / 13 quantise / 26 transport), so the deck fits whatever
box it is handed. Icon sizes come from `LayoutBuilder` (a fraction of the row
height), and every caption is `FittedBox(scaleDown)` or `Flexible`, so a large
system text scale shrinks lettering instead of overflowing.

Other compaction: the kit strip and the bank tabs share one row (banks are
`A` / `B` / `C`); the status bar and bottom toolbar are slimmer; and the
fold-out TUNE controls became a **bottom sheet** (they used to grow the panel
inline, which cannot work when nothing scrolls). Sheets may scroll -- the
instrument may not.

## 7. Files added in v5

| file | what |
|---|---|
| `lib/tape/loop_events.dart` | `LoopPadEvent` (raw + playback offsets), `QuantizeGrid`, `snapOffsetMs`, `effectiveOffsetMs`, `LoopScheduler`. Pure Dart, no imports at all. |
| `lib/ui/widgets/loop_waveform.dart` | the waveform / step-pattern LCD |
| `test/loop_scheduler_test.dart` | jittery-tick and quantise unit tests |
| `test/pad_layout_test.dart` | grid-origin and pad-label tests |

`computeWavPeaks` / `WavPeaks` were added to `lib/tape/wav_tools.dart`;
`stopClipNow`, `activeBufferSize` and `latencyDebugLine` to `AudioEngine`;
pad-layout and quantise persistence to `SettingsService`.

## 8. What to check first on a device

1. Hit the bottom-left hardware pad: the **bottom-left** square must light, and
   it must say `KICK`.
2. Settings -> AUDIO: which buffer size did the phone accept?
3. Record a sloppy 4-bar PADS loop with `QNT 1/16` on: the hits should tighten
   audibly, the waveform's marks should sit on the grid lines, and the LCD
   should read `QNT 1/16 - 4 BARS`. Turn quantise off: the sloppiness comes
   back (nothing is lost).
4. Overdub three layers and undo them one at a time: no doubling at the seam,
   no drift.
5. Rotate through every phone size you have: nothing scrolls, nothing overflows.

---

# VERSION 4 -- overdub, layers and undo

v3's looper could record one pass and repeat it. That is a tape delay, not a
looper. v4 makes the LOOP pad a proper **one-switch looper** in the Boss RC
sense: the same pad records the first pass, then adds layer after layer on top
of it, and UNDO takes the last one back off.

## 1. The tap cycle (`lib/tape/tape_deck.dart`)

```
  EMPTY ─tap─▶ ARMED ─first pad hit, or the mic crossing the
    ▲            │     threshold in MIC/BOTH ─▶ RECORDING (base layer, t=0)
    │            │                                   │
    │            │                       tap ends it, length quantised
    │            │                                   ▼
    │            │        ┌──────────────────────▶ PLAYING ◀─────────────┐
    │            │  tap   │                          │  ▲                │
    │            │ (END   │                      tap │  │ tap STOP       │
    │            │  DUB)  │                    (DUB) │  │                │
    │            │        └── OVERDUBBING ◀──────────┘  │                │
    │  tap STOP  │              │  tap STOP cancels      │                │
    │◀───────────┘              └───── this layer ───────┘                │
    │                                                                     │
    │       hold either tape pad 800ms                                    │
    └────────────── clears everything ◀──────── STOPPED ◀─────────────────┘
                                                  │ tap LOOP (PLAY)
                                                  └────────────▶ PLAYING
```

The LOOP pad's caption is **always the next tap's action**, never the current
state -- this was the single biggest complaint in v3 testing and it stays fixed:

| State | Pad reads | Colour |
|---|---|---|
| EMPTY | `ARM` | amber |
| ARMED | `REC` | amber, lit |
| RECORDING | `END REC` | red |
| PLAYING | `DUB` | green |
| OVERDUBBING | `END DUB` | red, **pulsing** (620ms breath on the glow) |
| STOPPED | `PLAY` | amber |

Overdubbing is deliberately the only pulsing state, so "laying a layer over a
running loop" can never be confused with "recording the first pass" or with
plain playback. The reels keep spinning during an overdub and the record lamp
goes red (`TapeDeck.isCapturing` drives both).

**What v3 behaviour changed:** tapping LOOP while playing used to restart the
loop from the top. That slot is now DUB. To restart from the top, tap STOP then
LOOP -- playback always starts from position 0.

**STOP** now means: while playing, silence the loop (it is kept); *during an
overdub*, throw away only the layer in progress and carry on playing; while
armed or recording the base pass, discard the take, exactly as before.

## 2. The layer model

A loop is a list of `_LoopLayer`s. `_layers[0]` is the base pass and can never
be removed by undo (hold a pad to clear instead). Each layer holds:

* the pad events it added (`List<LoopPadEvent>`, each tagged with its layer
  index), and
* `previousMasterPath` -- the master loop WAV as it was *before* this layer's
  microphone audio was mixed in, which is what undo restores.

`_events` (the flat, offset-sorted list the player walks) is **rebuilt from the
layers** every time one is added or removed, so the two can never disagree and
undo cannot leave a stray event behind.

| Source | What a layer is | Undo |
|---|---|---|
| **PADS** | More `(padId, offsetMs, velocity)` events, offsets taken modulo the loop length. Nothing is mixed, nothing degrades, no files at all. | Drop the layer, rebuild `_events`. Exact. |
| **MIC** | The take is summed into the master loop WAV at the right offset, wrapping round the end (`mixWavIntoLoop`). The result is written to a **new** file; the old one is kept as this layer's `previousMasterPath`. | Reload the previous master, delete the superseded one. |
| **BOTH** | Both of the above in one layer record. | One undo rolls back both. |

**Why mic layers are mixed down rather than played side by side:** one master
WAV looping inside SoLoud is guaranteed to stay sample-locked forever. Five
separate looping sources started at five different moments are not -- they drift,
and there is no way to nudge them back. Mixing costs an undo stack; drift costs
the whole feature.

Each committed mic layer writes one loop-length WAV into `Recordings/.loop/`.
`TapeDeck.maxOverdubLayers = 8`, so at most 8 backups plus the live master can
exist at once (a 10-second mono loop is ~880KB, so ~8MB worst case). Trying to
start a ninth overdub is refused with a message rather than silently dropping
the oldest backup -- predictable beats clever. `clearAll()` deletes every
backup, the live master, the staged master and any scratch take.

## 3. The timing model -- read this before touching the tick

There is **one clock**: `_transportClock`, a `Stopwatch` started when playback
begins. Everything is derived from it, nothing accumulates, so nothing can
drift relative to anything else:

```dart
elapsed  = _transportClock.elapsedMilliseconds;
pass     = elapsed ~/ loopMs;          // which lap we are on
position = elapsed - pass * loopMs;    // where in the loop we are
```

* `_loopPositionMs()` is the single source of "where is the tape". An overdub's
  start offset, a pad hit captured during an overdub, and the offset a recorded
  layer is mixed in at all come from it.
* **Pad events fire exactly once per pass.** `_nextEventIndex` only moves
  forward within a pass and is reset *only* at the seam. When the pass number
  changes, `_advancePlayback` first calls `_fireEventsUpTo(loopMs)` to flush
  anything still owed from the pass that just ended (so a hit 3ms before the end
  is never skipped by the 10ms tick), *then* resets the cursor. Double-firing is
  structurally impossible because the cursor never moves backwards except at
  that one reset.
* **Committing a pad layer mid-pass is safe.** `_rebuildEvents()` re-sorts and
  then `_reindexEvents()` sets the cursor past everything at or before the
  current position -- which is right, because the user just played those hits
  live and must not hear them again until the loop comes round.
* **The mic offset is read *after* `_recorder.start()` returns**, not when the
  pad was tapped. Opening the microphone takes a moment on a phone and the
  file's first sample belongs where the loop had actually got to by then. This
  is the one place with irreducible error: whatever latency the platform adds
  between `start()` returning and the first captured sample shows up as a fixed
  offset on that layer. If layers land consistently late on a device, that is
  the constant to trim.
* **The master WAV is swapped at the loop seam, never mid-loop.** A freshly
  mixed master is staged (`_pendingMasterPath` / `_pendingClipId`) and
  `_applyPendingMaster` swaps it in when the pass number changes -- the one
  moment when starting a new looping clip at position 0 agrees with the clock.
  Swapping mid-loop would put the audio out by however far round we were. STOP
  applies the staged master immediately (nothing is sounding, so there is
  nothing to be out of step with).
* Overdubbing again *before* the staged master reaches the seam is fine: the
  next mix reads the staged file (`_masterForMixing()`), stacks onto it, and
  supersedes the staging. The superseded *file* stays, because it has just
  become the new layer's undo target.
* **Undo restarts the loop from the top.** It has just swapped the master for a
  different file, and starting the audio and the clock together at zero is the
  only way to be *certain* they agree. Undo is a corrective action, not a
  musical one, so a jump to the top is an acceptable price for provable sync.
* Dart's stopwatch and SoLoud's native loop are still two independent clocks, so
  over many minutes the pad layer can creep against the mic layer. That was
  already true in v3; overdub does not make it worse.

## 4. New WAV maths (`lib/tape/wav_tools.dart`, unit-tested)

* `mixWavIntoLoop(loop, overlay, offset:)` -- sums `overlay` into `loop`
  starting `offset` into it, **wrapping around the end back to the start**, int16
  with clipping at +32767/-32768. The result is always exactly as long as `loop`,
  whatever the overlay's length: **overdub can never change the loop length.** An
  overlay longer than the loop keeps going round and sums onto its own earlier
  lap, which is what actually happened acoustically. A mono overlay lands on
  every channel of a stereo loop. The input arrays are never mutated -- undo
  depends on that.
* `buildSilentWav(...)` -- a silent bed of exactly the loop length, used when a
  mic layer arrives and there is no master audio yet (a BOTH loop whose base
  pass was pads only).
* `wavFramesForDuration(...)` -- the frame-rounding helper `wavBytesForDuration`
  now delegates to, so trimming, padding and overdub placement can never land a
  frame apart.

16 new tests in `test/wav_tools_test.dart` cover offsets, wraparound, offsets
past the loop end, over-length overlays, clipping, channel spreading,
non-mutation of the input, and the rejection cases.

## 5. UI (`lib/ui/widgets/tape_deck.dart`)

* **UNDO** is a sixth button on the transport row (LOOP, STOP, UNDO, REC, TUNE,
  TAPES), greyed out and unresponsive unless `TapeDeck.canUndo` -- i.e. there is
  an overdub layer *and* the deck is settled (playing or stopped). While a layer
  is being recorded, STOP is the control that throws it away, so undo stays
  unambiguous.
* **`LAYERS n`** shares the LCD's fourth line with the pad-hit count
  (`LAYERS 3  12 HITS`, or just `LAYERS 3` in MIC mode), so the readout keeps
  the four rows it has always had and the deck does not get taller.
* While overdubbing, the LCD's second line reads `DUB FROM 03.4s`, making it
  obvious a layer can be dropped in anywhere in the loop, not just at the top.
* **Mic bleed**: in MIC/BOTH only, one dim line under the source selector reads
  "Headphones recommended for overdubs". Overdubbing out loud means the mic
  re-records the loop from the phone's speaker, which turns to mush within a
  couple of layers. One line, no dialog, and it does not exist at all in PADS
  mode.

**Overflow budget**, since nothing here could be run: the transport row is now
six `Expanded`s (flex 4/4/3/3/3/3 = 20) and five 6dp gaps. On a 320dp phone the
deck's content width is 320 - 24 (margin) - 20 (padding) = 276dp, so 246dp
across 20 units = ~12dp per unit: LOOP/STOP ~49dp, the small buttons ~37dp.
Every caption in them is `maxLines: 1` + `ellipsis` (small buttons) or
`FittedBox(scaleDown)` (tape pads), so a narrow phone or a large text scale
shrinks type rather than overflowing. The mic-bleed line is a `FittedBox` in a
13dp box and only appears in MIC/BOTH, adding 17dp to the deck's height -- which
costs scroll, not an overflow, because the whole deck lives inside the home
screen's `SingleChildScrollView`.

## 6. What is most likely to bite (v4 edition)

1. **Mic-layer alignment on real hardware.** The offset is measured when
   `_recorder.start()` returns; any latency the platform adds before the first
   sample lands shows up as a constant late offset on every mic layer. Nothing
   here could be measured without a device. If layers land late, subtract a
   constant from `_overdubMicOffsetMs`.
2. **The seam swap is quantised to the 10ms tick.** A new master starts up to
   one tick late, so there can be a ~10ms hiccup at the boundary on the pass
   where a layer arrives. Audible as a tiny flam, not as a desync (the clock is
   not affected).
3. **`mixWavIntoLoop` runs on the UI isolate.** A 10s mono loop is ~440k frames
   and takes a few milliseconds; a 60s loop is ~2.6M and might hitch visibly at
   the moment a layer is committed. If it ever janks, put it behind `compute()`
   -- it is a pure function of two byte arrays for exactly that reason.
4. **Undo restarts the loop from the top** by design (see the timing model). If
   that ever reads as a bug, the fix is a seam-deferred undo, not an immediate
   mid-loop swap.
5. Everything from the v3 and v2 risk lists still applies.

---

# VERSION 3 -- the tape deck, rebuilt around real-world use

**Superseded in part by v4:** the looper's state machine and the LOOP pad's
labels are now the ones in the v4 section above (`DUB` / `END DUB` replace
`RESTART`). Everything else here -- quantise, the source selector, the recorder,
the WAV tools, the layout rules -- still stands.

v2's looper worked but was the wrong shape. Testing it on a real phone turned
up four complaints, and this version is a targeted answer to each:

| Complaint | Fix |
|---|---|
| "the recording captures the mic along with the pads -- that's a nono" | **Record source: PADS / MIC / BOTH**, defaulting to PADS, where the microphone is never opened at all. |
| "the loop is unending and the capture does not make sense" | New **FREE length** default: the loop ends when *you* say so, on the second tap. |
| "tap once to arm, loop starts once the pad hits, tapping again quantises it" | The new **state machine** below; the LOOP pad now always says what the next tap will do. |
| "I want a quantize loop button" | **QUANTIZE toggle** on the face of the deck, on by default. |

## 1. The looper's state machine (`lib/tape/tape_deck.dart`)

```
  EMPTY ──tap LOOP──▶ ARMED ──first PAD HIT (or, in MIC/BOTH, the mic
    ▲                   │      crossing the threshold)──▶ RECORDING
    │      tap STOP     │                                      │
    │◀──────────────────┘                    tap LOOP again ────┤ (or the bar
    │                                        closes the loop    │  count runs
    │                                                           ▼  out)
    │                                                        PLAYING
    │                                                    │          ▲
    │        hold either tape pad for 800ms              │ tap STOP │ tap LOOP
    └─────────────── (clears everything) ◀───── STOPPED ◀─┘          │
                                                     └──────────────┘
```

* **The LOOP pad is labelled with its *next* action**, not its current state:
  `ARM` → `REC` → `END` → `RESTART` (while playing) / `PLAY` (while stopped).
  Its colour follows too: amber when idle/armed, red while recording, green
  while playing. This was the single biggest source of confusion in v2.
* **Recording starts at exactly t=0.** Arming does not start the clock. The
  clock starts on the trigger -- the first pad hit, or (only in MIC/BOTH) the
  microphone crossing the threshold, whichever happens first. In MIC/BOTH the
  mic *is* already recording while armed; the "waiting" portion is snipped off
  the front afterwards, so nothing of the first note is lost.
* **The second tap ends the loop**, quantises it, and starts playback
  immediately. It repeats forever until STOP.
* **STOP**: while playing, silences the loop but keeps it (tap LOOP to resume).
  While armed or recording, it *discards* the take -- that's the escape hatch.
* **Hold either tape pad for 800ms** to wipe everything, with the same
  progress-fill animation as before.
* **Length selector: FREE / 4 / 8 / 16 bars**, FREE being the default. With
  FREE, only the second tap ends the loop. With 4/8/16, the recording also
  stops itself once that many bars have elapsed (v2's behaviour) -- the second
  tap still ends it early.
* Tempo is locked once a loop *exists* (rather than as soon as you arm, as in
  v2), so tap-tempo still works while you're waiting to start.

## 2. Quantise

A QUANTIZE toggle sits on the face of the deck, **on by default**, and reads
`QNT ON` / `QNT OFF` in amber-when-on so its state is unmissable.

When on, the finished loop's length is rounded to the **nearest whole bar** at
the current BPM, with a floor of **one bar**. A bar is `4 * 60 / bpm` seconds
(4/4). Concretely, in `TapeDeck._finalLength`:

```dart
var wholeBars = (raw.inMicroseconds / barDuration.inMicroseconds).round();
if (wholeBars < 1) wholeBars = 1;
```

Then the take is made to match, exactly:

* **too long** → trimmed (`trimWav`, as in v2);
* **too short** → topped up with silence (`padWavWithSilence`, new);
* **pad events keep their offsets**, and any event landing at or past the final
  length is dropped rather than wrapped around.

Both halves share `wavBytesForDuration()` so they can never disagree by a frame
at the seam. The resulting length is shown on the LCD (`4 BARS 8.0s`), so it is
obvious what quantise did.

With quantise off the loop is exactly the time between the two taps -- except
that a second tap within 250ms is treated as a fumble and ignored, since a
0.1s loop is never what anyone meant.

## 3. Record source: PADS / MIC / BOTH

A three-way selector on the deck's control strip, **defaulting to PADS**. It is
shared by the looper and the unlimited recorder (one deck, one source), and
changing it is refused while a loop exists -- the deck says "Clear the loop
before changing the source" rather than ending up half one thing and half the
other.

### In the looper

| Source | What happens |
|---|---|
| **PADS** (default) | Only the pad performance is captured, as the existing `(padId, offsetMs, velocity)` list, replayed through the sampler on every pass. **`AudioRecorder` is never constructed into use, `hasPermission()` is never called, and no permission dialog appears.** The trigger that starts recording is simply the first pad hit. |
| **MIC** | Only the microphone, threshold-armed exactly as in v2. Pad hits still *start* an armed loop (it's the most reliable "I've begun" signal) but are not stored as events. |
| **BOTH** | Two independent layers, played together: the mic WAV looping inside SoLoud plus the pad events re-triggered from Dart. They are deliberately **not** mixed into one file -- layering keeps the pads digitally clean. |

The threshold slider and input meter only appear in MIC/BOTH; in PADS mode
they're hidden entirely, because there is no input to threshold.

### In the unlimited recorder (`lib/tape/take_recorder.dart`)

The REC button records whatever the source selector says, so you can render a
clean, shareable take of a pad performance with no microphone involved:

* **PADS** taps the audio engine's own master output via
  `AudioEngine.startMasterCapture()`, which wraps `flutter_soloud`'s
  `SoLoud.instance.startMixerOutputStream(format: MixerOutputFormat.pcmS16le,
  sampleRate: 44100, channels: 2)`.
* **MIC** is the v2 behaviour.
* **BOTH** captures the two separately and then **sums them into one file**
  (`mixWavPair`, int16 with clipping rather than wrap-around). There's no
  live-feedback concern here, so one file is friendlier. If the pair is over
  60MB combined -- roughly 3.5 minutes, the point where a per-sample loop on
  the UI isolate stops being instant -- they are left side by side as
  `pads_*.wav` and `mic_*.wav` and the UI says so.

**Why raw PCM and not `MixerOutputFormat.wav`:** SoLoud's WAV mode emits a
44-byte header with *placeholder* sizes that has to be patched afterwards with
`getMixerOutputWavHeader()`. Since we pick the sample rate, channel count and
bit depth ourselves, it's simpler and safer to take plain `pcmS16le` and write
our own header with `buildWavHeader`. The chunks stream into a scratch `.pcm`
file in `Recordings/.loop/`, and on stop the header is written to the real
`.wav` and the PCM is piped in behind it -- so a long take never has to sit in
memory, and no bytes are ever rewritten in the middle of a file.

**`startMixerOutputStream` is marked `@experimental` upstream**, so every path
through it has a fallback: `startMasterCapture` returns `null` instead of
throwing, and if it fails the recorder records the **microphone** instead and
sets `TakeRecorder.notice`, which the deck flashes up as a snackbar. It never
silently records nothing.

## 4. New WAV tools (`lib/tape/wav_tools.dart`)

Still pure Dart, still no Flutter imports, all unit-tested in
`test/wav_tools_test.dart` (24 tests):

* `padWavWithSilence(bytes, targetLength:)` -- the other half of quantising.
  Zero-fills for signed PCM; 8-bit WAV is unsigned so its silence is 128, which
  is handled and tested.
* `mixWavPair(a, b)` -- sums two 16-bit WAVs, clipping at ±32767/-32768,
  duplicating a mono take across a stereo one, result as long as the longer
  input. Refuses (returns null) on mismatched sample rates.
* `wavBytesForDuration(...)` -- the shared frame-rounding helper.

## 5. Deck layout (`lib/ui/widgets/tape_deck.dart`)

Top to bottom: reels + LCD (92dp) / the always-visible control strip (28dp:
`SRC  PADS MIC BOTH   QNT ON`) / the transport row (56dp: LOOP, STOP, REC,
TUNE, TAPES) / and behind TUNE, the fold-out with tempo + tap tempo, the
FREE/4/8/16 length selector, and (MIC/BOTH only) the threshold slider and input
meter.

**Overflow safety**, since none of this could be run here: every horizontal row
divides its space with `Expanded`, and the only fixed widths in a row are the
short labels (30-44dp) and the quantise button (64dp) -- 108dp of fixed width
in the widest case, against ~276dp of content width on a 320dp phone. Every
caption is either a `FittedBox(BoxFit.scaleDown)` or has
`overflow: TextOverflow.ellipsis`, so text scaling can't break a row either.
The whole deck still lives inside the home screen's `SingleChildScrollView`, so
growing taller costs scroll, not an overflow. The one deliberate exception:
the threshold `Slider` row is *not* height-constrained, because a Material
Slider will shrink into a smaller box and then paint its thumb overlay outside
it.

The vintage reel-to-reel painter and the amber-on-charcoal theme are untouched.

## 6. What is most likely to bite (v3 edition)

1. **`startMixerOutputStream` is experimental** and was never run here. If the
   symbol doesn't exist in the resolved `flutter_soloud`, `audio_engine.dart`
   won't compile -- it is confined to `startMasterCapture` /
   `stopMasterCapture`, and deleting those two methods plus making
   `TakeRecorder._startEngineCapture` return `false` degrades the whole feature
   to "mic only", cleanly. (Verified present in the v4.1.6 tag of
   `alnitak/flutter_soloud`, which is what the pubspec pins.)
2. **Engine capture at runtime.** Native mixer capture may emit nothing on some
   Android devices. It fails loudly (falls back to the mic, shows a notice)
   rather than saving silence.
3. **BOTH on the recorder holds both WAVs in memory to mix**, on the UI
   isolate. Guarded at 60MB combined, above which it keeps two files instead.
   If it ever janks noticeably, move `mixWavPair` behind `compute()`.
4. Everything from the v2 risk list below still applies.

---

# VERSION 2 -- low-latency audio + tape deck

Everything below the "VERSION 1" divider is the original v1 write-up and is
still broadly accurate for MIDI, kits and the pad grid. This section covers
what changed in v2. **The looper's state machine, its length handling and the
recorder's source handling were all replaced in v3 -- read the v3 section
above for those; the rest of this section still stands.**

## 1. Playback latency: `audioplayers` is gone, `flutter_soloud` is in

**The problem.** v1's `lib/audio/audio_engine.dart` kept a pool of
`audioplayers` `AudioPlayer`s and called `player.play(DeviceFileSource(path))`
on every pad hit. That means: open the file, decode it, hand it to the platform
media player, then make a sound -- per hit. On top of that, `AppState._triggerPad`
did `await KitRepository.absoluteSamplePath(...)` (which awaits
`getApplicationDocumentsDirectory()`) *between* the MIDI/touch event and the
play call, adding at least one more event-loop turn.

**The fix, in two halves:**

1. **Preload the whole kit into RAM.** `AudioEngine.loadKitSamples()` decodes
   every sample of the current kit with `SoLoud.instance.loadFile(path,
   mode: LoadMode.memory)` and caches the resulting `AudioSource` per pad id.
   This runs when a kit is loaded or switched, while the status bar shows
   `LOADING KIT...` (`AppState.isLoadingKit`). Switching kits calls
   `unloadKitSamples()` first (`SoLoud.disposeSource` on every source), so
   memory doesn't grow with each switch.
2. **Make the trigger path completely synchronous.** `AudioEngine.playPad()`
   returns `void` and does nothing but `SoLoud.instance.play(source, ...)`.
   `AppState.hitPad` / `_triggerPad` are now `void` too, and the path lookup
   is gone (paths are resolved once, at preload time). There is no `await`
   anywhere between an event arriving and a voice starting.

The engine is started once in `AudioEngine.init()` with `bufferSize: 512`,
`sampleRate: 44100`, `Channels.stereo`, `lowLatency: true`. If the device
refuses that buffer size we retry at 1024 then 2048 (`_bufferSizeAttempts`).
If all three fail, `failureMessage` is set to `AUDIO ENGINE FAILED` and the
status bar shows it in red -- the app stays usable rather than crashing or
being silently mute.

Preserved from v1: per-pad volume, velocity scaling, master-volume knob,
pitch/speed knob (`setRelativePlaySpeed`) and choke groups (a
`Map<int, SoundHandle>` of the live voice per group; a new hit in the group
fires `SoLoud.stop()` on the old handle without awaiting it).

`flutter_soloud` is confined to `lib/audio/audio_engine.dart`, the same way
`flutter_midi_command` is confined to `lib/midi/midi_service.dart`. The tape
deck plays arbitrary WAV files through a small integer-id "clip" API
(`loadClip` / `playClip` / `stopClip` / `unloadClip` / `isClipVoiceActive`) so
it never imports the audio package itself.

## 2. Tape deck (looper + unlimited recorder)

Lives in `lib/tape/` (logic) and `lib/ui/widgets/tape_deck.dart` +
`lib/ui/widgets/tape_reels.dart` (presentation), pinned to the top of the home
screen above the kit strip.

### Looper state machine (`lib/tape/tape_deck.dart`)

```
  EMPTY ──tap LOOP──▶ ARMED ──mic crosses threshold, or a pad is hit──▶ RECORDING
    ▲                   │                                                  │
    │       tap STOP    │                                    loop length elapses
    │◀──────────────────┘                                                  ▼
    │                                                                   PLAYING
    │                                                                │       ▲
    │        hold either tape pad for 800ms wipes everything          │ STOP  │ LOOP
    └──────────────────────────────────── EMPTY ◀───────── STOPPED ◀──┘       │
                                                              └───────────────┘
```

* **Loop length** = `bars * 4 * (60 / bpm)` seconds (4/4). Bars is 4, 8 or 16.
  BPM defaults to 90, is adjustable by +/- 1 and by a **tap-tempo** button
  (averages the intervals of up to the last 5 taps; taps more than 2s apart
  start a fresh measurement). Tempo and bar count are locked while a loop
  exists -- the recorded audio and the captured pad hits are already locked to
  them, so you clear first.
* **Hands-free start.** Arming opens the mic *immediately* and records to a
  scratch WAV in `Recordings/.loop/`, but the loop clock does not start. When
  `record`'s `onAmplitudeChanged` reports a level at or above the threshold
  (adjustable slider, dBFS, default -30, with a live level meter beside it),
  or when the user hits a pad, we note `t0 = elapsed so far` and start the
  clock. Recording runs until `t0 + loopDuration`, then the take is trimmed:
  the first `t0` is cut off the front and anything past one loop length is cut
  off the end (`trimWav` in `lib/tape/wav_tools.dart`).
* **Pad hits are captured separately** as `(padId, offsetMs, velocity)` and
  re-triggered through the sampler on every pass by a 100Hz `Timer.periodic`,
  so drum parts loop at full digital quality rather than through the room.
  Both layers play together; hold-to-clear wipes both.
* Mic audio loops seamlessly via SoLoud's own `looping: true` -- Dart is not in
  the loop for the audio, only for the pad events.

### WAV trimming (`lib/tape/wav_tools.dart`)

Pure Dart, no Flutter imports, unit-tested in `test/wav_tools_test.dart`.
`readWavInfo` walks RIFF chunks properly (rather than assuming a 44-byte
header) so it copes with platforms that insert extra chunks, and clamps a
`data` chunk size that over-promises. `trimWav` cuts on whole frame boundaries
and rewrites a canonical 44-byte header with corrected `ChunkSize` /
`Subchunk2Size`.

### Unlimited recorder (`lib/tape/take_recorder.dart`)

The round REC button on the deck. No length limit; shows mm:ss while running;
saves to `<app documents>/Recordings/take_YYYYMMDD_HHMMSS.wav`. The
**Recordings screen** (`lib/ui/screens/recordings_screen.dart`, reachable from
the deck's TAPES button and from Settings) lists takes with play/stop, delete
and a **share/export** action via `SharePlus.instance.share(ShareParams(files:
[XFile(path)]))`.

### Microphone arbitration (`lib/tape/mic_arbiter.dart`)

Only one of the looper / take recorder may hold the mic at a time. Whoever
tries second gets a message instead of a confusing platform error.

### The reel-to-reel visuals (`lib/ui/widgets/tape_reels.dart`)

`TapeReelsPainter` draws two reels (spoked flange, metal hub with slotted
screws and a spindle, a wound-tape annulus whose radius tracks progress, a
sweep-gradient rim highlight), a tape path with a catenary sag over a
three-head block, and a lamp that goes red while recording. `TapeReelsView`
owns an `AnimationController` used purely as a per-frame clock: each frame it
eases the reel speed towards spinning/stopped, so the reels spin up and coast
to a halt, and it stops the controller entirely once they've settled.

## 3. Layout safety

The home screen is now `StatusBar` (fixed) / `SingleChildScrollView` (tape
deck, kit strip, bank tabs, pad grid, knobs) / learn banner + bottom toolbar
(fixed). Putting the whole middle in one scroll view means the layout can
never produce a RenderFlex overflow on a small phone -- it scrolls instead.
The deck itself is a fixed ~176dp (92 reels/LCD + 8 + 56 transport + 20
padding); the tempo/bars/threshold controls are behind the deck's TUNE toggle
so they only take space when wanted. Every line of the LCD readout is an
`Expanded` + `FittedBox(BoxFit.scaleDown)`, so it cannot overflow at any text
scale.

**Flutter trap worth remembering:** `Element.updateChild` short-circuits when
the new widget is *identical* to the old one, which is exactly what happens
with `const` child widgets. `_TapeLcd`, `_TapeSettings` and `_InputLevelMeter`
are const, so each wraps itself in its own `ListenableBuilder` on
`TapeDeck.instance` -- otherwise they would render once and then freeze.

## 4. Platform configuration

* Android `RECORD_AUDIO` permission added to **every** copy of the manifest,
  because CI overlays one of them over the generated project:
  * `android/app/src/main/AndroidManifest.xml`
  * `android_extras/AndroidManifest_reference.xml`
  * `ci_overlay/android_main/AndroidManifest.xml` (this is the one the GitHub
    Actions workflow copies into place -- if the permission is only in the
    first file it is silently dropped at build time)
* iOS `Info.plist`: `NSMicrophoneUsageDescription` added ("PadForge uses the
  microphone to record loops and audio takes."). Without it iOS kills the app
  the instant it touches the mic. `UIBackgroundModes: audio` was already set.
* iOS Podfile is already `platform :ios, '13.0'`, which satisfies both
  `flutter_soloud` and `record`.

## 5. Known risks for the CI build (read this first if it fails)

1. **`flutter_soloud: ^4.1.7`** -- 4.1.7 is very recent (8 Aug 2026) and has no
   git tag upstream yet. Every API this project uses (`init` with
   `bufferSize`/`lowLatency`, `loadFile`, `play(..., looping:)`,
   `setRelativePlaySpeed`, `setVolume`, `stop`, `disposeSource`,
   `getIsValidVoiceHandle`, `deinit`) also exists in **4.1.6**, so if pub can't
   resolve 4.1.7 the constraint can be relaxed to `^4.1.6` with no code change.
   `deinitAsync()` (4.1.7-only) was deliberately *not* used for this reason.
2. **`record: ^7.1.1` needs Dart `^3.12.0` / Flutter `>=3.44.0`.** CI is on
   stable 3.44.9, which should be Dart 3.12. If pub complains about the SDK,
   that is why.
3. **Native builds.** `flutter_soloud` compiles C++ through CMake/NDK, and
   `record_android` 2.1.2 wants `compileSdk 36`. Expect a noticeably longer
   first build and a bigger APK. If Gradle complains about `compileSdk`, the
   generated `android/app/build.gradle.kts` needs `compileSdk = 36`.
4. **win32 resolution.** `share_plus` 12.0.2 pins `win32: ^5.5.3` and
   `file_picker` 11.x pins `win32: ^5.9.0` -- both live in 5.x, so they
   co-exist. Do **not** bump `share_plus` to 13.x (it moves to win32 6.0.0 and
   will conflict with `file_picker` the same way `flutter_midi_command` 1.0.9
   did).
5. Unverifiable in this sandbox: nothing here was compiled. See "Manual
   review" below for what was checked by hand instead.

---

# VERSION 1 notes (original)

## TL;DR

- Full Flutter app source is written and believed correct, but **`flutter
  pub get` / `flutter analyze` could NOT be run in this sandbox** because
  outbound network access to the Flutter/Dart infrastructure domains
  (`storage.googleapis.com`, `pub.dev`, `dl.google.com`, etc.) is blocked by
  this sandbox's egress policy (confirmed via repeated `403` responses from
  the proxy -- see "Why Flutter tooling didn't run" below). `github.com` and
  `pypi.org` *were* reachable.
- Because of that, I could not run the Flutter/Dart analyzer as a ground
  truth. Instead I did a thorough manual review pass (see "Manual review"
  below) and fixed every issue I found by inspection, including one
  systemic bug (`num.clamp()` returns `num`, not the receiver's type).
- **First thing the next agent should do:** install Flutter, run `flutter
  pub get`, then `flutter analyze`, and fix anything that turns up. Given the
  manual review, I expect this to be clean or very close to it.
- The Android side (`android/`) is fully hand-written and should build as-is.
  The iOS side (`ios/`) has real, hand-written app files (Info.plist,
  AppDelegate.swift, storyboards, Assets.xcassets, Podfile) but is **missing
  `Runner.xcodeproj` / `Runner.xcworkspace`** -- see "iOS caveat" below.

## What was built

PadForge: an MPC-style companion sampler app for the Akai MPD218 USB MIDI pad
controller. Single Flutter codebase targeting iOS + Android.

Implemented, per the spec:

1. **USB MIDI connectivity** (`lib/midi/midi_service.dart`) via
   `flutter_midi_command`: device scan, auto-connect to a device whose name
   contains "MPD218", manual device picker fallback (`lib/ui/widgets/
   midi_device_picker.dart` + Settings screen), live connection status in the
   top status bar.
2. **MIDI IN**: Note On/Off (velocity-sensitive) and CC decoding in
   `midi_service.dart`, dispatched in `lib/state/app_state.dart` to either
   trigger pads / update knobs, or feed **MIDI Learn** capture
   (`lib/midi/midi_learn_controller.dart` + `AppState._handleIncomingNote` /
   `_handleIncomingCc`). Manual numeric note entry is available as an
   "Advanced" fallback on the pad editor.
3. **MIDI OUT**: `MidiService.sendNoteOn/sendNoteOff/sendCC`, exposed in the
   Settings screen as a "Send Test Note" button.
4. **Sample playback** (`lib/audio/audio_engine.dart`): **v2 replaced this
   entirely** -- see the Version 2 section above. It is now `flutter_soloud`
   with the whole kit preloaded into RAM and a synchronous trigger path.
5. **Kit / library management** (`lib/services/kit_repository.dart`,
   `lib/state/app_state.dart`): list/load/save/duplicate/rename/delete kits
   under `<app documents>/Kits/<name>/{kit.json, samples/*.wav}`; import WAV
   files via `file_picker` either auto-assigned to empty pads in the current
   kit, or to build a brand-new kit from scratch.
6. **UI** (`lib/ui/`): dark chassis theme (`ui/theme/app_theme.dart`), 4x4 pad
   grid with A/B/C bank tabs, 6 custom-painted rotary knobs
   (`ui/widgets/knob_widget.dart`, hand-drawn with `CustomPainter`, not a
   Material slider), kit-switcher strip, bottom toolbar (Import / MIDI Learn
   toggle / Edit Kit), and a full pad editor screen (sample, note + Learn,
   volume, choke group).
7. **Persistence** (`lib/services/settings_service.dart`): last kit and last
   MIDI device name via `shared_preferences`.
8. **Bundled kits**: three kits, 32 fully-synthesized sounds each, mapped to
   Banks A and B using MPD218 factory note numbers (36-51 and 52-67):
   "Vintage Kit" (dry/analog, `tools/synth_vintage_kit.py`), "Modern Pop"
   (bright/sub-heavy, `tools/synth_modern_pop_kit.py`) and "Lo-Fi Vibes"
   (dark/dusty, `tools/synth_lofi_kit.py`). All three are generated with
   numpy + scipy from shared DSP helpers in `tools/synth_common.py`, bundled
   as assets, and auto-copied into the app's documents `Kits/` folder on
   first launch (`KitRepository.ensureStarterKitInstalled`). "Vintage Kit" is
   the starter kit -- the one opened on a first launch.

## Full file tree

```
padforge/
  analysis_options.yaml
  pubspec.yaml
  PROJECT_NOTES.md
  .gitignore
  android/
    build.gradle
    settings.gradle
    gradle.properties
    gradlew, gradlew.bat            (hand-written, standard Gradle wrapper scripts)
    gradle/wrapper/gradle-wrapper.properties   (points at Gradle 8.9 -- see caveat below)
    app/
      build.gradle                  (applicationId com.padforge.app, minSdk 23)
      src/main/AndroidManifest.xml  (USB host feature, USB-attach intent filter)
      src/debug/AndroidManifest.xml
      src/profile/AndroidManifest.xml
      src/main/kotlin/com/padforge/app/MainActivity.kt
      src/main/res/values/styles.xml, values-night/styles.xml, values/colors.xml
      src/main/res/drawable/launch_background.xml, drawable-v21/launch_background.xml
      src/main/res/xml/device_filter.xml   (Akai USB vendor-id auto-launch filter)
      src/main/res/mipmap-{m,h,x,xx,xxx}hdpi/ic_launcher.png   (generated icon)
  ios/
    Podfile
    Runner/
      Info.plist, AppDelegate.swift, Runner-Bridging-Header.h
      Assets.xcassets/  (AppIcon.appiconset + LaunchImage.imageset, all PNGs generated)
      Base.lproj/LaunchScreen.storyboard, Main.storyboard
    # Runner.xcodeproj / Runner.xcworkspace NOT included -- see iOS caveat.
  assets/kits/vintage_kit/       # also modern_pop_kit/ and lofi_kit/
    kit.json
    samples/*.wav   (32 files per kit, see tools/synth_*_kit.py)
  lib/
    main.dart                        # App entry point + splash screen
    models/
      pad.dart                       # Pad model (note, sample, volume, choke group)
      knob.dart                      # KnobDef model + KnobFunction enum
      kit.dart                       # Kit model (48 pads, 6 knobs, JSON (de)serialization)
    services/
      kit_repository.dart            # All Kit file I/O (list/load/save/duplicate/...)
      recordings_repository.dart     # (v2) Recordings/ folder I/O + loop scratch folder
      sample_import_service.dart     # file_picker wrapper
      settings_service.dart          # shared_preferences wrapper
    midi/
      midi_service.dart              # flutter_midi_command wrapper (the only file that touches it)
      midi_events.dart               # MidiNoteEvent / MidiCcEvent plain data classes
      midi_learn_controller.dart     # MIDI Learn armed/target state
    audio/
      audio_engine.dart              # flutter_soloud engine: RAM-preloaded kit, sync playPad(), choke groups, tape clips
    tape/                            # (v2) the tape deck
      tape_deck.dart                 # Looper state machine, BPM/tap tempo, quantise, threshold arming, pad-hit capture/playback
      take_recorder.dart             # Unlimited recorder (engine output and/or mic) + playback of saved takes
      record_source.dart             # (v3) PADS / MIC / BOTH, shared by both machines
      wav_tools.dart                 # Pure-Dart RIFF/WAV reader, trimmer, silence-padder and mixer (unit-tested)
      mic_arbiter.dart               # Decides whether the looper or the recorder owns the mic
    state/
      app_state.dart                 # Central ChangeNotifier app state / orchestration
    ui/
      theme/app_theme.dart           # Color palette + ThemeData + LCD text style helper
      widgets/
        status_bar.dart, kit_strip.dart, bank_tabs.dart, pad_grid.dart,
        pad_button.dart, knob_widget.dart, bottom_toolbar.dart, midi_device_picker.dart,
        tape_deck.dart (v2), tape_reels.dart (v2)
      screens/
        home_screen.dart, pad_edit_screen.dart, kit_manager_screen.dart,
        settings_screen.dart, recordings_screen.dart (v2)
  test/
    kit_model_test.dart              # Pure-Dart unit tests for Kit/Pad model logic
    wav_tools_test.dart              # (v2) Unit tests for the WAV header reader / trimmer
  tools/
    synth_common.py                  # Shared synthesis/DSP helpers + kit.json writer
    synth_vintage_kit.py             # Generates the 32 Vintage Kit WAV samples
    synth_modern_pop_kit.py          # Generates the 32 Modern Pop WAV samples
    synth_lofi_kit.py                # Generates the 32 Lo-Fi Vibes WAV samples
    gen_branding.py                  # (v8) Renders the brand mark to every
                                     #      Android/iOS icon size into branding/
                                     #      (replaced gen_app_icon.py)
```

~3,000 lines of Dart across 24 files in `lib/`.

## Why Flutter tooling didn't run in this sandbox

This sandbox's outbound HTTPS goes through a policy-enforcing proxy
(`/root/.ccr/README.md`). Checked via `curl --cacert /root/.ccr/ca-bundle.crt`:

| Host | Result |
|---|---|
| `github.com` | reachable (used to `git clone` the Flutter SDK repo itself) |
| `pypi.org` / `files.pythonhosted.org` | reachable (used for `pip install numpy scipy Pillow`) |
| `storage.googleapis.com` | **403 policy denial** (this is where the Dart SDK/engine binaries and most pub.dev package archives are actually hosted) |
| `pub.dev` / `pub.dartlang.org` | **403 policy denial** |
| `dl.google.com`, `storage.flutter-io.cn`, `maven.google.com` | **403 policy denial** |

`git clone https://github.com/flutter/flutter.git -b stable` succeeded, but
`flutter --version` / `flutter precache` then fail immediately because they
need to download the Dart SDK from `storage.googleapis.com`. There is no
Flutter/Dart SDK, cached pub packages, or `dart` binary available anywhere on
this machine, and no apt/snap package provides one. This is a sandbox
network-policy limitation, not a project issue -- a normal dev machine or CI
runner with unrestricted (or Flutter-allowlisted) network access will not
hit this.

**Action for the next agent:** re-attempt the standard install (`git clone
... ~/flutter`, add to `PATH`, `flutter precache`) in an environment that can
reach `storage.googleapis.com` and `pub.dev`, then run:

```
flutter pub get
flutter analyze
```

and fix anything that comes up. I was not able to produce real output for
these commands -- do not trust any "output" you might see attributed to them
elsewhere; there isn't any, because they never ran here.

## Manual review performed instead

Since I couldn't run the analyzer, I did the following by hand:

- A script-based structural check across every `lib/**/*.dart` file: balanced
  brackets/braces/parens, and that every relative `import '../x/y.dart'`
  actually resolves to a file that exists.
- A full manual read-through of every file for type-correctness, checking
  constructor signatures, nullability, and cross-file API usage against my
  knowledge of the Flutter SDK and each package's public API
  (`flutter_midi_command`, `audioplayers`, `file_picker`, `path_provider`,
  `shared_preferences`, `google_fonts`, `path`).
- Verified `pubspec.yaml`'s asset globs match real files on disk, and that
  every bundled `kit.json`'s sample references all resolve.
- Verified all 96 generated WAV files parse as valid 16-bit PCM mono WAV
  (44.1kHz) via Python's `wave` module.

**Bug found and fixed by this review:** `num.clamp(lo, hi)` in Dart always
returns `num`, never the receiver's specific type (`int`/`double`) --
assigning/returning/passing the result directly into a `double`- or
`int`-typed context is a compile error. This pattern showed up in ~10 places
(volume/velocity/knob-value clamping in `audio_engine.dart`,
`midi_service.dart`, `app_state.dart`, `kit.dart`, `knob_widget.dart`,
`pad_edit_screen.dart`). Fixed everywhere by appending `.toDouble()` /
`.toInt()` after `.clamp(...)`. Two remaining `.clamp()` calls in
`knob_widget.dart`'s `CustomPainter` were left without an explicit cast
because they're immediately multiplied by a `double`-typed receiver
(`_sweepAngle * value.clamp(...)`), which forces the result back to `double`
per Dart's `num`/`double` operator-overload rules -- verified by hand, should
be safe, but worth a second look if `flutter analyze` disagrees.

If `flutter analyze` does find anything I missed, it should be something
small and local (wrong argument name, a nullability mismatch) rather than a
structural problem -- the app's architecture (see below) is straightforward
and each layer has a narrow, single responsibility.

## Architecture notes

- `AppState` (`lib/state/app_state.dart`) is a singleton `ChangeNotifier` that
  is the single source of truth: current kit, current bank, MIDI Learn state,
  and it owns the dispatch loop from `MidiService`'s note/CC streams to
  either "trigger a pad" / "move a knob" or "capture a MIDI Learn target".
  UI widgets read it via `ListenableBuilder(listenable: AppState.instance,
  ...)` and call its methods directly -- no external state management
  package, to keep the wiring simple.
- `MidiService` is the only file that imports `flutter_midi_command` --
  everything else goes through its `noteEvents`/`ccEvents` streams and
  `sendNoteOn/sendNoteOff/sendCC` methods.
- `KitRepository` is pure file I/O (no Flutter widget/state dependencies),
  so it's easy to reason about independently of MIDI/audio/UI.
- Pad "hit" flashes (both from touch and from hardware MIDI) go through a
  dedicated `Stream<String> padHitEvents` on `AppState`, rather than a full
  `notifyListeners()` on every hit, so hitting pads rapidly doesn't force a
  whole-screen rebuild.

## Deviations from the spec, and why

- **iOS Xcode project** (`ios/Runner.xcodeproj/project.pbxproj`,
  `ios/Runner.xcworkspace`) was **not** hand-written. That file is a
  UUID-cross-referenced generated format (every file reference, build phase,
  and target has to agree on opaque hex IDs) that I have no way to validate
  in this sandbox (no Xcode, no `flutter create`), and a single mismatched ID
  makes Xcode refuse to open the project outright -- worse than not having it
  at all. All the *content* files that go inside a real iOS project are
  present and hand-written (`Info.plist`, `AppDelegate.swift`,
  `Runner-Bridging-Header.h`, both storyboards, `Assets.xcassets` with a full
  generated app icon set + launch image, `Podfile`).
  **Fix:** once Flutter is installed with real network access, run
  `flutter create --platforms=ios .` from the project root. This is the
  standard, safe, official way to (re)generate just the missing
  platform-specific Xcode project scaffolding for an existing Flutter
  project -- it will not touch `lib/`, `pubspec.yaml`, `assets/`, or `test/`.
  Since iOS builds require Xcode on macOS anyway (impossible in this Linux
  sandbox regardless), this was the pragmatic tradeoff given the "later agent
  handles toolchain install + **APK** build" framing.
- **`android/gradle/wrapper/gradle-wrapper.jar`** (the actual wrapper binary)
  is **not** included -- it's a binary blob normally downloaded from
  `services.gradle.org`, which I also could not reach. `gradlew` /
  `gradlew.bat` (the plain-text wrapper scripts) and
  `gradle-wrapper.properties` (pinned to Gradle 8.9) are present and correct.
  **Fix:** once there's network access, either run `flutter build apk` (the
  Flutter tool can bootstrap the wrapper jar itself in most setups), or, if
  system Gradle is available, run `gradle wrapper --gradle-version 8.9`
  inside `android/` to generate the missing jar.
- **Desktop/web platform folders** (`linux/`, `macos/`, `windows/`, `web/`)
  were intentionally omitted -- the spec only asks for iOS + Android.
- **Package versions in `pubspec.yaml` are hand-pinned, not resolved.** The
  spec asked to run `flutter pub add <package>` so versions resolve against
  the real registry, but that requires the blocked `pub.dev` host. I picked
  versions I'm confident were current stable releases as of my training data
  (see table below) using `^` constraints, so `flutter pub get` should still
  resolve sensible up-to-date versions once it can actually run. **The
  "exact resolved versions" table below is therefore what I *specified*, not
  what pub actually resolved** -- the next agent should replace this with
  real `flutter pub get` output.
- The MPD218 USB vendor-id used in `android/app/src/main/res/xml/
  device_filter.xml` (2536 / 0x09E8, Akai Professional's registered USB
  vendor ID) is used for the *optional* "auto-launch PadForge when a USB MIDI
  device is plugged in" intent filter. If it's slightly off, the only effect
  is that auto-launch doesn't trigger -- manual launch + MIDI connect still
  works normally via `flutter_midi_command`.
- Knobs 3-6 are "assignable" placeholders (renamable, MIDI-learnable, value
  is tracked) but don't drive any audio parameter yet, per the spec's
  explicit "don't overbuild a mixing engine" instruction. Only knob 1
  (Master Vol) and knob 2 (Pitch/Speed) actually affect playback.

## Dependencies specified in pubspec.yaml (unresolved -- see caveat above)

(Updated for v2. The versions marked "CI-verified" took several build attempts
to settle -- do not change them casually.)

| Package | Constraint | Note |
|---|---|---|
| flutter_midi_command | ^1.0.2 | CI-verified. **Not** 1.0.9 -- conflicts with file_picker over win32. |
| flutter_soloud | ^4.1.7 | v2. Replaces audioplayers. Code is also 4.1.6-compatible. |
| record | ^7.1.1 | v2. Needs Dart >=3.12 / Flutter >=3.44. |
| share_plus | ^12.0.0 | v2. Do not bump to 13.x (win32 6.0.0 conflicts with file_picker). |
| file_picker | '>=8.1.2 <12.0.0' | CI-verified, resolves to 11.x -> **static** `FilePicker.pickFiles(...)`. |
| path_provider | ^2.1.4 | |
| path | ^1.9.0 | |
| shared_preferences | ^2.3.2 | |
| google_fonts | ^6.2.1 | |
| cupertino_icons | ^1.0.8 | |
| flutter_lints (dev) | ^4.0.0 | |

Dart SDK constraint: `>=3.4.0 <4.0.0`. Flutter constraint: `>=3.24.0`.

## Commands for the next agent to run

```bash
# 1. Install Flutter (needs real network access to storage.googleapis.com / pub.dev)
git clone https://github.com/flutter/flutter.git -b stable --depth 1 ~/flutter
export PATH="$HOME/flutter/bin:$PATH"
flutter precache
flutter doctor

# 2. From the project root:
cd padforge
flutter pub get
flutter analyze

# 3. Fix anything flutter analyze reports, then:
flutter create --platforms=ios .   # regenerates ios/Runner.xcodeproj safely

# 4. Android build (this is the one explicitly called out as this agent's job):
flutter build apk
```

Neither `flutter pub get` nor `flutter analyze` produced real output in this
session -- they were never runnable here. Everything above the "Commands"
section reflects a manual/static review, not a compiler-verified one.

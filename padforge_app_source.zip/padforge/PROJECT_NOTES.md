# PadForge -- Project Notes

Plain-English summary for whoever picks this up next (toolchain install +
build). Written by the agent that authored the source tree.

## TL;DR

- Full Flutter app source is written and believed correct, but **`flutter
  pub get` / `flutter analyze` could NOT be run in this sandbox** because
  outbound network access to the Flutter/Dart infrastructure domains
  (`storage.googleapis.com`, `pub.dev`, `dl.google.com`, etc.) is blocked by
  this sandbox's egress policy (confirmed via repeated `403` responses from
  the proxy -- see "Why Flutter tooling didn't run" below). `github.com` and
  `pypi.org` *were* reachable.
- Because of that, I could not run the Flutter/Dart analyzer as a ground
  truth. Instead I did a thorough manual review pass (see "Manual review"
  below) and fixed every issue I found by inspection, including one
  systemic bug (`num.clamp()` returns `num`, not the receiver's type).
- **First thing the next agent should do:** install Flutter, run `flutter
  pub get`, then `flutter analyze`, and fix anything that turns up. Given the
  manual review, I expect this to be clean or very close to it.
- The Android side (`android/`) is fully hand-written and should build as-is.
  The iOS side (`ios/`) has real, hand-written app files (Info.plist,
  AppDelegate.swift, storyboards, Assets.xcassets, Podfile) but is **missing
  `Runner.xcodeproj` / `Runner.xcworkspace`** -- see "iOS caveat" below.

## What was built

PadForge: an MPC-style companion sampler app for the Akai MPD218 USB MIDI pad
controller. Single Flutter codebase targeting iOS + Android.

Implemented, per the spec:

1. **USB MIDI connectivity** (`lib/midi/midi_service.dart`) via
   `flutter_midi_command`: device scan, auto-connect to a device whose name
   contains "MPD218", manual device picker fallback (`lib/ui/widgets/
   midi_device_picker.dart` + Settings screen), live connection status in the
   top status bar.
2. **MIDI IN**: Note On/Off (velocity-sensitive) and CC decoding in
   `midi_service.dart`, dispatched in `lib/state/app_state.dart` to either
   trigger pads / update knobs, or feed **MIDI Learn** capture
   (`lib/midi/midi_learn_controller.dart` + `AppState._handleIncomingNote` /
   `_handleIncomingCc`). Manual numeric note entry is available as an
   "Advanced" fallback on the pad editor.
3. **MIDI OUT**: `MidiService.sendNoteOn/sendNoteOff/sendCC`, exposed in the
   Settings screen as a "Send Test Note" button.
4. **Sample playback** (`lib/audio/audio_engine.dart`): a round-robin pool of
   16 `audioplayers` `AudioPlayer` instances (low-latency mode where
   supported), with per-choke-group cutoff logic.
5. **Kit / library management** (`lib/services/kit_repository.dart`,
   `lib/state/app_state.dart`): list/load/save/duplicate/rename/delete kits
   under `<app documents>/Kits/<name>/{kit.json, samples/*.wav}`; import WAV
   files via `file_picker` either auto-assigned to empty pads in the current
   kit, or to build a brand-new kit from scratch.
6. **UI** (`lib/ui/`): dark chassis theme (`ui/theme/app_theme.dart`), 4x4 pad
   grid with A/B/C bank tabs, 6 custom-painted rotary knobs
   (`ui/widgets/knob_widget.dart`, hand-drawn with `CustomPainter`, not a
   Material slider), kit-switcher strip, bottom toolbar (Import / MIDI Learn
   toggle / Edit Kit), and a full pad editor screen (sample, note + Learn,
   volume, choke group).
7. **Persistence** (`lib/services/settings_service.dart`): last kit and last
   MIDI device name via `shared_preferences`.
8. **Starter kit**: "Vintage Kit", 16 fully-synthesized drum sounds (numpy +
   scipy, `tools/synth_vintage_kit.py`) mapped to Bank A using MPD218 factory
   note numbers (36-51), bundled as assets and auto-copied into the app's
   documents `Kits/` folder on first launch
   (`KitRepository.ensureStarterKitInstalled`).

## Full file tree

```
padforge/
  analysis_options.yaml
  pubspec.yaml
  PROJECT_NOTES.md
  .gitignore
  android/
    build.gradle
    settings.gradle
    gradle.properties
    gradlew, gradlew.bat            (hand-written, standard Gradle wrapper scripts)
    gradle/wrapper/gradle-wrapper.properties   (points at Gradle 8.9 -- see caveat below)
    app/
      build.gradle                  (applicationId com.padforge.app, minSdk 23)
      src/main/AndroidManifest.xml  (USB host feature, USB-attach intent filter)
      src/debug/AndroidManifest.xml
      src/profile/AndroidManifest.xml
      src/main/kotlin/com/padforge/app/MainActivity.kt
      src/main/res/values/styles.xml, values-night/styles.xml, values/colors.xml
      src/main/res/drawable/launch_background.xml, drawable-v21/launch_background.xml
      src/main/res/xml/device_filter.xml   (Akai USB vendor-id auto-launch filter)
      src/main/res/mipmap-{m,h,x,xx,xxx}hdpi/ic_launcher.png   (generated icon)
  ios/
    Podfile
    Runner/
      Info.plist, AppDelegate.swift, Runner-Bridging-Header.h
      Assets.xcassets/  (AppIcon.appiconset + LaunchImage.imageset, all PNGs generated)
      Base.lproj/LaunchScreen.storyboard, Main.storyboard
    # Runner.xcodeproj / Runner.xcworkspace NOT included -- see iOS caveat.
  assets/kits/vintage_kit/
    kit.json
    samples/*.wav   (16 files, see tools/synth_vintage_kit.py)
  lib/
    main.dart                        # App entry point + splash screen
    models/
      pad.dart                       # Pad model (note, sample, volume, choke group)
      knob.dart                      # KnobDef model + KnobFunction enum
      kit.dart                       # Kit model (48 pads, 6 knobs, JSON (de)serialization)
    services/
      kit_repository.dart            # All Kit file I/O (list/load/save/duplicate/...)
      sample_import_service.dart     # file_picker wrapper
      settings_service.dart          # shared_preferences wrapper
    midi/
      midi_service.dart              # flutter_midi_command wrapper (the only file that touches it)
      midi_events.dart               # MidiNoteEvent / MidiCcEvent plain data classes
      midi_learn_controller.dart     # MIDI Learn armed/target state
    audio/
      audio_engine.dart              # 16-voice round-robin AudioPlayer pool + choke groups
    state/
      app_state.dart                 # Central ChangeNotifier app state / orchestration
    ui/
      theme/app_theme.dart           # Color palette + ThemeData + LCD text style helper
      widgets/
        status_bar.dart, kit_strip.dart, bank_tabs.dart, pad_grid.dart,
        pad_button.dart, knob_widget.dart, bottom_toolbar.dart, midi_device_picker.dart
      screens/
        home_screen.dart, pad_edit_screen.dart, kit_manager_screen.dart, settings_screen.dart
  test/
    kit_model_test.dart              # Pure-Dart unit tests for Kit/Pad model logic
  tools/
    synth_vintage_kit.py             # Generates the 16 starter-kit WAV samples
    gen_app_icon.py                  # Generates the app icon PNGs (Android + iOS)
```

~3,000 lines of Dart across 24 files in `lib/`.

## Why Flutter tooling didn't run in this sandbox

This sandbox's outbound HTTPS goes through a policy-enforcing proxy
(`/root/.ccr/README.md`). Checked via `curl --cacert /root/.ccr/ca-bundle.crt`:

| Host | Result |
|---|---|
| `github.com` | reachable (used to `git clone` the Flutter SDK repo itself) |
| `pypi.org` / `files.pythonhosted.org` | reachable (used for `pip install numpy scipy Pillow`) |
| `storage.googleapis.com` | **403 policy denial** (this is where the Dart SDK/engine binaries and most pub.dev package archives are actually hosted) |
| `pub.dev` / `pub.dartlang.org` | **403 policy denial** |
| `dl.google.com`, `storage.flutter-io.cn`, `maven.google.com` | **403 policy denial** |

`git clone https://github.com/flutter/flutter.git -b stable` succeeded, but
`flutter --version` / `flutter precache` then fail immediately because they
need to download the Dart SDK from `storage.googleapis.com`. There is no
Flutter/Dart SDK, cached pub packages, or `dart` binary available anywhere on
this machine, and no apt/snap package provides one. This is a sandbox
network-policy limitation, not a project issue -- a normal dev machine or CI
runner with unrestricted (or Flutter-allowlisted) network access will not
hit this.

**Action for the next agent:** re-attempt the standard install (`git clone
... ~/flutter`, add to `PATH`, `flutter precache`) in an environment that can
reach `storage.googleapis.com` and `pub.dev`, then run:

```
flutter pub get
flutter analyze
```

and fix anything that comes up. I was not able to produce real output for
these commands -- do not trust any "output" you might see attributed to them
elsewhere; there isn't any, because they never ran here.

## Manual review performed instead

Since I couldn't run the analyzer, I did the following by hand:

- A script-based structural check across every `lib/**/*.dart` file: balanced
  brackets/braces/parens, and that every relative `import '../x/y.dart'`
  actually resolves to a file that exists.
- A full manual read-through of every file for type-correctness, checking
  constructor signatures, nullability, and cross-file API usage against my
  knowledge of the Flutter SDK and each package's public API
  (`flutter_midi_command`, `audioplayers`, `file_picker`, `path_provider`,
  `shared_preferences`, `google_fonts`, `path`).
- Verified `pubspec.yaml`'s asset globs match real files on disk, and that
  `assets/kits/vintage_kit/kit.json`'s sample references all resolve.
- Verified all 16 generated WAV files parse as valid 16-bit PCM mono WAV
  (44.1kHz) via Python's `wave` module.

**Bug found and fixed by this review:** `num.clamp(lo, hi)` in Dart always
returns `num`, never the receiver's specific type (`int`/`double`) --
assigning/returning/passing the result directly into a `double`- or
`int`-typed context is a compile error. This pattern showed up in ~10 places
(volume/velocity/knob-value clamping in `audio_engine.dart`,
`midi_service.dart`, `app_state.dart`, `kit.dart`, `knob_widget.dart`,
`pad_edit_screen.dart`). Fixed everywhere by appending `.toDouble()` /
`.toInt()` after `.clamp(...)`. Two remaining `.clamp()` calls in
`knob_widget.dart`'s `CustomPainter` were left without an explicit cast
because they're immediately multiplied by a `double`-typed receiver
(`_sweepAngle * value.clamp(...)`), which forces the result back to `double`
per Dart's `num`/`double` operator-overload rules -- verified by hand, should
be safe, but worth a second look if `flutter analyze` disagrees.

If `flutter analyze` does find anything I missed, it should be something
small and local (wrong argument name, a nullability mismatch) rather than a
structural problem -- the app's architecture (see below) is straightforward
and each layer has a narrow, single responsibility.

## Architecture notes

- `AppState` (`lib/state/app_state.dart`) is a singleton `ChangeNotifier` that
  is the single source of truth: current kit, current bank, MIDI Learn state,
  and it owns the dispatch loop from `MidiService`'s note/CC streams to
  either "trigger a pad" / "move a knob" or "capture a MIDI Learn target".
  UI widgets read it via `ListenableBuilder(listenable: AppState.instance,
  ...)` and call its methods directly -- no external state management
  package, to keep the wiring simple.
- `MidiService` is the only file that imports `flutter_midi_command` --
  everything else goes through its `noteEvents`/`ccEvents` streams and
  `sendNoteOn/sendNoteOff/sendCC` methods.
- `KitRepository` is pure file I/O (no Flutter widget/state dependencies),
  so it's easy to reason about independently of MIDI/audio/UI.
- Pad "hit" flashes (both from touch and from hardware MIDI) go through a
  dedicated `Stream<String> padHitEvents` on `AppState`, rather than a full
  `notifyListeners()` on every hit, so hitting pads rapidly doesn't force a
  whole-screen rebuild.

## Deviations from the spec, and why

- **iOS Xcode project** (`ios/Runner.xcodeproj/project.pbxproj`,
  `ios/Runner.xcworkspace`) was **not** hand-written. That file is a
  UUID-cross-referenced generated format (every file reference, build phase,
  and target has to agree on opaque hex IDs) that I have no way to validate
  in this sandbox (no Xcode, no `flutter create`), and a single mismatched ID
  makes Xcode refuse to open the project outright -- worse than not having it
  at all. All the *content* files that go inside a real iOS project are
  present and hand-written (`Info.plist`, `AppDelegate.swift`,
  `Runner-Bridging-Header.h`, both storyboards, `Assets.xcassets` with a full
  generated app icon set + launch image, `Podfile`).
  **Fix:** once Flutter is installed with real network access, run
  `flutter create --platforms=ios .` from the project root. This is the
  standard, safe, official way to (re)generate just the missing
  platform-specific Xcode project scaffolding for an existing Flutter
  project -- it will not touch `lib/`, `pubspec.yaml`, `assets/`, or `test/`.
  Since iOS builds require Xcode on macOS anyway (impossible in this Linux
  sandbox regardless), this was the pragmatic tradeoff given the "later agent
  handles toolchain install + **APK** build" framing.
- **`android/gradle/wrapper/gradle-wrapper.jar`** (the actual wrapper binary)
  is **not** included -- it's a binary blob normally downloaded from
  `services.gradle.org`, which I also could not reach. `gradlew` /
  `gradlew.bat` (the plain-text wrapper scripts) and
  `gradle-wrapper.properties` (pinned to Gradle 8.9) are present and correct.
  **Fix:** once there's network access, either run `flutter build apk` (the
  Flutter tool can bootstrap the wrapper jar itself in most setups), or, if
  system Gradle is available, run `gradle wrapper --gradle-version 8.9`
  inside `android/` to generate the missing jar.
- **Desktop/web platform folders** (`linux/`, `macos/`, `windows/`, `web/`)
  were intentionally omitted -- the spec only asks for iOS + Android.
- **Package versions in `pubspec.yaml` are hand-pinned, not resolved.** The
  spec asked to run `flutter pub add <package>` so versions resolve against
  the real registry, but that requires the blocked `pub.dev` host. I picked
  versions I'm confident were current stable releases as of my training data
  (see table below) using `^` constraints, so `flutter pub get` should still
  resolve sensible up-to-date versions once it can actually run. **The
  "exact resolved versions" table below is therefore what I *specified*, not
  what pub actually resolved** -- the next agent should replace this with
  real `flutter pub get` output.
- The MPD218 USB vendor-id used in `android/app/src/main/res/xml/
  device_filter.xml` (2536 / 0x09E8, Akai Professional's registered USB
  vendor ID) is used for the *optional* "auto-launch PadForge when a USB MIDI
  device is plugged in" intent filter. If it's slightly off, the only effect
  is that auto-launch doesn't trigger -- manual launch + MIDI connect still
  works normally via `flutter_midi_command`.
- Knobs 3-6 are "assignable" placeholders (renamable, MIDI-learnable, value
  is tracked) but don't drive any audio parameter yet, per the spec's
  explicit "don't overbuild a mixing engine" instruction. Only knob 1
  (Master Vol) and knob 2 (Pitch/Speed) actually affect playback.

## Dependencies specified in pubspec.yaml (unresolved -- see caveat above)

| Package | Constraint specified |
|---|---|
| flutter_midi_command | ^0.5.1 |
| audioplayers | ^6.1.0 |
| file_picker | ^8.1.2 |
| path_provider | ^2.1.4 |
| path | ^1.9.0 |
| shared_preferences | ^2.3.2 |
| google_fonts | ^6.2.1 |
| cupertino_icons | ^1.0.8 |
| flutter_lints (dev) | ^4.0.0 |

Dart SDK constraint: `>=3.4.0 <4.0.0`. Flutter constraint: `>=3.24.0`.

## Commands for the next agent to run

```bash
# 1. Install Flutter (needs real network access to storage.googleapis.com / pub.dev)
git clone https://github.com/flutter/flutter.git -b stable --depth 1 ~/flutter
export PATH="$HOME/flutter/bin:$PATH"
flutter precache
flutter doctor

# 2. From the project root:
cd padforge
flutter pub get
flutter analyze

# 3. Fix anything flutter analyze reports, then:
flutter create --platforms=ios .   # regenerates ios/Runner.xcodeproj safely

# 4. Android build (this is the one explicitly called out as this agent's job):
flutter build apk
```

Neither `flutter pub get` nor `flutter analyze` produced real output in this
session -- they were never runnable here. Everything above the "Commands"
section reflects a manual/static review, not a compiler-verified one.

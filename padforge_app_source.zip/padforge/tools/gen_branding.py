#!/usr/bin/env python3
"""
PadForge brand mark -- raster generator.

Renders every launcher-icon size Android and iOS need from ONE description of
the mark, so the whole set can be regenerated from scratch at any time. The
master vector is `assets/branding/logo.svg`; this file is the same geometry
expressed in numbers, and `lib/ui/widgets/padforge_logo.dart` is the same
geometry again as a Flutter CustomPainter. All three must agree.

THE MARK -- "the struck pad and the rising step"
------------------------------------------------
A 4x4 pad grid in which the lit pads form an ascending staircase from the
bottom-left pad upwards and to the right (column heights 1, 2, 3, 4). The
bottom-left pad -- pad 1 on an MPD218 -- is drawn in cream: it is the pad that
has just been struck. The six unlit pads at the top left keep the grid
readable as a grid.

OUTPUT
------
    branding/android/mipmap-mdpi/ic_launcher.png      48
    branding/android/mipmap-hdpi/ic_launcher.png      72
    branding/android/mipmap-xhdpi/ic_launcher.png     96
    branding/android/mipmap-xxhdpi/ic_launcher.png   144
    branding/android/mipmap-xxxhdpi/ic_launcher.png  192
    branding/ios/AppIcon.appiconset/*.png + Contents.json
    branding/preview/padforge_icon_preview.png       (for humans, not shipped)

Android icons are a rounded-square plate with transparent corners (the legacy
`ic_launcher.png` convention -- launchers that mask icons then round an
already-rounded shape, which looks intentional). iOS icons are FULL BLEED and
strictly RGB with **no alpha channel**: iOS applies its own mask, and the App
Store rejects an icon with transparency.

Run with:  python3 tools/gen_branding.py
Requires:  Pillow, numpy   (pip install pillow --break-system-packages)
"""

import json
import os
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image, ImageDraw

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BRANDING = os.path.join(ROOT, "branding")
ANDROID_DIR = os.path.join(BRANDING, "android")
IOS_DIR = os.path.join(BRANDING, "ios", "AppIcon.appiconset")
PREVIEW_DIR = os.path.join(BRANDING, "preview")
SVG_PATH = os.path.join(ROOT, "assets", "branding", "logo.svg")

# --------------------------------------------------------------------------
# The design, in 1024 design units (identical to logo.svg's viewBox)
# --------------------------------------------------------------------------

DESIGN = 1024.0

GRID_ORIGIN = 152.0   # left/top edge of the 4x4 block
CELL = 150.0
GAP = 40.0
CELL_RADIUS = 33.0    # 22% of a cell
PLATE_RADIUS = 0.22   # fraction of the icon side, Android rounded plate only

CHASSIS = (0x1A, 0x18, 0x16)

# Vertical gradients as (offset, rgb) stops -- same stops as logo.svg.
LIT = [(0.00, (0xF2, 0xA9, 0x4F)), (0.55, (0xE8, 0x97, 0x3A)), (1.00, (0xC9, 0x7A, 0x22))]
STRIKE = [(0.00, (0xF2, 0xE8, 0xD5)), (0.60, (0xF0, 0xB6, 0x5E)), (1.00, (0xE8, 0x97, 0x3A))]
RECESS = [(0.00, (0x39, 0x33, 0x2B)), (1.00, (0x29, 0x24, 0x1E))]

HEAT_RGB = (0xE8, 0x97, 0x3A)
HEAT_CX, HEAT_CY, HEAT_R, HEAT_A = 0.30, 0.72, 0.62, 0.20

# Rows are indexed 0 (top) .. 3 (bottom); a pad is lit when row >= 3 - col,
# which gives column heights 1, 2, 3, 4 counting from the left.
STRUCK_ROW, STRUCK_COL = 3, 0

# Everything is rendered at this size and downsampled with LANCZOS, which is
# what keeps a 48px icon's rounded corners clean.
MASTER_PX = 2048


def is_lit(row: int, col: int) -> bool:
    return row >= 3 - col


# --------------------------------------------------------------------------
# Rendering
# --------------------------------------------------------------------------

def _gradient_tile(size: int, stops) -> Image.Image:
    """A `size` x `size` RGB tile filled with a vertical gradient."""
    ys = np.linspace(0.0, 1.0, size, dtype=np.float64)
    offs = np.array([s[0] for s in stops], dtype=np.float64)
    cols = np.array([s[1] for s in stops], dtype=np.float64)
    ramp = np.stack([np.interp(ys, offs, cols[:, c]) for c in range(3)], axis=1)
    tile = np.repeat(ramp[:, None, :], size, axis=1)
    return Image.fromarray(np.clip(tile, 0, 255).astype(np.uint8), "RGB")


def _rounded_mask(size: int, radius: float) -> Image.Image:
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        [0, 0, size - 1, size - 1], radius=radius, fill=255
    )
    return mask


def _heat_layer(px: int) -> np.ndarray:
    """Alpha map (0..1) for the soft amber glow behind the struck pad."""
    yy, xx = np.mgrid[0:px, 0:px].astype(np.float64)
    xx = xx / (px - 1) - HEAT_CX
    yy = yy / (px - 1) - HEAT_CY
    d = np.sqrt(xx * xx + yy * yy) / HEAT_R
    return np.clip(1.0 - d, 0.0, 1.0) * HEAT_A


def render_master(px: int = MASTER_PX, rounded_plate: bool = False) -> Image.Image:
    """Render the mark at `px` square.

    rounded_plate=False -> full-bleed opaque square (iOS, and the preview).
    rounded_plate=True  -> rounded-square plate, transparent outside (Android).
    """
    s = px / DESIGN

    base = np.zeros((px, px, 3), dtype=np.float64)
    base[:, :] = CHASSIS

    heat = _heat_layer(px)[:, :, None]
    base = base * (1.0 - heat) + np.array(HEAT_RGB, dtype=np.float64) * heat
    img = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8), "RGB")

    cell_px = int(round(CELL * s))
    mask = _rounded_mask(cell_px, CELL_RADIUS * s)
    tiles = {
        "lit": _gradient_tile(cell_px, LIT),
        "strike": _gradient_tile(cell_px, STRIKE),
        "recess": _gradient_tile(cell_px, RECESS),
    }

    for row in range(4):
        for col in range(4):
            if not is_lit(row, col):
                kind = "recess"
            elif (row, col) == (STRUCK_ROW, STRUCK_COL):
                kind = "strike"
            else:
                kind = "lit"
            x = int(round((GRID_ORIGIN + col * (CELL + GAP)) * s))
            y = int(round((GRID_ORIGIN + row * (CELL + GAP)) * s))
            img.paste(tiles[kind], (x, y), mask)

    if rounded_plate:
        out = img.convert("RGBA")
        out.putalpha(_rounded_mask(px, PLATE_RADIUS * px))
        return out
    return img


def _resize(master: Image.Image, size: int) -> Image.Image:
    return master.resize((size, size), Image.LANCZOS)


# --------------------------------------------------------------------------
# The icon sets
# --------------------------------------------------------------------------

ANDROID = [
    ("mipmap-mdpi", 48),
    ("mipmap-hdpi", 72),
    ("mipmap-xhdpi", 96),
    ("mipmap-xxhdpi", 144),
    ("mipmap-xxxhdpi", 192),
]

# (idiom, point size string, scale, pixel size). One entry per image Xcode's
# "iOS" app-icon set expects, plus the App Store marketing icon.
IOS = [
    ("iphone", "20x20", "2x", 40),
    ("iphone", "20x20", "3x", 60),
    ("iphone", "29x29", "1x", 29),
    ("iphone", "29x29", "2x", 58),
    ("iphone", "29x29", "3x", 87),
    ("iphone", "40x40", "2x", 80),
    ("iphone", "40x40", "3x", 120),
    ("iphone", "60x60", "2x", 120),
    ("iphone", "60x60", "3x", 180),
    ("ipad", "20x20", "1x", 20),
    ("ipad", "20x20", "2x", 40),
    ("ipad", "29x29", "1x", 29),
    ("ipad", "29x29", "2x", 58),
    ("ipad", "40x40", "1x", 40),
    ("ipad", "40x40", "2x", 80),
    ("ipad", "76x76", "1x", 76),
    ("ipad", "76x76", "2x", 152),
    ("ipad", "83.5x83.5", "2x", 167),
    ("ios-marketing", "1024x1024", "1x", 1024),
]


def ios_filename(point: str, scale: str) -> str:
    return f"Icon-App-{point}@{scale}.png"


def write_android(master_rounded: Image.Image):
    written = []
    for folder, size in ANDROID:
        path = os.path.join(ANDROID_DIR, folder, "ic_launcher.png")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        _resize(master_rounded, size).save(path, "PNG")
        written.append((path, size))
    return written


def write_ios(master_square: Image.Image):
    os.makedirs(IOS_DIR, exist_ok=True)
    written = []
    # Several (idiom, point, scale) entries share a pixel size and therefore a
    # file; dedupe so we never write the same bytes twice.
    for point, scale, size in sorted({(p, sc, px) for _, p, sc, px in IOS}):
        path = os.path.join(IOS_DIR, ios_filename(point, scale))
        # RGB, not RGBA: an iOS app icon must have no alpha channel at all.
        _resize(master_square, size).convert("RGB").save(path, "PNG")
        written.append((path, size))

    contents = {
        "images": [
            {
                "size": point,
                "idiom": idiom,
                "filename": ios_filename(point, scale),
                "scale": scale,
            }
            for idiom, point, scale, _ in IOS
        ],
        "info": {"version": 1, "author": "xcode"},
    }
    cpath = os.path.join(IOS_DIR, "Contents.json")
    with open(cpath, "w", encoding="utf-8") as f:
        json.dump(contents, f, indent=2)
        f.write("\n")
    return written, cpath


def write_preview(master_square: Image.Image, master_rounded: Image.Image):
    """A contact sheet a human can eyeball. Not shipped in the app."""
    os.makedirs(PREVIEW_DIR, exist_ok=True)
    sheet = Image.new("RGB", (760, 420), (0x0E, 0x0D, 0x0B))
    sheet.paste(_resize(master_square, 320), (30, 50))
    x = 400
    for size in (192, 96, 72, 48):
        thumb = _resize(master_rounded, size)
        sheet.paste(thumb, (x, 50 + (192 - size) // 2), thumb)
        x += size + 16
    x = 400
    for size in (48, 40, 29, 20):
        thumb = _resize(master_rounded, size)
        sheet.paste(thumb, (x, 300), thumb)
        x += size + 16
    path = os.path.join(PREVIEW_DIR, "padforge_icon_preview.png")
    sheet.save(path, "PNG")
    return path


# --------------------------------------------------------------------------
# Verification -- nothing here is allowed to be taken on trust
# --------------------------------------------------------------------------

def verify(android_files, ios_files, contents_path, preview_path):
    rows = []
    problems = []

    def check(path, size, want_alpha):
        rel = os.path.relpath(path, ROOT)
        try:
            with Image.open(path) as im:
                im.load()
                w, h = im.size
                mode = im.mode
                grey = np.asarray(im.convert("L"), dtype=np.float64)
        except Exception as exc:  # pragma: no cover - a corrupt write
            problems.append(f"{rel}: cannot open ({exc})")
            return
        if (w, h) != (size, size):
            problems.append(f"{rel}: is {w}x{h}, expected {size}x{size}")
        has_alpha = mode in ("RGBA", "LA") or "transparency" in getattr(im, "info", {})
        if want_alpha and not has_alpha:
            problems.append(f"{rel}: expected an alpha channel, mode is {mode}")
        if not want_alpha and has_alpha:
            problems.append(f"{rel}: MUST NOT have alpha (iOS), mode is {mode}")
        std = float(grey.std())
        if std < 8.0:
            problems.append(f"{rel}: looks blank (luma std {std:.2f})")
        rows.append((rel, f"{w}x{h}", mode, f"{std:6.2f}", f"{os.path.getsize(path) / 1024:.1f} KB"))

    for path, size in android_files:
        check(path, size, want_alpha=True)
    for path, size in ios_files:
        check(path, size, want_alpha=False)

    # Every filename named in Contents.json must exist on disk, and every PNG
    # on disk must be named by Contents.json. A mismatch fails an Xcode build.
    with open(contents_path, encoding="utf-8") as f:
        contents = json.load(f)
    named = {img["filename"] for img in contents["images"]}
    on_disk = {n for n in os.listdir(IOS_DIR) if n.endswith(".png")}
    for missing in sorted(named - on_disk):
        problems.append(f"Contents.json names {missing}, which is not on disk")
    for orphan in sorted(on_disk - named):
        problems.append(f"{orphan} is on disk but not named by Contents.json")
    for img in contents["images"]:
        for key in ("size", "idiom", "filename", "scale"):
            if key not in img:
                problems.append(f"Contents.json entry missing '{key}': {img}")

    # The master vector must at least be well-formed XML.
    try:
        root = ET.parse(SVG_PATH).getroot()
        if not root.tag.endswith("svg"):
            problems.append(f"{SVG_PATH}: root element is {root.tag}, not <svg>")
        rects = [e for e in root.iter() if e.tag.endswith("}rect") or e.tag == "rect"]
        # 2 background rects + 16 pads.
        if len(rects) != 18:
            problems.append(f"logo.svg: expected 18 <rect>s, found {len(rects)}")
    except ET.ParseError as exc:
        problems.append(f"{SVG_PATH}: not valid XML ({exc})")

    rows.append((os.path.relpath(preview_path, ROOT), "760x420", "RGB", "  --  ",
                 f"{os.path.getsize(preview_path) / 1024:.1f} KB"))
    rows.append((os.path.relpath(contents_path, ROOT),
                 f"{len(contents['images'])} entries", "json", "  --  ",
                 f"{os.path.getsize(contents_path) / 1024:.1f} KB"))
    rows.append((os.path.relpath(SVG_PATH, ROOT), "1024x1024", "svg", "  --  ",
                 f"{os.path.getsize(SVG_PATH) / 1024:.1f} KB"))
    return rows, problems


def main():
    master_square = render_master(MASTER_PX, rounded_plate=False)
    master_rounded = render_master(MASTER_PX, rounded_plate=True)

    android_files = write_android(master_rounded)
    ios_files, contents_path = write_ios(master_square)
    preview_path = write_preview(master_square, master_rounded)

    rows, problems = verify(android_files, ios_files, contents_path, preview_path)

    w0 = max(len(r[0]) for r in rows)
    w1 = max(len(r[1]) for r in rows)
    print(f"\n{'file'.ljust(w0)}  {'size'.ljust(w1)}  mode  luma-sd  bytes")
    print("-" * (w0 + w1 + 30))
    for rel, size, mode, std, size_kb in rows:
        print(f"{rel.ljust(w0)}  {size.ljust(w1)}  {mode:<5} {std}  {size_kb}")
    print(f"\n{len(rows)} files.")

    if problems:
        print("\nPROBLEMS:")
        for p in problems:
            print(f"  ! {p}")
        raise SystemExit(1)
    print("All checks passed: sizes exact, iOS set is alpha-free, no blank "
          "images, Contents.json matches the files on disk, logo.svg parses.")


if __name__ == "__main__":
    main()

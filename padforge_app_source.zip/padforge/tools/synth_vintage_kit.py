#!/usr/bin/env python3
"""
Synthesizes a full 16-sound "Vintage Kit" drum sample pack for PadForge.

Every sound here is generated purely from math (sine/triangle/square
oscillators, filtered noise bursts, and exponential envelopes) -- nothing is
sampled from real records or existing drum machines, so there are zero
licensing concerns. Run with:

    python3 tools/synth_vintage_kit.py

Requires numpy + scipy (pip install numpy scipy). Writes 16-bit PCM mono
WAV files into assets/kits/vintage_kit/samples/.
"""
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt
import os

SR = 44100
OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "assets", "kits", "vintage_kit", "samples")
os.makedirs(OUT_DIR, exist_ok=True)


def t_axis(dur):
    return np.linspace(0, dur, int(SR * dur), endpoint=False)


def env_exp(dur, decay):
    """Exponential decay envelope, decay = time constant in seconds."""
    t = t_axis(dur)
    return np.exp(-t / decay)


def normalize(x, peak=0.9):
    m = np.max(np.abs(x)) if len(x) else 1.0
    if m < 1e-9:
        return x
    return x / m * peak


def soft_clip(x, drive=1.0):
    """Gentle tanh soft-clipper for a bit of analog-style character."""
    return np.tanh(x * drive) / np.tanh(drive)


def bitcrush(x, bits=10):
    """Light bitcrush for lo-fi vintage color."""
    levels = 2 ** bits
    return np.round(x * levels) / levels


def butter_filter(x, cutoff, sr=SR, btype="low", order=4):
    nyq = sr / 2.0
    cutoff = np.clip(cutoff / nyq, 0.001, 0.999)
    sos = butter(order, cutoff, btype=btype, output="sos")
    return sosfilt(sos, x)


def white_noise(dur, seed=0):
    rng = np.random.default_rng(seed)
    return rng.uniform(-1, 1, int(SR * dur))


def sine_sweep(dur, f_start, f_end, shape="exp"):
    t = t_axis(dur)
    if shape == "exp" and f_end > 0 and f_start > 0:
        k = (f_end / f_start) ** (1.0 / dur) if dur > 0 else 1.0
        freq = f_start * (k ** t)
        phase = 2 * np.pi * f_start * (k ** t - 1) / np.log(k) if k != 1 else 2 * np.pi * f_start * t
    else:
        freq = np.linspace(f_start, f_end, len(t))
        phase = 2 * np.pi * np.cumsum(freq) / SR
    return np.sin(phase)


def save_wav(name, x):
    x = np.clip(x, -1.0, 1.0)
    data = (x * 32767.0).astype(np.int16)
    path = os.path.join(OUT_DIR, name)
    wavfile.write(path, SR, data)
    print(f"wrote {path} ({len(data) / SR:.3f}s)")


# ---------------------------------------------------------------------------
# 1. Kick -- pitch-swept sine body + short click transient
def make_kick():
    dur = 0.45
    body = sine_sweep(dur, 150, 45, "exp") * env_exp(dur, 0.09)
    click = white_noise(0.006, seed=1) * env_exp(0.006, 0.002)
    click = butter_filter(click, 3500, btype="low")
    x = body * 0.95
    x[: len(click)] += click * 0.6
    x = soft_clip(normalize(x, 0.95), 1.4)
    return normalize(x, 0.92)


# 2. Snare -- tonal thump + filtered noise "snap"
def make_snare():
    dur = 0.28
    tone = (sine_sweep(dur, 190, 130, "exp") * 0.6 + sine_sweep(dur, 330, 200, "exp") * 0.3)
    tone *= env_exp(dur, 0.045)
    noise = white_noise(dur, seed=2)
    noise = butter_filter(noise, 1800, btype="high")
    noise *= env_exp(dur, 0.07)
    x = tone * 0.55 + noise * 0.8
    return normalize(soft_clip(x, 1.2), 0.9)


# 3. Closed Hat -- short high-passed metallic noise burst
def make_closed_hat():
    dur = 0.09
    noise = white_noise(dur, seed=3)
    noise = butter_filter(noise, 7000, btype="high")
    x = noise * env_exp(dur, 0.015)
    return normalize(x, 0.75)


# 4. Open Hat -- same texture, longer decay
def make_open_hat():
    dur = 0.55
    noise = white_noise(dur, seed=4)
    noise = butter_filter(noise, 6500, btype="high")
    x = noise * env_exp(dur, 0.18)
    return normalize(x, 0.75)


# 5. Clap -- several staggered short noise bursts blurred together
def make_clap():
    dur = 0.3
    x = np.zeros(int(SR * dur))
    offsets = [0.0, 0.012, 0.024, 0.038]
    for i, off in enumerate(offsets):
        burst_dur = 0.09
        n = white_noise(burst_dur, seed=10 + i)
        n = butter_filter(n, 1200, btype="high")
        n *= env_exp(burst_dur, 0.03 if i < 3 else 0.09)
        start = int(off * SR)
        end = min(start + len(n), len(x))
        x[start:end] += n[: end - start] * (0.7 if i < 3 else 1.0)
    return normalize(x, 0.85)


# 6. Rimshot -- short high-pitched tone click + noise crack
def make_rimshot():
    dur = 0.12
    tone = sine_sweep(dur, 900, 420, "exp") * env_exp(dur, 0.02)
    noise = butter_filter(white_noise(dur, seed=5), 3000, btype="high") * env_exp(dur, 0.015)
    x = tone * 0.7 + noise * 0.6
    return normalize(soft_clip(x, 1.3), 0.85)


# 7/8/9. Toms -- pitched sine sweeps at different registers
def make_tom(f_start, f_end, dur=0.35, seed=6):
    body = sine_sweep(dur, f_start, f_end, "exp") * env_exp(dur, 0.14)
    click = butter_filter(white_noise(0.01, seed=seed), 4000, btype="low") * env_exp(0.01, 0.003)
    x = body
    x[: len(click)] += click * 0.3
    return normalize(x, 0.88)


# 10. Crash -- long bright filtered noise with slow decay
def make_crash():
    dur = 1.6
    noise = white_noise(dur, seed=7)
    noise = butter_filter(noise, 5000, btype="high")
    shimmer = np.sin(2 * np.pi * 6500 * t_axis(dur)) * 0.15
    x = (noise + shimmer) * env_exp(dur, 0.55)
    return normalize(x, 0.7)


# 11. Ride -- metallic bell tone + shorter noise wash
def make_ride():
    dur = 0.9
    bell = (np.sin(2 * np.pi * 850 * t_axis(dur)) * 0.5
            + np.sin(2 * np.pi * 1400 * t_axis(dur)) * 0.3
            + np.sin(2 * np.pi * 2300 * t_axis(dur)) * 0.2)
    bell *= env_exp(dur, 0.4)
    noise = butter_filter(white_noise(dur, seed=8), 4500, btype="high") * env_exp(dur, 0.25)
    x = bell * 0.5 + noise * 0.4
    return normalize(x, 0.7)


# 12. Cowbell -- two detuned square-ish tones
def make_cowbell():
    dur = 0.35
    t = t_axis(dur)
    f1, f2 = 560, 845
    sq1 = np.sign(np.sin(2 * np.pi * f1 * t))
    sq2 = np.sign(np.sin(2 * np.pi * f2 * t))
    x = (sq1 * 0.5 + sq2 * 0.5) * env_exp(dur, 0.09)
    x = butter_filter(x, 3500, btype="low")
    return normalize(soft_clip(x, 1.2), 0.8)


# 13. Shaker -- short bright noise, softer attack than hats
def make_shaker():
    dur = 0.16
    noise = white_noise(dur, seed=9)
    noise = butter_filter(noise, 5500, btype="high")
    attack = np.minimum(t_axis(dur) / 0.005, 1.0)
    x = noise * env_exp(dur, 0.05) * attack
    return normalize(x, 0.65)


# 14/15. Vintage "blips" -- short square/triangle stabs with pitch drop
def make_blip(f_start, f_end, dur=0.2, wave="tri", seed=20):
    t = t_axis(dur)
    if wave == "tri":
        k = (f_end / f_start) ** (1.0 / dur)
        freq = f_start * (k ** t)
        phase = 2 * np.pi * f_start * (k ** t - 1) / np.log(k)
        osc = 2 / np.pi * np.arcsin(np.sin(phase))
    else:
        freq = np.linspace(f_start, f_end, len(t))
        phase = 2 * np.pi * np.cumsum(freq) / SR
        osc = np.sign(np.sin(phase))
    x = osc * env_exp(dur, 0.06)
    x = bitcrush(x, bits=8)
    return normalize(x, 0.7)


# 16. Vintage "stab" -- short chord-like bleep, filtered + bitcrushed
def make_stab():
    dur = 0.3
    t = t_axis(dur)
    chord = (np.sin(2 * np.pi * 220 * t) + np.sin(2 * np.pi * 277 * t) + np.sin(2 * np.pi * 330 * t)) / 3
    chord *= env_exp(dur, 0.12)
    chord = butter_filter(chord, 2200, btype="low")
    chord = bitcrush(chord, bits=9)
    return normalize(chord, 0.75)


SOUNDS = [
    ("kick.wav", make_kick),
    ("snare.wav", make_snare),
    ("closed_hat.wav", make_closed_hat),
    ("open_hat.wav", make_open_hat),
    ("clap.wav", make_clap),
    ("rimshot.wav", make_rimshot),
    ("low_tom.wav", lambda: make_tom(160, 90, seed=6)),
    ("mid_tom.wav", lambda: make_tom(220, 120, seed=61)),
    ("hi_tom.wav", lambda: make_tom(300, 170, seed=62)),
    ("crash.wav", make_crash),
    ("ride.wav", make_ride),
    ("cowbell.wav", make_cowbell),
    ("shaker.wav", make_shaker),
    ("vintage_blip_1.wav", lambda: make_blip(700, 300, wave="tri", seed=20)),
    ("vintage_blip_2.wav", lambda: make_blip(950, 500, wave="square", seed=21)),
    ("vintage_stab.wav", make_stab),
]


def main():
    for filename, fn in SOUNDS:
        audio = fn()
        save_wav(filename, audio)
    print(f"\nDone. {len(SOUNDS)} samples written to {os.path.abspath(OUT_DIR)}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Synthesizes the 32-sound "Vintage Kit" sample pack for PadForge.

Character brief: dry, punchy, analog drum machine. Classic 808/909 territory
but voiced our own way -- short decays, no reverb to speak of, mid-focused,
and deliberately NOT sub-heavy or hyped (that's the Modern Pop kit's job).

    Bank A (MIDI notes 36-51): General MIDI drum map -- see GM_BANK_A_ROLES.
                               Pads 1-4 on the hardware = kick, rim, snare, clap.
    Bank B (MIDI notes 52-67): alternate kicks/snares, analog percussion, FX.

Every sound is generated from math -- oscillators, filtered noise and
envelopes -- so the whole kit is original and royalty-free. Run with:

    python3 tools/synth_vintage_kit.py

Requires numpy + scipy. Writes 16-bit PCM mono 44.1 kHz WAVs into
assets/kits/vintage_kit/samples/ and regenerates that kit's kit.json.
"""
import numpy as np

from synth_common import (
    CHOKE_CYMBAL, CHOKE_FX, CHOKE_HAT, CHOKE_PERC, SR, bandpass, butter_filter,
    click, compressor, env_ad, env_multi, layer, metal_stack,
    noise_burst, normalize, osc, pitch_env, place, rbj_bandpass, rbj_highpass,
    rbj_lowpass, render_all, saturate, sine, sweep_filter_noise, white_noise,
    write_kit_json, finalize,
)

KIT_DIR = "vintage_kit"

# Fundamentals (Hz) the verifier checks by FFT. Analog machines were tuned by
# ear, but ours are tuned to a scale so toms and congas play in key.
TUNING = {}


def vintage_bus(x, dur=None, thr=-14.0, ratio=3.0, atk=6.0, rel=90.0, drive=1.4,
                hpf=25.0):
    """Shared finishing chain: DC/rumble high-pass -> glue compressor -> tanh.

    The compressor runs BEFORE the final saturator so the clipper sees an
    already-even signal and adds harmonics rather than just squashing peaks --
    the same order a hardware drum machine's output stage effectively had.
    """
    y = butter_filter(np.asarray(x, dtype=np.float64), hpf, btype="high", order=2)
    y = normalize(y, 0.85)
    y = compressor(y, threshold_db=thr, ratio=ratio, attack_ms=atk, release_ms=rel)
    if drive and drive > 1.0:
        y = saturate(y, drive)
    return finalize(y)


# ===========================================================================
# BANK A -- General MIDI core kit (notes 36-51)
# ===========================================================================

# 36. Kick -- 808 weight with 909 attack. Three layers:
#   body   : sine on an exponential pitch envelope 125 -> 48 Hz in 22 ms
#   punch  : a second, faster-falling triangle an octave up for midrange cut
#   click  : resonant impulse ping, 2 ms, so it reads on small speakers
def make_kick(dur=0.42, f_end=48.0, f_start=130.0, tau=0.022, decay=0.105,
              punch_gain=0.30, click_gain=0.32, seed=101):
    body = osc(pitch_env(dur, f_start, f_end, tau)) * env_ad(dur, 0.0018, decay, curve=0.92)
    body = saturate(body, 2.1)

    punch = osc(pitch_env(dur, f_start * 2.0, f_end * 1.7, 0.011), "tri")
    punch *= env_ad(dur, 0.0008, 0.030, curve=1.1)
    punch = saturate(punch, 3.2)

    tick = click(0.009, tone=2400.0, q=1.1, decay=0.0016, kind="impulse")
    beater = click(0.007, tone=4200.0, q=0.9, decay=0.0012, seed=seed) * 0.5

    x = layer(dur, (body, 1.0), (punch, punch_gain), (tick, click_gain), (beater, 0.18))
    return vintage_bus(x, thr=-13.0, ratio=3.2, atk=8.0, rel=110.0, drive=1.6, hpf=26.0)


# 37. Rimshot -- 808-style: a very short resonant ping plus a wooden crack.
def make_rimshot(dur=0.11, seed=102):
    ping = osc(pitch_env(dur, 1750.0, 1420.0, 0.006), "tri") * env_ad(dur, 0.0004, 0.011)
    body = osc(pitch_env(dur, 480.0, 400.0, 0.008)) * env_ad(dur, 0.0006, 0.016)
    crack = noise_burst(dur, 1800, 7000, decay=0.008, seed=seed) * 0.7
    x = layer(dur, (ping, 0.9), (body, 0.5), (crack, 0.55),
              (click(0.004, 3000.0, q=0.8, decay=0.0009, kind="impulse"), 0.4))
    return vintage_bus(x, thr=-16.0, ratio=2.5, atk=1.0, rel=40.0, drive=1.8)


# 38. Snare -- the kit's centrepiece. Tonal shell (two detuned tuned modes,
# both dropping slightly in pitch like a real head) + band-passed "wires" with
# a longer two-stage decay + a 4 ms crack transient on top.
def make_snare(dur=0.30, f_lo=185.0, f_hi=330.0, wire_gain=0.85, seed=103):
    mode_lo = osc(pitch_env(dur, f_lo * 1.18, f_lo, 0.012)) * env_ad(dur, 0.0012, 0.048)
    mode_hi = osc(pitch_env(dur, f_hi * 1.15, f_hi, 0.010)) * env_ad(dur, 0.0010, 0.032)
    shell = saturate(mode_lo * 0.62 + mode_hi * 0.38, 2.4)

    # Wires: band-passed noise, then tilted DOWN by mixing in a low-passed
    # copy. Flat 1-8 kHz noise measures (and sounds) like a hiss burst rather
    # than a snare -- a real snare's energy is concentrated 300 Hz - 3 kHz with
    # only a shelf of air above it.
    wires = bandpass(white_noise(dur, seed=seed), 300, 6200, order=3)
    wires = wires * 0.30 + butter_filter(wires, 1300, btype="low", order=2) * 1.35
    wires *= env_multi(dur, [(0.020, 0.55), (0.085, 0.45)])
    wires = saturate(wires, 1.5)

    crack = noise_burst(0.012, 2200, 8000, decay=0.0022, seed=seed + 1)

    x = layer(dur, (shell, 1.15), (wires, wire_gain), (crack, 0.22))
    return vintage_bus(x, thr=-15.0, ratio=3.5, atk=3.0, rel=70.0, drive=1.4, hpf=60.0)


TUNING["snare.wav"] = 185.0


# 39. Clap -- four staggered slaps into a short diffuse tail. The tiny
# randomised gaps (not a fixed grid) are what stop it sounding like a flam.
def make_clap(dur=0.34, seed=104, taps=(0.0, 0.0095, 0.0205, 0.0315), bright=1.0):
    x = np.zeros(int(SR * dur))
    for i, off in enumerate(taps):
        slap = noise_burst(0.05, 900 * bright, 5200 * bright, decay=0.010,
                           seed=seed + i, order=3)
        place(x, slap, off, 0.85 if i < len(taps) - 1 else 1.0)
    tail = bandpass(white_noise(dur, seed=seed + 20), 1100 * bright, 4200 * bright, order=3)
    tail *= env_ad(dur, 0.004, 0.075, curve=1.3)
    x += tail * 0.75
    x = layer(dur, (x, 1.0), (click(0.005, 2600.0, q=1.0, decay=0.0010, seed=seed + 40), 0.25))
    return vintage_bus(x, thr=-18.0, ratio=3.6, atk=1.5, rel=90.0, drive=1.5, hpf=250.0)


# 40. Snare 2 -- the 808 voicing: more tone, less wire, snappier. Layers under
# note 38 nicely because its tuning is a fourth up.
def make_snare_alt(dur=0.22, seed=105):
    return make_snare(dur=dur, f_lo=245.0, f_hi=430.0, wire_gain=0.55, seed=seed)


TUNING["snare_alt.wav"] = 245.0


# 41/43/45/47/48/50. Toms -- one voice, six tunings, GM order (floor -> high).
# Sine fundamental + a quiet 2nd mode at a non-integer ratio (real drum heads
# are inharmonic) + a stick attack.
def make_tom(f0, dur=0.42, seed=110, stick=0.30, decay=0.16):
    body = osc(pitch_env(dur, f0 * 1.55, f0, 0.030)) * env_ad(dur, 0.0016, decay, curve=0.95)
    mode2 = osc(pitch_env(dur, f0 * 2.9, f0 * 2.4, 0.020)) * env_ad(dur, 0.0012, decay * 0.30)
    skin = noise_burst(0.03, 1200, 6500, decay=0.006, seed=seed) * stick
    x = layer(dur, (saturate(body, 1.9), 1.0), (mode2, 0.16), (skin, 0.5),
              (click(0.006, 1800.0, q=1.0, decay=0.0012, kind="impulse"), 0.16))
    return vintage_bus(x, thr=-15.0, ratio=2.8, atk=8.0, rel=90.0, drive=1.4, hpf=45.0)


# Toms are tuned to a G minor pentatonic-ish spread so fills stay musical.
TOM_HZ = {
    "tom_floor.wav": 98.0,     # 41  G2
    "tom_floor_hi.wav": 117.0,  # 43  Bb2
    "tom_low.wav": 131.0,      # 45  C3
    "tom_lowmid.wav": 147.0,   # 47  D3
    "tom_himid.wav": 175.0,    # 48  F3
    "tom_high.wav": 196.0,     # 50  G3
}
TUNING.update(TOM_HZ)


# ---------------------------------------------------------------------------
# Hi-hats and cymbals -- ONE metal source, differentiated only by filter and
# envelope, so closed/pedal/open are audibly the same instrument.
# ---------------------------------------------------------------------------

HAT_PHASES = [0.0, 1.7, 3.1, 4.4, 5.6, 2.3]


def _hat_source(dur, tune=1.0):
    return metal_stack(dur, tune=tune, phases=HAT_PHASES)


def make_closed_hat(dur=0.14, decay=0.020, hp=7200.0, gain_tick=0.30, seed=120):
    src = _hat_source(dur)
    y = rbj_highpass(src, hp, q=1.3)
    y = rbj_bandpass(y, 9500.0, q=0.55) * 1.6 + y * 0.5
    y *= env_ad(dur, 0.0004, decay, curve=1.15)
    tick = click(0.004, 9000.0, q=0.8, decay=0.0008, seed=seed)
    x = layer(dur, (y, 1.0), (tick, gain_tick))
    return vintage_bus(x, thr=-20.0, ratio=4.0, atk=0.4, rel=45.0, drive=1.5,
                       hpf=400.0)


def make_pedal_hat(dur=0.11, seed=121):
    """Foot-closed hat: darker and shorter than the stick-played closed hat."""
    src = _hat_source(dur)
    y = rbj_highpass(src, 5600.0, q=1.1)
    y *= env_ad(dur, 0.0006, 0.014, curve=1.3)
    x = layer(dur, (y, 1.0), (click(0.004, 6200.0, q=0.7, decay=0.0009, seed=seed), 0.22))
    return vintage_bus(x, thr=-20.0, ratio=4.0, atk=0.4, rel=40.0, drive=1.4,
                       hpf=400.0)


def make_open_hat(dur=0.72, seed=122):
    src = _hat_source(dur)
    y = rbj_highpass(src, 6400.0, q=1.2)
    y = rbj_bandpass(y, 8800.0, q=0.5) * 1.3 + y * 0.6
    # Two-stage decay: the initial strike falls away fast, the shell rings on.
    y *= env_multi(dur, [(0.045, 0.45), (0.22, 0.55)]) * env_ad(dur, 0.0005, 4.0)
    x = layer(dur, (y, 1.0), (click(0.004, 9000.0, q=0.8, decay=0.0008, seed=seed), 0.22))
    return vintage_bus(x, thr=-21.0, ratio=4.0, atk=0.5, rel=140.0, drive=1.4,
                       hpf=400.0)


# 49. Crash -- the same metal stack, detuned down and spread much wider, with
# a noise wash on top and a long multi-stage decay.
def make_crash(dur=1.70, seed=123):
    src = _hat_source(dur, tune=0.61) + _hat_source(dur, tune=0.83) * 0.7
    y = rbj_highpass(src, 3200.0, q=0.9)
    wash = bandpass(white_noise(dur, seed=seed), 3000, 15000, order=2)
    y = y * 0.75 + wash * 0.55
    y *= env_multi(dur, [(0.06, 0.30), (0.30, 0.35), (0.90, 0.35)])
    y *= env_ad(dur, 0.0016, 8.0)
    return vintage_bus(y, thr=-19.0, ratio=2.2, atk=6.0, rel=250.0, drive=1.3,
                       hpf=350.0)


# 51. Ride -- defined stick ping (a tuned bell chord) riding on a quiet wash,
# rather than the crash's undifferentiated splash.
def make_ride(dur=1.05, seed=124):
    src = _hat_source(dur, tune=0.55)
    metal = rbj_highpass(src, 2600.0, q=0.8) * env_multi(dur, [(0.10, 0.4), (0.45, 0.6)])
    bell = sum(sine(dur, f) * a for f, a in
               ((523.0, 0.5), (1180.0, 0.34), (2090.0, 0.22), (3150.0, 0.12)))
    bell *= env_multi(dur, [(0.035, 0.6), (0.28, 0.4)])
    ping = noise_burst(0.02, 4000, 12000, decay=0.004, seed=seed)
    y = layer(dur, (metal, 0.55), (bell, 0.55), (ping, 0.5))
    y *= env_ad(dur, 0.0012, 8.0)
    return vintage_bus(y, thr=-18.0, ratio=2.2, atk=5.0, rel=200.0, drive=1.3,
                       hpf=300.0)


TUNING["ride.wav"] = 523.0


# ===========================================================================
# BANK B -- alternate drums, analog percussion and FX (notes 52-67)
# ===========================================================================

def make_kick_long(dur=0.85):
    """808 long boom: slower pitch fall, long tail -- for half-time patterns."""
    return make_kick(dur=dur, f_end=42.0, f_start=105.0, tau=0.055, decay=0.26,
                     punch_gain=0.18, click_gain=0.20, seed=131)


TUNING["kick_long.wav"] = 42.0


def make_kick_punch(dur=0.26):
    """909 tight kick: hard beater, fast pitch drop, no tail to speak of."""
    return make_kick(dur=dur, f_end=57.0, f_start=175.0, tau=0.013, decay=0.055,
                     punch_gain=0.45, click_gain=0.55, seed=132)


def make_snare_gated(dur=0.36, seed=133):
    """Snare into a hard-gated room: bright tail that stops dead."""
    base = make_snare(dur=0.26, seed=seed)
    x = np.zeros(int(SR * dur))
    x[: len(base)] += base
    room = bandpass(white_noise(dur, seed=seed + 5), 450, 4800, order=2)
    room = room * 0.4 + butter_filter(room, 1500, btype="low", order=2) * 1.1
    room *= env_ad(dur, 0.006, 0.30, curve=1.0)
    # The gate: hold, then a fast (4 ms) cut rather than a fade.
    gate = np.ones(len(x))
    hold = int(SR * 0.20)
    fall = int(SR * 0.004)
    gate[hold + fall:] = 0.0
    gate[hold:hold + fall] = np.linspace(1.0, 0.0, fall)
    x += room * gate * 0.55
    return vintage_bus(x, thr=-15.0, ratio=3.0, atk=3.0, rel=60.0, drive=1.6, hpf=120.0)


def make_snare_noise(dur=0.24, seed=134):
    """Wire-only snare: no shell tone at all, for ghost notes and rolls."""
    wires = bandpass(white_noise(dur, seed=seed), 300, 5600, order=3)
    wires = wires * 0.35 + butter_filter(wires, 1200, btype="low", order=2) * 1.25
    wires *= env_multi(dur, [(0.012, 0.6), (0.055, 0.4)])
    crack = noise_burst(0.010, 2500, 9000, decay=0.002, seed=seed + 1)
    x = layer(dur, (saturate(wires, 1.6), 1.0), (crack, 0.25))
    return vintage_bus(x, thr=-17.0, ratio=3.5, atk=1.0, rel=60.0, drive=1.3,
                       hpf=180.0)


def make_clap_wide(dur=0.48, seed=135):
    """Bigger, looser clap -- six slaps over a longer, darker tail."""
    return make_clap(dur=dur, seed=seed, bright=0.85,
                     taps=(0.0, 0.008, 0.017, 0.027, 0.038, 0.051))


def make_cowbell(dur=0.38, seed=136):
    """The 808 cowbell: two detuned squares (540 / 800 Hz) band-passed."""
    a = osc(np.full(int(SR * dur), 540.0), "square")
    b = osc(np.full(int(SR * dur), 800.0), "square")
    y = bandpass(a * 0.5 + b * 0.5, 480, 5200, order=2)
    y *= env_ad(dur, 0.0009, 0.075, curve=1.1)
    x = layer(dur, (saturate(y, 1.8), 1.0),
              (click(0.005, 2600.0, q=1.0, decay=0.001, seed=seed), 0.2))
    return vintage_bus(x, thr=-16.0, ratio=2.5, atk=2.0, rel=60.0, drive=1.4,
                       hpf=300.0)


TUNING["cowbell.wav"] = (540.0, 420.0, 660.0)


def _wood(dur, f0, decay, seed, bright=3000.0):
    """Shared woodblock/clave voice: a struck resonant bar."""
    tone = osc(pitch_env(dur, f0 * 1.06, f0, 0.004)) * env_ad(dur, 0.0004, decay)
    over = sine(dur, f0 * 3.1) * env_ad(dur, 0.0003, decay * 0.35) * 0.25
    knock = noise_burst(0.006, bright * 0.6, bright * 2.4, decay=0.0012, seed=seed)
    x = layer(dur, (saturate(tone, 2.0), 1.0), (over, 0.5), (knock, 0.45))
    return vintage_bus(x, thr=-16.0, ratio=2.4, atk=1.0, rel=40.0, drive=1.5,
                       hpf=250.0)


def make_clave(dur=0.14, seed=137):
    return _wood(dur, 2350.0, 0.020, seed)


def make_woodblock(dur=0.12, seed=138):
    return _wood(dur, 1180.0, 0.018, seed, bright=2400.0)


TUNING["clave.wav"] = 2350.0
TUNING["woodblock.wav"] = 1180.0


def make_conga(f0, dur=0.38, seed=139, slap=0.45):
    """Hand drum: tighter and more harmonic than a tom, with a palm slap."""
    body = osc(pitch_env(dur, f0 * 1.35, f0, 0.018)) * env_ad(dur, 0.0012, 0.10, curve=1.0)
    mode2 = sine(dur, f0 * 2.75) * env_ad(dur, 0.0008, 0.030) * 0.22
    hand = noise_burst(0.02, 900, 5000, decay=0.004, seed=seed) * slap
    x = layer(dur, (saturate(body, 1.8), 1.0), (mode2, 0.5), (hand, 0.6))
    return vintage_bus(x, thr=-15.0, ratio=2.6, atk=5.0, rel=70.0, drive=1.4,
                       hpf=70.0)


TUNING["conga_hi.wav"] = 260.0
TUNING["conga_lo.wav"] = 175.0


def _shaken(dur, low, high, decay, seed, attack=0.002, grains=0):
    """Shaker/maracas: band-passed noise with a soft attack (beads take time
    to hit the shell) and, optionally, a few discrete bead transients."""
    y = bandpass(white_noise(dur, seed=seed), low, high, order=2)
    y *= env_ad(dur, attack, decay, curve=1.2)
    if grains:
        rng = np.random.default_rng(seed + 7)
        for i in range(grains):
            g = noise_burst(0.008, low * 1.4, high, decay=0.0015, seed=seed + 30 + i)
            place(y, g, rng.uniform(0.0, dur * 0.35), rng.uniform(0.2, 0.5))
    return vintage_bus(y, thr=-17.0, ratio=2.2, atk=3.0, rel=50.0, drive=1.3,
                       hpf=600.0)


def make_maracas(dur=0.14, seed=140):
    return _shaken(dur, 4500, 13000, 0.022, seed, attack=0.0015, grains=3)


def make_shaker(dur=0.22, seed=141):
    return _shaken(dur, 3800, 11000, 0.045, seed, attack=0.004, grains=4)


def make_tambourine(dur=0.55, seed=142):
    """Jingles: a cluster of high resonant bands over a noise body."""
    y = bandpass(white_noise(dur, seed=seed), 3500, 14000, order=2)
    jingles = np.zeros(len(y))
    for f, a in ((6300.0, 1.0), (8100.0, 0.8), (9700.0, 0.6), (11500.0, 0.4)):
        jingles += rbj_bandpass(y, f, q=9.0) * a
    y = y * 0.5 + jingles * 0.9
    y *= env_multi(dur, [(0.012, 0.55), (0.15, 0.45)]) * env_ad(dur, 0.0008, 8.0)
    return vintage_bus(y, thr=-18.0, ratio=2.2, atk=2.0, rel=90.0, drive=1.3,
                       hpf=800.0)


def make_crash_short(dur=0.85, seed=143):
    """Choked crash -- the same cymbal cut off short, for stabs."""
    return make_crash(dur=dur, seed=seed)


def make_zap(dur=0.30, seed=144):
    """Analog laser: fast downward square sweep through a resonant low-pass."""
    n = int(SR * dur)
    f = pitch_env(dur, 2600.0, 90.0, 0.055)
    y = osc(f, "square") * env_ad(dur, 0.0008, 0.075, curve=1.1)
    # Filter cutoff tracks the oscillator, which is what makes it a "zap"
    # rather than a buzz: render a few bands and crossfade.
    out = np.zeros(n)
    edges = np.linspace(0, n, 25).astype(int)
    for i in range(len(edges) - 1):
        a, b = edges[i], edges[i + 1]
        if b <= a:
            continue
        cutoff = float(np.mean(f[a:b])) * 3.0
        out[a:b] = rbj_lowpass(y, cutoff, q=3.5)[a:b]
    return vintage_bus(out, thr=-16.0, ratio=2.5, atk=2.0, rel=60.0, drive=1.7,
                       hpf=60.0)


def make_noise_sweep(dur=0.95, seed=145):
    """Upward filtered-noise riser into a soft landing."""
    y = sweep_filter_noise(dur, 400, 9000, seed=seed, q=2.5)
    y *= np.linspace(0.15, 1.0, len(y)) ** 1.8
    y *= env_ad(dur, 0.02, 4.0)
    y[-int(SR * 0.05):] *= np.linspace(1.0, 0.0, int(SR * 0.05)) ** 0.7
    return vintage_bus(y, thr=-18.0, ratio=2.0, atk=10.0, rel=150.0, drive=1.2,
                       hpf=200.0)


# ===========================================================================
# Kit layout -- bank A is the General MIDI drum map, in note order 36..51
# ===========================================================================

BANK_A = [
    ("kick.wav", make_kick),                                   # 36
    ("rimshot.wav", make_rimshot),                             # 37
    ("snare.wav", make_snare),                                 # 38
    ("clap.wav", make_clap),                                   # 39
    ("snare_alt.wav", make_snare_alt),                         # 40
    ("tom_floor.wav", lambda: make_tom(98.0, seed=110)),       # 41
    ("hat_closed.wav", make_closed_hat),                       # 42
    ("tom_floor_hi.wav", lambda: make_tom(117.0, seed=111)),   # 43
    ("hat_pedal.wav", make_pedal_hat),                         # 44
    ("tom_low.wav", lambda: make_tom(131.0, seed=112)),        # 45
    ("hat_open.wav", make_open_hat),                           # 46
    ("tom_lowmid.wav", lambda: make_tom(147.0, seed=113)),     # 47
    ("tom_himid.wav", lambda: make_tom(175.0, dur=0.36, seed=114)),  # 48
    ("crash.wav", make_crash),                                 # 49
    ("tom_high.wav", lambda: make_tom(196.0, dur=0.34, seed=115)),   # 50
    ("ride.wav", make_ride),                                   # 51
]

BANK_B = [
    ("kick_long.wav", make_kick_long),
    ("kick_punch.wav", make_kick_punch),
    ("snare_gated.wav", make_snare_gated),
    ("snare_noise.wav", make_snare_noise),
    ("clap_wide.wav", make_clap_wide),
    ("cowbell.wav", make_cowbell),
    ("clave.wav", make_clave),
    ("woodblock.wav", make_woodblock),
    ("conga_hi.wav", lambda: make_conga(260.0, seed=150)),
    ("conga_lo.wav", lambda: make_conga(175.0, dur=0.42, seed=151)),
    ("maracas.wav", make_maracas),
    ("shaker.wav", make_shaker),
    ("tambourine.wav", make_tambourine),
    ("crash_short.wav", make_crash_short),
    ("zap.wav", make_zap),
    ("noise_sweep.wav", make_noise_sweep),
]

# (filename, volume, chokeGroup) in note order.
#
# Every WAV is normalized to -1 dBFS, so `volume` is where the kit's actual
# mix balance lives: kick and snare up front, hats and cymbals well back (a
# hi-hat at the same level as a kick is the single most common thing that
# makes a sample kit sound amateur).
#   choke 1 = hi-hats  (closed/pedal/open are ONE instrument -- required)
#   choke 2 = crashes  |  3 = hand percussion  |  4 = FX sweeps
PADS_A = [
    ("kick.wav", 1.0, None),
    ("rimshot.wav", 0.7, None),
    ("snare.wav", 0.9, None),
    ("clap.wav", 0.85, None),
    ("snare_alt.wav", 0.8, None),
    ("tom_floor.wav", 0.85, None),
    ("hat_closed.wav", 0.55, CHOKE_HAT),
    ("tom_floor_hi.wav", 0.85, None),
    ("hat_pedal.wav", 0.5, CHOKE_HAT),
    ("tom_low.wav", 0.85, None),
    ("hat_open.wav", 0.55, CHOKE_HAT),
    ("tom_lowmid.wav", 0.85, None),
    ("tom_himid.wav", 0.85, None),
    ("crash.wav", 0.6, CHOKE_CYMBAL),
    ("tom_high.wav", 0.85, None),
    ("ride.wav", 0.6, None),
]

PADS_B = [
    ("kick_long.wav", 1.0, None),
    ("kick_punch.wav", 1.0, None),
    ("snare_gated.wav", 0.85, None),
    ("snare_noise.wav", 0.7, None),
    ("clap_wide.wav", 0.8, None),
    ("cowbell.wav", 0.7, None),
    ("clave.wav", 0.65, None),
    ("woodblock.wav", 0.65, None),
    ("conga_hi.wav", 0.8, CHOKE_PERC),
    ("conga_lo.wav", 0.8, CHOKE_PERC),
    ("maracas.wav", 0.6, CHOKE_PERC),
    ("shaker.wav", 0.6, CHOKE_PERC),
    ("tambourine.wav", 0.6, None),
    ("crash_short.wav", 0.6, CHOKE_CYMBAL),
    ("zap.wav", 0.7, CHOKE_FX),
    ("noise_sweep.wav", 0.7, CHOKE_FX),
]

KNOB_LABELS = ["Master Vol", "Pitch/Speed", "Grit", "Tone", "Decay", "Swing"]


def main():
    print("Vintage Kit -- 32 sounds (GM drum map on bank A)")
    render_all(KIT_DIR, BANK_A + BANK_B)
    write_kit_json(KIT_DIR, "Vintage Kit", PADS_A, PADS_B, KNOB_LABELS)


if __name__ == "__main__":
    main()

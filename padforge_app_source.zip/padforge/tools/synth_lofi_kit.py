#!/usr/bin/env python3
"""
Synthesizes the 32-sound "Lo-Fi Vibes" sample pack for PadForge.

Character brief: dusty and warm. Tape-saturated, band-limited, slightly
out-of-time-feeling drums plus the melodic furniture of a lo-fi beat -- Rhodes
7th chords, upright bass, muted guitar, vinyl crackle.

The important design point, and the one the previous version of this kit got
wrong: the lo-fi chain is a FINISHING process, not a sound design strategy.
Bit reduction, decimation, a 6 kHz ceiling and tape wow can only subtract. Run
them on a thin source and the result is not "warm", it is just quiet mud. So
every drum here is built to the same standard as the Vintage kit's -- real
pitch envelopes, layered transients, per-layer saturation, bus glue -- and is
only then run through `lofi_chain`. Dirty a good drum and you get a lo-fi
drum; dirty a bad one and you just get a worse one.

    Bank A (MIDI notes 36-51): General MIDI drum map -- see GM_BANK_A_ROLES.
                               Pads 1-4 on the hardware = kick, rim, snare, clap.
    Bank B (MIDI notes 52-67): Rhodes 7th chords, upright bass, muted guitar,
                               mallets, and the texture beds (vinyl, hiss).

All original synthesis, no sampled material. Run with:

    python3 tools/synth_lofi_kit.py

Requires numpy + scipy. Writes 16-bit PCM mono 44.1 kHz WAVs into
assets/kits/lofi_kit/samples/ plus that kit's kit.json.
"""
import numpy as np

from synth_common import (
    CHOKE_CHORD, CHOKE_CYMBAL, CHOKE_FX, CHOKE_HAT, CHOKE_MONO_BASS,
    CHOKE_PERC, CHOKE_TEXTURE, SR, bandpass, butter_filter, circular_highpass,
    circular_lowpass, click, compressor, env_ad, env_multi, env_swell,
    finalize, finalize_loop, fm_2op, karplus_strong, layer, lofi_chain,
    metal_stack, midi_hz, noise_burst, normalize, osc, pitch_env, place,
    rbj_bandpass, rbj_highpass, rbj_lowpass, render_all, reverb, saturate,
    sine, soft_clip, tape_wobble, white_noise, write_kit_json,
)

KIT_DIR = "lofi_kit"

TUNING = {}

# Seamless loops: these are built to be exactly periodic, so the verifier must
# NOT expect a fade at their edges (a fade would be an audible dip every time
# the loop wraps).
LOOP_SAMPLES = {"vinyl_crackle.wav", "tape_hiss.wav"}


def clean_bus(x, thr=-15.0, ratio=3.0, atk=5.0, rel=90.0, drive=1.5, hpf=30.0):
    """Stage 1: build a genuinely good drum, exactly as the other kits do."""
    y = butter_filter(np.asarray(x, dtype=np.float64), hpf, btype="high", order=2)
    y = normalize(y, 0.85)
    y = compressor(y, threshold_db=thr, ratio=ratio, attack_ms=atk, release_ms=rel)
    if drive and drive > 1.0:
        y = saturate(y, drive)
    return y


def dust(x, bits=11, decim=2, lowpass=6500.0, drive=1.6, wobble=0.0030, hiss=0.0016,
         hiss_tilt=3000.0, post_lowpass=9000.0, seed=0, highpass=None):
    """Stage 2: THE lo-fi chain -- wow/flutter, band limit, decimate, crush,
    tape saturation, post-filter, hiss floor. Applied to a finished drum.

    Two parameters here exist because measurement caught the first version out:

      `post_lowpass` tames the aliasing images the decimator creates. They are
      part of the charm, but unfiltered they sit ABOVE the lo-fi ceiling and
      make a "warm" kick measure brighter than the clean one it came from.

      `hiss_tilt` darkens the noise bed for bass-heavy material. A flat 4 kHz
      hiss floor under a 50 Hz kick contributes more high-frequency energy
      than the kick itself does -- the spectral centroid of the "kick" ends up
      being the centroid of the hiss.
    """
    y = lofi_chain(x, bits=bits, decim_factor=decim, lowpass=lowpass, drive=drive,
                   wobble_rate=0.8 + (seed % 7) * 0.15, wobble_depth=wobble,
                   hiss=hiss, hiss_tilt=hiss_tilt, post_lowpass=post_lowpass,
                   seed=seed, highpass=highpass)
    return finalize(y)


# ===========================================================================
# BANK A -- General MIDI core drums (notes 36-51)
# ===========================================================================

# 36. Kick -- a real layered kick (pitch envelope, punch layer, beater click)
# that then loses its top end to tape. The click is still there underneath the
# 6 kHz ceiling, which is what keeps it from turning into a cardboard box.
def make_kick(dur=0.48, f_end=52.0, f_start=125.0, tau=0.028, decay=0.115, seed=301):
    body = osc(pitch_env(dur, f_start, f_end, tau)) * env_ad(dur, 0.0025, decay, curve=0.9)
    body = saturate(body, 2.0)
    punch = osc(pitch_env(dur, f_start * 1.9, f_end * 1.7, 0.013), "tri")
    punch *= env_ad(dur, 0.0010, 0.032, curve=1.1)
    punch = saturate(punch, 3.0)
    beater = click(0.008, tone=2200.0, q=1.0, decay=0.0018, kind="impulse")
    x = layer(dur, (body, 1.0), (punch, 0.26), (beater, 0.26))
    x = clean_bus(x, thr=-13.0, ratio=3.2, atk=9.0, rel=110.0, drive=1.5, hpf=28.0)
    return dust(x, bits=11, decim=2, lowpass=5200.0, drive=1.4,
                hiss_tilt=2000.0, post_lowpass=7000.0, seed=seed)


def make_kick_thump(dur=0.30, seed=302):
    """Shorter, drier second kick for ghost notes and off-beats."""
    return make_kick(dur=dur, f_end=58.0, f_start=140.0, tau=0.018, decay=0.058,
                     seed=seed)


# 37. Rim / sidestick -- quiet, woody, almost no ring: it sits under a snare.
def make_rim(dur=0.10, seed=303):
    tone = osc(pitch_env(dur, 1150.0, 940.0, 0.006), "tri") * env_ad(dur, 0.0005, 0.012)
    body = osc(pitch_env(dur, 380.0, 330.0, 0.008)) * env_ad(dur, 0.0008, 0.020)
    knock = noise_burst(dur, 900, 4500, decay=0.006, seed=seed)
    x = layer(dur, (tone, 0.8), (body, 0.6), (knock, 0.5))
    x = clean_bus(x, thr=-16.0, ratio=2.5, atk=1.5, rel=45.0, drive=1.6, hpf=180.0)
    return dust(x, bits=10, decim=3, lowpass=5000.0, drive=1.5, seed=seed)


# 38. Snare -- boxy and warm. Same three-layer construction as the other kits,
# but the shell is tuned low, the wires are rolled off early, and a narrow
# resonant "box" band around 420 Hz gives it that cardboard character on
# purpose rather than by accident.
def make_snare(dur=0.34, f_lo=170.0, f_hi=290.0, wire_gain=0.7, box=0.35, seed=304):
    mode_lo = osc(pitch_env(dur, f_lo * 1.16, f_lo, 0.014)) * env_ad(dur, 0.0016, 0.055)
    mode_hi = osc(pitch_env(dur, f_hi * 1.13, f_hi, 0.011)) * env_ad(dur, 0.0012, 0.036)
    shell = saturate(mode_lo * 0.65 + mode_hi * 0.35, 2.2)

    wires = bandpass(white_noise(dur, seed=seed), 280, 5200, order=3)
    wires = wires * 0.35 + butter_filter(wires, 1100, btype="low", order=2) * 1.25
    wires *= env_multi(dur, [(0.022, 0.55), (0.080, 0.45)])
    wires = saturate(wires, 1.5)

    boxy = rbj_bandpass(white_noise(dur, seed=seed + 3), 420.0, q=4.5)
    boxy *= env_ad(dur, 0.0015, 0.045)

    crack = noise_burst(0.012, 1800, 6500, decay=0.0025, seed=seed + 1)

    x = layer(dur, (shell, 1.1), (wires, wire_gain), (boxy, box), (crack, 0.22))
    x = clean_bus(x, thr=-15.0, ratio=3.2, atk=3.5, rel=75.0, drive=1.5, hpf=70.0)
    return dust(x, bits=10, decim=3, lowpass=5800.0, drive=1.5, seed=seed)


TUNING["snare.wav"] = 170.0


# 40. Snare 2 -- brushed: no crack at all, soft swept attack, longer wash.
def make_snare_brush(dur=0.42, seed=305):
    swirl = bandpass(white_noise(dur, seed=seed), 350, 4800, order=3)
    swirl = swirl * 0.4 + butter_filter(swirl, 1200, btype="low", order=2) * 1.1
    swirl *= env_ad(dur, 0.012, 0.11, curve=1.1)
    shell = osc(pitch_env(dur, 200.0, 175.0, 0.020)) * env_ad(dur, 0.004, 0.05) * 0.5
    x = layer(dur, (swirl, 1.0), (shell, 0.5))
    x = clean_bus(x, thr=-17.0, ratio=2.6, atk=8.0, rel=90.0, drive=1.4, hpf=90.0)
    return dust(x, bits=10, decim=3, lowpass=5200.0, drive=1.5, seed=seed)


TUNING["snare_brush.wav"] = 175.0


# 39. Clap -- soft and blurry: slaps smeared closer together and filtered
# hard, so it reads as one warm handclap rather than four distinct hits.
def make_clap(dur=0.36, seed=306):
    x = np.zeros(int(SR * dur))
    for i, off in enumerate((0.0, 0.011, 0.023, 0.036)):
        slap = noise_burst(0.06, 600, 3600, decay=0.013, seed=seed + i, order=3)
        place(x, slap, off, 0.8 if i < 3 else 1.0)
    tail = bandpass(white_noise(dur, seed=seed + 20), 700, 3200, order=3)
    tail *= env_ad(dur, 0.006, 0.085, curve=1.3)
    x += tail * 0.8
    x = clean_bus(x, thr=-18.0, ratio=3.0, atk=4.0, rel=90.0, drive=1.4, hpf=200.0)
    return dust(x, bits=10, decim=3, lowpass=5000.0, drive=1.5, seed=seed)


# 41/43/45/47/48/50. Toms -- fat, damped, warm. Very little stick.
def make_tom(f0, dur=0.44, seed=310, decay=0.15):
    body = osc(pitch_env(dur, f0 * 1.45, f0, 0.034)) * env_ad(dur, 0.0030, decay, curve=1.0)
    mode2 = osc(pitch_env(dur, f0 * 2.8, f0 * 2.35, 0.022)) * env_ad(dur, 0.0020, decay * 0.25)
    skin = noise_burst(0.03, 700, 3800, decay=0.007, seed=seed)
    x = layer(dur, (saturate(body, 1.8), 1.0), (mode2, 0.13), (skin, 0.35))
    x = clean_bus(x, thr=-15.0, ratio=2.6, atk=9.0, rel=95.0, drive=1.3, hpf=45.0)
    return dust(x, bits=10, decim=3, lowpass=4600.0, drive=1.4,
                hiss_tilt=1800.0, post_lowpass=6500.0, seed=seed)


TOM_HZ = {
    "tom_floor.wav": 87.0,     # 41
    "tom_floor_hi.wav": 104.0,  # 43
    "tom_low.wav": 116.0,      # 45
    "tom_lowmid.wav": 131.0,   # 47
    "tom_himid.wav": 156.0,    # 48
    "tom_high.wav": 175.0,     # 50
}
TUNING.update(TOM_HZ)


# ---------------------------------------------------------------------------
# Hats and cymbals -- one metal source, as everywhere else. The lo-fi chain
# gets a higher ceiling here (9.5 kHz) than it does on the drums: dropping a
# hat to 5 kHz doesn't make it dusty, it makes it disappear.
# ---------------------------------------------------------------------------

HAT_PHASES = [2.4, 0.3, 4.1, 1.5, 5.9, 3.3]


def _hat_source(dur, tune=1.0):
    return metal_stack(dur, tune=tune, phases=HAT_PHASES)


def make_closed_hat(dur=0.12, seed=320):
    src = _hat_source(dur, tune=0.94)
    y = rbj_highpass(src, 6000.0, q=1.2)
    y = rbj_bandpass(y, 7800.0, q=0.6) * 1.5 + y * 0.5
    y *= env_ad(dur, 0.0006, 0.018, curve=1.2)
    x = layer(dur, (y, 1.0), (click(0.004, 7000.0, q=0.8, decay=0.0009, seed=seed), 0.25))
    x = clean_bus(x, thr=-20.0, ratio=4.0, atk=0.5, rel=45.0, drive=1.4, hpf=400.0)
    return dust(x, bits=10, decim=2, lowpass=9500.0, drive=1.5, hiss=0.002, seed=seed)


def make_pedal_hat(dur=0.09, seed=321):
    src = _hat_source(dur, tune=0.94)
    y = rbj_highpass(src, 5000.0, q=1.1) * env_ad(dur, 0.0008, 0.012, curve=1.3)
    x = layer(dur, (y, 1.0), (click(0.004, 5500.0, q=0.7, decay=0.0009, seed=seed), 0.2))
    x = clean_bus(x, thr=-20.0, ratio=4.0, atk=0.5, rel=40.0, drive=1.3, hpf=400.0)
    return dust(x, bits=10, decim=2, lowpass=9000.0, drive=1.4, hiss=0.002, seed=seed)


def make_open_hat(dur=0.55, seed=322):
    src = _hat_source(dur, tune=0.94)
    y = rbj_highpass(src, 5400.0, q=1.1)
    y = rbj_bandpass(y, 7400.0, q=0.5) * 1.3 + y * 0.6
    y *= env_multi(dur, [(0.040, 0.5), (0.19, 0.5)]) * env_ad(dur, 0.0007, 4.0)
    x = layer(dur, (y, 1.0), (click(0.004, 7000.0, q=0.8, decay=0.0009, seed=seed), 0.2))
    x = clean_bus(x, thr=-21.0, ratio=4.0, atk=0.6, rel=140.0, drive=1.3, hpf=400.0)
    return dust(x, bits=10, decim=2, lowpass=9500.0, drive=1.4, hiss=0.002, seed=seed)


# 49. Crash -- dark and washy, more "cymbal in the next room" than splash.
def make_crash(dur=1.55, seed=323):
    src = _hat_source(dur, tune=0.58) + _hat_source(dur, tune=0.78) * 0.7
    y = rbj_highpass(src, 2600.0, q=0.9)
    wash = bandpass(white_noise(dur, seed=seed), 2500, 11000, order=2)
    y = y * 0.7 + wash * 0.6
    y *= env_multi(dur, [(0.06, 0.30), (0.28, 0.35), (0.80, 0.35)])
    y *= env_ad(dur, 0.0025, 8.0)
    y = clean_bus(y, thr=-19.0, ratio=2.4, atk=7.0, rel=250.0, drive=1.25, hpf=320.0)
    return dust(y, bits=10, decim=2, lowpass=9000.0, drive=1.3, hiss=0.002, seed=seed)


# 51. Ride -- dusty, with a faint bell in the middle of the wash.
def make_ride(dur=1.00, seed=324):
    src = _hat_source(dur, tune=0.52)
    metal = rbj_highpass(src, 2400.0, q=0.8) * env_multi(dur, [(0.10, 0.45), (0.42, 0.55)])
    bell = sum(sine(dur, f) * a for f, a in
               ((466.0, 0.5), (1050.0, 0.3), (1870.0, 0.18)))
    bell *= env_multi(dur, [(0.040, 0.6), (0.26, 0.4)])
    ping = noise_burst(0.02, 3000, 9000, decay=0.005, seed=seed)
    y = layer(dur, (metal, 0.8), (bell, 0.65), (ping, 0.3))
    y *= env_ad(dur, 0.0018, 8.0)
    y = clean_bus(y, thr=-23.0, ratio=3.5, atk=2.0, rel=210.0, drive=1.25, hpf=300.0)
    return dust(y, bits=10, decim=2, lowpass=9000.0, drive=1.3, hiss=0.002, seed=seed)


TUNING["ride.wav"] = 466.0


# ===========================================================================
# BANK B -- melodic furniture and texture beds (notes 52-67)
# ===========================================================================

# Rhodes: 2-operator FM at a 2:1 ratio with a fast-decaying modulation index.
# The index decay is the tine "bark" -- brightness that dies away much faster
# than the note does, which no static filter can imitate.
def _rhodes_note(dur, note, index=3.4, seed=0):
    f0 = midi_hz(note)
    y = fm_2op(dur, f0, ratio=2.0, index=index, index_decay=0.055,
               amp_decay=dur * 0.42, attack=0.004)
    # A quiet detuned twin gives the chorused, slightly seasick Rhodes width.
    y += 0.35 * fm_2op(dur, f0 * 1.0015, ratio=2.0, index=index * 0.8,
                       index_decay=0.06, amp_decay=dur * 0.40, attack=0.006)
    return y


def make_rhodes(notes, dur=1.70, seed=330, root=None):
    """A Rhodes 7th chord: FM tines, tape wobble, short room, then dust."""
    x = np.zeros(int(SR * dur))
    for i, n in enumerate(notes):
        # Voices strummed a few ms apart -- nobody's fingers land simultaneously.
        v = _rhodes_note(dur, n, index=3.4 - 0.25 * i, seed=seed + i)
        place(x, v, 0.004 * i, 1.0 / len(notes))
    x = tape_wobble(x, rate=0.9, depth=0.0025, seed=seed)
    x = reverb(x, decay=0.30, tone=4500.0, predelay_ms=12.0, mix=0.20, seed=seed + 7,
               lowcut=200.0)
    x = clean_bus(x, thr=-18.0, ratio=2.5, atk=8.0, rel=140.0, drive=1.3, hpf=70.0)
    return dust(x, bits=11, decim=2, lowpass=6200.0, drive=1.5, wobble=0.0035, seed=seed)


# Chord voicings, all in C major / A minor so the five chords work together.
RHODES_CHORDS = [
    ("rhodes_cmaj7.wav", (60, 64, 67, 71)),
    ("rhodes_dm7.wav", (62, 65, 69, 72)),
    ("rhodes_fmaj7.wav", (65, 69, 72, 76)),
    ("rhodes_g7.wav", (67, 71, 74, 77)),
    ("rhodes_am7.wav", (69, 72, 76, 79)),
]
for _name, _notes in RHODES_CHORDS:
    # Verify the ROOT of each voicing, in a narrow window -- the loudest
    # partial of a 7th chord is frequently not its root.
    TUNING[_name] = (midi_hz(_notes[0]), midi_hz(_notes[0] - 1), midi_hz(_notes[0] + 1))


def make_upright_bass(note, dur=1.30, seed=340):
    """Upright bass: a heavily damped plucked string over a sine fundamental.

    Karplus-Strong gives the woody, fast-decaying overtones; the sine under it
    supplies the fundamental that a short delay line always under-delivers.
    """
    f0 = midi_hz(note)
    # Karplus-Strong damping is per loop pass, and a low note's loop is long,
    # so a fixed damping value leaves low notes measurably (and audibly)
    # brighter than high ones. Scale it with pitch to keep the instrument
    # consistent across its range.
    damping = float(np.clip(0.58 + (36 - note) * 0.015, 0.5, 0.8))
    string = karplus_strong(dur, f0, damping=damping, decay=0.9972, seed=seed,
                            excite_lp=max(1200.0, f0 * 22.0))
    string *= env_ad(dur, 0.004, dur * 0.40)
    fund = sine(dur, f0) * env_ad(dur, 0.010, dur * 0.34) * 0.9
    thumb = noise_burst(0.02, 250, 1800, decay=0.005, seed=seed + 1)
    x = layer(dur, (string, 0.75), (fund, 1.0), (thumb, 0.18))
    x = clean_bus(x, thr=-16.0, ratio=3.0, atk=10.0, rel=150.0, drive=1.6, hpf=35.0)
    return dust(x, bits=11, decim=2, lowpass=min(3800.0, f0 * 46.0), drive=1.5,
                hiss=0.0008, hiss_tilt=1400.0, post_lowpass=4200.0, seed=seed)


BASS_NOTES = [("bass_upright_c2.wav", 36), ("bass_upright_g1.wav", 31)]
for _name, _note in BASS_NOTES:
    TUNING[_name] = (midi_hz(_note), midi_hz(_note) * 0.8, midi_hz(_note) * 1.3)


def make_guitar_muted(note=57, dur=0.55, seed=345):
    """Palm-muted guitar chuck: a very damped string with a pick transient."""
    f0 = midi_hz(note)
    string = karplus_strong(dur, f0, damping=0.66, decay=0.9930, seed=seed,
                            excite_lp=3500.0)
    string *= env_ad(dur, 0.002, 0.14)
    pick = noise_burst(0.012, 1500, 6000, decay=0.0022, seed=seed + 1)
    x = layer(dur, (string, 1.0), (pick, 0.3))
    x = clean_bus(x, thr=-17.0, ratio=2.8, atk=3.0, rel=90.0, drive=1.5, hpf=110.0)
    return dust(x, bits=10, decim=3, lowpass=4600.0, drive=1.4,
                hiss_tilt=1800.0, post_lowpass=6500.0, seed=seed)


TUNING["guitar_muted.wav"] = (midi_hz(57), midi_hz(56), midi_hz(58))


def make_mallet(note=79, dur=1.10, seed=346):
    """Soft mallet / celeste: FM with a long index decay and a gentle attack."""
    f0 = midi_hz(note)
    y = fm_2op(dur, f0, ratio=3.0, index=1.6, index_decay=0.10,
               amp_decay=dur * 0.36, attack=0.006)
    y += 0.25 * sine(dur, f0 * 2.0) * env_ad(dur, 0.008, dur * 0.22)
    y = reverb(y, decay=0.28, tone=5000.0, predelay_ms=10.0, mix=0.22, seed=seed + 2,
               lowcut=250.0)
    y = clean_bus(y, thr=-18.0, ratio=2.4, atk=6.0, rel=130.0, drive=1.25, hpf=150.0)
    return dust(y, bits=11, decim=2, lowpass=6500.0, drive=1.4, seed=seed)


TUNING["mallet_soft.wav"] = (midi_hz(79), midi_hz(78), midi_hz(80))


def make_warm_sub(note=36, dur=1.30, seed=347):
    """Round sine sub with a slow attack -- sits under the Rhodes."""
    f0 = midi_hz(note)
    y = osc(pitch_env(dur, f0 * 1.6, f0, 0.045)) * env_ad(dur, 0.012, dur * 0.34)
    y = saturate(y, 1.7)
    y = clean_bus(y, thr=-15.0, ratio=2.5, atk=15.0, rel=200.0, drive=1.3, hpf=22.0)
    return dust(y, bits=11, decim=2, lowpass=2600.0, drive=1.3, hiss=0.0006,
                hiss_tilt=900.0, post_lowpass=3500.0, seed=seed)


TUNING["warm_sub.wav"] = (midi_hz(36), midi_hz(36) * 0.8, midi_hz(36) * 1.3)


def make_perc_tick(dur=0.09, seed=348):
    """Tiny wooden blip for 16th-note filler."""
    tone = osc(pitch_env(dur, 1500.0, 1300.0, 0.004)) * env_ad(dur, 0.0004, 0.012)
    knock = noise_burst(0.008, 1200, 5000, decay=0.0016, seed=seed)
    x = layer(dur, (tone, 0.8), (knock, 0.6))
    x = clean_bus(x, thr=-17.0, ratio=2.5, atk=1.0, rel=40.0, drive=1.5, hpf=250.0)
    return dust(x, bits=10, decim=3, lowpass=6000.0, drive=1.4, seed=seed)


def make_tape_stop(dur=0.75, seed=349):
    """Tape-stop: pitch and brightness collapse together into nothing."""
    f = pitch_env(dur, 320.0, 22.0, 0.20)
    y = osc(f, "tri") * env_ad(dur, 0.004, 0.34, curve=0.9)
    n = len(y)
    out = np.zeros(n)
    edges = np.linspace(0, n, 33).astype(int)
    for i in range(len(edges) - 1):
        a, b = edges[i], edges[i + 1]
        if b <= a:
            continue
        out[a:b] = rbj_lowpass(y, max(float(np.mean(f[a:b])) * 6.0, 60.0), q=1.6)[a:b]
    out = clean_bus(out, thr=-17.0, ratio=2.5, atk=8.0, rel=140.0, drive=1.4, hpf=25.0)
    return dust(out, bits=9, decim=4, lowpass=4200.0, drive=1.5, wobble=0.006, seed=seed)


def make_dust_swell(dur=1.40, seed=350):
    """Reverse-swell noise wash for transitions -- the 'breath' before a drop."""
    y = bandpass(white_noise(dur, seed=seed), 400, 6000, order=2)
    y = y * 0.5 + butter_filter(y, 1600, btype="low", order=2) * 1.0
    y *= env_swell(dur, peak_at=0.88, curve=2.0)
    y = reverb(y, decay=0.25, tone=4000.0, predelay_ms=15.0, mix=0.3, seed=seed + 1,
               lowcut=200.0)
    y = clean_bus(y, thr=-20.0, ratio=2.2, atk=20.0, rel=200.0, drive=1.2, hpf=150.0)
    return dust(y, bits=10, decim=3, lowpass=5200.0, drive=1.3, seed=seed)


# --- seamless texture loops -------------------------------------------------
# These two are built to be exactly periodic: every filter used on them is a
# circular (FFT-domain) one, and no fade is applied, so sample N-1 joins
# continuously back onto sample 0 and the loop never ticks.

def make_vinyl_crackle(dur=2.0, seed=360):
    """2 s seamless vinyl crackle: sparse impulsive pops over a surface bed."""
    n = int(SR * dur)
    rng = np.random.default_rng(seed)
    y = np.zeros(n)
    # Crackle: short decaying pops at random positions, wrapped modulo n so a
    # pop near the end continues at the start -- that wrap is what keeps the
    # loop seamless without a crossfade.
    for _ in range(260):
        pos = rng.integers(0, n)
        length = int(rng.integers(20, 160))
        env = np.exp(-np.arange(length) / max(length * 0.22, 1.0))
        pop = rng.normal(0, 1, length) * env * rng.uniform(0.15, 1.0)
        idx = (pos + np.arange(length)) % n
        y[idx] += pop
    bed = rng.normal(0, 1, n) * 0.06
    y = circular_highpass(y + bed, 900.0, order=2)
    y = circular_lowpass(y, 7000.0, order=2)
    y = soft_clip(normalize(y, 0.8), 1.6)
    return finalize_loop(y)


def make_tape_hiss(dur=2.0, seed=361):
    """2 s seamless tape hiss: dark noise with a slow, periodic breathing."""
    n = int(SR * dur)
    rng = np.random.default_rng(seed)
    y = rng.normal(0, 1, n)
    y = circular_lowpass(y, 5200.0, order=2)
    y = circular_highpass(y, 300.0, order=1)
    # Breathing LFO at exactly 2 cycles per loop, so it too is periodic.
    t = np.linspace(0, 2 * np.pi * 2, n, endpoint=False)
    y *= 1.0 + 0.18 * np.sin(t) + 0.08 * np.sin(3 * t + 1.1)
    return finalize_loop(soft_clip(normalize(y, 0.75), 1.3))


# ===========================================================================
# Kit layout -- bank A is the General MIDI drum map, in note order 36..51
# ===========================================================================

BANK_A = [
    ("kick.wav", make_kick),                                   # 36
    ("rim.wav", make_rim),                                     # 37
    ("snare.wav", make_snare),                                 # 38
    ("clap.wav", make_clap),                                   # 39
    ("snare_brush.wav", make_snare_brush),                     # 40
    ("tom_floor.wav", lambda: make_tom(87.0, seed=310)),       # 41
    ("hat_closed.wav", make_closed_hat),                       # 42
    ("tom_floor_hi.wav", lambda: make_tom(104.0, seed=311)),   # 43
    ("hat_pedal.wav", make_pedal_hat),                         # 44
    ("tom_low.wav", lambda: make_tom(116.0, seed=312)),        # 45
    ("hat_open.wav", make_open_hat),                           # 46
    ("tom_lowmid.wav", lambda: make_tom(131.0, seed=313)),     # 47
    ("tom_himid.wav", lambda: make_tom(156.0, dur=0.38, seed=314)),  # 48
    ("crash.wav", make_crash),                                 # 49
    ("tom_high.wav", lambda: make_tom(175.0, dur=0.36, seed=315)),   # 50
    ("ride.wav", make_ride),                                   # 51
]

BANK_B = [(name, (lambda ns=notes: make_rhodes(ns))) for name, notes in RHODES_CHORDS] + [
    ("bass_upright_c2.wav", lambda: make_upright_bass(36, seed=340)),
    ("bass_upright_g1.wav", lambda: make_upright_bass(31, dur=1.40, seed=341)),
    ("guitar_muted.wav", make_guitar_muted),
    ("mallet_soft.wav", make_mallet),
    ("warm_sub.wav", make_warm_sub),
    ("kick_thump.wav", make_kick_thump),
    ("perc_tick.wav", make_perc_tick),
    ("tape_stop.wav", make_tape_stop),
    ("dust_swell.wav", make_dust_swell),
    ("vinyl_crackle.wav", make_vinyl_crackle),
    ("tape_hiss.wav", make_tape_hiss),
]

# (filename, volume, chokeGroup) in note order.
#
# Every WAV is normalized to -1 dBFS, so `volume` carries the mix balance.
# The lo-fi kit sits its drums a touch lower than the other kits because the
# texture beds and Rhodes are meant to be audible underneath them.
PADS_A = [
    ("kick.wav", 1.0, None),
    ("rim.wav", 0.65, None),
    ("snare.wav", 0.85, None),
    ("clap.wav", 0.8, None),
    ("snare_brush.wav", 0.75, None),
    ("tom_floor.wav", 0.85, None),
    ("hat_closed.wav", 0.5, CHOKE_HAT),
    ("tom_floor_hi.wav", 0.85, None),
    ("hat_pedal.wav", 0.45, CHOKE_HAT),
    ("tom_low.wav", 0.85, None),
    ("hat_open.wav", 0.5, CHOKE_HAT),
    ("tom_lowmid.wav", 0.85, None),
    ("tom_himid.wav", 0.85, None),
    ("crash.wav", 0.55, CHOKE_CYMBAL),
    ("tom_high.wav", 0.85, None),
    ("ride.wav", 0.55, None),
]

# Rhodes chords share a choke group (one pair of hands plays one chord), the
# two bass notes share the monophonic bass group, and the looping texture beds
# share a group so only one bed can run at a time.
PADS_B = [(name, 0.8, CHOKE_CHORD) for name, _ in RHODES_CHORDS] + [
    ("bass_upright_c2.wav", 0.9, CHOKE_MONO_BASS),
    ("bass_upright_g1.wav", 0.9, CHOKE_MONO_BASS),
    ("guitar_muted.wav", 0.75, None),
    ("mallet_soft.wav", 0.7, None),
    ("warm_sub.wav", 0.85, CHOKE_MONO_BASS),
    ("kick_thump.wav", 0.9, None),
    ("perc_tick.wav", 0.65, CHOKE_PERC),
    ("tape_stop.wav", 0.75, CHOKE_FX),
    ("dust_swell.wav", 0.65, CHOKE_FX),
    ("vinyl_crackle.wav", 0.55, CHOKE_TEXTURE),
    ("tape_hiss.wav", 0.5, CHOKE_TEXTURE),
]

KNOB_LABELS = ["Master Vol", "Pitch/Speed", "Dust", "Warmth", "Wow", "Swing"]


def main():
    print("Lo-Fi Vibes -- 32 sounds (GM drum map on bank A)")
    render_all(KIT_DIR, BANK_A + BANK_B)
    write_kit_json(KIT_DIR, "Lo-Fi Vibes", PADS_A, PADS_B, KNOB_LABELS)


if __name__ == "__main__":
    main()

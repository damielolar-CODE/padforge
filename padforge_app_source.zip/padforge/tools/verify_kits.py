#!/usr/bin/env python3
"""
Measures every WAV in every bundled PadForge kit and prints an auditable table.

We cannot listen to these samples from a build box, so every quality claim has
to be a number. This script is the substitute for ears:

  FORMAT   every file parses via Python's stdlib `wave`: 16-bit PCM, mono,
           44100 Hz, non-zero frames.
  LEVEL    peak sits at about -1 dBFS with zero samples at full scale.
  DYNAMICS crest factor (peak minus RMS) inside a sane window -- below ~6 dB
           means the sound has been squashed into a brick, above ~20 dB means
           it is a weak peaky click with no body. Cymbals and loops are given
           their own wider windows because a 2 s decaying wash legitimately
           has a high crest factor.
  TONE     spectral centroid inside the band expected for the instrument
           class (kick low, snare mid, hats high).
  PITCH    tuned elements (toms, 808s, cowbell, chords) are checked by FFT
           against their intended fundamental, in cents.
  HYGIENE  no DC offset, and both ends of the file are at (or near) zero so a
           pad can never click on trigger or release.
  MIX      a one-bar demo groove per kit -- kick on 1 and 3, snare on 2 and 4,
           closed hats on 8ths, at the kit's own pad volumes -- summed and
           checked for clipping. Elements can each be fine and still turn to
           mush together; this is the check that catches that.

Usage:  python3 tools/verify_kits.py      (exit code 1 if anything fails)
"""
import importlib
import json
import os
import re
import sys
import wave

import numpy as np
from scipy.io import wavfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from synth_common import (  # noqa: E402
    CENTROID_BANDS, KITS_ROOT, SR, classify, cents_error, fundamental_hz, measure,
)

KITS = [
    ("vintage_kit", "synth_vintage_kit"),
    ("modern_pop_kit", "synth_modern_pop_kit"),
    ("lofi_kit", "synth_lofi_kit"),
]

# Crest-factor window per class, in dB. Sustained/washy material is allowed a
# wider window than a one-shot drum.
CREST_BANDS = {
    "kick": (6.0, 20.0),
    "sub": (6.0, 22.0),
    "snare": (6.0, 20.0),
    "clap": (6.0, 22.0),
    "rim": (6.0, 22.0),
    "tom": (6.0, 20.0),
    # Hats and cymbals are allowed a wider window on purpose: a 20 ms strike
    # sitting in a buffer long enough to hold its full decay tail has a high
    # crest factor by construction, and squashing it flat would kill the
    # "tick" that makes a hat cut through a mix.
    "hat": (6.0, 26.0),
    "cymbal": (6.0, 28.0),
    "perc": (6.0, 24.0),
    "tonal": (5.0, 26.0),
    "fx": (4.0, 30.0),
}

PEAK_MIN_DB = -1.6
PEAK_MAX_DB = -0.5
DC_MAX = 0.005
EDGE_MAX = 0.06   # first/last sample as a fraction of full scale

failures = []
warnings = []


def read_wav(path):
    """Reads a WAV twice: once through stdlib `wave` (format contract, which
    is what the app's decoder actually depends on) and once via scipy for the
    float samples."""
    with wave.open(path, "rb") as wf:
        fmt = {
            "channels": wf.getnchannels(),
            "sampwidth": wf.getsampwidth(),
            "framerate": wf.getframerate(),
            "frames": wf.getnframes(),
        }
    rate, data = wavfile.read(path)
    if data.dtype != np.int16:
        raise ValueError(f"{path}: not int16")
    return fmt, rate, data.astype(np.float64) / 32768.0


def check_file(kit, name, path, tuning, loops=()):
    fmt, rate, x = read_wav(path)
    rec = {"kit": kit, "name": name, "cls": classify(name)}

    if fmt["channels"] != 1 or fmt["sampwidth"] != 2 or fmt["framerate"] != SR:
        failures.append(f"{kit}/{name}: format is {fmt}, expected mono/16-bit/44100")
    if fmt["frames"] == 0:
        failures.append(f"{kit}/{name}: zero frames")
        return None

    m = measure(x)
    rec.update(m)

    # --- level -------------------------------------------------------------
    if m["clipped"]:
        failures.append(f"{kit}/{name}: {m['clipped']} samples at full scale (clipping)")
    if not (PEAK_MIN_DB <= m["peak_db"] <= PEAK_MAX_DB):
        failures.append(f"{kit}/{name}: peak {m['peak_db']:.2f} dBFS outside "
                        f"[{PEAK_MIN_DB}, {PEAK_MAX_DB}]")

    # --- dynamics ----------------------------------------------------------
    lo, hi = CREST_BANDS.get(rec["cls"], (4.0, 30.0))
    rec["crest_ok"] = lo <= m["crest_db"] <= hi
    if not rec["crest_ok"]:
        failures.append(f"{kit}/{name}: crest {m['crest_db']:.1f} dB outside "
                        f"[{lo}, {hi}] for class {rec['cls']}")

    # --- tone --------------------------------------------------------------
    clo, chi = CENTROID_BANDS.get(rec["cls"], (20, 20000))
    rec["centroid_ok"] = clo <= m["centroid_hz"] <= chi
    if not rec["centroid_ok"]:
        failures.append(f"{kit}/{name}: centroid {m['centroid_hz']:.0f} Hz outside "
                        f"[{clo}, {chi}] for class {rec['cls']}")

    # --- hygiene -----------------------------------------------------------
    if abs(m["dc"]) > DC_MAX:
        failures.append(f"{kit}/{name}: DC offset {m['dc']:.4f}")
    if name in loops:
        # Seamless loops must NOT be faded -- a fade would dip the level every
        # time the loop wraps. Instead we check the wrap itself: the step from
        # the last sample back to the first has to be no bigger than the steps
        # the waveform already takes internally, or the loop will tick.
        wrap = abs(x[0] - x[-1])
        internal = float(np.percentile(np.abs(np.diff(x)), 99.9))
        if wrap > max(internal * 4.0, 0.02):
            failures.append(f"{kit}/{name}: loop seam discontinuity {wrap:.4f} "
                            f"(99.9th-percentile internal step {internal:.4f})")
    elif abs(x[0]) > EDGE_MAX or abs(x[-1]) > EDGE_MAX:
        failures.append(f"{kit}/{name}: unfaded edge (first={x[0]:.3f}, last={x[-1]:.3f})")

    # --- pitch -------------------------------------------------------------
    target = tuning.get(name)
    if target:
        # A target may be a bare frequency, or (freq, fmin, fmax) when the
        # sound has other strong partials that a wide search would latch onto
        # (the 808 cowbell's 540/800 Hz pair, for instance).
        if isinstance(target, (tuple, list)):
            target, fmin, fmax = target
        else:
            fmin, fmax = max(target * 0.45, 20.0), target * 2.4
        f = fundamental_hz(x, fmin=fmin, fmax=fmax)
        cents = cents_error(f, target)
        rec["f0"] = f
        rec["target"] = target
        rec["cents"] = cents
        if abs(cents) > 35.0:
            failures.append(f"{kit}/{name}: fundamental {f:.1f} Hz vs target "
                            f"{target:.1f} Hz ({cents:+.0f} cents)")
        elif abs(cents) > 12.0:
            warnings.append(f"{kit}/{name}: fundamental off by {cents:+.0f} cents")
    return rec


def demo_groove(kit, pads_a, bpm=90.0):
    """Renders one bar of 4/4 from bank A at the kit's own pad volumes.

    Bank A is the GM map, so the parts are addressed by note number, which is
    itself a check that the map is where we think it is:
      36 kick on beats 1 and 3, 38 snare on 2 and 4, 42 closed hat on 8ths.
    """
    beat = 60.0 / bpm
    bar = beat * 4
    buf = np.zeros(int(SR * (bar + 2.0)))

    by_note = {36 + i: entry for i, entry in enumerate(pads_a)}

    def hit(note, at, extra_gain=1.0):
        entry = by_note.get(note)
        if not entry or not entry[0]:
            return
        path = os.path.join(KITS_ROOT, kit, "samples", entry[0])
        _, _, x = read_wav(path)
        start = int(at * SR)
        end = min(start + len(x), len(buf))
        buf[start:end] += x[: end - start] * entry[1] * extra_gain

    for b in (0, 2):
        hit(36, b * beat)
    for b in (1, 3):
        hit(38, b * beat)
    for i in range(8):
        hit(42, i * beat / 2, extra_gain=0.9 if i % 2 else 1.0)

    # Every sample is normalized to -1 dBFS individually, so summing three
    # voices necessarily exceeds 0 dBFS -- that is true of any drum machine and
    # is what the master volume exists for. The pass/fail test is therefore run
    # at MASTER_GAIN, the standard -6 dB of mix headroom, and asks: with a sane
    # master setting, does this kit's core groove stay clean?
    #
    # The raw (unity-master) peak is reported too, and flagged above +6 dBFS,
    # because that WOULD mean the elements are piling up on each other -- three
    # -1 dBFS one-shots whose low ends align coherently, i.e. the exact "each
    # sample is fine, together it's mush" failure this check exists to catch.
    MASTER_GAIN = 0.5
    raw = measure(buf)
    mixed = buf * MASTER_GAIN
    m = measure(mixed)
    over = int(np.sum(np.abs(mixed) > 1.0))

    status = "OK"
    if over:
        status = f"CLIPS ({over} samples over full scale at -6 dB master)"
        failures.append(f"{kit}: demo groove clips at -6 dB master -- {over} samples "
                        f"over full scale (peak {m['peak_db']:+.2f} dBFS). Lower pad "
                        f"volumes or tame the low-end overlap.")
    elif raw["peak_db"] > 6.0:
        status = f"PILE-UP (unity-master peak {raw['peak_db']:+.2f} dB)"
        failures.append(f"{kit}: demo groove sums to {raw['peak_db']:+.2f} dBFS at unity "
                        f"master -- elements are stacking coherently (mush).")
    elif m["peak_db"] > -0.5:
        status = f"TIGHT (peak {m['peak_db']:+.2f} dB)"
        warnings.append(f"{kit}: demo groove peaks at {m['peak_db']:+.2f} dBFS with a "
                        f"-6 dB master -- little headroom left.")
    m["raw_peak_db"] = raw["peak_db"]
    return m, status


def check_app_manifests(kits):
    """Cross-checks the Dart and pubspec sides of the asset contract.

    KitRepository ships an explicit per-kit list of sample filenames rather
    than reading AssetManifest.json at runtime. That is a deliberate choice,
    but it means a renamed WAV silently breaks kit installation on device --
    the asset load throws for a file the generator no longer writes. So the
    list is checked against what we actually generated, every run.
    """
    repo_root = os.path.dirname(os.path.dirname(KITS_ROOT))
    dart_path = os.path.join(repo_root, "lib", "services", "kit_repository.dart")
    pubspec_path = os.path.join(repo_root, "pubspec.yaml")

    dart = open(dart_path, encoding="utf-8").read()
    block = dart[dart.index("_bundledKitSampleFiles"):]
    block = block[: block.index("\n  };")]

    for kit, _ in kits:
        # bundledKits display-name map must still list the kit.
        if f"'{kit}':" not in dart.split("_bundledKitSampleFiles")[0]:
            failures.append(f"{kit}: missing from KitRepository.bundledKits")

        m = re.search(rf"'{kit}':\s*\[(.*?)\]", block, re.S)
        if not m:
            failures.append(f"{kit}: missing from KitRepository._bundledKitSampleFiles")
            continue
        declared = set(re.findall(r"'([^']+\.wav)'", m.group(1)))
        on_disk = {n for n in os.listdir(os.path.join(KITS_ROOT, kit, "samples"))
                   if n.endswith(".wav")}
        if declared != on_disk:
            failures.append(
                f"{kit}: KitRepository._bundledKitSampleFiles is out of sync -- "
                f"declared-but-absent={sorted(declared - on_disk)} "
                f"generated-but-undeclared={sorted(on_disk - declared)}")
        else:
            print(f"  {kit:<15} bundledKits + {len(declared)} sample filenames match")

        pub = open(pubspec_path, encoding="utf-8").read()
        for entry in (f"assets/kits/{kit}/kit.json", f"assets/kits/{kit}/samples/"):
            count = pub.count(f"- {entry}\n")
            if count == 0:
                failures.append(f"{kit}: pubspec.yaml does not declare {entry}")
            elif count > 1:
                failures.append(f"{kit}: pubspec.yaml declares {entry} {count} times")


def check_gm_map(kits):
    """Asserts the General MIDI drum map really is what shipped, per kit.

    Reads the generated kit.json (not the generator's python), so this checks
    the artefact the app actually loads: A1..A16 ascend 36..51 with A1 at the
    hardware's bottom-left pad, notes 36/38/39 are kick/snare/clap by filename,
    and the three hats share one choke group.
    """
    expect_role = {36: "kick", 38: "snare", 39: "clap", 42: "hat", 46: "hat", 51: "ride"}
    for kit, _ in kits:
        with open(os.path.join(KITS_ROOT, kit, "kit.json"), encoding="utf-8") as fh:
            pads = json.load(fh)["pads"]
        if len(pads) != 48:
            failures.append(f"{kit}: kit.json has {len(pads)} pads, expected 48")
        for i, pad in enumerate(pads):
            bank = "ABC"[i // 16]
            want_id, want_note = f"{bank}{i % 16 + 1}", 36 + i
            if pad["padId"] != want_id or pad["note"] != want_note:
                failures.append(f"{kit}: pad {i} is {pad['padId']}/{pad['note']}, "
                                f"expected {want_id}/{want_note}")
        by_note = {p["note"]: p for p in pads}
        for note, role in expect_role.items():
            name = (by_note[note]["sample"] or "").lower()
            if role not in name:
                failures.append(f"{kit}: GM note {note} should be a {role}, got {name!r}")
        hats = {by_note[n]["chokeGroup"] for n in (42, 44, 46)}
        if hats != {1}:
            failures.append(f"{kit}: hats (42/44/46) choke groups are {hats}, expected {{1}}")
        print(f"  {kit:<15} GM map OK -- 48 pads, A1=36 .. C16=83, hats choked together")


def main(only=()):
    rows = []
    grooves = []
    total_bytes = 0

    for kit, module_name in KITS:
        if only and kit not in only:
            continue
        mod = importlib.import_module(module_name)
        tuning = getattr(mod, "TUNING", {})
        loops = getattr(mod, "LOOP_SAMPLES", set())
        pads_a = getattr(mod, "PADS_A", [])
        sdir = os.path.join(KITS_ROOT, kit, "samples")
        names = sorted(os.listdir(sdir))

        declared = {n for n, _, _ in pads_a} | {n for n, _, _ in getattr(mod, "PADS_B", [])}
        on_disk = {n for n in names if n.endswith(".wav")}
        if declared != on_disk:
            failures.append(f"{kit}: kit.json pads vs samples/ mismatch: "
                            f"missing={sorted(declared - on_disk)} "
                            f"orphan={sorted(on_disk - declared)}")

        for name in names:
            if not name.endswith(".wav"):
                continue
            path = os.path.join(sdir, name)
            total_bytes += os.path.getsize(path)
            rec = check_file(kit, name, path, tuning, loops)
            if rec:
                rows.append(rec)

        total_bytes += os.path.getsize(os.path.join(KITS_ROOT, kit, "kit.json"))
        grooves.append((kit,) + demo_groove(kit, pads_a))

    # ---- table -------------------------------------------------------------
    hdr = (f"{'kit':<15}{'sample':<20}{'class':<8}{'dur s':>7}{'peak':>8}{'rms':>8}"
           f"{'crest':>8}{'centroid':>10}{'dc':>9}  pitch")
    print(hdr)
    print("-" * len(hdr))
    for r in rows:
        pitch = ""
        if "f0" in r:
            pitch = f"{r['f0']:7.2f} Hz vs {r['target']:7.2f} ({r['cents']:+5.1f} c)"
        flags = ""
        if not r.get("centroid_ok", True):
            flags += " <CENTROID"
        if not r.get("crest_ok", True):
            flags += " <CREST"
        print(f"{r['kit']:<15}{r['name']:<20}{r['cls']:<8}{r['dur_s']:7.3f}"
              f"{r['peak_db']:8.2f}{r['rms_db']:8.2f}{r['crest_db']:8.2f}"
              f"{r['centroid_hz']:10.0f}{r['dc']:9.5f}  {pitch}{flags}")

    print()
    print("One-bar demo groove (90 BPM, kick 1+3 / snare 2+4 / closed hat 8ths),")
    print("summed at the kit's own pad volumes into a -6 dB master:")
    for kit, m, status in grooves:
        print(f"  {kit:<15} peak {m['peak_db']:+6.2f} dBFS   rms {m['rms_db']:+6.2f} dBFS"
              f"   crest {m['crest_db']:5.2f} dB   (unity master would peak "
              f"{m['raw_peak_db']:+5.2f})   {status}")

    run_kits = [k for k in KITS if not only or k[0] in only]
    print()
    print("General MIDI drum map (read back from the generated kit.json):")
    check_gm_map(run_kits)
    print()
    print("App asset contract (pubspec.yaml + KitRepository):")
    check_app_manifests(run_kits)

    print()
    print(f"Samples measured : {len(rows)}")
    print(f"assets/kits size : {total_bytes / 1024 / 1024:.2f} MB")

    if warnings:
        print(f"\nWarnings ({len(warnings)}):")
        for w in warnings:
            print(f"  ! {w}")
    if failures:
        print(f"\nFAILURES ({len(failures)}):")
        for f in failures:
            print(f"  x {f}")
        return 1
    print("\nAll checks passed.")
    return 0


if __name__ == "__main__":
    # Optional args restrict the run to named kits, e.g. `verify_kits.py lofi_kit`.
    sys.exit(main(only=tuple(sys.argv[1:])))

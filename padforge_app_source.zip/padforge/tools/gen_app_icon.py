#!/usr/bin/env python3
"""
Generates PadForge's app icon (a simple 4x4 amber pad grid on a dark
chassis background, matching the in-app color palette) and writes it out at
every size Android and iOS need.

Run with: python3 tools/gen_app_icon.py
Requires Pillow (pip install Pillow).
"""
import os
from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(__file__), "..")

CHASSIS = (26, 24, 22, 255)
PAD = (46, 42, 36, 255)
AMBER = (232, 151, 58, 255)
AMBER_DEEP = (201, 122, 34, 255)


def draw_master(size=1024):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    margin = int(size * 0.06)
    radius = int(size * 0.18)
    draw.rounded_rectangle([margin, margin, size - margin, size - margin], radius=radius, fill=CHASSIS)

    # 4x4 grid of rounded amber/pad squares, like the app's pad grid.
    grid_margin = int(size * 0.16)
    gap = int(size * 0.035)
    cell = (size - 2 * grid_margin - 3 * gap) / 4

    for row in range(4):
        for col in range(4):
            x0 = grid_margin + col * (cell + gap)
            y0 = grid_margin + row * (cell + gap)
            x1 = x0 + cell
            y1 = y0 + cell
            # Light up a diagonal-ish pattern in amber, rest in dim pad color,
            # echoing the in-app "hit" glow look.
            lit = (row + col) % 3 == 0
            color = AMBER if lit else PAD
            draw.rounded_rectangle([x0, y0, x1, y1], radius=cell * 0.22, fill=color)

    return img


def save_resized(img, path, size):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    resized = img.resize((size, size), Image.LANCZOS)
    resized.save(path)
    print(f"wrote {path} ({size}x{size})")


def main():
    master = draw_master(1024)

    android_sizes = {
        "mipmap-mdpi": 48,
        "mipmap-hdpi": 72,
        "mipmap-xhdpi": 96,
        "mipmap-xxhdpi": 144,
        "mipmap-xxxhdpi": 192,
    }
    for folder, size in android_sizes.items():
        save_resized(master, os.path.join(ROOT, "android/app/src/main/res", folder, "ic_launcher.png"), size)

    ios_sizes = [
        ("Icon-App-20x20@1x.png", 20),
        ("Icon-App-20x20@2x.png", 40),
        ("Icon-App-20x20@3x.png", 60),
        ("Icon-App-29x29@1x.png", 29),
        ("Icon-App-29x29@2x.png", 58),
        ("Icon-App-29x29@3x.png", 87),
        ("Icon-App-40x40@1x.png", 40),
        ("Icon-App-40x40@2x.png", 80),
        ("Icon-App-40x40@3x.png", 120),
        ("Icon-App-60x60@2x.png", 120),
        ("Icon-App-60x60@3x.png", 180),
        ("Icon-App-76x76@1x.png", 76),
        ("Icon-App-76x76@2x.png", 152),
        ("Icon-App-83.5x83.5@2x.png", 167),
        ("Icon-App-1024x1024@1x.png", 1024),
    ]
    ios_dir = os.path.join(ROOT, "ios/Runner/Assets.xcassets/AppIcon.appiconset")
    for filename, size in ios_sizes:
        # iOS App Store icon must not have an alpha channel.
        flat = Image.new("RGB", (1024, 1024), CHASSIS[:3])
        flat.paste(master, (0, 0), master)
        save_resized(flat, os.path.join(ios_dir, filename), size)

    print("Done.")


if __name__ == "__main__":
    main()

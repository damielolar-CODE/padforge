#!/usr/bin/env python3
"""
Synthesizes the 32-sound "Modern Pop" sample pack for PadForge.

Character brief: bright, loud, heavily transient-designed. Contemporary pop /
trap-leaning production -- sub weight underneath the kick, a big layered and
slightly clappy snare, crisp hats with real air on them, and hard-hitting
transients everywhere. Where the Vintage kit is dry and mid-focused, this one
is deliberately hyped at both ends of the spectrum.

    Bank A (MIDI notes 36-51): General MIDI drum map -- see GM_BANK_A_ROLES.
                               Pads 1-4 on the hardware = kick, rim, snare, clap.
    Bank B (MIDI notes 52-59): tuned 808 sub-bass, one per degree of C minor,
                               monophonic (shared choke) like a real bassline.
              (notes 60-67):   sub drop, snap, impact, transitions and melodic
                               one-shots.

All original synthesis, no sampled material. Run with:

    python3 tools/synth_modern_pop_kit.py

Requires numpy + scipy. Writes 16-bit PCM mono 44.1 kHz WAVs into
assets/kits/modern_pop_kit/samples/ plus that kit's kit.json.
"""
import numpy as np

from synth_common import (
    CHOKE_CYMBAL, CHOKE_FX, CHOKE_HAT, CHOKE_MONO_BASS, SR, bandpass,
    butter_filter, click, compressor, detuned_stack, env_ad, env_multi,
    env_swell, finalize, fm_partials, karplus_strong, layer, metal_stack,
    midi_hz, noise_burst, normalize, osc, pitch_env, place, rbj_bandpass,
    rbj_highpass, rbj_lowpass, render_all, reverb, saturate, saw, sine,
    sweep_filter_noise, tilt_high, transient_shape, white_noise, write_kit_json,
)

KIT_DIR = "modern_pop_kit"

# Fundamentals (Hz) the verifier checks by FFT. The 808s in particular have to
# be dead in tune -- they are played as a bassline, so a few cents of drift
# would fight whatever the user writes on top.
TUNING = {}


def pop_bus(x, thr=-13.0, ratio=4.0, atk=3.0, rel=80.0, drive=1.8, hpf=24.0,
            air_amount=0.0, air_hz=9000.0, punch=1.0):
    """Modern finishing chain: high-pass -> transient boost -> glue comp ->
    saturation -> air shelf.

    The order is the point. Boosting the transient BEFORE the compressor and
    then compressing hard is what produces the modern "loud but still punchy"
    result: the compressor evens out the body while the exaggerated first few
    ms still pokes through. Air goes on last so the shelf lifts the finished
    sound rather than being flattened by the compressor.
    """
    y = butter_filter(np.asarray(x, dtype=np.float64), hpf, btype="high", order=2)
    if punch > 1.0:
        y = transient_shape(y, attack_boost=punch, split_ms=9.0)
    y = normalize(y, 0.85)
    y = compressor(y, threshold_db=thr, ratio=ratio, attack_ms=atk, release_ms=rel)
    if drive and drive > 1.0:
        y = saturate(y, drive)
    if air_amount:
        y = tilt_high(y, air_hz, air_amount)
    return finalize(y)


# ===========================================================================
# BANK A -- General MIDI core drums (notes 36-51)
# ===========================================================================

# 36. Kick -- three distinct jobs in three layers:
#   sub    : 38 Hz fundamental with a long tail, the weight you feel
#   punch  : 95 Hz-ish mid body, the part that survives a phone speaker
#   click  : 3 kHz beater tick, the part that survives a laptop speaker
def make_kick(dur=0.62, seed=201):
    sub = osc(pitch_env(dur, 105.0, 41.0, 0.030)) * env_ad(dur, 0.0025, 0.155, curve=0.85)
    sub = saturate(sub, 1.9)

    punch = osc(pitch_env(dur, 240.0, 92.0, 0.014), "tri")
    punch *= env_ad(dur, 0.0008, 0.038, curve=1.1)
    punch = saturate(punch, 3.6)

    tick = click(0.010, tone=3100.0, q=1.0, decay=0.0018, kind="impulse")
    beater = click(0.008, tone=5200.0, q=0.8, decay=0.0011, seed=seed)

    x = layer(dur, (sub, 1.0), (punch, 0.34), (tick, 0.34), (beater, 0.22))
    return pop_bus(x, thr=-12.0, ratio=4.5, atk=9.0, rel=120.0, drive=1.9, hpf=25.0,
                   punch=1.25)


TUNING["kick.wav"] = (41.0, 30.0, 70.0)


# 37. Rim -- sharp and plasticky, the modern sidestick: a very high resonant
# ping over a tiny wooden body, gone in 60 ms.
def make_rim(dur=0.09, seed=202):
    ping = osc(pitch_env(dur, 2350.0, 1900.0, 0.005), "tri") * env_ad(dur, 0.0003, 0.008)
    body = osc(pitch_env(dur, 620.0, 520.0, 0.006)) * env_ad(dur, 0.0005, 0.012)
    snap = noise_burst(dur, 2500, 9000, decay=0.005, seed=seed)
    x = layer(dur, (ping, 0.9), (body, 0.45), (snap, 0.5),
              (click(0.004, 4200.0, q=0.8, decay=0.0007, kind="impulse"), 0.45))
    return pop_bus(x, thr=-16.0, ratio=3.0, atk=0.6, rel=35.0, drive=1.8, hpf=280.0,
                   air_amount=0.25, punch=1.2)


# 38. Snare -- the big one. FOUR layers:
#   shell  : two detuned tuned modes (200 / 355 Hz) for pitch and weight
#   wires  : tilted band-passed noise with a two-stage decay
#   claps  : three tiny staggered noise slaps, which is what gives modern pop
#            snares their width and "smack" without adding length
#   crack  : a 3 ms high transient on top
# then a very short bright room so it sits in a mix instead of on top of it.
def make_snare(dur=0.42, f_lo=200.0, f_hi=355.0, clap_gain=0.45, room=0.16, seed=203):
    mode_lo = osc(pitch_env(dur, f_lo * 1.2, f_lo, 0.012)) * env_ad(dur, 0.0010, 0.050)
    mode_hi = osc(pitch_env(dur, f_hi * 1.16, f_hi, 0.010)) * env_ad(dur, 0.0008, 0.034)
    shell = saturate(mode_lo * 0.6 + mode_hi * 0.4, 2.6)

    wires = bandpass(white_noise(dur, seed=seed), 320, 7500, order=3)
    wires = wires * 0.38 + butter_filter(wires, 1500, btype="low", order=2) * 1.25
    wires *= env_multi(dur, [(0.022, 0.5), (0.095, 0.5)])
    wires = saturate(wires, 1.6)

    claps = np.zeros(int(SR * dur))
    for i, off in enumerate((0.0, 0.007, 0.015)):
        place(claps, noise_burst(0.05, 800, 4800, decay=0.009, seed=seed + 10 + i, order=3),
              off, 0.9 - 0.15 * i)

    crack = noise_burst(0.010, 2400, 9000, decay=0.0020, seed=seed + 30)

    x = layer(dur, (shell, 1.05), (wires, 0.85), (claps, clap_gain), (crack, 0.30))
    x = reverb(x, decay=0.10, tone=4500.0, predelay_ms=5.0, mix=room, seed=seed + 50,
               lowcut=350.0)
    return pop_bus(x, thr=-14.0, ratio=4.5, atk=2.5, rel=70.0, drive=1.5, hpf=70.0,
                   air_amount=0.22, punch=1.3)


TUNING["snare.wav"] = 200.0


# 39. Clap -- tight, bright and modern: four fast slaps, minimal tail.
def make_clap(dur=0.30, seed=204, taps=(0.0, 0.0075, 0.016, 0.025), tail_gain=0.5,
              bright=1.0):
    x = np.zeros(int(SR * dur))
    for i, off in enumerate(taps):
        slap = noise_burst(0.045, 1000 * bright, 6000 * bright, decay=0.008,
                           seed=seed + i, order=3)
        place(x, slap, off, 0.9 if i < len(taps) - 1 else 1.0)
    tail = bandpass(white_noise(dur, seed=seed + 20), 1200 * bright, 5000 * bright, order=3)
    tail = tail * 0.45 + butter_filter(tail, 2200, btype="low", order=2) * 0.9
    tail *= env_ad(dur, 0.003, 0.055, curve=1.4)
    x = layer(dur, (x, 1.0), (tail, tail_gain),
              (click(0.004, 3400.0, q=1.0, decay=0.0008, seed=seed + 40), 0.3))
    x = reverb(x, decay=0.07, tone=6000.0, predelay_ms=4.0, mix=0.12, seed=seed + 60,
               lowcut=500.0)
    return pop_bus(x, thr=-16.0, ratio=4.0, atk=1.2, rel=70.0, drive=1.6, hpf=260.0,
                   air_amount=0.3, punch=1.25)


# 40. Snare 2 -- the "arena" layer: same voice tuned up, longer bright room.
# Stacking 38 and 40 together is the intended trick for choruses.
def make_snare_arena(dur=0.62, seed=205):
    return make_snare(dur=dur, f_lo=235.0, f_hi=410.0, clap_gain=0.6, room=0.34, seed=seed)


TUNING["snare_arena.wav"] = 235.0


# 41/43/45/47/48/50. Toms -- tuned, punchy, with modern top-end attack.
def make_tom(f0, dur=0.46, seed=210, decay=0.17):
    body = osc(pitch_env(dur, f0 * 1.6, f0, 0.028)) * env_ad(dur, 0.0014, decay, curve=0.95)
    mode2 = osc(pitch_env(dur, f0 * 3.0, f0 * 2.5, 0.018)) * env_ad(dur, 0.0010, decay * 0.28)
    stick = noise_burst(0.025, 1800, 9000, decay=0.005, seed=seed)
    x = layer(dur, (saturate(body, 2.1), 1.0), (mode2, 0.18), (stick, 0.42),
              (click(0.006, 2600.0, q=1.0, decay=0.0011, kind="impulse"), 0.2))
    x = reverb(x, decay=0.09, tone=4000.0, predelay_ms=6.0, mix=0.12, seed=seed + 5,
               lowcut=200.0)
    return pop_bus(x, thr=-14.0, ratio=3.5, atk=8.0, rel=95.0, drive=1.5, hpf=45.0,
                   air_amount=0.15, punch=1.2)


TOM_HZ = {
    "tom_floor.wav": 92.0,     # 41
    "tom_floor_hi.wav": 110.0,  # 43
    "tom_low.wav": 123.0,      # 45
    "tom_lowmid.wav": 147.0,   # 47
    "tom_himid.wav": 165.0,    # 48
    "tom_high.wav": 185.0,     # 50
}
TUNING.update(TOM_HZ)


# ---------------------------------------------------------------------------
# Hats and cymbals -- one metal source, tuned a little higher and filtered a
# lot brighter than the vintage kit's. Closed/pedal/open are the same voice.
# ---------------------------------------------------------------------------

HAT_PHASES = [0.6, 2.1, 3.9, 5.0, 1.2, 4.7]


def _hat_source(dur, tune=1.0):
    return metal_stack(dur, tune=tune, phases=HAT_PHASES)


def make_closed_hat(dur=0.11, seed=220):
    src = _hat_source(dur, tune=1.12)
    y = rbj_highpass(src, 8200.0, q=1.4)
    y = rbj_bandpass(y, 11500.0, q=0.6) * 1.7 + y * 0.5
    y *= env_ad(dur, 0.0003, 0.014, curve=1.2)
    x = layer(dur, (y, 1.0), (click(0.003, 11000.0, q=0.7, decay=0.0006, seed=seed), 0.35))
    return pop_bus(x, thr=-20.0, ratio=4.5, atk=0.4, rel=40.0, drive=1.6, hpf=500.0,
                   air_amount=0.25)


def make_pedal_hat(dur=0.09, seed=221):
    src = _hat_source(dur, tune=1.12)
    y = rbj_highpass(src, 6500.0, q=1.2) * env_ad(dur, 0.0005, 0.010, curve=1.3)
    x = layer(dur, (y, 1.0), (click(0.003, 7500.0, q=0.7, decay=0.0006, seed=seed), 0.25))
    return pop_bus(x, thr=-20.0, ratio=4.5, atk=0.4, rel=35.0, drive=1.5, hpf=500.0,
                   air_amount=0.2)


def make_open_hat(dur=0.60, seed=222):
    src = _hat_source(dur, tune=1.12)
    y = rbj_highpass(src, 7200.0, q=1.3)
    y = rbj_bandpass(y, 10500.0, q=0.55) * 1.4 + y * 0.6
    y *= env_multi(dur, [(0.035, 0.5), (0.17, 0.5)]) * env_ad(dur, 0.0004, 4.0)
    x = layer(dur, (y, 1.0), (click(0.003, 11000.0, q=0.7, decay=0.0006, seed=seed), 0.25))
    return pop_bus(x, thr=-21.0, ratio=4.0, atk=0.5, rel=130.0, drive=1.5, hpf=500.0,
                   air_amount=0.25)


# 49. Crash -- wide, bright, with a real (short) reverb behind it.
def make_crash(dur=1.75, seed=223):
    src = _hat_source(dur, tune=0.66) + _hat_source(dur, tune=0.89) * 0.7
    y = rbj_highpass(src, 3600.0, q=0.9)
    wash = bandpass(white_noise(dur, seed=seed), 3500, 17000, order=2)
    y = y * 0.7 + wash * 0.65
    y *= env_multi(dur, [(0.05, 0.30), (0.28, 0.35), (0.85, 0.35)])
    y *= env_ad(dur, 0.0014, 8.0)
    y = reverb(y, decay=0.30, tone=8000.0, predelay_ms=10.0, mix=0.18, seed=seed + 3,
               lowcut=500.0)
    return pop_bus(y, thr=-19.0, ratio=3.0, atk=5.0, rel=260.0, drive=1.3, hpf=400.0,
                   air_amount=0.3)


# 51. Ride -- tight modern ping with a clear stick attack and a quiet wash.
def make_ride(dur=1.05, seed=224):
    src = _hat_source(dur, tune=0.60)
    metal = rbj_highpass(src, 3000.0, q=0.8) * env_multi(dur, [(0.09, 0.45), (0.40, 0.55)])
    bell = sum(sine(dur, f) * a for f, a in
               ((587.0, 0.5), (1320.0, 0.32), (2350.0, 0.2), (3520.0, 0.12)))
    bell *= env_multi(dur, [(0.030, 0.6), (0.24, 0.4)])
    ping = noise_burst(0.018, 5000, 14000, decay=0.0035, seed=seed)
    y = layer(dur, (metal, 0.85), (bell, 0.7), (ping, 0.32))
    y *= env_ad(dur, 0.0010, 8.0)
    return pop_bus(y, thr=-24.0, ratio=4.0, atk=1.5, rel=220.0, drive=1.3, hpf=350.0,
                   air_amount=0.25)


TUNING["ride.wav"] = 587.0


# ===========================================================================
# BANK B -- tuned 808 sub-bass (52-59) then FX and melodic hits (60-67)
# ===========================================================================

# The 808 is the identity of this kit, so it gets the most careful build:
#   * pitch drops from a fifth-and-an-octave above the target into the
#     fundamental in ~22 ms -- that drop IS the "808 kick" attack, which is
#     why an 808 needs no separate kick layered under it
#   * long exponential amplitude decay (the note has to sustain under a bar)
#   * tanh saturation, which is essential rather than decorative: a 33 Hz sine
#     is inaudible on a phone speaker, but its saturation harmonics at 65/98/
#     131 Hz are not, and the ear reconstructs the missing fundamental from
#     them. This is exactly why real 808s are distorted.
#   * a short click transient so it also reads as a drum hit
C_MINOR_808 = [
    ("808_c1.wav", 24),   # C1  32.70 Hz
    ("808_d1.wav", 26),   # D1  36.71
    ("808_eb1.wav", 27),  # Eb1 38.89
    ("808_f1.wav", 29),   # F1  43.65
    ("808_g1.wav", 31),   # G1  49.00
    ("808_ab1.wav", 32),  # Ab1 51.91
    ("808_bb1.wav", 34),  # Bb1 58.27
    ("808_c2.wav", 36),   # C2  65.41
]


def make_808(note, dur=1.15, drive=2.4, seed=230):
    f0 = midi_hz(note)
    body = osc(pitch_env(dur, f0 * 3.0, f0, 0.022))
    body *= env_ad(dur, 0.0035, dur * 0.30, curve=0.85)
    body = saturate(body, drive)

    # A quiet octave-up layer keeps the note audible on small speakers without
    # muddying the fundamental the way more distortion would.
    upper = osc(pitch_env(dur, f0 * 4.0, f0 * 2.0, 0.030)) * env_ad(dur, 0.003, dur * 0.16)

    tick = click(0.008, tone=1600.0, q=1.0, decay=0.0016, kind="impulse")
    x = layer(dur, (body, 1.0), (upper, 0.10), (tick, 0.18))
    return pop_bus(x, thr=-13.0, ratio=3.5, atk=12.0, rel=200.0, drive=1.25, hpf=18.0)


for _name, _note in C_MINOR_808:
    # Search window is +/- a fourth so the check can never latch onto the
    # octave-up layer and call a flat note "in tune".
    TUNING[_name] = (midi_hz(_note), midi_hz(_note) * 0.78, midi_hz(_note) * 1.32)


def make_sub_drop(dur=1.30, seed=231):
    """Untuned 808 boom: a long, slow fall used as a transition, not a note."""
    f = pitch_env(dur, 150.0, 28.0, 0.22)
    body = saturate(osc(f) * env_ad(dur, 0.004, 0.42, curve=0.9), 2.0)
    x = layer(dur, (body, 1.0), (click(0.008, 1200.0, q=1.0, decay=0.0015,
                                       kind="impulse"), 0.14))
    return pop_bus(x, thr=-14.0, ratio=3.0, atk=15.0, rel=250.0, drive=1.3, hpf=18.0)


def make_snap(dur=0.075, seed=232):
    """Finger snap: a dry crack over a small woody resonance.

    Kept deliberately short -- a real snap is 60-80 ms. An earlier 160 ms
    version measured a 25 dB crest factor, which is the number's way of saying
    "30 ms of click followed by 130 ms of nothing": it read as a tick rather
    than a snap, and wasted disk doing it.
    """
    crack = noise_burst(0.03, 1800, 9000, decay=0.005, seed=seed, order=3)
    wood = rbj_bandpass(white_noise(dur, seed=seed + 1), 1150.0, q=7.0)
    wood *= env_ad(dur, 0.0008, 0.026)
    x = layer(dur, (crack, 1.0), (wood, 1.1),
              (click(0.004, 3800.0, q=0.9, decay=0.0008, seed=seed + 2), 0.28))
    return pop_bus(x, thr=-24.0, ratio=5.0, atk=0.6, rel=55.0, drive=1.7, hpf=350.0,
                   air_amount=0.3)


def make_impact(dur=1.25, seed=233):
    """Cinematic hit: sub boom + noise blast + a metallic ring, into reverb."""
    boom = saturate(osc(pitch_env(dur, 110.0, 34.0, 0.10)) *
                    env_ad(dur, 0.004, 0.30, curve=0.9), 2.2)
    blast = bandpass(white_noise(dur, seed=seed), 400, 12000, order=2)
    blast *= env_ad(dur, 0.001, 0.09, curve=1.2)
    ring = fm_partials(dur, 210.0, [1.0, 2.41, 4.07, 6.83], [0.5, 0.3, 0.2, 0.12],
                       [0.5, 0.32, 0.2, 0.12])
    x = layer(dur, (boom, 1.0), (blast, 0.5), (ring, 0.28))
    x = reverb(x, decay=0.35, tone=5500.0, predelay_ms=12.0, mix=0.25, seed=seed + 4,
               lowcut=150.0)
    return pop_bus(x, thr=-15.0, ratio=3.0, atk=8.0, rel=200.0, drive=1.5, hpf=22.0,
                   air_amount=0.15)


def make_riser(dur=1.60, seed=234):
    """Bandpass noise sweeping up plus a rising tone, cut hard at the top."""
    noise = sweep_filter_noise(dur, 500, 12000, seed=seed, q=3.0)
    tone = osc(pitch_env(dur, 220.0, 1800.0, dur * 0.9)) * 0.35
    y = layer(dur, (noise, 1.0), (tone, 0.4))
    y *= env_swell(dur, peak_at=0.94, curve=2.2)
    return pop_bus(y, thr=-18.0, ratio=2.5, atk=15.0, rel=200.0, drive=1.3, hpf=180.0,
                   air_amount=0.25)


def make_downlifter(dur=1.40, seed=235):
    """The riser reversed: falls away into a drop."""
    noise = sweep_filter_noise(dur, 11000, 400, seed=seed, q=3.0)
    tone = osc(pitch_env(dur, 1500.0, 90.0, dur * 0.35)) * 0.35
    y = layer(dur, (noise, 1.0), (tone, 0.4))
    y *= env_ad(dur, 0.006, dur * 0.42, curve=0.9)
    return pop_bus(y, thr=-18.0, ratio=2.5, atk=10.0, rel=180.0, drive=1.3, hpf=120.0,
                   air_amount=0.2)


def make_stab(notes=(60, 63, 67, 70), dur=0.60, seed=236, bright=6500.0):
    """Detuned saw chord through a fast filter envelope -- the pop chord stab."""
    n = int(SR * dur)
    x = np.zeros(n)
    for i, note in enumerate(notes):
        x += detuned_stack(dur, midi_hz(note), voices=3, spread_cents=9.0, wave=saw,
                           seed=seed + i)
    x /= len(notes)
    # Filter envelope rendered as a short crossfade between fixed cutoffs.
    env = env_ad(dur, 0.004, 0.16, curve=1.1)
    out = np.zeros(n)
    edges = np.linspace(0, n, 33).astype(int)
    for i in range(len(edges) - 1):
        a, b = edges[i], edges[i + 1]
        if b <= a:
            continue
        cutoff = 400.0 + bright * float(np.mean(env[a:b])) ** 1.4
        out[a:b] = rbj_lowpass(x, cutoff, q=1.4)[a:b]
    out *= env
    out = reverb(out, decay=0.12, tone=6000.0, predelay_ms=8.0, mix=0.15, seed=seed + 9,
                 lowcut=250.0)
    return pop_bus(out, thr=-15.0, ratio=3.0, atk=4.0, rel=100.0, drive=1.5, hpf=90.0,
                   air_amount=0.2)


# For a chord we verify the ROOT specifically -- the loudest partial of a
# minor-7th voicing is usually the 7th, so the search window is deliberately
# narrow (roughly +/- a semitone around C4).
TUNING["stab_minor.wav"] = (midi_hz(60), midi_hz(59), midi_hz(61))


def make_bell(note=84, dur=1.50, seed=237):
    """Struck-metal bell: inharmonic partials, each with its own decay."""
    f0 = midi_hz(note)
    y = fm_partials(dur, f0, [1.0, 2.0, 2.76, 5.40, 8.93],
                    [1.0, 0.5, 0.36, 0.2, 0.1],
                    [0.75, 0.5, 0.36, 0.22, 0.13])
    strike = noise_burst(0.010, 3000, 12000, decay=0.002, seed=seed)
    x = layer(dur, (y, 1.0), (strike, 0.22))
    x = reverb(x, decay=0.25, tone=8000.0, predelay_ms=10.0, mix=0.18, seed=seed + 2,
               lowcut=300.0)
    return pop_bus(x, thr=-17.0, ratio=2.5, atk=3.0, rel=150.0, drive=1.2, hpf=150.0,
                   air_amount=0.2)


TUNING["bell.wav"] = midi_hz(84)


def make_pluck(note=72, dur=0.62, seed=238):
    """Karplus-Strong pluck -- the melodic counter-line voice."""
    f0 = midi_hz(note)
    y = karplus_strong(dur, f0, damping=0.42, decay=0.9965, seed=seed, excite_lp=6000.0)
    y *= env_ad(dur, 0.001, dur * 0.42, curve=1.0)
    body = sine(dur, f0) * env_ad(dur, 0.002, 0.10) * 0.25
    x = layer(dur, (y, 1.0), (body, 0.5))
    x = reverb(x, decay=0.14, tone=6500.0, predelay_ms=7.0, mix=0.14, seed=seed + 1,
               lowcut=200.0)
    return pop_bus(x, thr=-16.0, ratio=3.0, atk=3.0, rel=90.0, drive=1.4, hpf=120.0,
                   air_amount=0.2)


TUNING["pluck.wav"] = midi_hz(72)


# ===========================================================================
# Kit layout -- bank A is the General MIDI drum map, in note order 36..51
# ===========================================================================

BANK_A = [
    ("kick.wav", make_kick),                                   # 36
    ("rim.wav", make_rim),                                     # 37
    ("snare.wav", make_snare),                                 # 38
    ("clap.wav", make_clap),                                   # 39
    ("snare_arena.wav", make_snare_arena),                     # 40
    ("tom_floor.wav", lambda: make_tom(92.0, seed=210)),       # 41
    ("hat_closed.wav", make_closed_hat),                       # 42
    ("tom_floor_hi.wav", lambda: make_tom(110.0, seed=211)),   # 43
    ("hat_pedal.wav", make_pedal_hat),                         # 44
    ("tom_low.wav", lambda: make_tom(123.0, seed=212)),        # 45
    ("hat_open.wav", make_open_hat),                           # 46
    ("tom_lowmid.wav", lambda: make_tom(147.0, seed=213)),     # 47
    ("tom_himid.wav", lambda: make_tom(165.0, dur=0.40, seed=214)),  # 48
    ("crash.wav", make_crash),                                 # 49
    ("tom_high.wav", lambda: make_tom(185.0, dur=0.38, seed=215)),   # 50
    ("ride.wav", make_ride),                                   # 51
]

BANK_B = [(name, (lambda n=note: make_808(n))) for name, note in C_MINOR_808] + [
    ("sub_drop.wav", make_sub_drop),
    ("snap.wav", make_snap),
    ("impact.wav", make_impact),
    ("riser.wav", make_riser),
    ("downlifter.wav", make_downlifter),
    ("stab_minor.wav", make_stab),
    ("bell.wav", make_bell),
    ("pluck.wav", make_pluck),
]

# (filename, volume, chokeGroup) in note order.
#
# Every WAV is normalized to -1 dBFS, so `volume` carries the mix balance:
# kick and snare forward, hats and cymbals well back.
PADS_A = [
    ("kick.wav", 1.0, None),
    ("rim.wav", 0.7, None),
    ("snare.wav", 0.9, None),
    ("clap.wav", 0.85, None),
    ("snare_arena.wav", 0.8, None),
    ("tom_floor.wav", 0.85, None),
    ("hat_closed.wav", 0.5, CHOKE_HAT),
    ("tom_floor_hi.wav", 0.85, None),
    ("hat_pedal.wav", 0.45, CHOKE_HAT),
    ("tom_low.wav", 0.85, None),
    ("hat_open.wav", 0.5, CHOKE_HAT),
    ("tom_lowmid.wav", 0.85, None),
    ("tom_himid.wav", 0.85, None),
    ("crash.wav", 0.55, CHOKE_CYMBAL),
    ("tom_high.wav", 0.85, None),
    ("ride.wav", 0.55, None),
]

# The 808s all share one choke group: a bassline is monophonic, so a new note
# has to cut the previous one dead or the sub notes ring into each other and
# turn to mud.
PADS_B = [(name, 0.95, CHOKE_MONO_BASS) for name, _ in C_MINOR_808] + [
    ("sub_drop.wav", 0.9, CHOKE_MONO_BASS),
    ("snap.wav", 0.75, None),
    ("impact.wav", 0.8, None),
    ("riser.wav", 0.7, CHOKE_FX),
    ("downlifter.wav", 0.7, CHOKE_FX),
    ("stab_minor.wav", 0.75, None),
    ("bell.wav", 0.7, None),
    ("pluck.wav", 0.75, None),
]

KNOB_LABELS = ["Master Vol", "Pitch/Speed", "Sub", "Air", "Punch", "Swing"]


def main():
    print("Modern Pop -- 32 sounds (GM drum map on bank A, tuned 808s on bank B)")
    render_all(KIT_DIR, BANK_A + BANK_B)
    write_kit_json(KIT_DIR, "Modern Pop", PADS_A, PADS_B, KNOB_LABELS)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
Shared synthesis toolkit for every PadForge sample kit.

Everything in every PadForge kit is generated purely from math -- oscillators,
filtered noise, envelopes and DSP -- so there is nothing sampled from real
records, drum machines or instruments and therefore zero licensing risk.

This module holds the building blocks the individual kit scripts share:

    tools/synth_vintage_kit.py     -> assets/kits/vintage_kit
    tools/synth_modern_pop_kit.py  -> assets/kits/modern_pop_kit
    tools/synth_lofi_kit.py        -> assets/kits/lofi_kit

and is exercised end-to-end by tools/verify_kits.py, which measures every
rendered WAV and renders a one-bar demo groove per kit to catch kits whose
elements are fine alone but mush together.

Design notes (what actually makes these sound like drums rather than beeps):

  * Layered construction. Every drum is built from separate body / transient /
    noise layers, each with its OWN amplitude envelope and its OWN saturation
    stage, then glued with a bus compressor. Saturating the sum only is what
    makes naive synth drums sound flat.
  * Real pitch envelopes (`pitch_env`) -- an exponential decay TOWARD a target
    frequency with a time constant, not a linear glide across the whole buffer.
    A kick that lands on its fundamental in 25 ms reads as a kick; one that is
    still sliding 300 ms later reads as a laser.
  * Non-instant attacks. `env_ad` gives every layer a 0.3-3 ms shaped attack.
    An instant edge is a full-scale step: it clicks, and the click is not the
    good kind.
  * Resonant RBJ biquads (`rbj_*`) rather than plain Butterworth where the
    resonance is the character (hats, toms, zaps).

Conventions used everywhere:
  * 44100 Hz, mono, 16-bit PCM WAV output.
  * Every rendered sound goes through finalize(), which DC-blocks, peak
    normalizes with headroom (never above ~-1 dBFS) and applies a short
    fade-in/fade-out so pads can never click.
  * Random sources are seeded, so re-running any script reproduces the exact
    same bytes.

Requires numpy + scipy:  pip install numpy scipy --break-system-packages
"""
import json
import os

import numpy as np
from scipy.signal import butter, fftconvolve, sosfilt

SR = 44100

# Peak ceiling for every rendered sound: -1 dBFS, leaving headroom so layered
# pads and the app's own master-volume knob have room to work.
PEAK_CEILING = 0.891

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
KITS_ROOT = os.path.join(REPO_ROOT, "assets", "kits")


# ---------------------------------------------------------------------------
# Time bases and envelopes
# ---------------------------------------------------------------------------

def t_axis(dur):
    """Time vector in seconds for a buffer of `dur` seconds."""
    return np.linspace(0, dur, int(SR * dur), endpoint=False)


def n_samples(dur):
    return int(SR * dur)


def env_exp(dur, decay):
    """Exponential decay envelope; `decay` is the time constant in seconds."""
    return np.exp(-t_axis(dur) / decay)


def env_ad(dur, attack=0.001, decay=0.1, curve=1.0, floor_db=-70.0):
    """The workhorse envelope: shaped attack, exponential decay, clean end.

    * `attack` is a raised-cosine ramp (smooth in both value and slope), so
      there is no step discontinuity at t=0 to click.
    * The decay is a true exponential with time constant `decay`; `curve` > 1
      holds the top longer (fatter, more "tuned drum"), < 1 drops away faster
      (snappier, more "electronic").
    * The tail is offset-and-rescaled so the envelope reaches exactly 0 at the
      end of the buffer instead of being chopped off at whatever level the
      exponential happened to be at. That truncation step is a classic source
      of end-of-sample ticks.
    """
    t = t_axis(dur)
    n = len(t)
    if n == 0:
        return t
    a = max(attack, 1e-5)
    atk = np.clip(t / a, 0.0, 1.0)
    atk = 0.5 - 0.5 * np.cos(np.pi * atk)
    dec = np.exp(-np.maximum(t - a, 0.0) / max(decay, 1e-5)) ** max(curve, 1e-3)
    # Subtract the residual so the envelope truly lands on zero.
    floor = 10.0 ** (floor_db / 20.0)
    tail = dec[-1]
    if tail > floor:
        dec = np.clip((dec - tail) / max(1.0 - tail, 1e-9), 0.0, 1.0)
    return atk * dec


def env_ar(dur, attack, decay, curve=1.0):
    """Backwards-compatible alias for env_ad (linear-ish attack, exp decay)."""
    return env_ad(dur, attack=attack, decay=decay, curve=curve)


def env_multi(dur, stages):
    """Multi-stage decay: `stages` is [(time_constant, weight), ...].

    Real drums do not decay with a single time constant -- a snare's initial
    crack falls away in ~30 ms while the wires ring for 150 ms. Summing two or
    three weighted exponentials models that far better than one.
    """
    t = t_axis(dur)
    out = np.zeros(len(t))
    total = sum(w for _, w in stages) or 1.0
    for tau, weight in stages:
        out += (weight / total) * np.exp(-t / max(tau, 1e-5))
    return out


def env_swell(dur, peak_at=0.85, curve=2.5):
    """Reverse/swell envelope: rises to a peak near the end, then stops.

    Used for reverse cymbals and risers. `peak_at` is where (0-1 through the
    buffer) the loudest point sits.
    """
    t = np.linspace(0, 1, n_samples(dur), endpoint=False)
    rise = np.clip(t / peak_at, 0.0, 1.0) ** curve
    tail = np.clip((1.0 - t) / max(1.0 - peak_at, 1e-6), 0.0, 1.0)
    return rise * np.where(t > peak_at, tail, 1.0)


def pitch_env(dur, f_start, f_end, tau, curve=1.0):
    """Frequency-vs-time curve that decays exponentially TOWARD f_end.

        f(t) = f_end + (f_start - f_end) * exp(-t / tau)

    This is the envelope an analog drum synth's pitch CV actually follows, and
    it is the single biggest difference between "kick drum" and "sine sweep".
    `tau` is how long the pitch takes to fall (25 ms = punchy modern kick,
    60-90 ms = long 808 boom).
    """
    t = t_axis(dur)
    shape = np.exp(-(t / max(tau, 1e-5)) ** max(curve, 1e-3))
    return f_end + (f_start - f_end) * shape


def osc(freq, wave="sine", phase0=0.0):
    """Oscillator driven by a per-sample frequency array (Hz).

    Accepts either a scalar or a full frequency curve from pitch_env(), which
    is what lets one function cover static tones and pitch-swept drums.
    """
    freq = np.asarray(freq, dtype=np.float64)
    ph = 2 * np.pi * np.cumsum(freq) / SR + phase0
    if wave == "sine":
        return np.sin(ph)
    if wave == "tri":
        return 2 / np.pi * np.arcsin(np.sin(ph))
    if wave == "square":
        return np.sign(np.sin(ph))
    if wave == "saw":
        return 2.0 * ((ph / (2 * np.pi)) % 1.0) - 1.0
    raise ValueError(f"unknown wave {wave!r}")


# ---------------------------------------------------------------------------
# Oscillators and noise
# ---------------------------------------------------------------------------

def white_noise(dur, seed=0):
    rng = np.random.default_rng(seed)
    return rng.uniform(-1, 1, n_samples(dur))


def midi_hz(note):
    """MIDI note number -> frequency in Hz (A4 = note 69 = 440 Hz)."""
    return 440.0 * (2.0 ** ((note - 69) / 12.0))


def _sweep_phase(dur, f_start, f_end, shape="exp"):
    """Phase vector for a frequency sweep, in radians."""
    t = t_axis(dur)
    if shape == "exp" and f_end > 0 and f_start > 0 and dur > 0:
        k = (f_end / f_start) ** (1.0 / dur)
        if k != 1:
            return 2 * np.pi * f_start * (k ** t - 1) / np.log(k)
        return 2 * np.pi * f_start * t
    freq = np.linspace(f_start, f_end, len(t))
    return 2 * np.pi * np.cumsum(freq) / SR


def sine_sweep(dur, f_start, f_end, shape="exp"):
    """Sine whose pitch glides from f_start to f_end across the whole buffer.

    Prefer osc(pitch_env(...)) for drums -- this linear/geometric glide is only
    right for risers and zaps, where the sweep IS the sound.
    """
    return np.sin(_sweep_phase(dur, f_start, f_end, shape))


def tri_sweep(dur, f_start, f_end, shape="exp"):
    return 2 / np.pi * np.arcsin(np.sin(_sweep_phase(dur, f_start, f_end, shape)))


def square_sweep(dur, f_start, f_end, shape="exp"):
    return np.sign(np.sin(_sweep_phase(dur, f_start, f_end, shape)))


def sine(dur, freq, phase=0.0):
    return np.sin(2 * np.pi * freq * t_axis(dur) + phase)


def triangle(dur, freq, phase=0.0):
    return 2 / np.pi * np.arcsin(np.sin(2 * np.pi * freq * t_axis(dur) + phase))


def saw(dur, freq, phase=0.0):
    """Naive sawtooth. Always low-passed downstream, so aliasing stays tame."""
    p = (freq * t_axis(dur) + phase / (2 * np.pi)) % 1.0
    return 2.0 * p - 1.0


def detuned_stack(dur, freq, voices=3, spread_cents=7.0, wave=saw, seed=0):
    """Several slightly-detuned copies of an oscillator summed together.

    This is what gives synth stabs and pad chords their chorused width without
    needing an actual chorus effect.
    """
    rng = np.random.default_rng(seed)
    out = np.zeros(n_samples(dur))
    for i in range(voices):
        cents = spread_cents * (i - (voices - 1) / 2.0) / max(voices - 1, 1)
        f = freq * (2.0 ** (cents / 1200.0))
        out += wave(dur, f, phase=rng.uniform(0, 2 * np.pi))
    return out / voices


# The Roland TR-808's cymbal/hi-hat voice is six square-wave oscillators at
# these (deliberately inharmonic) frequencies, summed and then band-passed
# hard. Nothing about it is white noise, which is exactly why 808 hats have
# that specific metallic pitch to them.
METAL_808_HZ = (205.3, 304.4, 369.6, 522.7, 540.0, 800.0)


def metal_stack(dur, freqs=METAL_808_HZ, tune=1.0, wave="square", phases=None):
    """The 808 "metal" source: a stack of inharmonic square oscillators.

    Closed hat, pedal hat, open hat, ride and crash in a kit should all be
    rendered from ONE call to this (same `tune`, same `phases`) and then
    differentiated by filter and envelope only. That is what makes them sound
    like one instrument being played different ways instead of five unrelated
    noise bursts.
    """
    n = n_samples(dur)
    out = np.zeros(n)
    phases = phases if phases is not None else [0.0] * len(freqs)
    for f, ph in zip(freqs, phases):
        out += osc(np.full(n, f * tune), wave=wave, phase0=ph)
    return out / len(freqs)


def fm_2op(dur, freq, ratio=2.0, index=3.0, index_decay=0.06, amp_decay=0.8,
           attack=0.002, feedback=0.0):
    """Two-operator FM: one sine modulating another.

    This is how every DX7-era electric piano was made, and it is the only
    cheap way to get a tone whose BRIGHTNESS decays faster than its volume --
    which is what a struck tine, a bell or a plucked string actually does, and
    what a filtered sawtooth never quite convinces you of.

    `index` is the modulation depth at the strike; `index_decay` is how fast
    that brightness falls away (short = tine attack, long = bell).
    """
    t = t_axis(dur)
    mod = np.sin(2 * np.pi * freq * ratio * t)
    if feedback:
        mod = np.sin(2 * np.pi * freq * ratio * t + feedback * mod)
    idx = index * np.exp(-t / max(index_decay, 1e-5))
    car = np.sin(2 * np.pi * freq * t + idx * mod)
    return car * env_ad(dur, attack=attack, decay=amp_decay)


def karplus_strong(dur, freq, damping=0.48, decay=0.996, seed=0, excite_lp=None):
    """Plucked-string synthesis (Karplus-Strong).

    A short noise burst is fed into a delay line one period long; each pass
    through the line is averaged with its neighbour, which low-passes the
    signal a little more every cycle. That's exactly how a real string loses
    its highs faster than its fundamental, so it sounds like a pluck rather
    than a filtered noise blip.
    """
    n = n_samples(dur)
    period = max(int(SR / max(freq, 20.0)), 2)
    rng = np.random.default_rng(seed)
    buf = rng.uniform(-1, 1, period)
    if excite_lp is not None:
        buf = butter_filter(buf, excite_lp, btype="low", order=2)
    out = np.empty(n)
    idx = 0
    prev = 0.0
    for i in range(n):
        cur = buf[idx]
        out[i] = cur
        buf[idx] = decay * ((1.0 - damping) * cur + damping * prev)
        prev = cur
        idx = (idx + 1) % period
    return out


def fm_partials(dur, freq, ratios, amps, decays):
    """Additive stack of inharmonic partials, each with its own decay.

    Ratios like [1, 2.76, 5.40, 8.93] give the classic struck-metal / tubular
    bell timbre that pure harmonic stacks can't produce.
    """
    out = np.zeros(n_samples(dur))
    for ratio, amp, dec in zip(ratios, amps, decays):
        out += amp * sine(dur, freq * ratio) * env_exp(dur, dec)
    return out


# ---------------------------------------------------------------------------
# Filters
# ---------------------------------------------------------------------------

def butter_filter(x, cutoff, sr=SR, btype="low", order=4):
    nyq = sr / 2.0
    cutoff = np.clip(cutoff / nyq, 0.001, 0.999)
    sos = butter(order, cutoff, btype=btype, output="sos")
    return sosfilt(sos, x)


def bandpass(x, low, high, sr=SR, order=4):
    nyq = sr / 2.0
    lo = np.clip(low / nyq, 0.001, 0.998)
    hi = np.clip(high / nyq, lo + 0.001, 0.999)
    sos = butter(order, [lo, hi], btype="band", output="sos")
    return sosfilt(sos, x)


def _rbj(kind, fc, q, sr=SR):
    """RBJ cookbook biquad coefficients as a 1-section SOS array.

    Butterworth sections have no resonance control; these do. Resonance is a
    huge part of hat/tom/zap character, so it needs to be a first-class knob.
    """
    fc = float(np.clip(fc, 10.0, sr * 0.49))
    q = max(float(q), 0.1)
    w0 = 2 * np.pi * fc / sr
    cw, sw = np.cos(w0), np.sin(w0)
    alpha = sw / (2 * q)
    if kind == "low":
        b = [(1 - cw) / 2, 1 - cw, (1 - cw) / 2]
    elif kind == "high":
        b = [(1 + cw) / 2, -(1 + cw), (1 + cw) / 2]
    elif kind == "band":  # constant peak gain
        b = [alpha, 0.0, -alpha]
    else:
        raise ValueError(kind)
    a = [1 + alpha, -2 * cw, 1 - alpha]
    return np.array([[b[0] / a[0], b[1] / a[0], b[2] / a[0], 1.0, a[1] / a[0], a[2] / a[0]]])


def rbj_lowpass(x, fc, q=0.707, sr=SR):
    return sosfilt(_rbj("low", fc, q, sr), x)


def rbj_highpass(x, fc, q=0.707, sr=SR):
    return sosfilt(_rbj("high", fc, q, sr), x)


def rbj_bandpass(x, fc, q=1.0, sr=SR):
    return sosfilt(_rbj("band", fc, q, sr), x)


def resonant_band(x, center, q=6.0, sr=SR):
    """Narrow resonant bandpass -- one formant / one metallic resonance."""
    return rbj_bandpass(x, center, q=q, sr=sr)


def tilt_high(x, freq=8000.0, amount=0.35, order=2):
    """High-shelf-ish "air": a high-passed copy mixed back in."""
    if amount == 0:
        return x
    return x + butter_filter(x, freq, btype="high", order=order) * amount


def formant(x, freqs, gains=None, qs=None):
    """Parallel bank of resonant bands: crude but effective vocal-tract model."""
    gains = gains if gains is not None else [1.0] * len(freqs)
    qs = qs if qs is not None else [8.0] * len(freqs)
    out = np.zeros_like(x)
    for f, g, q in zip(freqs, gains, qs):
        out += g * resonant_band(x, f, q=q)
    return out


def sweep_filter_noise(dur, f_start, f_end, seed=0, q=4.0, steps=64):
    """Noise through a bandpass whose centre frequency glides over time."""
    noise = white_noise(dur, seed=seed)
    n = len(noise)
    out = np.zeros(n)
    edges = np.linspace(0, n, steps + 1).astype(int)
    centers = np.geomspace(max(f_start, 20.0), max(f_end, 21.0), steps)
    for i in range(steps):
        a, b = edges[i], edges[i + 1]
        if b <= a:
            continue
        seg = resonant_band(noise, centers[i], q=q)
        win = np.hanning(max(b - a, 3))
        out[a:b] += seg[a:b] * win[: b - a]
    return out


# ---------------------------------------------------------------------------
# Transient design
# ---------------------------------------------------------------------------

def click(dur=0.006, tone=3000.0, q=1.2, decay=0.0018, seed=0, kind="noise"):
    """A drum's first 5-15 ms: the layer that makes it read as *punchy*.

    `kind="noise"` gives a filtered noise spit (beater, stick, brush).
    `kind="impulse"` gives a resonant ping struck from a single sample, which
    is tighter and more "electronic" (808 kick click, rim, zap).
    """
    n = n_samples(dur)
    if kind == "impulse":
        src = np.zeros(n)
        src[0] = 1.0
        y = rbj_bandpass(src, tone, q=q)
    else:
        y = rbj_bandpass(white_noise(dur, seed=seed), tone, q=q)
    y *= env_ad(dur, attack=0.00015, decay=decay)
    m = np.max(np.abs(y))
    return y / m if m > 1e-9 else y


def noise_burst(dur, low, high, decay, attack=0.0004, seed=0, curve=1.0, order=4):
    """Band-passed noise with its own AD envelope -- snare wires, hat wash."""
    y = bandpass(white_noise(dur, seed=seed), low, high, order=order)
    return y * env_ad(dur, attack=attack, decay=decay, curve=curve)


# ---------------------------------------------------------------------------
# Saturation / dynamics / space
# ---------------------------------------------------------------------------

def saturate(x, drive=2.0, kind="tanh", mix=1.0):
    """Per-layer harmonic generator. Level-compensated so drive != volume.

    Applied on individual layers (not just the master) because that is how you
    get a kick whose *body* is warm while its *click* stays clean, rather than
    one uniformly crunchy blob.
    """
    peak = np.max(np.abs(x))
    if peak < 1e-9:
        return x
    unit = x / peak
    if kind == "tanh":
        y = np.tanh(unit * drive) / np.tanh(drive)
    elif kind == "atan":
        y = np.arctan(unit * drive) / np.arctan(drive)
    elif kind == "fold":
        y = np.sin(unit * drive * np.pi / 2) / np.sin(min(drive, 1.0) * np.pi / 2)
    else:
        raise ValueError(kind)
    return peak * (unit * (1 - mix) + y * mix)


def soft_clip(x, drive=1.0):
    """Gentle tanh soft-clipper (legacy name, kept for the lo-fi chain)."""
    return np.tanh(x * drive) / np.tanh(drive)


def compressor(x, threshold_db=-18.0, ratio=4.0, attack_ms=3.0, release_ms=90.0,
               makeup_db=None, knee_db=6.0):
    """Envelope-follower bus compressor -- the "glue" stage.

    Layered drums built from independent envelopes have a lumpy composite
    envelope; a slowish attack (3-10 ms) lets the transient through and then
    clamps the body, which both glues the layers into one event and raises
    perceived loudness. This is a feed-forward peak design with a soft knee.

    `makeup_db=None` auto-compensates using the gain reduction applied at the
    signal's own peak, which keeps the drive/level relationship predictable.
    """
    eps = 1e-9
    n = len(x)
    if n == 0:
        return x
    env = np.abs(x)
    # Peak follower: instant-ish attack on the detector, smoothed release.
    a_rel = np.exp(-1.0 / (SR * max(release_ms, 0.1) / 1000.0))
    det = np.empty(n)
    run = 0.0
    for i in range(n):
        v = env[i]
        run = v if v > run else a_rel * run + (1 - a_rel) * v
        det[i] = run
    det_db = 20 * np.log10(det + eps)

    # Soft-knee static gain computer.
    over = det_db - threshold_db
    gr_db = np.zeros(n)
    knee = max(knee_db, 1e-6)
    below = over <= -knee / 2
    inside = (over > -knee / 2) & (over < knee / 2)
    above = over >= knee / 2
    gr_db[above] = (1.0 / ratio - 1.0) * over[above]
    gr_db[inside] = (1.0 / ratio - 1.0) * ((over[inside] + knee / 2) ** 2) / (2 * knee)
    gr_db[below] = 0.0

    # Smooth the gain signal itself with the attack constant (this is what the
    # "attack" control really does -- it is not a delay, it is a slew rate).
    a_atk = np.exp(-1.0 / (SR * max(attack_ms, 0.01) / 1000.0))
    smooth = np.empty(n)
    run = 0.0
    for i in range(n):
        g = gr_db[i]
        run = a_atk * run + (1 - a_atk) * g if g < run else a_rel * run + (1 - a_rel) * g
        smooth[i] = run

    gain = 10.0 ** (smooth / 20.0)
    y = x * gain
    if makeup_db is None:
        peak_over = np.max(det_db) - threshold_db
        makeup_db = max(0.0, (1.0 - 1.0 / ratio) * max(peak_over, 0.0)) * 0.7
    return y * (10.0 ** (makeup_db / 20.0))


def transient_shape(x, attack_boost=1.0, split_ms=8.0):
    """Crude transient designer: boosts the first `split_ms` relative to body."""
    n = len(x)
    k = min(int(SR * split_ms / 1000.0), n)
    y = x.copy()
    ramp = np.ones(n)
    ramp[:k] = attack_boost - (attack_boost - 1.0) * np.linspace(0, 1, k) ** 2
    return y * ramp


def reverb(x, dur=None, decay=0.35, tone=5000.0, predelay_ms=8.0, mix=0.25, seed=0,
           lowcut=200.0):
    """Convolution reverb with a synthesized exponentially-decaying noise IR.

    Cheaper to store than real ambience (the IR is generated, never shipped)
    and much smoother than a handful of delay taps, which comb-filter audibly
    on snares and cymbals. Used sparingly -- a dry kit is easier to mix.
    """
    if mix <= 0:
        return x
    ir_dur = dur if dur is not None else decay * 3.0
    n_ir = n_samples(ir_dur)
    rng = np.random.default_rng(seed)
    ir = rng.normal(0, 1, n_ir) * np.exp(-np.arange(n_ir) / (SR * max(decay, 1e-3)))
    ir = butter_filter(ir, tone, btype="low", order=2)
    ir = butter_filter(ir, lowcut, btype="high", order=2)
    pre = n_samples(predelay_ms / 1000.0)
    if pre:
        ir = np.concatenate([np.zeros(pre), ir])
    m = np.max(np.abs(ir))
    if m > 1e-9:
        ir = ir / m
    wet = fftconvolve(x, ir)[: len(x)]
    wm = np.max(np.abs(wet))
    if wm > 1e-9:
        wet = wet / wm * max(np.max(np.abs(x)), 1e-9)
    return x * (1 - mix) + wet * mix


# ---------------------------------------------------------------------------
# Lo-fi degradation
# ---------------------------------------------------------------------------

def bitcrush(x, bits=10):
    """Quantize to `bits` of resolution (digital grit)."""
    levels = 2 ** bits
    return np.round(x * levels) / levels


def decimate_hold(x, factor):
    """Sample-and-hold decimation: drops the effective sample rate to SR/factor.

    Deliberately does NOT anti-alias -- the fold-back is exactly the crunchy
    "old sampler" artefact the lo-fi kit is after.
    """
    factor = max(int(factor), 1)
    if factor == 1:
        return x.copy()
    idx = (np.arange(len(x)) // factor) * factor
    return x[idx]


def tape_wobble(x, rate=1.1, depth=0.004, seed=0, jitter=0.35):
    """Slow LFO on playback position: warped-tape wow & flutter."""
    n = len(x)
    if n < 8:
        return x.copy()
    t = np.arange(n) / SR
    rng = np.random.default_rng(seed)
    lfo = np.sin(2 * np.pi * rate * t + rng.uniform(0, 2 * np.pi))
    lfo += jitter * np.sin(2 * np.pi * rate * 3.7 * t + rng.uniform(0, 2 * np.pi))
    pos = np.cumsum(1.0 + depth * lfo)
    pos = pos - pos[0]
    pos = np.clip(pos, 0, n - 1)
    return np.interp(pos, np.arange(n), x)


def noise_floor(x, level=0.004, seed=0, tilt_hz=4000.0):  # noqa: D401
    """Adds a quiet, slightly dark hiss bed underneath a sound."""
    hiss = butter_filter(white_noise(len(x) / SR, seed=seed), tilt_hz, btype="low")
    if len(hiss) < len(x):
        hiss = np.pad(hiss, (0, len(x) - len(hiss)))
    return x + hiss[: len(x)] * level


def lofi_chain(
    x,
    bits=11,
    decim_factor=2,
    lowpass=7000.0,
    drive=1.5,
    wobble_rate=1.1,
    wobble_depth=0.0035,
    hiss=0.0035,
    hiss_tilt=4000.0,
    post_lowpass=None,
    seed=0,
    highpass=None,
):
    """THE lo-fi kit's signature chain -- written once, used on every sound.

    Order mirrors a real dusty-sampler signal path:
      1. tape wobble (warped playback rate)
      2. optional high-pass (old machines had no low end either)
      3. low-pass (the 6-8 kHz ceiling of a 12-bit sampler)
      4. sample-rate decimation (aliasing crunch)
      5. bit reduction (quantization grit)
      6. soft-clip saturation (tape/preamp warmth)
      7. noise floor (hiss so nothing is ever digitally silent)

    Crucially this is a *finishing* chain: it can only dirty what it is given.
    The lo-fi kit feeds it fully-designed, punchy source drums for that reason
    -- running it on weak sources just yields quiet mud.
    """
    y = tape_wobble(x, rate=wobble_rate, depth=wobble_depth, seed=seed)
    if highpass:
        y = butter_filter(y, highpass, btype="high", order=2)
    y = butter_filter(y, lowpass, btype="low", order=4)
    y = decimate_hold(y, decim_factor)
    y = bitcrush(y, bits=bits)
    y = soft_clip(y, drive)
    if post_lowpass:
        y = butter_filter(y, post_lowpass, btype="low", order=2)
    y = noise_floor(y, level=hiss, seed=seed + 991, tilt_hz=hiss_tilt)
    return y


# ---------------------------------------------------------------------------
# Layout helpers
# ---------------------------------------------------------------------------

def place(dst, src, at_seconds, gain=1.0):
    """Mix `src` into `dst` starting at `at_seconds`, clipped to fit."""
    start = int(at_seconds * SR)
    if start >= len(dst):
        return dst
    end = min(start + len(src), len(dst))
    dst[start:end] += src[: end - start] * gain
    return dst


def layer(dur, *parts):
    """Sum layers of differing lengths into one buffer of `dur` seconds.

    `parts` are (signal, gain) tuples. Anything longer than the buffer is
    truncated; anything shorter is zero-padded. Keeps kit code readable.
    """
    out = np.zeros(n_samples(dur))
    for sig, gain in parts:
        k = min(len(sig), len(out))
        out[:k] += sig[:k] * gain
    return out


def dc_block(x):
    return x - np.mean(x) if len(x) else x


def normalize(x, peak=0.9):
    m = np.max(np.abs(x)) if len(x) else 1.0
    if m < 1e-9:
        return x
    return x / m * peak


def fade(x, fade_in_ms=1.0, fade_out_ms=6.0):
    """Short raised-cosine fades so a pad can never click on start or stop."""
    y = x.copy()
    n = len(y)
    ni = min(int(SR * fade_in_ms / 1000.0), n // 2)
    no = min(int(SR * fade_out_ms / 1000.0), n // 2)
    if ni > 1:
        y[:ni] *= 0.5 - 0.5 * np.cos(np.linspace(0, np.pi, ni))
    if no > 1:
        y[-no:] *= 0.5 + 0.5 * np.cos(np.linspace(0, np.pi, no))
    return y


def trim_tail(x, threshold_db=-72.0, min_ms=40.0):
    """Drops digital silence off the end so long buffers don't waste disk."""
    thr = 10.0 ** (threshold_db / 20.0) * max(np.max(np.abs(x)), 1e-9)
    idx = np.where(np.abs(x) > thr)[0]
    if len(idx) == 0:
        return x
    end = max(int(idx[-1]) + 1, n_samples(min_ms / 1000.0))
    return x[: min(end, len(x))]


def finalize(x, peak=PEAK_CEILING, fade_in_ms=0.6, fade_out_ms=6.0, trim=True,
             dc_hpf=None):
    """Final polish applied to every single sound in every kit.

    DC-block (optionally a real high-pass, which beats mean-subtraction for
    sounds with a strong low-frequency tail) -> trim silence -> fade in/out ->
    peak normalize with headroom. `peak` is clamped to PEAK_CEILING so nothing
    ever lands hotter than about -1 dBFS.
    """
    y = np.asarray(x, dtype=np.float64)
    y = butter_filter(y, dc_hpf, btype="high", order=2) if dc_hpf else dc_block(y)
    if dc_hpf:
        y = dc_block(y)
    if trim:
        y = trim_tail(y)
    y = fade(y, fade_in_ms=fade_in_ms, fade_out_ms=fade_out_ms)
    return normalize(y, min(peak, PEAK_CEILING))


def finalize_loop(x, peak=PEAK_CEILING):
    """Finalize for seamless loops: no fades (they would break the loop seam)."""
    y = dc_block(np.asarray(x, dtype=np.float64))
    return normalize(y, min(peak, PEAK_CEILING))


def circular_lowpass(x, cutoff, order=2):
    """Low-pass in the frequency domain, preserving periodicity (loops)."""
    spec = np.fft.rfft(x)
    freqs = np.fft.rfftfreq(len(x), 1.0 / SR)
    mag = 1.0 / np.sqrt(1.0 + (freqs / max(cutoff, 1.0)) ** (2 * order))
    return np.fft.irfft(spec * mag, n=len(x))


def circular_highpass(x, cutoff, order=2):
    spec = np.fft.rfft(x)
    freqs = np.fft.rfftfreq(len(x), 1.0 / SR)
    ratio = np.maximum(freqs, 1e-6) / max(cutoff, 1.0)
    mag = ratio ** order / np.sqrt(1.0 + ratio ** (2 * order))
    return np.fft.irfft(spec * mag, n=len(x))


# ---------------------------------------------------------------------------
# Measurement -- we cannot listen, so every sound gets measured instead
# ---------------------------------------------------------------------------

def db(x):
    return 20 * np.log10(max(float(x), 1e-12))


def peak_dbfs(x):
    return db(np.max(np.abs(x)) if len(x) else 0.0)


def rms_dbfs(x):
    return db(np.sqrt(np.mean(np.square(x))) if len(x) else 0.0)


def crest_db(x):
    return peak_dbfs(x) - rms_dbfs(x)


def spectral_centroid(x, sr=SR):
    """Brightness in Hz: the amplitude-weighted mean frequency.

    Sanity band per class -- kick 40-160, snare 500-2500, hats 4k-10k. A hat
    that measures 1.5 kHz is a thud; a kick that measures 900 Hz is a click
    with no body. Both are audible failures this number catches.
    """
    if len(x) < 64:
        return 0.0
    w = np.hanning(len(x))
    spec = np.abs(np.fft.rfft(x * w))
    freqs = np.fft.rfftfreq(len(x), 1.0 / sr)
    total = spec.sum()
    return float((spec * freqs).sum() / total) if total > 1e-12 else 0.0


def fundamental_hz(x, fmin=20.0, fmax=2000.0, sr=SR, skip_ms=60.0):
    """FFT fundamental with parabolic interpolation, measured on the sustain.

    The first tens of ms of a tuned drum are still moving in pitch, so the
    measurement skips them -- otherwise every 808 reads sharp. The skip is
    `skip_ms` or 15% of the sample, whichever is longer, so long sustained
    notes (808s) skip proportionally more of their pitch envelope than a
    short tom does.
    """
    skip = max(n_samples(skip_ms / 1000.0), int(0.15 * len(x)))
    start = min(skip, max(len(x) - 2048, 0))
    seg = x[start:]
    if len(seg) < 2048:
        seg = x
    if len(seg) < 256:
        return 0.0
    n = 1 << int(np.ceil(np.log2(len(seg) * 4)))
    spec = np.abs(np.fft.rfft(seg * np.hanning(len(seg)), n=n))
    freqs = np.fft.rfftfreq(n, 1.0 / sr)
    band = (freqs >= fmin) & (freqs <= fmax)
    if not band.any():
        return 0.0
    idx = np.argmax(np.where(band, spec, 0.0))
    if 0 < idx < len(spec) - 1:
        a, b, c = spec[idx - 1], spec[idx], spec[idx + 1]
        denom = a - 2 * b + c
        delta = 0.5 * (a - c) / denom if abs(denom) > 1e-12 else 0.0
    else:
        delta = 0.0
    return float((idx + delta) * sr / n)


def cents_error(measured, target):
    if measured <= 0 or target <= 0:
        return float("inf")
    return 1200.0 * np.log2(measured / target)


def dc_offset(x):
    return float(np.mean(x)) if len(x) else 0.0


def measure(x, sr=SR):
    """Full measurement dict for one rendered sound."""
    x = np.asarray(x, dtype=np.float64)
    return {
        "peak_db": peak_dbfs(x),
        "rms_db": rms_dbfs(x),
        "crest_db": crest_db(x),
        "centroid_hz": spectral_centroid(x, sr),
        "dc": dc_offset(x),
        "dur_s": len(x) / sr,
        "clipped": int(np.sum(np.abs(x) >= 0.9999)),
    }


# Expected spectral centroid band (Hz) per instrument class, used by
# tools/verify_kits.py. Deliberately generous at the edges -- these are
# "something is wrong" tripwires, not taste police.
CENTROID_BANDS = {
    "kick": (35, 260),
    "sub": (30, 320),
    "bass": (60, 1100),
    "snare": (400, 3200),
    "clap": (700, 4200),
    "rim": (700, 6000),
    "tom": (90, 1400),
    "hat": (3500, 12000),
    "cymbal": (2500, 11000),
    "perc": (200, 12000),
    "tonal": (60, 6000),
    "fx": (60, 14000),
}


def classify(filename):
    """Maps a sample filename to a measurement class (best-effort)."""
    n = filename.lower()
    if n.startswith("808") or "sub" in n:
        return "sub"
    if "bass" in n or "upright" in n:
        return "bass"
    if "kick" in n:
        return "kick"
    if "snare" in n:
        return "snare"
    if "clap" in n or "snap" in n:
        return "clap"
    if "rim" in n or "stick" in n:
        return "rim"
    if "tom" in n or "conga" in n or "bongo" in n:
        return "tom"
    if "hat" in n:
        return "hat"
    if "crash" in n or "ride" in n or "cymbal" in n:
        return "cymbal"
    if any(k in n for k in ("shaker", "tamb", "maraca", "cowbell", "clave", "wood",
                            "triangle", "perc", "tick")):
        return "perc"
    if any(k in n for k in ("rhodes", "bell", "pluck", "stab", "pad", "vox", "mallet",
                            "guitar", "keys", "chord")):
        return "tonal"
    return "fx"


# ---------------------------------------------------------------------------
# Output: WAV files and kit.json
# ---------------------------------------------------------------------------

def samples_dir(kit_dir_name):
    path = os.path.join(KITS_ROOT, kit_dir_name, "samples")
    os.makedirs(path, exist_ok=True)
    return path


def save_wav(kit_dir_name, filename, x):
    """Writes 16-bit PCM mono WAV into assets/kits/<kit>/samples/."""
    from scipy.io import wavfile

    x = np.clip(np.asarray(x, dtype=np.float64), -1.0, 1.0)
    data = (x * 32767.0).astype(np.int16)
    path = os.path.join(samples_dir(kit_dir_name), filename)
    wavfile.write(path, SR, data)
    return path, len(data) / SR


def render_all(kit_dir_name, sounds, verbose=True, prune=True):
    """Renders a list of (filename, callable) pairs into a kit's samples dir.

    `prune` deletes any stale WAV in the directory that this run did not write,
    which is what keeps a rename from leaving an orphan file behind (and the
    asset bundle from silently growing).
    """
    total = 0.0
    written = set()
    for filename, fn in sounds:
        path, dur = save_wav(kit_dir_name, filename, fn())
        written.add(filename)
        total += dur
        if verbose:
            print(f"  wrote {os.path.basename(path):<26} {dur:5.3f}s")
    if prune:
        d = samples_dir(kit_dir_name)
        for stale in sorted(set(os.listdir(d)) - written):
            if stale.lower().endswith(".wav"):
                os.remove(os.path.join(d, stale))
                if verbose:
                    print(f"  removed stale {stale}")
    if verbose:
        print(f"  -- {len(sounds)} samples, {total:.2f}s of audio total")
    return total


DEFAULT_KNOB_CCS = [70, 71, 72, 73, 74, 75]


def build_knobs(labels):
    """6 knob defs. Knob 1 is always master volume, knob 2 always pitch/speed
    (that's what the app's audio engine actually reads); knobs 3-6 are
    assignable and only carry a kit-flavoured label for now."""
    assert len(labels) == 6, "a kit needs exactly 6 knob labels"
    knobs = []
    for i, label in enumerate(labels):
        if i == 0:
            function = "masterVolume"
        elif i == 1:
            function = "pitchSpeed"
        else:
            function = "assignable"
        knobs.append(
            {"index": i + 1, "label": label, "cc": DEFAULT_KNOB_CCS[i], "function": function}
        )
    return knobs


def _pad_entry(pad_id, note, sample, volume, choke):
    return {
        "padId": pad_id,
        "note": note,
        "sample": None if sample is None else f"samples/{sample}",
        "volume": volume,
        "chokeGroup": choke,
    }


# General MIDI drum map for MPD218 factory bank A (notes 36-51). Bank A entry
# `i` in every kit MUST be the role listed here -- that is what makes PadForge
# kits interchangeable with GM drum parts from any other gear, and what puts
# kick/rim/snare/clap on the hardware's bottom pad row (pads 1-4 = 36-39).
GM_BANK_A_ROLES = [
    (36, "Kick"),
    (37, "Rimshot / sidestick"),
    (38, "Snare"),
    (39, "Clap"),
    (40, "Snare 2 (alt / layered)"),
    (41, "Low tom"),
    (42, "Closed hat"),
    (43, "Low tom 2"),
    (44, "Pedal / tight hat"),
    (45, "Mid tom"),
    (46, "Open hat"),
    (47, "Mid tom 2"),
    (48, "Hi tom"),
    (49, "Crash"),
    (50, "Hi tom 2"),
    (51, "Ride"),
]

# Every kit uses the same choke-group numbering so muscle memory transfers.
CHOKE_HAT = 1       # closed / pedal / open hat -- one physical hi-hat
CHOKE_CYMBAL = 2    # crash swells / reverse cymbals
CHOKE_PERC = 3      # hand percussion (one pair of hands)
CHOKE_FX = 4        # risers / downlifters / sweeps
CHOKE_MONO_BASS = 5  # 808 / bass notes -- a bassline is monophonic
CHOKE_CHORD = 6      # chord stabs -- two hands play one chord at a time
CHOKE_TEXTURE = 7    # looping ambience beds -- only one bed at a time


def build_pads(bank_a, bank_b, bank_c=()):
    """Builds all 48 pad entries.

    `bank_a` / `bank_b` / `bank_c` are lists of (filename, volume, chokeGroup)
    tuples, up to 16 each.

    MPD218 factory notes: bank A = 36-51, B = 52-67, C = 68-83, and padId A1
    is the hardware's BOTTOM-LEFT pad, so A1..A16 ascend 36..51.
    """
    pads = []
    banks = [("A", bank_a), ("B", bank_b), ("C", list(bank_c))]
    for bank_index, (bank, entries) in enumerate(banks):
        assert len(entries) <= 16, f"bank {bank} has more than 16 pads"
        for i in range(16):
            note = 36 + bank_index * 16 + i
            if i < len(entries):
                sample, volume, choke = entries[i]
            else:
                sample, volume, choke = None, 1.0, None
            pads.append(_pad_entry(f"{bank}{i + 1}", note, sample, volume, choke))
    return pads


def assert_gm_layout(bank_a, kit_dir_name):
    """Fails loudly if bank A is not 16 entries in General MIDI order."""
    if len(bank_a) != 16:
        raise SystemExit(
            f"{kit_dir_name}: bank A has {len(bank_a)} entries, GM map needs all 16 "
            f"(notes 36-51) filled."
        )
    hats = [bank_a[i] for i in (6, 8, 10)]  # notes 42, 44, 46
    groups = {h[2] for h in hats}
    if groups != {CHOKE_HAT}:
        raise SystemExit(
            f"{kit_dir_name}: closed/pedal/open hat (notes 42/44/46) must all share "
            f"choke group {CHOKE_HAT}, got {groups}."
        )


def write_kit_json(kit_dir_name, name, bank_a, bank_b, knob_labels, bank_c=()):
    """Writes assets/kits/<kit>/kit.json in the exact schema the app reads.

    Schema is unchanged from the hand-written original: schemaVersion, name,
    48 pads (padId, note, sample, volume, chokeGroup) and 6 knobs.
    """
    assert_gm_layout(bank_a, kit_dir_name)
    pads = build_pads(bank_a, bank_b, bank_c)
    knobs = build_knobs(knob_labels)

    sample_col = max((len(json.dumps(p["sample"])) for p in pads), default=6)
    lines = ["{", '  "schemaVersion": 1,', f'  "name": {json.dumps(name)},', '  "pads": [']
    for i, pad in enumerate(pads):
        if i > 0 and i % 16 == 0:
            lines.append("")
        comma = "," if i < len(pads) - 1 else ""
        lines.append(
            '    {{ "padId": {:<6} "note": {:<4} "sample": {:<{w}} "volume": {:<6} "chokeGroup": {} }}{}'.format(
                json.dumps(pad["padId"]) + ",",
                str(pad["note"]) + ",",
                json.dumps(pad["sample"]) + ",",
                json.dumps(pad["volume"]) + ",",
                json.dumps(pad["chokeGroup"]),
                comma,
                w=sample_col + 1,
            )
        )
    lines.append("  ],")
    lines.append('  "knobs": [')
    for i, knob in enumerate(knobs):
        comma = "," if i < len(knobs) - 1 else ""
        lines.append(
            '    {{ "index": {}, "label": {}, "cc": {}, "function": {} }}{}'.format(
                knob["index"], json.dumps(knob["label"]), knob["cc"],
                json.dumps(knob["function"]), comma
            )
        )
    lines.append("  ]")
    lines.append("}")

    path = os.path.join(KITS_ROOT, kit_dir_name, "kit.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    # Sanity check: the file we just wrote must be valid JSON and every sample
    # it references must exist on disk.
    with open(path, encoding="utf-8") as fh:
        parsed = json.load(fh)
    missing = [
        p["sample"]
        for p in parsed["pads"]
        if p["sample"] and not os.path.exists(os.path.join(KITS_ROOT, kit_dir_name, p["sample"]))
    ]
    if missing:
        raise SystemExit(f"{kit_dir_name}: kit.json references missing samples: {missing}")
    print(f"  wrote {path}")
    return path
